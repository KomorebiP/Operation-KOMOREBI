# Validated fixed-spin chemistry replay

Komorebi P. - Reviewed edition, 13 November 2026

Start with reading-edition/reproduce.md for environment setup, all commands, input definitions and failure interpretation. Run `python verify_public_replay.py` to check the included hashes and saved certificates with the standard library. The verifier does not rerun the scientific computations.

Three completed bounded runs are under validation/exact-001, validation/molecular-001 and validation/extensions-001. Earlier results remain under chemistry_stage14/exact-audit-001 and molecular-audit-001 with their historical identities.

FIXTURE_VIEW.json distinguishes the original full source-container hash from this selected-array view. FIXTURE_PROVENANCE.json and molecular_fixture_generator.py identify geometry, units and basis. The view preserves the original h1, eri and ground_energy array bytes. Different numerical environments must measure and validate their own action errors.

This bundle verifies a declared nine-state arithmetic model and conditional written extensions. It does not certify full-H10 physical approximation error, world priority or a runtime advantage. The separate original Stage14_Fixed_Spin_Recovery.zip remains unchanged.
