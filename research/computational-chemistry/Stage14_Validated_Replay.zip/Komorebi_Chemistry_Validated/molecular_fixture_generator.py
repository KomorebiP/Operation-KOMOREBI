"""Generate exact-in-basis molecular electron-removal test fixtures with PySCF."""

import argparse
import hashlib
import json
import math
from pathlib import Path
import platform
import time

import h5py
import numpy as np
from pyscf import ao2mo, fci, gto, lib, scf
import pyscf
from scipy import linalg, sparse
import scipy


def geometries():
    water = [("O", (0.0, 0.0, 0.0)), ("H", (0.0, 0.757, 0.587)),
             ("H", (0.0, -0.757, 0.587))]
    hydrogen = {
        f"h{size}_{spacing:.1f}": [("H", (0.0, 0.0, index * spacing)) for index in range(size)]
        for size, spacing in [(2, 1.4), (6, 1.4), (6, 2.2), (8, 1.4), (8, 2.2), (10, 1.4)]
    }
    return hydrogen | {"water": water}


def build_action(h1, eri, n_orbitals, sector):
    h2e = fci.direct_spin1.absorb_h1e(h1, eri, n_orbitals, sector, fac=0.5)
    links = tuple(fci.cistring.gen_linkstr_index_trilidx(range(n_orbitals), n_electrons)
                  for n_electrons in sector)

    def action(vector):
        return np.asarray(fci.direct_spin1.contract_2e(h2e, vector, n_orbitals, sector, links)).ravel()

    return action


def dense_hamiltonian(h1, eri, n_orbitals, sector):
    dimension = math.comb(n_orbitals, sector[0]) * math.comb(n_orbitals, sector[1])
    order, matrix = fci.direct_spin1.pspace(h1, eri, n_orbitals, sector, np=dimension)
    if not np.array_equal(order, np.arange(dimension)):
        raise ValueError("Determinant order disagrees with the FCI contraction order")
    return matrix


def build_fixture(name, atoms, output, store_eigenvectors=False):
    started = time.perf_counter()
    molecule = gto.M(atom=atoms, unit="Angstrom", basis="sto-3g", charge=0, spin=0, verbose=0)
    mean_field = scf.RHF(molecule)
    mean_field.conv_tol = 1e-12
    mean_field.kernel()
    if not mean_field.converged:
        raise ValueError(f"RHF orbital generation failed for {name}")

    n_orbitals = mean_field.mo_coeff.shape[1]
    s_eig, s_vec = linalg.eigh(mean_field.get_ovlp())
    symmetric_orthogonal_ao = (s_vec / np.sqrt(s_eig)) @ s_vec.T
    ao_to_mo = mean_field.mo_coeff.T @ mean_field.get_ovlp() @ symmetric_orthogonal_ao
    ao_orthogonality = np.linalg.norm(ao_to_mo.T @ ao_to_mo - np.eye(n_orbitals), ord=2)
    if ao_orthogonality > 1e-11:
        raise ValueError("Löwdin orbitals failed the orthogonality check")

    coefficients = mean_field.mo_coeff
    h1 = coefficients.T @ mean_field.get_hcore() @ coefficients
    eri = ao2mo.kernel(molecule, coefficients)
    ground_sector = molecule.nelec
    ion_sector = (ground_sector[0] - 1, ground_sector[1])
    ground_action = build_action(h1, eri, n_orbitals, ground_sector)
    ion_action = build_action(h1, eri, n_orbitals, ion_sector)
    ground_dimension = math.comb(n_orbitals, ground_sector[0]) * math.comb(n_orbitals, ground_sector[1])

    if ground_dimension <= 5000:
        ground_matrix = dense_hamiltonian(h1, eri, n_orbitals, ground_sector)
        ground_eigenvalues, ground_vectors = linalg.eigh(ground_matrix, subset_by_index=(0, 1))
        ground_energy = ground_eigenvalues[0]
        ground_state = ground_vectors[:, 0]
        ground_gap = float(ground_eigenvalues[1] - ground_energy)
        ground_method = "dense Hermitian eigensolver (two lowest states)"
    else:
        operator = sparse.linalg.LinearOperator((ground_dimension, ground_dimension), matvec=ground_action,
                                                dtype=np.dtype(float))
        start_vector = np.random.default_rng(54).normal(size=ground_dimension)
        ground_eigenvalues, ground_vectors = sparse.linalg.eigsh(
            operator, k=2, which="SA", tol=1e-11, ncv=32, maxiter=500, v0=start_vector
        )
        ground_energy = ground_eigenvalues[0]
        ground_state = ground_vectors[:, 0]
        ground_gap = float(ground_eigenvalues[1] - ground_energy)
        ground_method = "SciPy ARPACK Hermitian FCI action (two smallest converged Ritz roots)"

    ground_residual = np.linalg.norm(ground_action(ground_state) - ground_energy * ground_state)
    ground_spin_square, _ = fci.spin_op.spin_square0(ground_state, n_orbitals, ground_sector)
    if ground_residual > 5e-8 or abs(ground_spin_square) > 1e-7:
        raise ValueError(f"FCI ground checks failed for {name}: {ground_residual}, {ground_spin_square}")

    # PySCF uses alpha determinant rows and beta determinant columns. The
    # source for Löwdin AO j is sum_p <MO_p|AO_j^Löwdin> a_(p,alpha)|Psi_N>.
    mo_sources = np.column_stack([
        fci.addons.des_a(ground_state, n_orbitals, ground_sector, orbital).ravel()
        for orbital in range(n_orbitals)
    ])
    sources = mo_sources @ ao_to_mo
    ao_labels = molecule.ao_labels()
    source_index = next(index for index, label in enumerate(ao_labels) if "2px" in label) if name == "water" else 0
    source = sources[:, source_index].copy()
    alpha_rdm, _ = fci.direct_spin1.make_rdm1s(ground_state, n_orbitals, ground_sector)
    source_gram_error = np.linalg.norm(sources.T @ sources - ao_to_mo.T @ alpha_rdm @ ao_to_mo)
    source_trace_error = abs(np.linalg.norm(sources, ord="fro") ** 2 - ground_sector[0])
    if max(source_gram_error, source_trace_error) > 1e-10:
        raise ValueError("Local annihilation sources failed the one-body density matrix checks")

    output_data = dict(source=source, sources=sources, source_index=source_index,
                       ground_energy=ground_energy, ground_state=ground_state,
                       ground_sector=ground_sector, ion_sector=ion_sector, h1=h1, eri=eri,
                       n_orbitals=n_orbitals, nuclear_energy=molecule.energy_nuc(),
                       ao_labels=np.array(ao_labels), ao_to_mo=ao_to_mo)
    reference_info = {}
    ion_dimension = source.size
    if ion_dimension <= 5000:
        h_ion = dense_hamiltonian(h1, eri, n_orbitals, ion_sector)
        # Nuclear repulsion cancels between sectors at a fixed geometry.
        h_poles = -h_ion
        h_poles.flat[::ion_dimension + 1] += ground_energy
        rng = np.random.default_rng(81)
        action_error = max(
            np.linalg.norm(h_poles @ test - (ground_energy * test - ion_action(test)))
            for test in [source] + [rng.normal(size=ion_dimension) / np.sqrt(ion_dimension)
                                   for _ in range(3)]
        )
        if action_error > 1e-10:
            raise ValueError(f"Dense and matrix-free ion Hamiltonians disagree: {action_error}")

        eigvals, eigvecs = linalg.eigh(h_poles, driver="evd", check_finite=False)
        pole_amplitudes = eigvecs.T @ sources
        pole_weights = abs(pole_amplitudes[:, source_index]) ** 2
        moment_errors = [
            abs(pole_weights.sum() - source @ source),
            abs(pole_weights @ eigvals - source @ h_poles @ source),
            abs(pole_weights @ (eigvals ** 2) - np.linalg.norm(h_poles @ source) ** 2),
        ]
        eigenpairs_sample = np.unique(np.linspace(0, ion_dimension - 1, 12, dtype=int))
        sample_eigenpair_residual = np.linalg.norm(
            h_poles @ eigvecs[:, eigenpairs_sample]
            - eigvecs[:, eigenpairs_sample] * eigvals[eigenpairs_sample], ord=2
        )
        if max(moment_errors) > 1e-10 or sample_eigenpair_residual > 1e-9:
            raise ValueError("Dense pole decomposition failed moment/eigenpair checks")
        output_data.update(hamiltonian=h_poles, eigvals=eigvals, pole_amplitudes=pole_amplitudes,
                           pole_weights=pole_weights)
        if store_eigenvectors:
            output_data["eigvecs"] = eigvecs

        # This check compares the direct resolvent to the pole sum for the
        # smallest cases. The largest dense cases use moments and eigenpairs.
        direct_resolvent_errors = []
        if ion_dimension <= 500:
            for z in (-1.8 + 0.07j, -0.6 + 0.025j, -0.2 + 0.05j):
                direct = source @ linalg.solve(z * np.eye(ion_dimension) - h_poles, source, assume_a="gen")
                direct_resolvent_errors.append(float(abs(direct - np.sum(pole_weights / (z - eigvals)))))
        if max(direct_resolvent_errors, default=0.0) > 1e-10:
            raise ValueError(f"The pole sum did not match the directly solved resolvent: {direct_resolvent_errors}")
        reference_info = {
            "dense_ion_action_error": float(action_error),
            "pole_moment_errors_degree_0_1_2": [float(error) for error in moment_errors],
            "sample_eigenpair_residual": float(sample_eigenpair_residual),
            "direct_resolvent_errors": direct_resolvent_errors,
            "brightest_poles": [
                {"energy_hartree": float(eigvals[i]), "weight": float(pole_weights[i])}
                for i in np.argsort(pole_weights)[-12:][::-1] if pole_weights[i] > 1e-15
            ],
        }

    destination = output / f"{name}.npz"
    np.savez_compressed(destination, **output_data)
    with destination.open("rb") as fixture_file:
        fixture_hash = hashlib.file_digest(fixture_file, "sha256").hexdigest()
    return {
        "geometry_angstrom": atoms, "basis": "sto-3g", "ground_method": ground_method,
        "ground_sector": ground_sector, "ion_sector": ion_sector, "ground_dimension": ground_dimension,
        "ion_dimension": ion_dimension, "ground_electronic_energy_hartree": float(ground_energy),
        "nuclear_repulsion_hartree": molecule.energy_nuc(), "ground_gap_hartree": ground_gap,
        "ground_residual": float(ground_residual), "ground_spin_square": float(ground_spin_square),
        "orthogonality_error": float(ao_orthogonality), "source_gram_error": float(source_gram_error),
        "source_trace_error": float(source_trace_error), "source_label": ao_labels[source_index],
        "source_weight": float(source @ source), "path": destination.name,
        "fixture_sha256": fixture_hash,
        "fixture_bytes": destination.stat().st_size, "runtime_seconds": time.perf_counter() - started,
    } | reference_info


def main():
    candidates = geometries()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cases", nargs="+", choices=list(candidates), default=["h2_1.4", "h6_1.4", "water"])
    parser.add_argument("--output", type=Path, default=Path(__file__).with_suffix(""))
    parser.add_argument("--store-eigenvectors", action="store_true")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    lib.num_threads(1)
    metadata = {"pyscf": pyscf.__version__, "h5py": h5py.__version__, "numpy": np.__version__,
                "scipy": scipy.__version__, "python": platform.python_version(), "cases": {}}
    for case in args.cases:
        result = build_fixture(case, candidates[case], args.output, args.store_eigenvectors)
        metadata["cases"][case] = result
        (args.output / "metadata.json").write_text(json.dumps(metadata, indent=2) + "\n")
        print(f"{case}: neutral dimension {result['ground_dimension']}, ion dimension {result['ion_dimension']}, "
              f"source weight {result['source_weight']:.12f}, generated in {result['runtime_seconds']:.2f} s", flush=True)


if __name__ == "__main__":
    main()
