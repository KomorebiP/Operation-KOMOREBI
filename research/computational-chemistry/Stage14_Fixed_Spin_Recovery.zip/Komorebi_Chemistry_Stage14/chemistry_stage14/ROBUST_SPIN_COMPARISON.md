# Robust separation beyond total-spin information

Komorebi P. 2026-11-13. Three spatial orbitals, N_alpha=2,N_beta=1.

Use the normal form of NORMAL_FORM.md with scalar0, K=T1/8 and C=I5/64.
Call the resulting sector operator H0 and take source b=e0 in determinant
order. It is a pure doublet: S^2 b=(3/4)b. C is positive definite, so H0 has
an explicit positive-integral representative. The commutator norm bound
gives ||H0||_2<=1/4+25/64=41/64: the five T_a have squared eigenvalue
diameters4,9,4,4,4. Let Y0=H0V for the three fixed probes.

At energy0 and eta1 the exact structured response is

\[
 g_0=-{107\over1157}-{1146i\over1157}.
\]

Allow aggregate RAW action error epsilon=1/4096 and real source error
delta=1/8192. The recovery theorem encloses every compatible response by

\[
 |g-g_0|\le {\sqrt{20}\over4096}
               +{16385\over67108864}
   \approx0.00133599.\tag{1}
\]

All compatible H also satisfy C>=0, since ||C-C0||_2<=r_H/4<1/64.
They obey the spectral interval[-1,1], since41/64+r_H<1. Thus these
extra promises do not invalidate the enclosure.

For a stronger comparator than arbitrary symmetric matrices, retain the
EXACT total-spin operator as well as the same cache and spectral interval.
Let

\[
 u=(5/8,0,-1/8,-3/8,1/8,0,1/4,0,0)^T,\quad
 H_1=H_0+{uu^T\over4u^Tu}.
\]

Directly, V^Tu=0,u^Tu=5/8, and u is orthogonal to the quartet vector
q=(0,0,1,0,-1,0,1,0,0)^T. Since S^2=(3/4)I+qq^T, H1 commutes with
S^2 and H1V=H0V. Also ||H1||_2<=57/64<1. Its exact response at the SAME
source/energy/broadening is

\[
 g_1=-{9186358980826208\over40332559606654033}
       -i{37472614526567424\over40332559606654033}.
\]

Its pi-scaled LDOS differs from that of H0 by

\[
 {2865298301987012250\over46664771464898716181}
 \approx0.06140174,
\]

which is strictly greater than the radius in(1), verified by exact rational
comparison after isolating/squaring the one positive square root. Therefore
integral-symmetry structure gives a strictly smaller response set even AFTER
total spin, spin projection, the full three-query cache and a common spectral
interval are supplied to the comparator.

H1 is not in the integral-symmetry family, by its exact injectivity and the
same-cache/nonzero-perturbation facts. The example is an algebraic positive-
integral model, with no proof that its tensor is a Coulomb integral tensor of
actual orbitals. The error caps are assumptions here, not a neutral-state
error certificate. This proves information separation, not runtime superiority
over an observable-specific Krylov method.
