# Source comparison and bounded attribution

Checked2026-11-13. Same-researcher source check and second search pass; no
independent review. No fetched full-text copies are bundled. The proofs use
internal CAR and finite-dimensional linear algebra; these references check
conventions and overlap, not an unavailable load-bearing theorem.

## General action-query recovery

Diana Halikias and Alex Townsend, *Structured matrix recovery from matrix-vector
products*, [arXiv:2212.09841v2](https://arxiv.org/html/2212.09841v2),
29 May2023; *Numerical Linear Algebra with Applications*31(1),e2531(2024),
[DOI10.1002/nla.2531](https://doi.org/10.1002/nla.2531).
The official versioned full text, Definition2, Lemma3/equation(1), and the
following generic-probe discussion were read. Its p-parameter,N-state lower
bound specializes to ceil(21/9)=3 after our sector dimension proof. This
part is a **formal corollary not stated** for the present family. Solving
the action coefficient system and using least squares are known methods.
The inspected paper does not give our fixed nine-state family, the displayed
three-probe design, its rational frame certificate or the spin-preserving
response witness: **partial or adjacent result only** for that construction.

The Cornell primary record for Diana Halikias's2025 dissertation,
[*Structured matrix recovery and approximation from matrix-vector products*](https://hdl.handle.net/1813/117505),
was discovered and its metadata/abstract inspected. Its full269-page text was
not reviewed. This is an explicit remaining overlap-check target, not evidence
that the dissertation omits the finite construction.

## Molecular operator and frozen-core conventions

PySCF developers, live official source documentation, unversioned web snapshot
checked on the date above; no release-specific source hash retained:

- [pyscf.fci.direct_spin1.contract_2e](https://pyscf.org/_modules/pyscf/fci/direct_spin1.html): the documented E-product identity contains the delta_qr E_ps contraction. The API's absorbed tensor differs from the physical ERIs; its energy path calls absorb_h1e with factor1/2. We reconstruct the physical operator directly and never pass raw g as its absorbed tensor.
- [pyscf.ao2mo.addons.restore](https://pyscf.org/_modules/pyscf/ao2mo/addons.html): chemists' notation and fourfold/eightfold permutation storage agree with the pair-packed fixture and our explicit completion.
- [pyscf.mcscf.casci.h1e_for_cas](https://pyscf.org/_modules/pyscf/mcscf/casci.html): doubled closed-shell core density gives a core potential added to the active one-body matrix, and a separate core energy. We omit the nuclear constant consistently with the fixture's electronic energies.

Authentication and formula extraction were performed on the official module
sources. The translation to this project's index order and factors is
**verified** by direct internal exact matrix constructions. Future website
changes are outside this snapshot. Positivity of real Coulomb ERIs follows
from their nonnegative Coulomb self-energy quadratic form; the converse
Coulomb-realizability implication is not used or proved.

## Different meaning of tomography

Artur Czerwinski, *Minimal number of observables for quantum tomography of
systems with evolution given by double commutators*,
[DOI10.1007/s40509-017-0101-6](https://doi.org/10.1007/s40509-017-0101-6),
published2017. Publisher full text, introductory problem definition,
Theorem1 and equations(5)-(9) were inspected. It reconstructs an unknown
initial density matrix under a known generator from scalar expectation
measurements over time. Our unknown is the generator/operator and our data
are complete action vectors. Its result is **inapplicable** as a theorem
proving our three-query claim, and **partial or adjacent result only** as
background for double-commutator operator notation. Double commutators,
vectorization, particle-hole duality and Choi reshuffling are established
tools; none is claimed as a new general device here.

## Search scope and unresolved priority

English web search and arXiv/official-source discovery were used with these
exact query families, first from chemistry and then from operator recovery:

`"Hamiltonian" "three electrons" "three orbitals" "matrix" "21"`;
`"Hamiltonian recovery" "double commutator"`;
`"matrix recovery" "spin" "matrix-vector" molecular Hamiltonian`;
`"particle hole" "Choi" "Hamiltonian" reconstruction`;
`"three orbitals" "Hamiltonian" "21" integrals spin`;
`"three electrons" "Hamiltonian" "double commutator"`;
`"Jamiołkowski" "double commutator" generators real symmetric`;
`"three orbitals" "matrix-vector" recovery`;
`"three-electron" "21" "integrals" Hamiltonian`;
`"three orbitals" "Hamiltonian reconstruction"`;
`"three orbitals" "double commutator"`;
`"three electrons" "operator space" Hamiltonian`.

The prior stage's structured-recovery source and its dimension-count/generic-
probe references supplied a second search strategy; the double-commutator
tomography source supplied a neighboring-field comparison. Papers by authors
named Choi are not evidence about the Choi isomorphism without checking their
content. Search snippets and irrelevant results were not treated as theorem
evidence. There was no comprehensive citation-forward search, MathSciNet,
zbMATH, chemistry indexing database or exhaustive review of unitary-group
and active-space Hamiltonian inverse problems. The search horizon is the
material accessible on2026-11-13; no global literature coverage is claimed.

The exact21-parameter normal form, explicit minimum-count probe construction,
quantitative certificate and spin-preserving separation are concrete candidate
contributions. **Originality, priority and publication significance remain
unestablished.** The finite-family phase is closed on correctness while the
priority route remains open.
