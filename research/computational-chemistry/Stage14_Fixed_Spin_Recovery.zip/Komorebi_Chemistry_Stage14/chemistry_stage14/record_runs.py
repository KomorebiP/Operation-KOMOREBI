"""Freeze versioned contracts and launch only explicitly named bounded audits."""
import argparse
import json
from pathlib import Path
import platform
import subprocess
import sys
import numpy
import sympy

ROOT=Path(__file__).resolve().parents[1]


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--runner',type=Path,required=True);parser.add_argument('--kind',choices=['exact','molecular'],required=True);parser.add_argument('--run',default='001');args=parser.parse_args()
    common=['molecular_model.py','normal_model.py','sector_recovery.py','recover_sector_cache.py','probes.json','NORMAL_FORM.md','RECOVERY_THEOREM.md']
    if args.kind=='exact':
        script='audit_sector.py';files=common+['audit_sector.py','example_cache.json','ROBUST_SPIN_COMPARISON.md']
        extras=['chemistry_stage12/hodge_model.py'];results=['checks.json','example_certificate.json'];timeout='240'
        assertion='All27 integral generators cross-checked against full64 Jordan-Wigner and E-product constructions;9 hole identities,21 Choi and h/g representatives,6 gauge identities, spin, exact21-rank three-probe map, exact positive frame certificate, decoder and CLI noise/positivity cases, same-cache spin-preserving response witness'
    else:
        script='qualify_frozen_core.py';files=common+[script,'FROZEN_CORE_CONTRACT.md'];extras=['chemistry_checkpoint/molecular_fixtures/h10_1.4.npz']
        results=['molecular_cache.json','molecular_certificate.json','molecular_reference.json','qualification.json'];timeout='300'
        assertion='For one explicitly symmetry-completed H10-derived frozen-core9-state projection, compare full ladder projection with exact frozen-core formula; verify exact integral positivity and structured reconstruction; measure all binary64 three-action error exactly and compare exact rational response with the returned certificate at eta1/100'
    inputs=['chemistry_stage14/'+name for name in files]+extras+['chemistry_stage13/'+name for name in ['recover_cache.py','closed_decoder.py']]
    folder=f'chemistry_stage14/{args.kind}-audit-{args.run}'
    cp=ROOT/f'chemistry_stage14/{args.kind}-audit-{args.run}-contract.json'
    if cp.exists():raise FileExistsError(cp)
    contract={'claim_id':'C_STAGE14_'+args.kind.upper(),'mathematics':{'assertion_tested':assertion,
        'coefficient_domain':'Exact integer/rational matrices, finite binary64 interpreted as exact dyadics; outward rational square-root bounds',
        'conventions':'Three spatial orbitals, active2alpha1beta,9 determinant states, spin-free h and chemists eightfold g, raw3-probe V norms sqrt3',
        'inputs':inputs,'bounds':{'sector_dimension':9,'operator_dimension':21,'queries':3,'square_root_bits':80},
        'non_claims':['No global novelty claim','No original full H10 response certificate','No actual Coulomb-realizability converse','No exact sharp frame constant or runtime advantage']},
        'execution_artifacts':inputs,'software':[{'name':name,'version':version} for name,version in [('Python',platform.python_version()),('NumPy',numpy.__version__),('SymPy',sympy.__version__)]],
        'randomness':{'used':False}}
    cp.write_text(json.dumps(contract,indent=2)+'\n')
    argv=[sys.executable,str(args.runner),'--root',str(ROOT),'--contract',str(cp),'--output',folder,'--timeout',timeout,'--max-output-bytes','1048576','--max-threads','1']
    for path in inputs:argv.extend(['--input',path])
    for name in results:argv.extend(['--result',folder+'/'+name])
    argv.extend(['--',sys.executable,'chemistry_stage14/'+script,'--output',folder])
    subprocess.run(argv,cwd=ROOT,check=True)


if __name__=='__main__':main()
