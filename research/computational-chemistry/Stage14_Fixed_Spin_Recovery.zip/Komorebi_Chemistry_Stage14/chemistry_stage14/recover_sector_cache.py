"""Exact conditional recovery for the fixed-spin three-orbital sector."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import sympy as S
from sector_recovery import setup,decode,unpack,integral_representative,is_psd

sys.path.append(str(Path(__file__).resolve().parents[1]/"chemistry_stage13"))
from recover_cache import rational,sqrt_bounds


def recover(data):
    rows=data["action_matrix"]
    if len(rows)!=9 or any(len(row)!=3 for row in rows):raise ValueError("Need9x3 action matrix")
    Y=S.Matrix([[rational(x) for x in row] for row in rows])
    source=data["b_hat"]
    if len(source)!=9:raise ValueError("Need length9 source")
    b=S.Matrix([rational(x) for x in source]);epsilon=rational(data["raw_error_radius"])
    delta=rational(data.get("source_radius","0"));energy=rational(data.get("energy","0"));eta=rational(data.get("eta","1"))
    if epsilon<0 or delta<0 or eta<=0:raise ValueError("Invalid radius or broadening")
    model=setup();Hhat,theta=decode(model,Y);residual=Y-Hhat*model["V"]
    d2=sum(x*x for x in residual);consistent=bool(d2<=epsilon**2)
    scalar,K,C=unpack(model,theta);h,g=integral_representative(model,theta)
    pairs=[(0,0),(0,1),(0,2),(1,1),(1,2),(2,2)]
    result={"method":"CHEM-STAGE14 three-probe fixed-spin integral-symmetry recovery",
        "class":"3 spatial orbitals, N_alpha=2 N_beta=1, real spin-free h/eightfold ERIs",
        "raw_probe_norm_squared":"3","frame_raw_lower_bound":"1/20",
        "full_linear_consistent":consistent,"raw_error_radius":str(epsilon),"source_radius":str(delta),
        "least_squares_residual_squared":str(d2),"theta":[str(x) for x in theta],
        "estimated_H":[[str(x) for x in row] for row in Hhat.tolist()],
        "normal_C":[[str(x) for x in row] for row in C.tolist()],
        "positive_integral_estimate":is_psd(C),
        "integral_representative":{"h":[[str(x) for x in row] for row in h.tolist()],
            "eri_pair_order":[list(pair) for pair in pairs],
            "eri_pair_matrix":[[str(g[I+J]) for J in pairs] for I in pairs]},
        "scope":"Conditional on supplied data/source bounds; PSD integral representation does not establish Coulomb realizability"}
    if not consistent:
        result["positive_integral_feasibility"]=False
        return result
    radius2=20*(epsilon**2-d2);_,rhi=sqrt_bounds(radius2)
    b2=sum(x*x for x in b);_,bhi=sqrt_bounds(b2)
    response=S.simplify((b.T*((energy+S.I*eta)*S.eye(9)-Hhat).inv(method="DM")*b)[0])
    real=S.simplify(S.re(response));imag=S.simplify(S.im(response))
    response_radius=b2*rhi/eta**2+delta*(2*bhi+delta)/eta
    all_positive=is_psd(C-rhi*S.eye(5)/4)
    feasibility=True if result["positive_integral_estimate"] else (False if epsilon**2==d2 else None)
    result.update({"operator_radius_squared_upper":str(radius2),"operator_radius_rational_upper":str(rhi),
        "operator_bound_is_sharp":False,"all_compatible_positive_integral":all_positive,
        "positive_integral_feasibility":feasibility,
        "positivity_interpretation":"All-compatible flag is sufficient; a negative estimate under noise alone does not decide positive-subclass feasibility",
        "response_center":{"real":str(real),"imaginary":str(imag)},
        "response_radius_rational_upper":str(response_radius),
        "pi_scaled_ldos_interval":{"lower":str(-imag-response_radius),"upper":str(-imag+response_radius)}})
    return result


def main():
    parser=argparse.ArgumentParser();parser.add_argument("--input",type=Path,required=True);parser.add_argument("--output",type=Path,required=True);args=parser.parse_args()
    if args.output.exists():raise FileExistsError(args.output)
    raw=args.input.read_bytes();result=recover(json.loads(raw));result["input_sha256"]=hashlib.sha256(raw).hexdigest()
    args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps({k:v for k,v in result.items() if k not in ["theta","estimated_H","normal_C","integral_representative"]},indent=2))


if __name__=="__main__":main()
