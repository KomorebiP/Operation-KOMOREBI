"""Rational recovery for the nine-state molecular integral-symmetry sector."""
from itertools import combinations
import json
from pathlib import Path
import sympy as S
from normal_model import family
from molecular_model import action_matrix


def setup():
    model=family();frozen=json.loads(Path(__file__).with_name("probes.json").read_text())
    V=S.Matrix(frozen["queries"]);M=action_matrix(model["basis"],V)
    G=S.Matrix([[sum(a*b for a,b in zip(H,K)) for K in model["basis"]] for H in model["basis"]])
    K=M.T*M;N=20*K-G;L,D=N.LDLdecomposition(hermitian=False)
    if L*D*L.T!=N or any(D[i,i]<=0 for i in range(21)):raise ArithmeticError("Frame certificate failed")
    model.update(V=V,M=M,G=G,K=K,left_inverse=K.inv()*M.T,
        frame_integer_matrix=N,frame_ldl_diagonal=[D[i,i] for i in range(21)])
    return model


def decode(model,Y):
    theta=model["left_inverse"]*S.Matrix(list(Y));H=S.zeros(9)
    for value,operator in zip(theta,model["basis"]):H+=value*operator
    return H,theta


def unpack(model,theta):
    scalar=theta[0];K=S.zeros(3);C=S.zeros(5)
    for i,T in enumerate(model["T"]):K+=theta[1+i]*T
    for index,label in enumerate(model["labels"]):
        if label["kind"]=="quadratic":
            i,j=label["indices"];C[i,j]=C[j,i]=theta[index]
    return scalar,K,C


def integral_representative(model,theta):
    scalar,K,C=unpack(model,theta);T=model["T"]
    g={}
    for p in range(3):
        for q in range(3):
            for r in range(3):
                for s in range(3):
                    g[p,q,r,s]=2*sum(C[a,b]*T[a][p,q]*T[b][r,s] for a in range(5) for b in range(5))
    contraction=S.Matrix(3,3,lambda p,s:sum(g[p,q,q,s] for q in range(3)))
    h=-K+contraction/2+scalar*S.eye(3)/3
    return h,g


def is_psd(M):
    if M!=M.T:return False
    return all(M.extract(indices,indices).det()>=0 for n in range(1,M.rows+1) for indices in combinations(range(M.rows),n))
