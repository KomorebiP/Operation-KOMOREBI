"""Exact reference and binary64-action qualification of a declared H10 projection.

This is a derived, symmetry-completed, frozen-core model, not a certificate for
the full original H10 ion response or its molecular approximation error.
"""
import argparse
import hashlib
from itertools import combinations,product
import json
from pathlib import Path
import subprocess
import sys
import numpy as np
import sympy as S
from molecular_model import family as integral_family,term_on_sector
from sector_recovery import setup,decode,unpack,is_psd
from recover_sector_cache import recover
from recover_cache import rational,sqrt_bounds

ROOT=Path(__file__).resolve().parents[1]


def pair_index(p,q):
    high,low=max(p,q),min(p,q)
    return high*(high+1)//2+low


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
    args.output.mkdir(parents=True,exist_ok=True)
    path=ROOT/'chemistry_checkpoint/molecular_fixtures/h10_1.4.npz';raw=path.read_bytes()
    fixture=np.load(path,allow_pickle=False);hraw=fixture['h1'];graw=fixture['eri']
    assert hraw.shape==(10,10) and graw.shape==(55,55)
    hd=[[rational(float(x)) for x in row] for row in hraw]
    gd=[[rational(float(x)) for x in row] for row in graw]
    h=lambda p,q:(hd[p][q]+hd[q][p])/2
    g=lambda p,q,r,s:(gd[pair_index(p,q)][pair_index(r,s)]+gd[pair_index(r,s)][pair_index(p,q)])/2
    # Complete pair and h symmetry explicitly; never rewrite the source fixture.
    core=range(3);active=range(3,6)
    ecore=2*sum(h(i,i) for i in core)+sum(2*g(i,i,j,j)-g(i,j,j,i) for i,j in product(core,repeat=2))
    heff=S.Matrix(3,3,lambda p,q:h(p+3,q+3)+sum(2*g(p+3,q+3,i,i)-g(p+3,i,i,q+3) for i in core))
    original=integral_family();H=ecore*S.eye(9)
    for label,operator in zip(original['labels'],original['operators']):
        if label['kind']=='h':coefficient=heff[tuple(label['indices'])]
        else:
            (p,q),(r,s)=label['indices'];coefficient=g(p+3,q+3,r+3,s+3)
        H+=coefficient*operator
    # Independent embedding/projection of the six-spatial-orbital Hamiltonian:
    # six frozen electrons, three active electrons, the four outer orbitals empty.
    masks=[sum(1<<i for i in tuple(core)+alpha+tuple(i+6 for i in core)+(beta+6,))
        for alpha in combinations(active,2) for beta in active]
    projected=S.zeros(9)
    for p,q in product(range(6),repeat=2):
        for spin in [0,6]:projected+=h(p,q)*term_on_sector(masks,[(q+spin,False),(p+spin,True)])
    nonzero_quartic=0
    for p,q,r,s in product(range(6),repeat=4):
        for sigma,tau in product([0,6],repeat=2):
            term=term_on_sector(masks,[(q+sigma,False),(s+tau,False),(r+tau,True),(p+sigma,True)])
            if term!=S.zeros(9):
                projected+=g(p,q,r,s)*term/2;nonzero_quartic+=1
    if projected!=H:raise AssertionError('Frozen-core formula does not match exact embedded projection')
    model=setup();V=model['V'];Hdecode,theta=decode(model,H*V)
    if Hdecode!=H:raise AssertionError('Derived model is not in the identified family')
    _,_,C=unpack(model,theta)
    gpairs=S.Matrix(6,6,lambda i,j:g(*(tuple(x+3 for x in original['pairs'][i])+tuple(x+3 for x in original['pairs'][j]))))
    if not is_psd(gpairs) or not is_psd(C):raise AssertionError('Derived integral Gram failed exact positivity')
    # Three raw actions in binary64, followed by exact measurement of ALL action
    # error against the rational reference. Counts exclude reference-building QA.
    Hfloat=np.array(H.tolist(),dtype=np.float64);Vfloat=np.array(V.tolist(),dtype=np.float64)
    Yfloat=Hfloat@Vfloat;Y=S.Matrix([[rational(float(x)) for x in row] for row in Yfloat])
    exactY=H*V;error2=sum(x*x for x in Y-exactY);_,epsilon=sqrt_bounds(error2)
    b=S.eye(9)[:,0];energy=rational(float(fixture['ground_energy']))+S.Rational(1,2);eta=S.Rational(1,100)
    data={'action_matrix':Yfloat.tolist(),'b_hat':[1]+[0]*8,'raw_error_radius':str(epsilon),'source_radius':'0',
        'energy':str(energy),'eta':str(eta),'model':'Declared symmetry-completed H10 frozen-core projection; exact Slater source, not original annihilation source'}
    cache=args.output/'molecular_cache.json';certificate=args.output/'molecular_certificate.json'
    cache.write_text(json.dumps(data,indent=2)+'\n')
    process=subprocess.run([sys.executable,str(Path(__file__).with_name('recover_sector_cache.py')),'--input',str(cache),'--output',str(certificate)],capture_output=True,text=True,timeout=120)
    if process.returncode:raise RuntimeError(process.stderr)
    result=json.loads(certificate.read_text());r=S.Rational(result['response_radius_rational_upper']);z=energy+S.I*eta
    exact_response=S.simplify((b.T*(z*S.eye(9)-H).inv(method='DM')*b)[0])
    center=S.Rational(result['response_center']['real'])+S.I*S.Rational(result['response_center']['imaginary'])
    difference=S.simplify(exact_response-center);response_error2=S.re(difference)**2+S.im(difference)**2
    estimated=S.Matrix(result['estimated_H']);operator_error2=sum(x*x for x in estimated-H)
    if not (result['full_linear_consistent'] and result['all_compatible_positive_integral'] and error2<=epsilon**2 and response_error2<=r*r and operator_error2<=S.Rational(result['operator_radius_squared_upper'])):
        raise AssertionError('Derived molecular certificate failed reference comparison')
    h_asym=max(abs(hd[p][q]-hd[q][p]) for p,q in product(range(10),repeat=2))
    g_asym=max(abs(gd[p][q]-gd[q][p]) for p,q in product(range(55),repeat=2))
    reference={'fixture_sha256':hashlib.sha256(raw).hexdigest(),'source_fixture':'chemistry_checkpoint/molecular_fixtures/h10_1.4.npz',
        'spatial_orbital_indices_zero_based':{'doubly_occupied_core':[0,1,2],'active':[3,4,5],'empty':[6,7,8,9]},
        'sector':'Total5 alpha,4 beta; active2 alpha,1 beta. Spin-conjugate component to original4 alpha,5 beta fixture sector',
        'symmetry_completion':'Exact dyadic h becomes(h+h.T)/2; pair-packed eri becomes(eri+eri.T)/2; packed lower triangular pair index max*(max+1)/2+min',
        'maximum_h_transpose_discrepancy':str(h_asym),'maximum_pair_eri_transpose_discrepancy':str(g_asym),
        'frozen_core_energy':str(ecore),'h_effective':[[str(x) for x in row] for row in heff.tolist()],
        'active_eri_pair_order':[list(I) for I in original['pairs']],
        'active_eri_pair_matrix':[[str(x) for x in row] for row in gpairs.tolist()],
        'exact_H':[[str(x) for x in row] for row in H.tolist()],
        'exact_response':{'real':str(S.re(exact_response)),'imaginary':str(S.im(exact_response))},
        'energy_origin':'Stored approximate neutral electronic reference plus1/2 Hartree; not a certified neutral ground energy',
        'source':'First determinant in active sector, norm1 exactly; delta0 by definition, not original neutral-state annihilation source'}
    (args.output/'molecular_reference.json').write_text(json.dumps(reference,indent=2)+'\n')
    summary={'status':'passed','projection_equal_exactly':True,'embedded_determinants':len(masks),'nonzero_quartic_terms_in_projection':nonzero_quartic,
        'active_eri_positive_exactly':True,'normal_C_positive_exactly':True,
        'query_count':3,'query_norm_squared':3,'action_error_squared_exact':str(error2),'action_error_radius_rational_upper':str(epsilon),
        'action_error_radius_decimal':float(epsilon),'least_squares_residual_squared':result['least_squares_residual_squared'],
        'operator_error_squared_exact':str(operator_error2),'operator_radius_rational_upper':result['operator_radius_rational_upper'],
        'all_compatible_positive_integral':result['all_compatible_positive_integral'],
        'response_error_squared_exact':str(response_error2),'response_radius_rational_upper':str(r),'response_radius_decimal':float(r),
        'response_center_decimal':{'real':float(S.re(center)),'imaginary':float(S.im(center))},
        'eta_Hartree':'1/100','fixture_sha256':reference['fixture_sha256'],
        'scope':'Arithmetic validation against the EXACT defined finite projection; includes binary64 Hamiltonian conversion and matvec error',
        'non_claims':['No certificate for the original full52920-state ion response','No frozen-core or basis-set model-error bound','No neutral-state energy or source-error certificate','No physical observable accuracy claim','No oracle-count or wall-time comparison with Krylov methods']}
    (args.output/'qualification.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps({k:summary[k] for k in ['status','projection_equal_exactly','query_count','action_error_radius_decimal','response_radius_decimal','response_center_decimal','all_compatible_positive_integral']},indent=2))


if __name__=='__main__':main()
