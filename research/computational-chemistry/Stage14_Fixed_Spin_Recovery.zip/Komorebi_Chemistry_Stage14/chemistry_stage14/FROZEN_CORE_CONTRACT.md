# One declared H10-derived finite model

R14-E supplements the algebraic result with a molecular-integral arithmetic
qualification. It does not replace the original full H10 problem.

Use the immutable h10_1.4.npz ten-orbital fixture. Interpret each finite binary64
entry as an exact dyadic. Define h=(h_raw+h_raw^T)/2 and the pair-packed
g=(eri_raw+eri_raw^T)/2, then restore within-pair symmetry by the lower-triangular
pair index max(p,q)*(max(p,q)+1)/2+min(p,q). This explicitly defines a NEW
symmetry-completed finite model. The previous strict stored-bit operator and
all its historical audits remain unchanged.

Freeze spatial orbitals0,1,2 doubly occupied; keep orbitals3,4,5 active, with
two alpha and one beta electrons; keep6,7,8,9 empty. There are9 determinants,
with total5 alpha and4 beta electrons, the spin-conjugate sector to the source
fixture's4 alpha and5 beta ion sector. Use electronic energies with

E_core=2 sum_i h_ii + sum_ij (2g_iijj-g_ijji),

h_eff_pq=h_pq+sum_i(2g_pqii-g_piiq),

and the restricted active g, with i,j in the frozen core. Include E_core I.
Independently construct all nonzero ladder contributions to the same9 by9
projection in the first six spatial orbitals and require exact equality.

Perform three raw matrix-vector products with the frozen integer V using
binary64 H and V. Measure their aggregate Frobenius error exactly against the
rational reference H V, including conversion of H to binary64. Round its
square root outward at80 binary places. This validates the supplied action
cap for THIS defined model; it does not assume the cap from a floating residual.

Use b=e0, source radius0, eta=1/100 Hartree and the fixture's stored approximate
neutral electronic reference plus1/2 Hartree as E. This energy is a fixed
evaluation coordinate, not a certified ground-state estimate. The source is
an exact Slater determinant, not annihilation of the original neutral state.
Require exact C positivity, returned all-compatible positivity, and exact
comparison of the returned response disk with the independently computed
rational9 by9 resolvent.

Success means a rigorous arithmetic enclosure for the declared finite model.
Failure distinguishes projection/index convention errors, positivity failures,
and certificate failures. No frozen-core truncation, orbital/basis error,
neutral-state/source error, original52920-state response or speed advantage is
certified. Reference construction and validation costs are separate from the
three-query identification count.
