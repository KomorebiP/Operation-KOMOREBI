"""Hole/electron commutator normal form for the fixed-spin molecular family."""
import numpy as np
import sympy as S
from molecular_model import sector_states


def hole_change():
    states,_=sector_states();change=S.zeros(9)
    for i in range(3):
        for j in range(3):
            alpha=tuple(q for q in range(3) if q!=i)
            row=states.index(tuple(sorted(alpha+(j+3,))))
            change[row,3*i+j]=(-1)**i
    return change


def traceless_basis():
    result=[S.diag(1,-1,0),S.diag(1,1,-2)]
    for p,q in [(0,1),(0,2),(1,2)]:
        T=S.zeros(3);T[p,q]=T[q,p]=1;result.append(T)
    return result


def commutator(T):return S.kronecker_product(T,S.eye(3))-S.kronecker_product(S.eye(3),T.T)


def family():
    change=hole_change();T=traceless_basis();ad=[commutator(A) for A in T]
    normal=[S.eye(9)]+ad[:];labels=[{"kind":"scalar"}]+[{"kind":"commutator","index":i} for i in range(5)]
    for a in range(5):
        for b in range(a,5):
            normal.append(ad[a]*ad[b] if a==b else ad[a]*ad[b]+ad[b]*ad[a])
            labels.append({"kind":"quadratic","indices":[a,b]})
    basis=[change*H*change.T for H in normal]
    return {"change":change,"T":T,"ad":ad,"normal_basis":normal,"basis":basis,"labels":labels}


def choi(A):
    # Choi blocks Phi(E_ij), with row-vectorized input/output superoperator A.
    J=S.zeros(9)
    for i in range(3):
        for j in range(3):
            column=A[:,3*i+j]
            block=S.Matrix(3,3,list(column))
            J[3*i:3*i+3,3*j:3*j+3]=block
    return J
