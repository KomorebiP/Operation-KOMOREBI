# Focused self-audit: the fixed-spin three-query theorem

Primary verdict: **proved as written** for the declared nine-state real
integral-symmetry family and positive-integral relaxation, with a sufficient
stability bound. Review date2026-11-13. Same-author adversarial self-review;
the separate Jordan-Wigner construction is a second implementation, not an
independent reviewer or proof-assistant certificate.

## Claim card and exact revision

For EVERY real symmetric h and real eightfold-symmetric g on three spatial
orbitals, restrict the spin-free electronic Hamiltonian to N_alpha=2,N_beta=1.
The resulting real symmetric9 by9 operator family is21-dimensional with the
stated unique(t,K,C) normal form. Exactly three real full-vector actions
suffice, and fewer than three cannot suffice even deterministically
adaptively. With positive integral Gram tensors and unrestricted h, the
family is C>=0 and has the same minimum query count. The fixed-probe inverse
constant is bounded by sqrt20 in raw units. The posterior/response bounds
are rigorous sufficient enclosures, not exact scalar or frame optima.

All dimensions, coefficients, signs and ordering belong to this exact finite
class, not every molecular sector. The following table pins the raw proofs,
implementation, convention/source records and canonical evidence reviewed.
The exact base index is included because no Git revision exists here.

| Artifact relative to chemistry_stage14 | SHA256 |
| --- | --- |
| NORMAL_FORM.md | b84adaff4c4acd83ac133308989756031078d8fb2c05733b2815577896593993 |
| RECOVERY_THEOREM.md | 4e738c4f3d32e94de45cc1d46c8703551a9e851e2b27326f942e054d84e8269a |
| ROBUST_SPIN_COMPARISON.md | fed3542aea8c53a4506b4fbcddbad8996890f09689db0cf0e6288b7225d3be32 |
| FROZEN_CORE_CONTRACT.md | 357667529cee82136f3818cdf4a2530568e401964ee150be81ede47beddbbc1e |
| molecular_model.py | 776996c4e8302e71b1ecf474da091a479b586250ed788bbf03294e132a8572b1 |
| normal_model.py | ac1581afbb4dcb0d3131e22f7177614f6d4ac90c375623f42654467b90b0fcfd |
| sector_recovery.py | 063a3bee301f4cc4a96121738c612cc5e527014ae3e6d5c9cd9bf1a119cd7a9c |
| recover_sector_cache.py | a1f82cc218529b13eac0d81b6c425e42b320b08314e0a95daf295e1c45abae0f |
| probes.json | ac4cb112a32adf4c02d5dd22b6251d5286a6968355546b61f8a76aec9250acf9 |
| audit_sector.py | 6dc5c69bc78cde615891b9465ace51dd1c3ce1a4a8b1113265b352c9397492d4 |
| qualify_frozen_core.py | 2c049278f3e01f908c9e3d15cb8c4c863e3cd276f9ece24956e61beae2080dc1 |
| example_cache.json | 3ffaa577a889dd377b5dc8d07381e9523582e9e19b242a14dff897100fb5ff8a |
| LITERATURE.md | 94afdb03ecb3ed6c31f98b1cce0d9f606f52b9202c7169e45bceb2b45fb8307c |
| exact-audit-001/manifest.json | b388c0fef1d438953a75b56ee57ee59b2ff544786adfbf0ea50a1b30412777ab |
| exact-audit-001/checks.json | 4175f14acd6ed9796b02fbfb8c8235286c5aefa45c392a6c960a1f564e0bcc38 |
| exact-audit-001/example_certificate.json | 739a5d65aa7eee431c09d8506b0a2f2d77b17f53ddb3877266acba981f608461 |
| molecular-audit-001/manifest.json | 4486438c75a3d45df540781c80f92ac68608737bc3371d5adc96118335192afc |
| molecular-audit-001/qualification.json | c200b99c9cde16da1e58cb58c2517d3d3e0c11d110e9c3fed399b610adb020d2 |
| molecular-audit-001/molecular_reference.json | e1b4100a0938d3ecff16aca1b646b129ff41c809f4e860d3f95ec2f218adfd30 |
| molecular-audit-001/molecular_certificate.json | d98fe835f4886ba2cbf5ca39bd8abcf82208a97f571fb5bc4368c84f0b3d0705 |
| ../SHA256SUMS_STAGE13.txt | c2be1d7ccbbffac13d1371704c83c81b512118c741fa823f1879d5775d961744 |

## Dependency graph

CAR and determinant order -> hole/electron E action -> exact normal form
and projected Choi identity -> uniqueness and dimension21 -> parameter
lower bound/local positive-C adaptive indistinguishability. Separately:
fixed V and exact M -> nonzero21-minor, positive20K-G -> injectivity,
least-squares Pythagoras and Frobenius error bound -> resolvent/source disk.
The Choi norm estimate -> positive-C margin. The spin-preserving rank-one
completion -> strict same-cache response separation. Each external
convention is independently reconstructed internally; no missing external
theorem supplies a load-bearing step. General matrix-recovery attribution is
checked separately in LITERATURE.md.

## Obligations

| Obligation | Status and reason |
| --- | --- |
| Operator definition and factors | Passed: physical g multiplies half the quartic term; all27 direct ladder generators match full64 Jordan-Wigner and spin-free E-product constructions, including the contraction |
| Hole/electron signs | Passed: U is a signed permutation; all9 E_pq=delta_pq I-ad(e_qp) identities hold. No symmetric-only check hides the transpose convention |
| Spanning | Passed: pair symmetry leaves symmetric commutators; trace pieces vanish, leaving five traceless directions. Explicit g=2 sum C_ab Ta tensor Tb and h=-K+R/2+tI/3 reconstruct all21 normal directions |
| Uniqueness | Passed: projected Choi reshuffling removes scalar/one-body/anticommutator terms and retains-2 U_T C U_T^T. Independent Ta imply C=0; evaluation at I gives t=0; centrality/tracelessness gives K=0 |
| Integral gauge | Passed: E_trace=N I and fixed N=3 give the six displayed gauges; exact six basis identities and rank27-to21 agree. The original integrals are not identifiable |
| Positivity | Passed: restriction of a positive g to the traceless symmetric block yields C>=0. Conversely the explicit representative is positive whenever C is. This uses unrestricted h and supplies no Coulomb-realizability converse |
| C norm bound | Passed: Choi reshuffling is an entry permutation, compression is contractive and the five orthogonal Ta have squared norm at least2; hence norm(C)<=norm(H)/4 |
| Lower bound/adaptivity | Passed: at most18 scalar constraints leave a nonzero21-parameter perturbation. Fixing the path and perturbing in its common nullspace preserves every deterministic query/output. An interior C>0 admits a sufficiently small perturbation |
| Upper count and frame | Passed: V^T V=3I; the chosen21-minor has determinant-2054739197952 by Bareiss and Berkowitz; all21 LDL pivots and leading principal minors of20K-G are strictly positive. These are exact finite certificates for the whole linear family |
| Error normalization | Passed: raw probes have norm sqrt3; unit-probe error scales by1/sqrt3 and the inverse constant becomes sqrt60. The operator upper frame bound follows from VV^T<=3I |
| Least squares/consistency | Passed: exact left inverse, all21 basis roundtrips and residual normal equations. Pythagoras proves consistency iff d<=epsilon and the upper radius. No unsupported sharpness claim is made |
| Positive-subclass handling | Passed: all-compatible C margin is sufficient. A PSD estimate is feasible; an indefinite singleton is infeasible; an indefinite noisy estimate alone leaves feasibility unknown, as tested by the CLI |
| Response perturbation | Passed: real symmetry and eta>0 give resolvent norms at most1/eta for H and Hhat. Expanding source perturbations gives delta(2 norm(bhat)+delta)/eta. No spectral prior is needed for this estimate |
| Strong comparator | Passed: u is orthogonal to V and the quartet q; H1 preserves the cache AND S^2. Analytic norm caps put both in[-1,1]. Exact response values and a rational outward square-root radius verify the strict LDOS gap |
| Molecular finite model | Passed within its scope: exact symmetry completion declared BEFORE evaluation; direct embedded ladder projection equals the frozen-core formula. The exact dyadic source data remain unchanged. Positive input Gram and normal C are checked exactly |
| Molecular arithmetic cap | Passed: exact difference between the binary64 outputs and rational H V includes conversion/matvec error. Saved CLI input is hash-bound; exact rational operator/response errors lie within returned radii at eta1/100 |
| Original H10 accuracy/runtime | Out of scope: no discarded-space/model, neutral-state/source or runtime-comparison bound. The tiny arithmetic radius is not physical chemical accuracy |
| Originality | Not addressed by proof: bounded literature comparison establishes general-method overlap but does not establish priority |

## Edge cases and domain limits

The full linear consistency test includes zero noise and singleton residual
boundaries. Zero observed source is allowed; its source term becomes
delta^2/eta. Negative radii/nonpositive eta and nonfinite JSON floats are
rejected by the CLI and inherited exact-number parser. Rational square-root
bounds use integer arithmetic and are outward, including the exact zero case.
The inherited stage-thirteen parser/square-root implementation was retained
unchanged and pinned by both manifests; current molecular binary64 parsing is
also exercised end to end. Separate per-column balls are only enclosed by
an aggregate ball. Optional physical restrictions can shrink this set.

Positive g is a six-dimensional symmetric-pair Gram condition, while C has
five traceless directions. An energy constant is representable within the
family because N=3 is fixed. No C positivity claim is made for the general
full linear class. Necessity for the smaller actual-Coulomb-realizable family
is explicitly unproved. The9-state model and stage-thirteen20-state family
are different problems; their query counts are not a same-input speedup.

## Evidence and remaining gap

exact-audit-001 completed with82 named checks/260 aggregated cases. Its all-
basis reductions validate the explicit fixed matrix claims; the normal-form
and adaptive lower-bound reasoning are the durable universal arguments for
this specified family. molecular-audit-001 completed with an exact9-state
projection identity involving564 nonzero quartic terms, positivity, measured
action errors and exact reference inclusion. Both current-input manifests
validated. No canonical failed run is concealed.

No gap remains in the stated local correctness contract under this self-
review. The larger research program remains open on actual Coulomb
realizability, molecular model/source error, larger-sector structure, sharp
probe design, runtime gain and priority. CLOSEOUT.md records the next
discriminating action for each. The cheapest reuse check is to replay the
saved9 by3 CLI cache and validate the two manifests; that does not replace
independent mathematical review.

Proofreading self-review covered the three theorem/example documents and
new results/contract/closeout/reproduction prose. No mathematical-token edit
was required after the canonical audits. Project compact numerical spacing
was retained. Markdown links and audit pins are checked separately by the
verification script. Historical stages were outside the edit scope.
