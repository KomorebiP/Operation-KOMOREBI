"""Finite exact certificates for the explicitly defined nine-state family."""
import argparse
import hashlib
from itertools import product
import json
from pathlib import Path
import subprocess
import sys
import numpy as np
import sympy as S
from molecular_model import family as integral_family,eri_tensor,action_matrix,term_on_sector,spin_square
from normal_model import family as normal_family,commutator,choi
from sector_recovery import setup,decode,unpack,integral_representative,is_psd
from recover_sector_cache import recover

ROOT=Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT/'chemistry_stage12'))
from hodge_model import jw_annihilators


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
    args.output.mkdir(parents=True,exist_ok=True)
    checks=[]
    def check(name,condition,count=1):
        if not condition:raise AssertionError(name)
        checks.append({'assertion':name,'cases':count})
    model=setup();original=integral_family();U=model['change'];T=model['T'];basis=model['basis']
    states=original['masks'];a=jw_annihilators(6)
    Efull={(p,q):sum((a[p+s].T@a[q+s] for s in [0,3]),np.zeros((64,64),dtype=np.int64)) for p,q in product(range(3),repeat=2)}
    E={key:S.Matrix(value[np.ix_(states,states)]) for key,value in Efull.items()}
    independent=[];product_operators=[]
    for label in original['labels']:
        if label['kind']=='h':
            p,q=label['indices'];pairs=set([(p,q),(q,p)])
            full=sum((Efull[I] for I in pairs),np.zeros((64,64),dtype=np.int64))
            direct=S.Matrix(full[np.ix_(states,states)])
            eproduct=sum((E[I] for I in pairs),S.zeros(9))
        else:
            I,J=map(tuple,label['indices']);g=eri_tensor(I,J)
            full=np.zeros((64,64),dtype=np.int64);eproduct=S.zeros(9)
            for p,q,r,s in g:
                for sigma,tau in product([0,3],repeat=2):full+=a[p+sigma].T@a[r+tau].T@a[s+tau]@a[q+sigma]
                eproduct+=(E[p,q]*E[r,s]-(E[p,s] if q==r else S.zeros(9)))/2
            direct=S.Matrix(full[np.ix_(states,states)])/2
        independent.append(direct);product_operators.append(eproduct)
    check('All six h and twenty-one g direct ladder generators equal independent full64 Jordan-Wigner matrices',independent==original['operators'],27)
    check('All twenty-seven generators equal the spin-free E-product Hamiltonian with its contraction',product_operators==original['operators'],27)
    for p,q in product(range(3),repeat=2):
        unit=S.zeros(3);unit[q,p]=1
        expected=(S.eye(9) if p==q else S.zeros(9))-commutator(unit)
        check(f'Hole/electron formula E_{p}{q}',U.T*E[p,q]*U==expected)
    spinplus=sum((a[p].T@a[p+3] for p in range(3)),np.zeros((64,64),dtype=np.int64))
    sjw=S.Rational(3,4)*S.eye(9)+S.Matrix((spinplus.T@spinplus)[np.ix_(states,states)])
    spin=spin_square();q=U*S.Matrix(list(S.eye(3)))
    check('Total spin independently constructed and quartet vector fixed',spin==sjw==S.Rational(3,4)*S.eye(9)+q*q.T and (q.T*q)[0]==3)
    check('All integral generators commute with total spin',all(H*spin==spin*H for H in independent),27)
    check('Integral and normal families both have dimension21 and equal span',original['parameter_map'].rank()==21 and S.Matrix.hstack(*[S.Matrix(list(H)) for H in basis]).rank()==21 and S.Matrix.hstack(original['parameter_map'],*[S.Matrix(list(H)) for H in basis]).rank()==21)
    for k,H in enumerate(basis):
        theta=S.eye(21)[:,k];_,_,C=unpack(model,theta);P=S.eye(9)-S.Matrix(list(S.eye(3)))*S.Matrix(list(S.eye(3))).T/3
        expected=-2*sum((C[i,j]*S.Matrix(list(T[i]))*S.Matrix(list(T[j])).T for i,j in product(range(5),repeat=2)),S.zeros(9))
        check(f'Projected Choi identity normal basis{k}',P*choi(U.T*H*U)*P==expected)
        h,g=integral_representative(model,theta);reconstructed=S.zeros(9)
        for label,operator in zip(original['labels'],original['operators']):
            coefficient=h[tuple(label['indices'])] if label['kind']=='h' else g[tuple(label['indices'][0])+tuple(label['indices'][1])]
            reconstructed+=coefficient*operator
        check(f'Explicit h/g representative normal basis{k}',reconstructed==H)
    for hi,(p,q0) in enumerate(original['pairs']):
        h=S.zeros(3);h[p,q0]=h[q0,p]=1;Hg=S.zeros(9)
        for label,operator in zip(original['labels'][6:],original['operators'][6:]):
            (p,q0),(r,s)=label['indices'];value=(h[p,q0]*int(r==s)+int(p==q0)*h[r,s])/2
            Hg+=value*operator
        check(f'Six-dimensional one-body integral gauge basis{hi}',Hg==original['operators'][hi])
    for p in range(3):
        h_index=original['labels'].index({'kind':'h','indices':[p,p]})
        g_index=original['labels'].index({'kind':'g','indices':[[p,p],[p,p]]})
        occupations=[int(bool(mask&(1<<p)))+int(bool(mask&(1<<(p+3)))) for mask in states]
        double=[int(bool(mask&(1<<p)) and bool(mask&(1<<(p+3)))) for mask in states]
        check(f'One-orbital hand benchmarks{p}',original['operators'][h_index]==S.diag(*occupations) and original['operators'][g_index]==S.diag(*double))
    frozen=json.loads(Path(__file__).with_name('probes.json').read_text());V=model['V'];M=model['M'];G=model['G'];K=model['K']
    check('Three orthogonal raw probes of squared norm3',V.T*V==3*S.eye(3))
    minor=M.extract(frozen['minor_rows'],range(21));det1=minor.det(method='bareiss');det2=minor.det(method='berkowitz')
    check('Frozen21 by21 action minor verified by two determinant algorithms',det1==det2==S.Integer(frozen['minor_determinant']))
    N=20*K-G;L,D=N.LDLdecomposition(hermitian=False);leading=[N[:j,:j].det(method='bareiss') for j in range(1,22)]
    check('Exact frame LDL residual vanishes with all twenty-one positive pivots',L*D*L.T==N and all(D[i,i]>0 for i in range(21)),21)
    check('All twenty-one frame leading principal minors positive',all(x>0 for x in leading),21)
    check('Decoder is left inverse on the entire21-dimensional coefficient space',model['left_inverse']*M==S.eye(21),21)
    theta=S.zeros(21,1);theta[1]=S.Rational(1,8)
    for i,label in enumerate(model['labels']):
        if label.get('indices') and label['indices'][0]==label['indices'][1]:theta[i]=S.Rational(1,64)
    H0=sum((x*H for x,H in zip(theta,basis)),S.zeros(9));b=S.eye(9)[:,0]
    check('Exact roundtrip of every normal basis',all(decode(model,H*V)[0]==H for H in basis),21)
    residual_direction=(S.eye(27)-M*model['left_inverse'])*S.eye(27)[:,0]
    noisy=H0*V+S.Matrix(9,3,list(M[:,0]/8192+residual_direction/4096))
    Hhat,noisytheta=decode(model,noisy);residual=S.Matrix(list(noisy-Hhat*V))
    check('Noisy least-squares residual is orthogonal to every structured action',M.T*residual==S.zeros(21,1) and residual!=S.zeros(27,1),21)
    check('Pythagoras for the chosen noisy action example',sum(x*x for x in noisy-H0*V)==sum(x*x for x in residual)+sum(x*x for x in (Hhat-H0)*V))
    u=S.Matrix([S.Rational(5,8),0,-S.Rational(1,8),-S.Rational(3,8),S.Rational(1,8),0,S.Rational(1,4),0,0]);u2=(u.T*u)[0]
    H1=H0+u*u.T/(4*u2)
    check('Strong comparator preserves all three cached actions and total spin',V.T*u==S.zeros(3,1) and (q.T*u)[0]==0 and H1*V==H0*V and H1*spin==spin*H1)
    check('Common spectrum prior via analytic norm caps',S.Rational(41,64)+S.Rational(1,4)<1 and u2==S.Rational(5,8))
    response=lambda H:S.simplify((b.T*(S.I*S.eye(9)-H).inv(method='DM')*b)[0])
    g0=response(H0);g1=response(H1);gap=S.simplify(S.im(g1-g0))
    check('Exact structured response benchmark',g0==-S.Rational(107,1157)-S.I*S.Rational(1146,1157))
    check('Exact positive pi-scaled LDOS separation',gap==S.Rational(2865298301987012250,46664771464898716181))
    example=Path(__file__).with_name('example_cache.json');certificate=args.output/'example_certificate.json'
    execution=subprocess.run([sys.executable,str(Path(__file__).with_name('recover_sector_cache.py')),'--input',str(example),'--output',str(certificate)],capture_output=True,text=True,timeout=60)
    check('CLI exited successfully',execution.returncode==0)
    result=json.loads(certificate.read_text());radius=S.Rational(result['response_radius_rational_upper'])
    check('Example CLI exact center, consistency, positive margin, strict response separation',result['full_linear_consistent'] and result['all_compatible_positive_integral'] and S.Rational(result['response_center']['real'])==S.re(g0) and S.Rational(result['response_center']['imaginary'])==S.im(g0) and gap>radius and not result['operator_bound_is_sharp'])
    bad=json.loads(example.read_text());bad['action_matrix']=[[str(x) for x in row] for row in noisy.tolist()];bad['raw_error_radius']='0'
    invalid=recover(bad)
    check('Inconsistent data returns no response certificate',not invalid['full_linear_consistent'] and not invalid['positive_integral_feasibility'] and 'response_center' not in invalid)
    indefinite=theta.copy();indefinite[6]=-S.Rational(1,64);Hneg=sum((x*H for x,H in zip(indefinite,basis)),S.zeros(9));bad['action_matrix']=[[str(x) for x in row] for row in (Hneg*V).tolist()]
    singleton=recover(bad)
    check('Singleton with indefinite C correctly fails positive-integral feasibility',singleton['full_linear_consistent'] and not singleton['positive_integral_estimate'] and singleton['positive_integral_feasibility'] is False)
    bad['raw_error_radius']='1';uncertain=recover(bad)
    check('Indefinite estimate with nonzero noise does not decide positive feasibility',uncertain['positive_integral_feasibility'] is None)
    summary={'status':'passed','assertion_tested':'Exact finite-basis and matrix certificates for the nine-state21-parameter family; finite checks support the explicit reductions in the separate proofs','checks':checks,'check_count':len(checks),'summed_cases':sum(c['cases'] for c in checks),'minor_determinant':str(det1),'ldl_pivots':[str(D[i,i]) for i in range(21)],'leading_principal_minors':[str(x) for x in leading],'g0':str(g0),'g1':str(g1),'pi_scaled_ldos_gap':str(gap),'certified_example_response_radius':str(radius),'source_and_scope':'Self-authored computational audit; independent matrix construction, not an independent human or fresh-agent review','non_claims':['No unbounded molecular-sector theorem','No actual Coulomb-realizability theorem','No original full H10 response or runtime advantage','No exact sharp frame constant']}
    (args.output/'checks.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps({k:summary[k] for k in ['status','check_count','summed_cases','minor_determinant','pi_scaled_ldos_gap']},indent=2))


if __name__=='__main__':main()
