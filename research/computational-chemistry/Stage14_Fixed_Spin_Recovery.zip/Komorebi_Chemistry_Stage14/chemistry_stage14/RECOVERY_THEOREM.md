# Exactly three sector actions and a certified stability bound

Komorebi P. 2026-11-13. Claim C_MOLECULAR_THREE_QUERY_RECOVERY.
Class and conventions are in NORMAL_FORM.md. Count exact real full-vector
actions on the nine-dimensional fixed N_alpha=2,N_beta=1 sector.

**Theorem.** Three fixed real probes suffice to identify every operator in
the21-dimensional integral-symmetry family. Fewer than three cannot identify
every member, even with deterministic adaptive choice. The same minimum
holds for the positive-integral relaxation C>=0.

Proof of necessity. After at most two queries there are at most18 real
linear constraints on21 independent parameters. Fix the query path of an
adaptive strategy at a particular H. A nonzero family perturbation annihilates
both queried vectors, so a perturbed operator gives the same outputs and
therefore the same path. For the full linear family any such perturbation is
admissible. For C>=0 run at an interior C>0 and scale the perturbation small
enough to preserve positivity. This is an information lower bound, not a
floating runtime or quantum-measurement claim.

## Fixed sufficient design

In determinant order use the three columns

\[
 V=\begin{pmatrix}
 -1&0&0\\0&1&0\\0&0&1\\-1&0&0\\0&0&1\\0&-1&0\\1&0&0\\0&1&0\\0&0&1
 \end{pmatrix},\qquad V^TV=3I_3.\tag{1}
\]

Every probe has norm sqrt3 and exactly three signed unit entries. They are
frozen in probes.json. Let H_k be the21 normal-form basis operators: scalar,
five D_a, then the quadratic products in lexicographic a<=b order (five
squares and ten symmetric cross products). Let M have columns vec(H_k V), with observation row order
determinant_index*3+query_index. Define the operator Gram matrix
G_kl=<H_k,H_l>_F and K=M^TM.

The selected21x21 minor in probes.json has exact determinant
-2054739197952. Independently, the exact rational LDL factorization of
N=20K-G has positive diagonal and zero reconstruction residual. These finite
certificates are checked canonically on the explicit integer matrices.
Thus M has column rank21, proving sufficiency for every real coefficient
vector, not merely sampled Hamiltonians. QED.

The design was selected from a finite numerical search, but neither its
rank proof nor its stated stability bound uses a numerical singular value.
The initial special Rademacher probe set failed at three queries; this was
a property of that set, not an obstruction to all three-query designs.

## Stable least squares

Since20K-G is positive definite and V^TV=3I,

\[
 {1\over\sqrt{20}}\|H\|_F\le\|HV\|_F
       \le\sqrt3\|H\|_F,\qquad H\in L.\tag{2}
\]

The lower bound is certified, not asserted sharp. The condition number is
at most sqrt60; for unit probes Q=V/sqrt3 the inverse noise constant is
at most sqrt60. For raw V the inverse constant is at most sqrt20.

For real observed Y, set theta_hat=(M^TM)^-1 M^T vec(Y) and
Hhat=sum theta_hat_k H_k. This is the unique structured least-squares
estimate. With d=||Y-Hhat V||_F and an aggregate raw error cap epsilon,
the full linear family is consistent iff d<=epsilon. Every compatible H obeys

\[
 \boxed{\|H-Hhat\|_F\le\sqrt{20(\epsilon^2-d^2)}=:r_H.}\tag{3}
\]

Orthogonal least-squares Pythagoras and (2) prove the bound. Unlike the
stage-thirteen exact spectral formula, (3) is an upper bound on the minimax
radius, not an asserted exact radius. Separate column-error balls may be
combined via epsilon^2=sum epsilon_j^2 for a valid outer enclosure.

By NORMAL_FORM.md(5), all compatible operators satisfy
||C-C_hat||_2<=r_H/4. Thus C_hat-(r_H/4)I>=0 is a sufficient condition that
the ENTIRE compatible set has positive-integral representatives. If this
condition fails under nonzero noise, positivity feasibility is unresolved;
an indefinite estimate alone does not prove infeasibility of that subset.

## Response enclosure

For z=E+i eta,eta>0, real source ||b-bhat||<=delta and
ghat=bhat^T(zI-Hhat)^-1 bhat,

\[
 |g-ghat|\le {\|bhat\|^2r_H\over\eta^2}
       +{\delta(2\|bhat\|+\delta)\over\eta}.\tag{4}
\]

This is the same elementary resolvent/source perturbation argument as in
stage thirteen. It gives a rigorous enclosure conditional on the supplied
error caps, with no scalar optimality claim. Rational observed data permit
exact rational decoding, residual and center; square-root bounds may be
rounded outward rationally. Actual action/model/source errors still need
external justification in a molecular calculation.

The theorem concerns the integral-symmetry family and its positive-Gram
relaxation. It neither proves necessity for the smaller set of actually
Coulomb-realizable integral tensors nor supplies an H10 runtime advantage.
