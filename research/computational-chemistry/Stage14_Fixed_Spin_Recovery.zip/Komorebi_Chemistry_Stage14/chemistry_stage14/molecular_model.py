"""Exact three-spatial-orbital spin-free integral-symmetry sector matrices."""
from itertools import combinations,combinations_with_replacement,product
import numpy as np
import sympy as S


def ladder(mask,mode,create):
    occupied=(mask>>mode)&1
    if occupied==int(create):return None
    sign=(-1)**((mask&((1<<mode)-1)).bit_count())
    return mask^(1<<mode),sign


def term_on_sector(masks,sequence):
    lookup={mask:i for i,mask in enumerate(masks)}
    result=S.zeros(len(masks))
    for column,mask in enumerate(masks):
        coefficient=1
        for mode,create in sequence:
            step=ladder(mask,mode,create)
            if step is None:break
            mask,sign=step;coefficient*=sign
        else:
            if mask in lookup:result[lookup[mask],column]+=coefficient
    return result


def sector_states():
    states=[tuple(sorted(alpha+(beta,))) for alpha in combinations(range(3),2) for beta in range(3,6)]
    masks=[sum(1<<i for i in state) for state in states]
    return states,masks


def eri_tensor(I,J):
    g={}
    for first,second in [(I,J),(J,I)]:
        for p,q in set([first,first[::-1]]):
            for r,s in set([second,second[::-1]]):g[p,q,r,s]=S.Integer(1)
    return g


def family():
    states,masks=sector_states();pairs=list(combinations_with_replacement(range(3),2))
    operators=[];labels=[]
    for p,q in pairs:
        H=S.zeros(9)
        for a,b in set([(p,q),(q,p)]):
            for spin in [0,3]:H+=term_on_sector(masks,[(b+spin,False),(a+spin,True)])
        operators.append(H);labels.append({"kind":"h","indices":[p,q]})
    for i,I in enumerate(pairs):
        for J in pairs[i:]:
            g=eri_tensor(I,J);H=S.zeros(9)
            for (p,q,r,s),value in g.items():
                for sigma,tau in product([0,3],repeat=2):
                    H+=value*term_on_sector(masks,[(q+sigma,False),(s+tau,False),(r+tau,True),(p+sigma,True)])/2
            operators.append(H);labels.append({"kind":"g","indices":[list(I),list(J)]})
    assert len(operators)==27 and all(H==H.T for H in operators)
    flat=S.Matrix.hstack(*[S.Matrix(list(H)) for H in operators])
    _,pivots=flat.rref();basis=[operators[i] for i in pivots]
    return {"states":states,"masks":masks,"pairs":pairs,"operators":operators,
        "labels":labels,"basis":basis,"basis_indices":list(pivots),"parameter_map":flat}


def spin_square():
    states,masks=sector_states()
    # On M_s=1/2, S^2 = S_- S_+ + 3/4 I. Intermediate M_s=3/2 has one determinant.
    all_masks=[mask for mask in range(64) if mask.bit_count()==3]
    Splus=S.zeros(len(all_masks));lookup={mask:i for i,mask in enumerate(all_masks)}
    for p in range(3):Splus+=term_on_sector(all_masks,[(p+3,False),(p,True)])
    columns=[lookup[mask] for mask in masks]
    raising=Splus[:,columns]
    return S.Rational(3,4)*S.eye(9)+raising.T*raising


def action_matrix(basis,V):
    return S.Matrix.hstack(*[S.Matrix(list(H*V)) for H in basis])
