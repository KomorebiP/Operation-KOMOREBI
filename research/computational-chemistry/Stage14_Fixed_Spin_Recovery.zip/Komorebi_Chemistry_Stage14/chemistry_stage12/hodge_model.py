"""Particle-hole involution and independent Jordan-Wigner construction."""
from itertools import combinations
import numpy as np


def hodge(determinants,modes=6):
    lookup={state:i for i,state in enumerate(determinants)}
    J=np.zeros((len(determinants),len(determinants)),dtype=np.int64)
    for column,state in enumerate(determinants):
        complement=tuple(i for i in range(modes) if i not in state)
        inversions=sum(i-j for j,i in enumerate(state))
        J[lookup[complement],column]=(-1)**inversions
    return J


def jw_annihilators(modes):
    identity=np.eye(2,dtype=np.int64);parity=np.diag([1,-1]);destroy=np.array([[0,1],[0,0]],dtype=np.int64)
    result=[]
    for j in range(modes):
        operator=np.ones((1,1),dtype=np.int64)
        for k in reversed(range(modes)):
            operator=np.kron(operator,destroy if k==j else parity if k<j else identity)
        result.append(operator)
    return result


def independent_basis(determinants,labels,modes=6):
    masks=[sum(1<<i for i in state) for state in determinants]
    a=jw_annihilators(modes);operators=[]
    for I,J in labels:
        p,q=I;r,s=J
        term=a[p].T@a[q].T@a[s]@a[r]
        full=term if I==J else term+term.T
        operators.append(full[np.ix_(masks,masks)])
    return np.array(operators,dtype=np.int64),a,masks


def contraction(B,pairs,modes=6):
    lookup={pair:i for i,pair in enumerate(pairs)}
    C=np.zeros((modes,modes),dtype=np.int64)
    for p in range(modes):
        for q in range(modes):
            for r in range(modes):
                if p==r or q==r:continue
                I=tuple(sorted((p,r)));J=tuple(sorted((q,r)))
                sign=(1 if p<r else -1)*(1 if q<r else -1)
                C[p,q]+=sign*B[lookup[I],lookup[J]]
    return C


def onebody(h,annihilators,masks):
    n=len(annihilators);full=np.zeros_like(annihilators[0])
    for p in range(n):
        for q in range(n):full+=int(h[p,q])*(annihilators[p].T@annihilators[q])
    return full[np.ix_(masks,masks)]
