"""Exact conditional recovery and response enclosure from a JSON action cache."""
import argparse
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path
import sympy as S
from closed_decoder import design,decode


def rational(value):
    if isinstance(value,bool):raise ValueError("Boolean is not a numeric input")
    if isinstance(value,float):
        if not math.isfinite(value):raise ValueError("Finite input required")
        p,q=value.as_integer_ratio();return S.Rational(p,q)
    f=Fraction(value);return S.Rational(f.numerator,f.denominator)


def sqrt_bounds(value,bits=80):
    value=S.Rational(value)
    if value<0:raise ValueError("Negative squared quantity")
    numerator=int(value.p)<<(2*bits);denominator=int(value.q)
    root=math.isqrt(numerator//denominator);scale=1<<bits
    lo=S.Rational(root,scale)
    hi=lo if root*root*denominator==numerator else S.Rational(root+1,scale)
    assert lo*lo<=value<=hi*hi
    return lo,hi


def recover(data):
    rows=data["action_matrix"]
    if len(rows)!=20 or any(len(row)!=10 for row in rows):raise ValueError("Need20x10 action matrix")
    Y=S.Matrix([[rational(x) for x in row] for row in rows])
    source=data["b_hat"]
    if len(source)!=20:raise ValueError("Need length20 source")
    b=S.Matrix([rational(x) for x in source]);epsilon=rational(data["raw_error_radius"])
    delta=rational(data.get("source_radius","0"));energy=rational(data.get("energy","0"));eta=rational(data.get("eta","1"))
    if epsilon<0 or delta<0 or eta<=0:raise ValueError("Invalid error radius or broadening")
    model=design();Hhat=decode(model,Y);residual=Y-Hhat*model["V"]
    d2=sum(x*x for x in residual);consistent=bool(d2<=epsilon**2)
    result={"method":"CHEM-STAGE13 integer V=2E+JE, rational closed decoder",
        "arithmetic":"Binary64 inputs interpreted as exact dyadics; subsequent rational arithmetic; outward dyadic square-root bounds",
        "raw_probe_norm_squared":"5","consistent":consistent,"raw_error_radius":str(epsilon),
        "source_radius":str(delta),"least_squares_residual_squared":str(d2),
        "estimated_H":[[str(Hhat[i,j]) for j in range(20)] for i in range(20)],
        "scope":"Conditional on all supplied action/source error bounds and the full real 6-mode/3-particle two-body family"}
    if not consistent:return result
    radius2=2*(epsilon**2-d2);rlo,rhi=sqrt_bounds(radius2)
    b2=sum(x*x for x in b);blo,bhi=sqrt_bounds(b2)
    response=S.simplify((b.T*((energy+S.I*eta)*S.eye(20)-Hhat).inv(method="DM")*b)[0])
    real=S.simplify(S.re(response));imag=S.simplify(S.im(response))
    response_radius=b2*rhi/eta**2+delta*(2*bhi+delta)/eta
    result.update({"operator_minimax_radius_squared":str(radius2),
        "operator_radius_rational_lower":str(rlo),"operator_radius_rational_upper":str(rhi),
        "response_center":{"real":str(real),"imaginary":str(imag)},
        "response_radius_rational_upper":str(response_radius),
        "pi_scaled_ldos_interval":{"lower":str(-imag-response_radius),"upper":str(-imag+response_radius)},
        "response_bound":"Rigorous enclosure; scalar optimality is not claimed"})
    return result


def main():
    parser=argparse.ArgumentParser();parser.add_argument("--input",type=Path,required=True)
    parser.add_argument("--output",type=Path,required=True);args=parser.parse_args()
    if args.output.exists():raise FileExistsError(args.output)
    raw=args.input.read_bytes();result=recover(json.loads(raw))
    result["input_sha256"]=hashlib.sha256(raw).hexdigest()
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps({k:v for k,v in result.items() if k!="estimated_H"},indent=2))


if __name__=="__main__":main()
