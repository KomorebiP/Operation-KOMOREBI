"""Explicit rational decoder with no coefficient-matrix inversion."""
from itertools import combinations
import sympy as S


def design():
    states=list(combinations(range(6),3));lookup={state:i for i,state in enumerate(states)}
    J=S.zeros(20)
    for column,state in enumerate(states):
        complement=tuple(i for i in range(6) if i not in state)
        J[lookup[complement],column]=(-1)**(sum(state)-3)
    E=S.eye(20)[:,[i for i,state in enumerate(states) if 0 in state]];F=J*E
    pairs=list(combinations(range(1,6),2));pair_lookup={pair:i for i,pair in enumerate(pairs)}
    hopping=[]
    for mode in range(1,6):
        T=S.zeros(10)
        for i,I in enumerate(pairs):
            for k,K in enumerate(pairs):
                if set(I)&set(K):continue
                leftover=next(iter(set(range(1,6))-set(I)-set(K)))
                if leftover!=mode:continue
                T[i,k]=(-1)**(sum(I)-3+sum(q<mode for q in K))
        hopping.append(T)
    V=2*E+F
    return {"J":J,"E":E,"F":F,"V":V,"JV":J*V,"C":V.row_join(J*V),
        "pairs":pairs,"pair_lookup":pair_lookup,"S_generators":hopping}


def onebody_on_pairs(h,pairs):
    def delta(i,j):return 1 if i==j else 0
    return S.Matrix(10,10,lambda i,j:
        h[pairs[i][0]-1,pairs[j][0]-1]*delta(pairs[i][1],pairs[j][1])
        -h[pairs[i][0]-1,pairs[j][1]-1]*delta(pairs[i][1],pairs[j][0])
        -h[pairs[i][1]-1,pairs[j][0]-1]*delta(pairs[i][0],pairs[j][1])
        +h[pairs[i][1]-1,pairs[j][1]-1]*delta(pairs[i][0],pairs[j][0]))


def projections(model,W):
    W=(W+W.T)/2;contraction=S.zeros(5)
    lookup=model["pair_lookup"]
    for p in range(1,6):
        for q in range(1,6):
            for r in range(1,6):
                if p==r or q==r:continue
                sign=(1 if p<r else -1)*(1 if q<r else -1)
                contraction[p-1,q-1]+=sign*W[lookup[tuple(sorted((p,r)))],lookup[tuple(sorted((q,r)))]]
    D=onebody_on_pairs(contraction,model["pairs"])/3-S.trace(W)*S.eye(10)/6
    P=S.zeros(10)
    for generator in model["S_generators"]:
        coefficient=sum(a*b for a,b in zip(generator,W))/6
        P+=coefficient*generator
    return D,P


def decode(model,Y):
    R=model["V"].T*Y/5;W=model["JV"].T*Y/5
    D,P=projections(model,W)
    S_theta=D+P;D_theta=-S.Rational(3,4)*D+S.Rational(4,3)*P
    Z=(W-W.T)/2+S_theta;A=(R+R.T)/2
    block=A.row_join(Z.T).col_join(Z.row_join(A-2*D_theta))
    return model["C"]*block*model["C"].T/5
