#!/usr/bin/env python3
"""Exact interval margins at the canceled pole.
Author: Komorebi P.
Run after verify_exact.py. Rational comparisons certify that the canceled root
is neither a pole nor a zero of the reduced complementary cubic impedance.
"""
from pathlib import Path
from fractions import Fraction as R
import json
from mpmath import mp

data = Path(__file__).resolve().parents[1] / 'data'
mp.dps = 185
xa = json.loads((data/'original_cubic_high_precision.json').read_text())
yb = json.loads((data/'dark_solution_high_precision.json').read_text())
x = [R(mp.nstr(mp.mpf(v),112)) for v in xa['components_160digits']]
y = [R(mp.nstr(mp.mpf(v),110)) for v in yb['approximations_160digits']]
rx=R(1,10**80); ry=R(1,10**56)

def add(a,b):return a[0]+b[0],a[1]+b[1]
def mul(a,b):
    v=[a[i]*b[j] for i in (0,1) for j in (0,1)]
    return min(v),max(v)
def point(v):return v,v
def box(v,r):return v-r,v+r
def horner(coefficients,argument):
    value=point(R(0))
    for c in reversed(coefficients):value=add(mul(value,argument),c)
    return value

sb=box(y[14],ry)
B=horner([box(x[j],rx) for j in (3,4,5)]+[point(R(1))],sb)
V=horner([box(x[j],rx) for j in (9,10,11)],sb)
T=add(mul(point(R(4,5)),B),V)
assert -R(169,1000)<B[0] and B[1]<-R(165,1000)
assert R(246,1000)<T[0] and T[1]<R(252,1000)
assert B[1]<0<T[0]
out={'status':'EXACT INTERVAL MARGINS PASSED',
 'B_at_dark_pole_interval':[str(v) for v in B],
 'T_at_dark_pole_interval':[str(v) for v in T],
 'rational_enclosures':{'B':['-169/1000','-165/1000'],'T':['246/1000','252/1000']},
 'first_stage_radius':str(rx),'dark_radius':str(ry),
 'scope':'Conditional on the roots isolated by verify_exact.py; all margin comparisons use exact rational arithmetic.'}
(data/'dark_pole_interval_margins.json').write_text(json.dumps(out,indent=2))
print('B(s0) in (-0.169, -0.165); T(s0) in (0.246, 0.252): exact PASS')
