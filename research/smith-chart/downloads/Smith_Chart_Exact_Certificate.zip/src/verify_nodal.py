#!/usr/bin/env python3
"""Independent nodal solve (not spanning-forest representation) of the two series sections.
Author: Komorebi P. High-precision numerical cross-check, not the exact certificate.
"""
import numpy as np, json,itertools
from pathlib import Path
from mpmath import mp
p=Path(__file__).resolve().parents[1]/'data'; par=p
mp.dps=85
x=list(map(mp.mpf,json.loads((p/'original_cubic_high_precision.json').read_text())['components_160digits']))
y=list(map(mp.mpf,json.loads((p/'dark_solution_high_precision.json').read_text())['approximations_160digits']))

def nodal_section_A(s):
    a,b,c,d,u,v,w=x[12:]
    E=[((0,2),a),((0,3),b+u/s),((1,2),c+v/s),((1,3),w*s),((2,3),d)]
    M=mp.matrix(3)
    for (i,j),ad in E:
        if i:M[i-1,i-1]+=ad
        if j:M[j-1,j-1]+=ad
        if i and j:M[i-1,j-1]-=ad;M[j-1,i-1]-=ad
    return mp.det(mp.matrix([[M[i,j] for j in (1,2)] for i in (1,2)]))/mp.det(M)

edges=list(itertools.combinations(range(5),2));reacts=[('L',8),('L',2),('C',9),('C',4)]
def nodal_section_B(s):
    ye=y[:10].copy()
    for i,(kind,j) in enumerate(reacts):ye[j]+=y[10+i]/s if kind=='L' else y[10+i]*s
    M=mp.matrix(4)
    for e,(i,j) in enumerate(edges):
        z=ye[e]
        if i:M[i-1,i-1]+=z
        if j:M[j-1,j-1]+=z
        if i and j:M[i-1,j-1]-=z;M[j-1,i-1]-=z
    return mp.det(mp.matrix([[M[i,j] for j in (1,2,3)] for i in (1,2,3)]))/mp.det(M)

def target(s):
    P=450*s**6+1385*s**5+2477*s**4+2200*s**3+1142*s**2+335*s+75
    Q=150*s**6+795*s**5+1375*s**4+1720*s**3+1250*s**2+445*s+25
    return P/Q

# Check at frequencies away from poles or zeros using completely separate nodal formulas.
maxerror=mp.mpf(0);worst=None
for w in np.geomspace(0.0001,100,161):
    s=mp.mpc(mp.mpf('0.2'),mp.mpf(str(w)))
    z=nodal_section_A(s)+nodal_section_B(s)
    err=abs(z-target(s))/max(mp.mpf(1),abs(target(s)))
    if err>maxerror:maxerror,worst=err,str(w)
for s in [mp.mpc('1','1'),mp.mpc('0.001','0.003'),mp.mpc('5','7'),mp.mpc('20','0')]:
    err=abs(nodal_section_A(s)+nodal_section_B(s)-target(s))/max(mp.mpf(1),abs(target(s)))
    if err>maxerror:maxerror,worst=err,str(s)
print('independent samples',165,'max scaled error',mp.nstr(maxerror,15),'at',worst)
print('reactive A 2L+1C, B 2L+2C, total 4L+3C')
print('B component normalized values')
for i,z in enumerate(y[:14]):
 print(('g'+str(i)) if i<10 else ('h'+str(i-10)),mp.nstr(z,20))
print('SI, Z0 50ohm and tau 1ns')
for i,z in enumerate(y[:10]):print(f'R_B {edges[i]} =',float(50/z),'ohm')
for i,(kind,edge) in enumerate(reacts):
  z=y[10+i]
  print(f'{kind}_B {edges[edge]} =',float(50/z) if kind=='L' else float(20*z),'nH' if kind=='L' else 'pF')
assert maxerror<mp.mpf('1e-70')
(p/'independent_nodal_check.json').write_text(json.dumps({'samples':165,'max_scaled_error_85digit_center':mp.nstr(maxerror,24),'error_definition':'abs(Z_A_nodal + Z_B_nodal - Z6) / max(1, abs(Z6))','worst':worst,'state':'independent numerical cross-check passed; rigorous proof is rational contraction system'},indent=2))
