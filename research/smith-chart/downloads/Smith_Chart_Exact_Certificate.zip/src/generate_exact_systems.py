#!/usr/bin/env python3
"""Regenerate every SymPy polynomial system directly from circuit graph and target.
Author: Komorebi P. Pure exact algebra; no numerical fitting, no external files.
"""
import sympy as sp, pickle, itertools, sys
from pathlib import Path
p=Path(__file__).resolve().parents[1]/'data' if __file__.endswith('/src/generate_exact_systems.py') else Path(__file__).resolve().parent
p.mkdir(parents=True,exist_ok=True)
s=sp.Symbol('s')
P=450*s**6+1385*s**5+2477*s**4+2200*s**3+1142*s**2+335*s+75
Q=150*s**6+795*s**5+1375*s**4+1720*s**3+1250*s**2+445*s+25
# 19-variable cubic extraction + first passive circuit.
xx=sp.symbols('a0 a1 a2 b0 b1 b2 x0 x1 x2 y0 y1 y2 gA gB gC gD hL1 hL2 hC')
A=s**3+xx[2]*s**2+xx[1]*s+xx[0];B=s**3+xx[5]*s**2+xx[4]*s+xx[3]
U=xx[8]*s**2+xx[7]*s+xx[6];V=xx[11]*s**2+xx[10]*s+xx[9]
a,b,c,d,u,v,w=xx[12:]
# Direct grounded nodal determinant on port node 1 and internal 2,3.
Y=sp.zeros(3)
for (i,j),ad in [((0,2),a),((0,3),b+u/s),((1,2),c+v/s),((1,3),w*s),((2,3),d)]:
    if i>0:Y[i-1,i-1]+=ad
    if j>0:Y[j-1,j-1]+=ad
    if i>0 and j>0:Y[i-1,j-1]-=ad;Y[j-1,i-1]-=ad
NA=sp.cancel(s**2*Y.minor_submatrix(0,0).det());DA=sp.cancel(s**2*Y.det())
F19=[sp.expand(A*B-Q/150).coeff(s,i) for i in range(6)] + [sp.expand(U*B+V*A-(P-3*Q)/150).coeff(s,i) for i in range(6)] + [sp.expand(NA*A-DA*(sp.Rational(11,5)*A+U)).coeff(s,i) for i in range(7)]
assert len(F19)==19
with (p/'cubic_symbolic.pkl').open('wb') as f:pickle.dump((xx,F19,sp.Matrix(F19).jacobian(xx)),f)
print('cubic 19 equations',flush=True)
# Graph q4: 5 nodes; every edge contains a resistor. A separate L or C can parallel R.
n=5;edges=list(itertools.combinations(range(n),2));g=sp.symbols('g0:10');h=sp.symbols('h0:4');pars=g+h
react=[('L',8),('L',2),('C',9),('C',4)]

def forest_info(sel):
    parent=list(range(n))
    def find(x):
        while parent[x]!=x:
            x=parent[x]
        return x
    for k in sel:
        i,j=edges[k];parent[find(i)]=find(j)
    return len({find(i) for i in range(n)}),find(0)!=find(1)

def edge_factor(idx):
    coeff={0:g[idx]}
    for j,(kind,ei) in enumerate(react):
        if ei==idx:coeff[1 if kind=='C' else -1]=h[j]
    return coeff

def polyforest(sels):
    coeff={k:sp.Integer(0) for k in range(5)}
    for sub in sels:
        local={0:sp.Integer(1)}
        for edge in sub:
            src=edge_factor(edge);nxt={}
            for k,v in local.items():
                for kk,vv in src.items():nxt[k+kk]=nxt.get(k+kk,0)+v*vv
            local=nxt
        for k,v in local.items():coeff[k+2]+=v
    return [sp.expand(coeff[k]) for k in range(5)]
tr=[sel for sel in itertools.combinations(range(10),4) if forest_info(sel)[0]==1]
fo=[sel for sel in itertools.combinations(range(10),3) if forest_info(sel)==(2,True)]
D=polyforest(tr);N=polyforest(fo)
Bsym=sp.symbols('B0:4');Tsym=sp.symbols('T0:4')
F8=[]
for k in range(8):F8.append(sp.expand(sum(N[j]*Bsym[k-j]-D[j]*Tsym[k-j] for j in range(5) if 0<=k-j<=3)))
# Original active selection and six positive fixed resistor conductances.
picked=[3,5,6,7,10,11,12,13];fixed=sorted(set(range(14))-set(picked))
with (p/'q4_symbolic.pkl').open('wb') as f:pickle.dump((pars,N,D,edges,react,Bsym,Tsym,F8,picked,fixed),f)
print('quartic network 8 equations',len(tr),'trees',len(fo),'forests',flush=True)
# Lift the cancellation as a null vector of grounded rY(r), with zero port coordinate.
r,alpha,beta=sp.symbols('r alpha beta')
Yn=sp.zeros(4)
for k,(i,j) in enumerate(edges):
    adm=r*g[k]
    for kk,(kind,ei) in enumerate(react):
        if ei==k:adm+=h[kk] if kind=='L' else h[kk]*r**2
    if i>0:Yn[i-1,i-1]+=adm
    if j>0:Yn[j-1,j-1]+=adm
    if i>0 and j>0:Yn[i-1,j-1]-=adm;Yn[j-1,i-1]-=adm
G11=F8[:7]+[sp.expand(t) for t in Yn*sp.Matrix([0,alpha,1,beta])]
allvars=pars+(r,alpha,beta)
with (p/'dark_system.pkl').open('wb') as f:pickle.dump((allvars,G11,Bsym,Tsym,edges,react),f)
print('dark-mode lifted 11 equations',flush=True)
