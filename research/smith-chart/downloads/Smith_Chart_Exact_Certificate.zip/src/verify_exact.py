#!/usr/bin/env python3
"""Exact rational proof of passive transformer-free 7-reactive realization.
Two nested fixed-point certificates: 19-variable cubic extraction, then 11-variable
4-reactive network plus port-dark-mode. Author: Komorebi P.
Run with CPython + sympy + mpmath. No plotting and no numerical acceptance tolerances.
"""
import json, math, pickle, sys, time
from fractions import Fraction as R
from pathlib import Path
import sympy as sp
from mpmath import mp

P=Path(__file__).resolve().parents[1]/'data'; O=P;mp.dps=185

def rat(x, sig=110):
    return R(mp.nstr(mp.mpf(x),sig))

def absupper(x):
    return math.ceil(abs(x)) + 1

def loadterms(exprs,vars,subs=None):
    res=[]
    for e in exprs:
        if subs: e=e.subs(subs)
        p=sp.Poly(e,*vars,domain='QQ')
        res.append([(tuple(m),R(int(c.p),int(c.q))) for m,c in p.terms()])
    return res

def powers(center,maxpow):
    return [[x**k for k in range(maxpow+1)] for x in center]

def evalFJ(terms,center,active):
    nx=len(center);nr=len(terms)
    maxpow=max(z for eq in terms for ex,c in eq for z in ex)
    powv=powers(center,maxpow)
    ff=[R(0)]*nr; J=[[R(0) for j in active] for i in range(nr)]
    for i,eq in enumerate(terms):
      for e,c in eq:
        v=c
        for j,k in enumerate(e):
            if k:v*=powv[j][k]
        ff[i]+=v
        for j,a in enumerate(active):
            if e[a]:J[i][j]+=v*e[a]/center[a]
    return ff,J

def upper_global(terms,center):
    Mi=[max(2,absupper(t)) for t in center]
    # Coarse but exact bound for all variable partials and Hessian norm.
    vals=[];jac=[];hess=[]
    for eq in terms:
        vv=R(0);jj=R(0);hh=R(0)
        for ex,c in eq:
            term=abs(c)
            for j,k in enumerate(ex):
                if k:term*=Mi[j]**k
            deg=sum(ex);vv+=term;jj+=term*deg;hh+=term*deg*(deg-1)
        vals.append(vv);jac.append(jj);hess.append(hh)
    return max(vals),max(jac),max(hess)

def evaluate_certificate(label,terms,center,active,ratinverse_digits,radius):
    t0=time.time(); n=len(active);assert n==len(terms)
    F,J=evalFJ(terms,center,active)
    JJ=mp.matrix([[mp.mpf(v.numerator)/v.denominator for v in row] for row in J])
    inv=JJ**-1
    MM=[[rat(inv[i,j],ratinverse_digits) for j in range(n)] for i in range(n)]
    bnorm=R(0); q0=R(0);delta=R(0)
    for i in range(n):
        row_norm=sum((abs(v) for v in MM[i]),R(0));bnorm=max(bnorm,row_norm)
        eps=sum((MM[i][j]*F[j] for j in range(n)),R(0));delta=max(delta,abs(eps))
        mat_err=R(0)
        for j in range(n):
            ij=sum((MM[i][k]*J[k][j] for k in range(n)),R(0))
            mat_err+=abs((R(1) if i==j else R(0))-ij)
        q0=max(q0,mat_err)
    Mval,Mjac,H=upper_global(terms,center)
    q=q0+bnorm*H*radius
    print(f'[{label}]',n,'terms',sum(map(len,terms)),'invnorm',float(bnorm),'H',float(H),'q0',float(q0),'delta',float(delta),'delta/r',float(delta/radius),'q',float(q),'seconds',round(time.time()-t0,2),flush=True)
    assert q<1 and delta+q*radius<radius, 'contraction cannot be certified'
    return {'name':label,'n':n,'terms':sum(map(len,terms)),'radius':str(radius),'inverse_norm_upper':float(bnorm),'hessian_global_upper':float(H),'q0_upper':float(q0),'q_upper':float(q),'offset_over_radius_upper':float(delta/radius)},(bnorm,q0,delta,H)

orig_names,orig_exprs,_=pickle.load(open(P/'cubic_symbolic.pkl','rb'))
orig_hp=json.loads((O/'original_cubic_high_precision.json').read_text())['components_160digits']
xcenter=[rat(v,112) for v in orig_hp]
assert len(xcenter)==19 and all(v!=0 for v in xcenter)
assert min(xcenter[12:])>R(1,10**80), 'first-stage component positivity failed'
term19=loadterms(orig_exprs,orig_names)
print('built terms19',flush=True)
first,met19=evaluate_certificate('original cubic',term19,xcenter,list(range(19)),73,R(1,10**80))

allvars,G11,Bsym,Tsym,edges,reacts=pickle.load(open(O/'dark_system.pkl','rb'))
dark_hp=json.loads((O/'dark_solution_high_precision.json').read_text())
ycenter=[rat(v,110) for v in dark_hp['approximations_160digits']]
active=dark_hp['active_indices'];fix=dark_hp['fixed_indices']
assert len(ycenter)==17 and all(v!=0 for v in ycenter)
assert len(active)==len(set(active))==11 and len(fix)==len(set(fix))==6
assert set(active).isdisjoint(fix) and set(active)|set(fix)==set(range(17))
assert set(fix)<=set(range(10)), 'fixed coordinates must be resistor conductances'
# substitute algebraic target coefficients at rational centers of first theorem
bs=[xcenter[3],xcenter[4],xcenter[5],R(1)]
ts=[R(4,5)*bs[j]+(xcenter[9+j] if j<3 else R(0)) for j in range(4)]
sub={u:sp.Rational(v.numerator,v.denominator) for u,v in zip(Bsym,bs)}
sub.update({u:sp.Rational(v.numerator,v.denominator) for u,v in zip(Tsym,ts)})
terms11=loadterms(G11,allvars,sub)
print('built terms11',sum(map(len,terms11)),flush=True)

# Whole-system target can vary over original 19-box, so add rigorous parameter perturbation.
second,(bnorm,q0,delta,H)=evaluate_certificate('dark 11 at fixed original center',terms11,ycenter,active,70,R(1,10**56))
# uniform errors in B0-2 and T0-2 due to deviation <=10^-80 in original cubic coefficients
rr=R(1,10**80);rad=R(1,10**56)
base=pickle.load(open(P/'q4_symbolic.pkl','rb'))
network_vars,N,D=base[:3]
Nterms=loadterms(N,network_vars); Dterms=loadterms(D,network_vars)
MvN,MjN,_=upper_global(Nterms,ycenter[:14]); MvD,MjD,_=upper_global(Dterms,ycenter[:14])
# if |B_j-B_j_center|<=rx, |T_j-T_j_center|<= (4/5+1)rx = 9/5 rx
# each of 7 coefficient residuals has no more than 3 N, D contributions
param_F=(R(3)*MvN+R(27,5)*MvD)*rr
# Jacob row 1-norm, bounded by derivatives summed over the 11 active coordinates
param_J=R(len(active))*(R(3)*MjN+R(27,5)*MjD)*rr
q_uni=q0+bnorm*(H*rad+param_J)
d_uni=delta+bnorm*param_F
print('parameter bounds',float(MvN),float(MvD),float(MjN),float(MjD),'q_uni',float(q_uni),'delta/r_uni',float(d_uni/rad),flush=True)
assert q_uni<1 and d_uni+q_uni*rad<rad
assert min(ycenter[:14])>rad
assert (ycenter[14]+rad)<0 and (ycenter[14]-rad)!=0
# Ground truth: polynomial identity after dark mode because F_7 coefficient forced zero.
# The graph F_0...F_6=0, and Y(r)[0,w2,1,w4]=0 implies N(r)=D(r)=0.
# Consequently F(r)=0. Since F(s) is multiple of s^7 and r is nonzero, F_7=0.
assert len(G11)==11 and len(base[7])==8
report={'status':'EXACT CERTIFICATE PASSED','author':'Komorebi P.',
 'result':'7-reactive transformer-free RLC realization of degree-six filtered-LC impedance',
 'construction':'series sum of certified degree-3 ZA with (2 inductors,1 capacitor) and certified degree-3 ZB with (2 inductors,2 capacitors)',
 'theorem1':first,'theorem2_fixed_center':second,'theorem2_uniform':{'radius':str(rad),'uncertainty_original':str(rr),'q_upper':float(q_uni),'offset_over_radius_upper':float(d_uni/rad), 'parameter_value_upper':float(param_F),'parameter_jacobian_upper':float(param_J), 'positive_component_lower_bound':str(min(ycenter[:14])-rad), 'dark_pole_nonzero':True},'topology':{'edges':edges,'reactives':reacts,'fixed_indices':fix,'active_indices':active},'limitations':'Proves upper bound q<=7, not absence of a 6-reactive network; no originality claim.'}
(O/'seven_reactive_exact_certificate.json').write_text(json.dumps(report,indent=2))
print('SEVEN-REACTIVE EXACT CERTIFICATION COMPLETED',flush=True)
