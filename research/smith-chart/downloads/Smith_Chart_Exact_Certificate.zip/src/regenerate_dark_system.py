"""Augmented 7 coefficient constraints plus exact dark-mode equations; no hidden square issue.
Author: Komorebi P.
"""
from pathlib import Path
import sympy as sp,pickle
p=Path(__file__).resolve().parents[1]/'data'
o=p
v,N,D,edges,reacts,Bsym,Tsym,F,pick,fix=pickle.load(open(p/'q4_symbolic.pkl','rb'))
r,w2,w4=sp.symbols('r w2 w4')
volt=[sp.Integer(0),w2,sp.Integer(1),w4] # node 1 through 4
assert len(v)==14
# polynomial r*Y(r) 
Y=sp.zeros(4)
for i,(a,b) in enumerate(edges):
    val=v[i]*r
    for j,(kind,ei) in enumerate(reacts):
        if ei==i:val+=v[10+j] if kind=='L' else v[10+j]*r**2
    if a>0:Y[a-1,a-1]+=val
    if b>0:Y[b-1,b-1]+=val
    if a>0 and b>0:Y[a-1,b-1]-=val;Y[b-1,a-1]-=val
full=sp.expand(Y*sp.Matrix(volt))
G=[sp.expand(f) for f in F[:7]]+[sp.expand(t) for t in full]
unknown=v+(r,w2,w4)
print('equations',len(G),'unknown',len(unknown),'terms',sum(len(sp.Poly(f,*unknown).terms()) for f in G),flush=True)
with open(o/'dark_system.pkl','wb') as ff:pickle.dump((unknown,G,Bsym,Tsym,edges,reacts),ff)
