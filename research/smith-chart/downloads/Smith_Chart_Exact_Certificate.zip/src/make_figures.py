#!/usr/bin/env python3
"""Python/Matplotlib figures for exact seven-reactive certificate. Author: Komorebi P."""
import json, itertools
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, Circle
P=Path(__file__).resolve().parents[1]/'data';out=P.parent/'figures';out.mkdir(exist_ok=True)
Acoords={0:(0,0),1:(0,2.4),2:(2.8,2.0),3:(2.8,0.3)}
Bcoords={0:(0,0),1:(0,2.5),2:(2.3,2.7),3:(3.6,1.4),4:(2.3,-.3)}
fig,ax=plt.subplots(1,2,figsize=(14,6.6),dpi=145,gridspec_kw={'width_ratios':[0.93,1.07]})
for a in ax:a.set_aspect('equal');a.axis('off')

def basegraph(a,coords,edges,title,subtitle):
 for u,v in edges:
  x,y=coords[u];X,Y=coords[v]
  a.plot([x,X],[y,Y],alpha=.36,lw=2.4,zorder=1)
 for i,(x,y) in coords.items():
  a.add_patch(Circle((x,y),.16,facecolor='white',edgecolor='black',lw=1.6,zorder=10))
  a.text(x,y,str(i),ha='center',va='center',fontsize=12,weight='bold',zorder=11)
 a.set_title(title,fontsize=16,weight='semibold',pad=20)
 a.text(0.5,-0.12,subtitle,transform=a.transAxes,ha='center',va='top',fontsize=10.6)
 a.set_xlim(-.6,max(p[0] for p in coords.values())+.55)
 a.set_ylim(-.6,max(p[1] for p in coords.values())+.55)

def addreact(a,coords,edge,k,label,rad,offset=(0,0)):
 u,v=edge
 x,y=coords[u];X,Y=coords[v]
 arrow=FancyArrowPatch((x,y),(X,Y),connectionstyle=f'arc3,rad={rad}',arrowstyle='-',linewidth=3.5,mutation_scale=10,zorder=5)
 a.add_patch(arrow)
 mx,my=(x+X)/2,(y+Y)/2
 dx,dy=X-x,Y-y;norm=np.hypot(dx,dy)
 mx+=(-dy/norm)*rad*norm/2 +offset[0];my+=(dx/norm)*rad*norm/2+offset[1]
 a.text(mx,my,label,fontsize=12,ha='center',va='center',fontweight='bold',bbox={'facecolor':'white','alpha':.9,'edgecolor':'none','pad':2},zorder=7)

basegraph(ax[0],Acoords,[(0,2),(0,3),(1,2),(1,3),(2,3)],'Section A · 3 reactive elements','2 inductors + 1 capacitor · 4 resistors')
addreact(ax[0],Acoords,(0,3),'L','L₁',-.24,offset=(0,-.16))
addreact(ax[0],Acoords,(1,2),'L','L₂',.27,offset=(.05,.15))
addreact(ax[0],Acoords,(1,3),'C','C₁',-.25,offset=(.18,.05))

basegraph(ax[1],Bcoords,list(itertools.combinations(range(5),2)),'Section B · 4 reactive elements','2 inductors + 2 capacitors · 10 resistors')
addreact(ax[1],Bcoords,(2,4),'L','L₃',-.25,offset=(.24,.03))
addreact(ax[1],Bcoords,(0,3),'L','L₄',.29,offset=(.0,-.16))
addreact(ax[1],Bcoords,(3,4),'C','C₂',.30,offset=(.15,.01))
addreact(ax[1],Bcoords,(1,2),'C','C₃',-.30,offset=(.02,.19))
fig.text(.5,.02,'Series connect the two input one-ports. Faint edges are positive resistors; labeled arcs are additional reactive branches.',ha='center',fontsize=10.8)
fig.subplots_adjust(left=.025,right=.975,top=.87,bottom=.16,wspace=.16)
fig.savefig(out/'39_seven_reactive_graphs.png',bbox_inches='tight');plt.close(fig)

# Pole-zero map of exact quartic network with cancellation.
from mpmath import mp
import sympy as sp,pickle
mp.dps=55
p=P
v,N,D,_,_,_,_,_,_,_=pickle.load(open(p/'q4_symbolic.pkl','rb'))
y=list(map(mp.mpf,json.loads((P/'dark_solution_high_precision.json').read_text())['approximations_160digits']))
ff=sp.lambdify(v,N+D,'mpmath');coef=ff(*y[:14]);num=np.array([float(c) for c in coef[:5]][::-1]);den=np.array([float(c) for c in coef[5:]][::-1]);
zeros=np.roots(num);poles=np.roots(den);dark=float(y[14]);
fig,ax=plt.subplots(figsize=(10,5.4),dpi=155)
ax.axhline(0,lw=.85,alpha=.55);ax.axvline(0,lw=.85,alpha=.4)
ax.scatter(zeros.real,zeros.imag,marker='o',facecolors='white',edgecolors='C0',linewidths=2.6,s=110,label='Quartic numerator zero',zorder=4)
ax.scatter(poles.real,poles.imag,marker='x',color='C1',s=125,linewidths=2.8,label='Quartic denominator pole',zorder=5)
ax.scatter([dark],[0],facecolors='none',edgecolors='C3',s=650,linewidth=2.0,zorder=6)
ax.annotate('Exact common factor\n(port-dark mode)',(dark,0),xytext=(-.95,-.76),arrowprops={'arrowstyle':'->','lw':1.4},fontsize=11,ha='center')
ax.set_xlim(-1.62,.16);ax.set_ylim(-1.45,1.45)
ax.set_xlabel('Real(s)');ax.set_ylabel('Imag(s)');ax.set_title('Why the four-state network has a cubic driving-point impedance',fontsize=15,pad=14)
ax.legend(loc='upper left',fontsize=9)
ax.grid(alpha=.12);fig.tight_layout()
fig.savefig(out/'40_dark_pole_cancellation.png',bbox_inches='tight');plt.close(fig)
print('saved figures',*[str(x) for x in out.glob('*.png')],sep='\n')
