#!/usr/bin/env python3
"""Exact-rational rank-two certificate for the port-dark internal 3x3 block.
Author: Komorebi P. Uses verified 10^-56 component box from main theorem.
"""
import json,itertools
from pathlib import Path
from fractions import Fraction as R
p=Path(__file__).resolve().parents[1]/'data' if __file__.endswith('/src/check_dark_mode_rank.py') else Path(__file__).resolve().parent
rec=json.loads((p/'dark_solution_high_precision.json').read_text())['approximations_160digits']
# Round to 110-significant-figure exact rational center exactly as in the main verifier.
from mpmath import mp
mp.dps=185
y=[R(mp.nstr(mp.mpf(v),110)) for v in rec]
r=y[14];eps=R(1,10**56)
assert -R(198,1000)<r-eps and r+eps<-R(197,1000)
assert max(y[10:12])+eps<2 and max(y[12:14])+eps<5
E=list(itertools.combinations(range(5),2));react=[('L',8),('L',2),('C',9),('C',4)]
M=[[R(0) for j in range(4)] for i in range(4)]
for k,(i,j) in enumerate(E):
   val=y[k]
   for kk,(kind,ei) in enumerate(react):
       if ei==k:val+=y[10+kk]/r if kind=='L' else y[10+kk]*r
   if i:M[i-1][i-1]+=val
   if j:M[j-1][j-1]+=val
   if i and j:M[i-1][j-1]-=val;M[j-1][i-1]-=val
# Internal nodes 2 and 3 correspond to indices 1,2 of grounded Y.
det=M[1][1]*M[2][2]-M[1][2]**2
print('center internal 2x2 determinant:',float(det))
assert det < -42
# Every admittance y_e has variation <=101 eps in the certified box:
# g: <=eps. On L edge 1/s: |s|>.197 and |h|<2 yields <60eps,
# on C edge h*s: |h|<5, |s|<.2 => <6eps. Thus <=101eps.
# Each grounded Y entry changes by at most 4*101eps<500eps.
# At center, each relevant Y entry has |.|<100 (checked exactly).
assert max(abs(M[i][j]) for i in [1,2] for j in [1,2])<100
eps=R(1,10**56);dev=R(500)*eps
# determinant difference <= 4*100*dev+2*dev^2 (one product, one square)
bound=R(400)*dev+2*dev*dev
assert abs(det)>42+bound
print('uniform internal minor < -42 across certified cube: PASS')
print('rank(Y_internal(r))=2 exactly (dark nullvector nonzero gives rank<=2)')
