# Exact seven reactive element certificate

Author: Komorebi P.  
Unpublished. Replayed and checked on 11 November 2026.

This package establishes an exact transformer-free passive RLC realization of the degree-six target using four inductors, three capacitors, and fourteen positive resistors. The reduced input degree is six. The supported minimum-count interval is therefore 6 ≤ q_min ≤ 7. The six-element case remains open.

## Reproduce

Use Python with SymPy, mpmath, and NumPy. Run from this directory:

```text
python src/generate_exact_systems.py
python src/verify_exact.py
python src/check_dark_mode_rank.py
python src/verify_interval_margins.py
python src/verify_nodal.py
```

The first command constructs every symbolic system from the graph definitions. It creates the local serialized intermediates needed by the subsequent commands. The delivered inputs are transparent source and JSON rational centers.

`verify_exact.py` checks the two nested rational fixed-point certificates and explicit positivity/coordinate guards. The second-stage test includes uniform uncertainty of the first-stage algebraic coefficients. `check_dark_mode_rank.py` checks the nonzero internal minor. `verify_interval_margins.py` certifies that the reduced target's numerator and denominator are nonzero at the canceled pole. All acceptance inequalities in these three programs use rational arithmetic.

`verify_nodal.py` independently evaluates the nodal circuits at 165 complex right-half-plane points. Its reported error is abs(computed − target) / max(1, abs(target)) at every point. This finite high-precision regression is distinct from the exact existence proof.

The approximate component table in the reading is for orientation. Exact components are the isolated algebraic roots defined by these polynomial systems, boxes, and fixed rational conductances.

## Circuit assembly

Each section is analyzed with its own local nodes 0 and 1. For the series connection, identify 0_A with 1_B. Drive 1_A and ground 0_B. Do not identify the two section-local node-zero references.

## Optional figures

With Matplotlib installed, `python src/make_figures.py` regenerates the two focused circuit figures. The complete reading also supplies a separate Python construction-map script.

No hardware measurement, SPICE validation, six-element exclusion, resistor minimality, or historical priority claim is made.
