"""Author: Komorebi P. Separate the former degree-ten timeout into stages."""
from pathlib import Path
import sys,time,json
from fractions import Fraction as F
B=Path(__file__).resolve().parents[1]
OLD=B/'prior_release/smith_hughes_generalization'
sys.path.insert(0,str(OLD/'src'))
from algebraic_inverse import v,extended,extract
from local_core import certify_neighbourhood
from recover_components import recover,verify_core_certificate
k=4;P=list(map(F,v.P));Q=list(map(F,v.Q))
for j in range(k):P,Q=extended(P,Q,'RC' if j%2==0 else 'RL',21+j)
eps=F(1,10**(22+5*k))
P=[c+eps*(j+1)*(-1)**j for j,c in enumerate(P)]
Q=[c+eps*(j+2)*(-1)**(j+1) if j<len(Q)-1 else c for j,c in enumerate(Q)]
target={'P':list(map(str,P)),'Q':list(map(str,Q))}
(B/'examples/independent_degree_10_input.json').write_text(json.dumps(target,indent=2))
t=time.perf_counter();print('starting extraction',flush=True)
result=extract(P,Q);print('extraction',result['status'],time.perf_counter()-t,flush=True)
(B/'examples/independent_degree_10.json').write_text(json.dumps(result,indent=2))
t=time.perf_counter();core=certify_neighbourhood();print('uniform inverse',core['status'],time.perf_counter()-t,flush=True)
t=time.perf_counter();print('starting fresh core recovery',flush=True)
cert=recover(result);print('recovery',cert.get('status'),time.perf_counter()-t,flush=True)
(B/'results/independent_degree_10_component_certificate.json').write_text(json.dumps(cert,indent=2))
print('replay',verify_core_certificate(cert,result),flush=True)
