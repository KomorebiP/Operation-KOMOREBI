# Interrupted development experiments

**Author: Komorebi P.**

These are provenance, not the recommended reproduction commands. They exercise the old extractor that failed to complete and the failed diagnostic profiler. Running benchmark_degree_ten.py may overwrite generated example/result files. Use a disposable copy if reproducing these failures. Run the supported scripts in src/ for certificate replay. Logs are retained in results/failures/.
