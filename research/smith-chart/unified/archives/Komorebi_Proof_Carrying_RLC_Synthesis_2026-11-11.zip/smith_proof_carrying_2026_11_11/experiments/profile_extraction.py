"""Author: Komorebi P. Interrupted diagnostic experiment, not an acceptance test."""
import sys,json,time,faulthandler
from pathlib import Path
B=Path(__file__).resolve().parents[1];sys.path.insert(0,str(B/'prior_release/smith_hughes_generalization/src'))
from algebraic_inverse import extract
faulthandler.dump_traceback_later(5,repeat=True)
a=json.loads((B/'examples/independent_degree_10_input.json').read_text())
t=time.perf_counter();r=extract(a['P'],a['Q']);print('done',time.perf_counter()-t,r['status'])
