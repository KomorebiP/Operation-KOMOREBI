# Results summary

**Author: Komorebi P.**  
**Date: 11 November 2026**

## Completed

The independent verification layer now accepts exact rational polynomial infeasibility identities and exact real-algebraic component witnesses. Target, budget and topology scope are bound to the proof. A complete q-1 refutation plus a q-component witness suffices for minimum storage. The proof languages are based on classical real algebraic geometry; automatic discovery remains limited.

The package independently replays 18 certificate artifacts with third-party packages disabled. Its 30 portable and 12 integration methods pass, 42 methods total. Deliberate corruptions, a wrong cubic target, missing proof terms, bad algebraic intervals, excessive budgets and misleading scope are rejected.

The old degree-ten local timeout is replaced by a completed exact Sturm/dyadic extraction and a fresh positive core certificate at radius `1e-40`. Directly perturbed degree12/16/20 inputs also enter the independently verified uniform core neighborhood. These inputs use very small coefficient perturbations and are not a general-target benchmark.

A classical real-pole route resolves the earlier small generic-timeout examples with minimum storage one and two. Hughes's degree-two/five-storage example has an independently checked algebraic-circuit upper witness; its exact lower bound still comes from his published theorem.

## Not completed

No general efficient unrestricted minimum synthesis is established. A new full mixed-RLC degree-two/budget-two SMT attempt still returns UNKNOWN at the selected 500ms limit. The generated higher-budget refutations are signature restricted, not global mixed-RLC lower bounds. There is no general automatic mixed-RLC SOS/ideal refutation generator and no tested generic algebraic-target-coefficient API.

## Audit fixes and failures

The final audit fixed a zero-budget resistor-signature scope bug before packaging and added its exact regression. An unsupported enlargement of the local coefficient radius is now rejected. The old bounded extractor and profiler did not complete successfully. A combined integration run was interrupted; both final partitions completed. Full details and logs are retained rather than hidden.

## Interpretation

The main advance is a checkable proof layer and improved coverage by complementary synthesis routes. It is not a claim that an arbitrary solver rejection is valid, that every degree-n impedance needs n storage elements, or that the general search problem has become tractable.
