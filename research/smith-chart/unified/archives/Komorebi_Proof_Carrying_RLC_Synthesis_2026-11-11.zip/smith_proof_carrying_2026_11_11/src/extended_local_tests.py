"""Author: Komorebi P. Independent coefficient perturbations above degree ten."""
from pathlib import Path
from fractions import Fraction as F
import json,time
from fast_algebraic_inverse import extract_fast,v
B=Path(__file__).resolve().parents[1]

def extend(P,Q,kind,a):
    pp=[F(0)]*(len(P)+1);qq=[F(0)]*(len(Q)+1)
    for j,c in enumerate(P):pp[j]+=a*c;pp[j+1]+=c
    for j,c in enumerate(Q):qq[j]+=a*c;qq[j+1]+=c;pp[j+(kind=='RL')]+=c
    return pp,qq

def target(n):
    k=n-6;P=list(map(F,v.P));Q=list(map(F,v.Q))
    for j in range(k):P,Q=extend(P,Q,'RC' if j%2==0 else 'RL',21+j)
    eps=F(1,10**(22+5*k))
    P=[c+eps*(j+1)*(-1)**j for j,c in enumerate(P)]
    Q=[c+eps*(j+2)*(-1)**(j+1) if j<len(Q)-1 else c for j,c in enumerate(Q)]
    return {'P':list(map(str,P)),'Q':list(map(str,Q))}

if __name__=='__main__':
    reports=[]
    for n in [12,16,20]:
        a=target(n);(B/f'examples/independent_degree_{n}_input.json').write_text(json.dumps(a,indent=2))
        print('starting',n,flush=True);t=time.perf_counter()
        try:
            r=extract_fast(a['P'],a['Q'])
            (B/f'examples/independent_degree_{n}_fast.json').write_text(json.dumps(r,indent=2))
            report={'degree':n,'status':r['status'],'seconds':time.perf_counter()-t,'max_core_deviation':r['readable_max_core_deviation'],
                    'claim':'Deflation into the independently replayed uniform core box, not fresh component-center certification'}
        except Exception as e:report={'degree':n,'status':'NOT_CERTIFIED','exception':repr(e),'seconds':time.perf_counter()-t}
        reports.append(report);(B/'results/extended_local_tests.json').write_text(json.dumps(reports,indent=2))
        print(report,flush=True)
