"""Author: Komorebi P. Generate portable exact certificate fixtures."""
from pathlib import Path
from fractions import Fraction as F
import json,time
from polynomial_budget import zero_storage_refutation,monotonic_refutation,check_circuit_refutation,compile_budget
from algebraic_witness import verify_algebraic_circuit,verify_minimality_bundle
from real_algebraic import RealField
from real_pole_synthesis import synthesize_real_poles
B=Path(__file__).resolve().parents[1]

def save(name,obj):
    (B/'examples'/name).write_text(json.dumps(obj,indent=2))

def circuit(P,Q,q,f,interval,branches):
    return {'format':'komorebi-algebraic-circuit-v1','target':{'P':P,'Q':Q},'storage_budget':q,
        'field':{'polynomial':f,'interval':interval},
        'branches':[{'type':t,'nodes':[a,b],'coefficient':list(map(str,p))} for t,a,b,p in branches]}

def main():
    reports={}
    specs=[('all_topology_zero_storage',dict(P=[1],Q=[2,1],q=0))]
    for q in [1,2,3,6]:
        specs += [(f'RC_exclusion_q{q}',dict(P=[1,1],Q=[2,1],q=q,types=['g','c'])),
                  (f'RL_exclusion_q{q}',dict(P=[3,1],Q=[2,1],q=q,types=['g','h']))]
    for label,spec in specs:
        t=time.perf_counter();proof=zero_storage_refutation(spec) if spec['q']==0 else monotonic_refutation(spec)
        report=check_circuit_refutation(spec,proof);report['seconds']=time.perf_counter()-t
        save(label+'.json',{'problem':spec,'proof':proof});reports[label]=report
    circuits={}
    circuits['quadratic_algebraic_RC']=circuit([20,14,2],[7,6,1],2,[-2,0,1],[1,'3/2'],[
        ('g',1,2,[3,-1]),('c',1,2,[1]),('g',2,3,[3,1]),('c',2,3,[1]),('g',0,3,['1/2'])])
    K=RealField([-2,0,1],[1,'3/2']);t=K.element([0,1]);a=3-t;b=3+t
    rho=1/(2*t);u=rho/b;r0=2-u
    circuits['quadratic_algebraic_mixed']=circuit([15,12,2],[7,6,1],2,[-2,0,1],[1,'3/2'],[
        ('g',1,2,(a/rho).p),('c',1,2,(1/rho).p),('g',2,3,(1/u).p),
        ('h',2,3,(b/u).p),('g',0,3,(1/r0).p)])
    circuits['cubic_algebraic_RC']=circuit([96,69,15,1],[51,45,12,1],3,[1,-3,0,1],[0,'1/2'],[
        ('g',1,2,[4,1]),('c',1,2,[1]),('g',2,3,[2,0,1]),('c',2,3,[1]),
        ('g',3,4,[6,-1,-1]),('c',3,4,[1]),('g',0,4,[1])])
    circuits['Hughes_hidden_modes_upper']=circuit(['2/3','1/2',1],['3/2','1/3',1],5,[0,1],[-1,1],[
        ('h',1,2,[1]),('g',0,2,['9/4']),('g',1,3,[1]),('h',2,4,['31/8']),
        ('h',3,4,['186/169']),('c',3,4,['186/169']),('c',0,4,['31/8'])])
    circuits['one_RC_rational']=circuit([1],[2,1],1,[0,1],[-1,1],[('g',0,1,[2]),('c',0,1,[1])])
    for name,c in circuits.items():
        t0=time.perf_counter();r=verify_algebraic_circuit(c);r['seconds']=time.perf_counter()-t0
        save(name+'.json',c);reports[name]=r
    spec=specs[0][1]
    bundle={'target':{'P':[1],'Q':[2,1]},'q':1,'witness':circuits['one_RC_rational'],
        'lower_budget_refutation':{'problem':spec,'proof':zero_storage_refutation(spec)}}
    save('two_sided_minimum_one.json',bundle);reports['two_sided_minimum_one']=verify_minimality_bundle(bundle)
    # These two targets timed out on the previous generic path. The route is now constructive.
    for label,P,Q in [('former_timeout_one',[3,1],[2,1]),('former_timeout_two',[7,8,2],[2,3,1]),
                      ('irrational_mixed_real_poles',[15,12,2],[7,6,1])]:
        t0=time.perf_counter();out=synthesize_real_poles(P,Q);reports[label]={**out['verification'],'seconds':time.perf_counter()-t0}
        save(label+'_foster.json',out['certificate'])
    for q in [1,2,6,10]:
        _,meta,_=compile_budget({'P':[1],'Q':[1,1],'q':q})
        reports[f'full_compiler_q{q}']=meta
    (B/'results/portable_examples.json').write_text(json.dumps(reports,indent=2))
    for name,r in reports.items():print(name,r.get('status','COMPILED'),r.get('seconds',''),flush=True)
if __name__=='__main__':main()
