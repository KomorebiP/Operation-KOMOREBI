#!/usr/bin/env python3
"""Author: Komorebi P. Replay saved witnesses and refutations using stdlib only.
Run with python -S to exclude all third-party site packages.
"""
from pathlib import Path
import json,time
from polynomial_budget import check_circuit_refutation
from algebraic_witness import verify_algebraic_circuit,verify_minimality_bundle
from real_pole_synthesis import verify_real_pole_certificate
B=Path(__file__).resolve().parents[1]

def replay():
    reports=[];start=time.perf_counter()
    for path in sorted((B/'examples').glob('*.json')):
        obj=json.loads(path.read_text());form=obj.get('format');out=None
        if 'problem' in obj and 'proof' in obj:out=check_circuit_refutation(obj['problem'],obj['proof'])
        elif form=='komorebi-algebraic-circuit-v1':out=verify_algebraic_circuit(obj)
        elif form=='komorebi-real-pole-synthesis-v1':out=verify_real_pole_certificate(obj)
        elif 'witness' in obj and 'q' in obj:out=verify_minimality_bundle(obj)
        if out is not None:reports.append({'file':path.name,'status':out['status'],'verification':out})
    result={'status':'PASS','certificates_replayed':len(reports),'seconds':time.perf_counter()-start,
            'dependencies':'Python standard library only','reports':reports}
    return result
if __name__=='__main__':
    r=replay();(B/'results/portable_replay.json').write_text(json.dumps(r,indent=2))
    print(json.dumps({k:v for k,v in r.items() if k!='reports'},indent=2))
