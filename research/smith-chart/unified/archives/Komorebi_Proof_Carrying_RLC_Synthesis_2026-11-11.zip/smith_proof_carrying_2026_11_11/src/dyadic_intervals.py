"""Author: Komorebi P. Outward-rounded fixed-grid RATIONAL intervals.
Rounding is exact integer floor/ceiling, not floating point. Bounding endpoint
bit lengths prevents denominator growth during repeated algebraic deflation.
"""
from fractions import Fraction as F
from dataclasses import dataclass
BITS=640
SCALE=1<<BITS

def floor(x):return x.numerator//x.denominator

def ceil(x):return -((-x.numerator)//x.denominator)

@dataclass(frozen=True)
class I:
    low:int
    high:int
    def __init__(self,lo,hi=None):
        lo=F(lo);hi=lo if hi is None else F(hi)
        if lo>hi:raise ValueError('Reversed interval')
        object.__setattr__(self,'low',floor(lo*SCALE));object.__setattr__(self,'high',ceil(hi*SCALE))
    @classmethod
    def raw(cls,lo,hi):
        if lo>hi:raise ValueError('Reversed integer interval')
        obj=object.__new__(cls);object.__setattr__(obj,'low',lo);object.__setattr__(obj,'high',hi);return obj
    @property
    def lo(self):return F(self.low,SCALE)
    @property
    def hi(self):return F(self.high,SCALE)
    def __add__(self,o):
        o=asI(o);return I.raw(self.low+o.low,self.high+o.high)
    __radd__=__add__
    def __neg__(self):return I.raw(-self.high,-self.low)
    def __sub__(self,o):return self+-asI(o)
    def __rsub__(self,o):return asI(o)+-self
    def __mul__(self,o):
        o=asI(o);v=[a*b for a in (self.low,self.high) for b in (o.low,o.high)]
        return I.raw(min(v)//SCALE,-((-max(v))//SCALE))
    __rmul__=__mul__
    def __truediv__(self,o):
        o=asI(o)
        if o.low<=0<=o.high:raise ValueError('Interval denominator contains zero')
        v=[F(a,b) for a in (self.low,self.high) for b in (o.low,o.high)]
        return I(min(v),max(v))
    def absmax(self):return max(abs(self.lo),abs(self.hi))
    def serialize(self):return [str(self.lo),str(self.hi)]

def asI(x):return x if isinstance(x,I) else I(x)

def horner(p,x):
    z=I(0)
    for c in reversed(p):z=z*x+asI(c)
    return z

def synthetic(p,alpha):
    if len(p)<2:raise ValueError('Cannot deflate constant polynomial')
    q=[I(0)]*(len(p)-1);q[-1]=asI(p[-1])
    for j in range(len(q)-2,-1,-1):q[j]=asI(p[j+1])+alpha*q[j+1]
    return q,asI(p[0])+alpha*q[0]
