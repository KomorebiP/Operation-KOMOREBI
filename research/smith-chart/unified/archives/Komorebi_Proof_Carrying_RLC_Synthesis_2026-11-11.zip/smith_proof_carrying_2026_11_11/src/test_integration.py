"""Author: Komorebi P. Integration tests. SymPy/mpmath used by proposal paths."""
from pathlib import Path
import sys,json,time,unittest
from unittest.mock import patch
B=Path(__file__).resolve().parents[1];OLD=B/'prior_release/smith_hughes_generalization';sys.path.append(str(OLD/'src'))
from fast_algebraic_inverse import extract_fast
from local_core import setup,v,certify_neighbourhood
from recover_components import verify_core_certificate
from solver_model_adapter import propose
from algebraic_witness import verify_algebraic_circuit
from synthesize_checked import minimum

class IntegrationTests(unittest.TestCase):
    def test_original_seed(self):
        c,*_=setup();self.assertEqual(v.verify(c)['status'],'PASS')
    def test_uniform_inverse(self):self.assertEqual(certify_neighbourhood()['status'],'PASS')
    def test_old_independent_targets_with_new_extractor(self):
        for n in [6,7,8]:
            a=json.loads((OLD/f'examples/independent_degree_{n}_input.json').read_text());r=extract_fast(a['P'],a['Q'])
            self.assertEqual(r['status'],'PASS')
            c=json.loads((OLD/f'results/independent_degree_{n}_component_certificate.json').read_text())
            self.assertEqual(verify_core_certificate(c,r)['status'],'PASS')
    def test_degree_ten_fresh_certificate(self):
        a=json.loads((B/'examples/independent_degree_10_input.json').read_text());r=extract_fast(a['P'],a['Q'])
        from fractions import Fraction
        with self.assertRaises(ValueError):extract_fast(a['P'],a['Q'],core_delta=Fraction(1,10**12))
        c=json.loads((B/'results/independent_degree_10_component_certificate.json').read_text())
        self.assertEqual(verify_core_certificate(c,r)['status'],'PASS')
    def test_extended_local_degrees(self):
        for n in [12,16,20]:
            a=json.loads((B/f'examples/independent_degree_{n}_input.json').read_text())
            self.assertEqual(extract_fast(a['P'],a['Q'])['status'],'PASS')
    def test_former_generic_timeouts(self):
        for P,Q,n in [([3,1],[2,1],1),([7,8,2],[2,3,1],2)]:
            r=minimum(P,Q,generic=False);self.assertEqual(r['status'],'CERTIFIED_MINIMUM');self.assertEqual(r['minimum_reactive_count'],n)
    def test_all_first_order_types(self):
        targets=[([3],[1],0),([0,2],[1],1),([2],[0,1],1),([2,3],[1],1),([3,1],[2,1],1),([1,1],[2,1],1),([1,3],[0,1],1)]
        for P,Q,n in targets:
            r=minimum(P,Q,generic=False);self.assertEqual(r['minimum_reactive_count'],n)
    def test_hughes_hidden_mode_route(self):
        r=minimum(['2/3','1/2',1],['3/2','1/3',1],generic=False)
        self.assertEqual(r['minimum_reactive_count'],5);self.assertEqual(r['verification']['status'],'PASS')
        self.assertIn('Hughes',r['lower_bound_trust'])
    def test_raw_unsat_is_not_a_lower_bound(self):
        with patch('budget_solver.run',return_value=({'status':'unsat','values':None},'')):
            r=minimum([1,1,1],[2,2,1],max_budget=3)
        self.assertEqual(r['status'],'UNVERIFIED_UNSAT');self.assertEqual(r['known_lower_bound'],2)
        self.assertIsNone(r['minimum_reactive_count'])
    def test_timeout_is_not_infeasible(self):
        with patch('budget_solver.run',return_value=({'status':'unknown'},'')):
            r=minimum([1,1,1],[2,2,1])
        self.assertEqual(r['status'],'UNKNOWN');self.assertIsNone(r['minimum_reactive_count'])
    def test_algebraic_root_object_adapter(self):
        text='((g_1_2 (- 3 (root-obj (+ (^ x 2) (- 2)) 2))) (c_1_2 1) (g_2_3 (+ 3 (root-obj (+ (^ x 2) (- 2)) 2))) (c_2_3 1) (g_0_3 (/ 1 2)))'
        c=propose([20,14,2],[7,6,1],2,text)
        self.assertEqual(verify_algebraic_circuit(c)['status'],'PASS')
    def test_real_solver_failure_remains_explicit(self):
        from budget_solver import run
        try:r,_=run([1,1,1],[2,2,1],2,timeout_ms=500)
        except RuntimeError as e:r={'status':'unavailable','reason':str(e)}
        (B/'results/generic_solver_probe.json').write_text(json.dumps(r,indent=2))
        self.assertIn(r['status'],['sat','unsat','unknown','unavailable'])
if __name__=='__main__':
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('--part',type=int,choices=[0,1]);args=ap.parse_args()
    suffix='' if args.part is None else '_part'+str(args.part)
    t=time.perf_counter();suite=unittest.defaultTestLoader.loadTestsFromTestCase(IntegrationTests)
    if args.part is not None:
        cases=list(suite);mid=(len(cases)+1)//2;suite=unittest.TestSuite(cases[:mid] if args.part==0 else cases[mid:])
    with (B/('results/integration_tests'+suffix+'.log')).open('w') as stream:r=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
    out={'status':'PASS' if r.wasSuccessful() else 'FAIL','test_methods':r.testsRun,'failures':len(r.failures),'errors':len(r.errors),'seconds':time.perf_counter()-t}
    (B/('results/integration_tests'+suffix+'.json')).write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
    if not r.wasSuccessful():print((B/('results/integration_tests'+suffix+'.log')).read_text());raise SystemExit(1)
