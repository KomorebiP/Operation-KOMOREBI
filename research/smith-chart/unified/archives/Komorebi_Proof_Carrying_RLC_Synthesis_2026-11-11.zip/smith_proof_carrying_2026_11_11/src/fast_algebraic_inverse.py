"""Author: Komorebi P. Local inverse with exact Sturm/dyadic root handling.
Same local family as prior release. No general-target coverage claim.
"""
from fractions import Fraction as F
from pathlib import Path
import sys,time
from real_algebraic import (trim,gcd,derivative,integer_sturm,root_count,evaluate,primitive_signed)
from dyadic_intervals import I,horner,synthetic,BITS
B=Path(__file__).resolve().parents[1]
OLD=B/'prior_release/smith_hughes_generalization'
sys.path.insert(0,str(OLD/'src'))
from local_core import v


def isolate_extension_poles(Q,k,bits=512):
    if len(gcd(Q,derivative(Q)))!=1:raise ValueError('This local chart requires a squarefree denominator')
    st=integer_sturm(Q);threshold=F(-15)
    if not evaluate(Q,threshold):raise ValueError('Pole lies on chart boundary')
    count=root_count(st,'-inf',threshold)
    if count!=k:raise ValueError('Wrong number of poles below -15')
    brackets=[]
    for j in range(k):
        center=F(-21-j);a,b=center-F(1,4),center+F(1,4)
        if not evaluate(Q,a) or not evaluate(Q,b) or root_count(st,a,b)!=1:
            raise ValueError('Pole left the labelled quarter-unit chart; no rejection of general feasibility')
        brackets.append((a,b))
    brackets.sort()
    # Disjoint brackets each contain one root, and the count below -15 is k.
    Qint=primitive_signed(Q);out=[];eps=F(1,1<<bits)
    for a,b in brackets:
        va=evaluate(Qint,a);vb=evaluate(Qint,b)
        if va*vb>=0:raise ValueError('Unique squarefree real root must cross sign')
        while b-a>eps:
            mid=(a+b)/2;vm=evaluate(Qint,mid)
            if not vm:a=b=mid;break
            if va*vm<0:b=mid;vb=vm
            else:a=mid;va=vm
        out.append((a,b))
    return out


def extract_fast(P,Q,core_delta=F(1,10**13),bits=512):
    if not isinstance(core_delta,(int,F)) or not 0<core_delta<=F(1,10**13):
        raise ValueError('Requested core radius exceeds the independently certified bound')
    t0=time.perf_counter();P=trim(P);Q=trim(Q);n=max(len(P),len(Q))-1
    if n<6 or len(P)!=len(Q) or Q[-1]!=150:raise ValueError('Need normalized biproper degree>=6 target')
    if len(gcd(P,Q))!=1:raise ValueError('Target not reduced')
    roots=isolate_extension_poles(Q,n-6,bits);root_seconds=time.perf_counter()-t0
    dQ=derivative(Q);pp=list(map(I,P));qq=list(map(I,Q));modules=[]
    for a,b in roots:
        root=I(a,b);rho=horner(P,root)/horner(dQ,root)
        if rho.lo>0:kind='RC';u=rho
        elif rho.hi<0:kind='RL';u=rho/root
        else:raise ValueError('Residue sign not certified')
        if u.lo<=0:raise ValueError('Nonpositive module')
        qhat,rq=synthetic(qq,root);term=qhat if kind=='RC' else [I(0)]+qhat
        difference=[z-u*term[j] if j<len(term) else z for j,z in enumerate(pp)]
        phat,rp=synthetic(difference,root)
        if not (rq.lo<=0<=rq.hi and rp.lo<=0<=rp.hi):raise ValueError('Deflation enclosure inconsistency')
        pp,qq=phat,qhat
        modules.append({'kind':kind,'pole_interval':[str(a),str(b)],'residue_interval':rho.serialize(),
                        'u_interval':u.serialize(),'exact_definition':'alpha is isolated root of original Q; rho=P(alpha)/Qprime(alpha); RC u=rho; RL u=rho/alpha'})
    if len(pp)!=7 or len(qq)!=7:raise ValueError('Wrong core size')
    deviation=max((z-I(c)).absmax() for z,c in list(zip(pp,v.P))+list(zip(qq,v.Q)))
    ok=deviation<=core_delta and qq[-1].lo==qq[-1].hi==150
    return {'status':'PASS' if ok else 'OUTSIDE_CERTIFIED_CHART','degree':n,
            'minimum_reactive_count':n if ok else None,'modules':modules,
            'core_P_intervals':[z.serialize() for z in pp],'core_Q_intervals':[z.serialize() for z in qq],
            'max_core_coefficient_deviation':str(deviation),'readable_max_core_deviation':float(deviation),
            'allowed_core_deviation':str(core_delta),'root_seconds':root_seconds,'total_seconds':time.perf_counter()-t0,
            'root_isolation':'standard-library primitive Sturm sequence and exact dyadic bisection',
            'interval_precision_bits':BITS,'proof':'isolated-root residues + outward rational deflation + prior uniform core theorem',
            'caveat':'This extraction result must be coupled to successful replay of the uniform core certificate'}
