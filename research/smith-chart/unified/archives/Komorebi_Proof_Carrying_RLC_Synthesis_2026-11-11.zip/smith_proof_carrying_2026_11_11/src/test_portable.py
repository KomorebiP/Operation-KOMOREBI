"""Author: Komorebi P. Independent-kernel tests and deliberate rejection controls."""
import unittest,copy,json,random,time
from pathlib import Path
from fractions import Fraction as F
from exact_polynomials import (var,const,square,add,scale,check_refutation,certificate)
from polynomial_budget import compile_budget,check_circuit_refutation,zero_storage_refutation,monotonic_refutation
from real_algebraic import RealField,evaluate
from algebraic_witness import verify_algebraic_circuit,verify_minimality_bundle
from real_pole_synthesis import verify_real_pole_certificate
from dyadic_intervals import I
B=Path(__file__).resolve().parents[1]
def load(name):return json.loads((B/'examples'/name).read_text())
class PortableTests(unittest.TestCase):
    def test_zero_storage_global_refutation(self):
        a=load('all_topology_zero_storage.json');r=check_circuit_refutation(a['problem'],a['proof'])
        self.assertEqual(r['status'],'PASS');self.assertEqual(r['global_lower_bound'],1)
    def test_eight_signature_refutations(self):
        for kind in ['RC','RL']:
            for q in [1,2,3,6]:
                a=load(f'{kind}_exclusion_q{q}.json');r=check_circuit_refutation(a['problem'],a['proof'])
                self.assertEqual(r['status'],'PASS');self.assertIsNone(r['global_lower_bound'])
    def test_negative_square_weight_rejected(self):
        a=load('RC_exclusion_q2.json');a['proof']['squares'][0]['weight']='-1'
        with self.assertRaises(ValueError):check_circuit_refutation(a['problem'],a['proof'])
    def test_omitted_square_rejected(self):
        a=load('RC_exclusion_q2.json');a['proof']['squares'].pop()
        with self.assertRaises(ValueError):check_circuit_refutation(a['problem'],a['proof'])
    def test_mutated_multiplier_rejected(self):
        a=load('all_topology_zero_storage.json');a['proof']['multipliers'][0]['polynomial'][0][0]='999'
        with self.assertRaises(ValueError):check_circuit_refutation(a['problem'],a['proof'])
    def test_problem_binding(self):
        a=load('all_topology_zero_storage.json');a['problem']['P']=[2]
        with self.assertRaises(ValueError):check_circuit_refutation(a['problem'],a['proof'])
    def test_restricted_proof_cannot_be_relabelled_full(self):
        a=load('RC_exclusion_q2.json');del a['problem']['types']
        with self.assertRaises(ValueError):check_circuit_refutation(a['problem'],a['proof'])
    def test_full_compiler_cubic(self):
        for q in [0,1,2,4]:
            _,m,_=compile_budget({'P':[1],'Q':[1,1],'q':q})
            self.assertTrue(m['full_topology_coverage']);self.assertLessEqual(m['max_polynomial_degree'],3)
            self.assertEqual(m['sample_count'],q+2)
    def test_compiler_restriction_flags(self):
        _,m,_=compile_budget({'P':[1],'Q':[1,1],'q':1,'nodes':3})
        self.assertFalse(m['full_topology_coverage'])
        _,m,_=compile_budget({'P':[1],'Q':[1,1],'q':1,'allowed':[['g',0,1],['c',0,1]]})
        self.assertFalse(m['full_topology_coverage'])
    def test_zero_budget_no_resistors_is_restricted(self):
        # With all branch types removed, -1=KCL is a valid refutation but must
        # never exclude a constant positive resistor in the full network class.
        spec={'P':[3],'Q':[1],'q':0,'types':[]}
        E,meta,_=compile_budget(spec)
        proof=certificate(E,(),[('kcl_1_1',const(1))])
        result=check_circuit_refutation(spec,proof)
        self.assertEqual(result['status'],'PASS')
        self.assertFalse(result['full_topology_coverage'])
        self.assertIsNone(result['global_lower_bound'])
    def test_bad_root_intervals(self):
        for f,i in [([-2,0,1],[2,3]),([-2,0,1],[-2,2]),([-2,0,1],[2,1]),([-1,0,1],[1,2]),([1,-2,1],[0,2])]:
            with self.assertRaises(ValueError):RealField(f,i)
    def test_quadratic_arithmetic(self):
        k=RealField([-2,0,1],[1,'3/2']);t=k.element([0,1]);self.assertEqual(t*t,2)
        self.assertEqual((3-t)*(3+t),7);self.assertEqual(t/t,1);self.assertEqual((t-F(7,5)).sign(),1)
    def test_cubic_arithmetic(self):
        k=RealField([1,-3,0,1],[0,'1/2']);t=k.element([0,1])
        self.assertEqual(t**3-3*t+1,0);self.assertEqual((t+1)/(t+1),1)
    def test_five_circuit_witnesses(self):
        for file in ['quadratic_algebraic_RC.json','quadratic_algebraic_mixed.json','cubic_algebraic_RC.json','Hughes_hidden_modes_upper.json','one_RC_rational.json']:
            self.assertEqual(verify_algebraic_circuit(load(file))['status'],'PASS')
    def test_nonminimal_witness_not_called_minimal(self):
        r=verify_algebraic_circuit(load('Hughes_hidden_modes_upper.json'))
        self.assertEqual(r['actual_storage'],5);self.assertEqual(r['reduced_target_degree'],2)
        self.assertFalse(r['global_minimum_proved_by_degree'])
    def test_negative_component_rejected(self):
        a=load('quadratic_algebraic_RC.json');a['branches'][0]['coefficient']=['-1']
        with self.assertRaises(ValueError):verify_algebraic_circuit(a)
    def test_tiny_component_corruption_rejected(self):
        a=load('quadratic_algebraic_RC.json');a['branches'][0]['coefficient'][0]=str(F(3)+F(1,10**50))
        with self.assertRaises(ValueError):verify_algebraic_circuit(a)
    def test_old_cubic_sign_error_rejected(self):
        a=load('cubic_algebraic_RC.json');a['target']['P'][0]=98;a['target']['Q'][0]=53
        with self.assertRaises(ValueError):verify_algebraic_circuit(a)
    def test_budget_rejection(self):
        a=load('quadratic_algebraic_RC.json');a['storage_budget']=1
        with self.assertRaises(ValueError):verify_algebraic_circuit(a)
    def test_target_binding(self):
        a=load('quadratic_algebraic_RC.json')
        with self.assertRaises(ValueError):verify_algebraic_circuit(a,{'P':[1],'Q':[1]})
    def test_two_sided_minimum(self):
        r=verify_minimality_bundle(load('two_sided_minimum_one.json'))
        self.assertEqual(r['minimum_reactive_count'],1);self.assertEqual(r['lower_bound']['status'],'PASS')
    def test_minimum_missing_refutation_rejected(self):
        w=load('Hughes_hidden_modes_upper.json');b={'target':w['target'],'q':5,'witness':w}
        with self.assertRaises(ValueError):verify_minimality_bundle(b)
    def test_three_real_pole_proofs(self):
        for name in ['former_timeout_one','former_timeout_two','irrational_mixed_real_poles']:
            self.assertEqual(verify_real_pole_certificate(load(name+'_foster.json'))['status'],'PASS')
    def test_false_pole_rejected(self):
        a=load('former_timeout_one_foster.json');a['pole_intervals']=[['-3','-3']]
        with self.assertRaises(ValueError):verify_real_pole_certificate(a)
    def test_missing_pole_rejected(self):
        a=load('former_timeout_two_foster.json');a['pole_intervals'].pop()
        with self.assertRaises(ValueError):verify_real_pole_certificate(a)
    def test_dyadic_enclosures(self):
        rng=random.Random(117)
        for _ in range(100):
            x=F(rng.randrange(-100,101),rng.randrange(1,50));y=F(rng.randrange(-100,101),rng.randrange(1,50))
            for value,interval in [(x+y,I(x)+I(y)),(x-y,I(x)-I(y)),(x*y,I(x)*I(y))]:
                self.assertLessEqual(interval.lo,value);self.assertGreaterEqual(interval.hi,value)
            if y:
                interval=I(x)/I(y);self.assertLessEqual(interval.lo,x/y);self.assertGreaterEqual(interval.hi,x/y)
    def test_interval_safety(self):
        with self.assertRaises(ValueError):I(1)/I(-1,1)
        with self.assertRaises(ValueError):I(2,1)
    def test_real_not_complex_infeasibility(self):
        x=var('x');E={'eq':add(square(x),const(1))};p=certificate(E,[(1,x)],[('eq',const(-1))])
        self.assertEqual(check_refutation(E,p)['status'],'PASS')
    def test_satisfiable_equations_reject_fake_proof(self):
        E={'eq':add(var('x'),const(-1))};p=certificate(E,(),[('eq',const(-1))])
        with self.assertRaises(ValueError):check_refutation(E,p)
    def test_float_polynomial_payload_rejected(self):
        a=load('all_topology_zero_storage.json');a['proof']['multipliers'][0]['polynomial'][0][0]=0.5
        with self.assertRaises(ValueError):check_circuit_refutation(a['problem'],a['proof'])

if __name__=='__main__':
    t=time.perf_counter();suite=unittest.defaultTestLoader.loadTestsFromTestCase(PortableTests)
    with (B/'results/portable_tests.log').open('w') as stream:r=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
    out={'status':'PASS' if r.wasSuccessful() else 'FAIL','test_methods':r.testsRun,'failures':len(r.failures),'errors':len(r.errors),'seconds':time.perf_counter()-t,'dependencies':'stdlib only'}
    (B/'results/portable_tests.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
    if not r.wasSuccessful():print((B/'results/portable_tests.log').read_text());raise SystemExit(1)
