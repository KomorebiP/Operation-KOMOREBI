"""Author: Komorebi P. UNTRUSTED proposal conversion for Z3 exact real values.
Rational and root-obj values are converted through a common primitive element.
Only algebraic_witness.verify_algebraic_circuit is an acceptance authority.
The conversion can be slow and may fail. It never certifies by itself.
"""
from fractions import Fraction as F
import re

def parse(text):
    ts=re.findall(r'\(|\)|[^\s()]+',text);j=0
    def rec():
        nonlocal j
        if j==len(ts):raise ValueError('Incomplete S-expression')
        t=ts[j];j+=1
        if t!= '(':return t
        z=[]
        while j<len(ts) and ts[j]!=')':z.append(rec())
        if j==len(ts):raise ValueError('Missing closing parenthesis')
        j+=1;return z
    out=rec()
    if j!=len(ts):raise ValueError('Trailing S-expression tokens')
    return out

def expression(node,symbol=None):
    import sympy as S
    if isinstance(node,str):
        if symbol is not None and node=='x':return symbol
        return S.Rational(F(node).numerator,F(node).denominator)
    op,*args=node
    if op=='root-obj':
        x=S.Symbol('x');p=expression(args[0],x);index=int(args[1])
        if index<1:raise ValueError('Positive root-object index required')
        root=S.CRootOf(p,x,index-1)
        if root.is_real is not True:raise ValueError('Root-object proposal is not real')
        return root
    xs=[expression(x,symbol) for x in args]
    if op=='+':return S.Add(*xs)
    if op=='*':return S.Mul(*xs)
    if op=='-':return -xs[0] if len(xs)==1 else xs[0]-sum(xs[1:])
    if op=='/' and len(xs)==2:return xs[0]/xs[1]
    if op=='^' and len(xs)==2 and xs[1].is_Integer and xs[1]>=0:return xs[0]**xs[1]
    raise ValueError('Unsupported exact solver expression')

def propose(P,Q,q,text):
    import sympy as S
    vals=[]
    for name,val in parse(text):
        hit=re.fullmatch(r'([ghc])_(\d+)_(\d+)',name)
        if hit is None:continue
        t,a,b=hit.group(1),int(hit.group(2)),int(hit.group(3));v=expression(val)
        if v!=0:vals.append((t,a,b,v))
    reached={0}
    while True:
        more=reached|{b for _,a,b,_ in vals if a in reached}|{a for _,a,b,_ in vals if b in reached}
        if more==reached:break
        reached=more
    vals=[row for row in vals if row[1] in reached and row[2] in reached]
    nums=[z for _,_,_,z in vals]
    if all(z.is_Rational for z in nums):
        f=[0,1];interval=[-1,1];reps=[[str(z)] for z in nums]
    else:
        x=S.Symbol('t');fpoly,comb,reps_desc=S.polys.numberfields.primitive_element(nums,x,ex=True,polys=True)
        theta=sum(c*v for c,v in zip(comb,nums));estimate=S.N(theta,70)
        intervals=fpoly.intervals(eps=S.Rational(1,1000));matches=[]
        for (a,b),mult in intervals:
            if mult==1 and S.N(a,70)<=estimate<=S.N(b,70):matches.append((a,b))
        if len(matches)!=1:raise ValueError('Unable to propose unique primitive-element interval')
        a,b=matches[0]
        if a==b:a-=1;b+=1
        f=list(map(str,reversed(fpoly.all_coeffs())));interval=[str(a),str(b)]
        reps=[list(map(lambda z:str(S.Rational(z)),reversed(row))) for row in reps_desc]
    cert={'format':'komorebi-algebraic-circuit-v1','target':{'P':list(map(str,P)),'Q':list(map(str,Q))},
          'storage_budget':q,'field':{'polynomial':f,'interval':interval},
          'branches':[{'type':t,'nodes':[a,b],'coefficient':rep} for (t,a,b,_),rep in zip(vals,reps)]}
    return cert
