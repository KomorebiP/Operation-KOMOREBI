"""Author: Komorebi P. Certified real-pole synthesis with classical Foster sections.
The mathematical construction is classical, not claimed novel. It supplies a fast
route for all nonzero rational positive-real targets of degree <=1 and a broad
higher-degree real-pole subclass. Failure means OUTSIDE_THIS_CHART, not RLC UNSAT.
Proposal root isolation uses SymPy; acceptance uses only standard-library code.
"""
from __future__ import annotations
from fractions import Fraction as F
from real_algebraic import (trim,gcd,derivative,divmod_poly,evaluate,integer_sturm,
                           root_count,primitive_signed,sub,scale)
from dyadic_intervals import I,horner


def prepare(P,Q):
    P=trim(P);Q=trim(Q)
    if not any(P) or not any(Q):raise ValueError('Nonzero target required')
    if len(gcd(P,Q))!=1:raise ValueError('Reduced target required')
    n=max(len(P),len(Q))-1
    part,rem=divmod_poly(P,Q)
    if len(part)>2:raise ValueError('Polynomial part exceeds degree one')
    R=part[0];L=part[1] if len(part)>1 else F(0)
    if L<0:raise ValueError('Negative leading inductance')
    zero_residue=F(0);QQ=Q
    if len(QQ)>1 and QQ[0]==0:
        if QQ[1]==0:raise ValueError('Multiple zero pole not in passive chart')
        zero_residue=rem[0]/QQ[1]
        if zero_residue<=0:raise ValueError('Nonpositive origin residue')
        qhat=QQ[1:];pnum=sub(rem,scale(qhat,zero_residue))
        if pnum[0]!=0:raise AssertionError('Origin deflation inconsistency')
        rem=trim(pnum[1:] or [F(0)]);QQ=trim(qhat)
    if len(gcd(QQ,derivative(QQ)))>1:raise ValueError('Repeated nonzero pole')
    return P,Q,n,R,L,zero_residue,rem,QQ


def refine_interval(p,seq,interval,bits=256):
    a,b=map(F,interval)
    if a>b or b>=0:raise ValueError('Strictly negative ordered pole bracket required')
    if a==b:
        if evaluate(p,a)!=0:raise ValueError('Claimed rational pole is not a root')
        return a,b
    if evaluate(p,a)==0 or evaluate(p,b)==0:raise ValueError('Endpoints must not be roots unless interval is a point')
    if root_count(seq,a,b)!=1:raise ValueError('Pole interval does not isolate one root')
    p=primitive_signed(p);fa=evaluate(p,a);fb=evaluate(p,b)
    if fa*fb>=0:raise ValueError('Simple-root bracket must change sign')
    eps=F(1,1<<bits)
    while b-a>eps:
        mid=(a+b)/2;fm=evaluate(p,mid)
        if fm==0:return mid,mid
        if fa*fm<0:b=mid;fb=fm
        else:a=mid;fa=fm
    return a,b


def verify_real_pole_certificate(cert):
    if cert.get('format')!='komorebi-real-pole-synthesis-v1':raise ValueError('Wrong certificate format')
    P,Q,n,R,L,c0,rem,QQ=prepare(cert['target']['P'],cert['target']['Q'])
    intervals=cert['pole_intervals'];d=len(QQ)-1
    if len(intervals)!=d:raise ValueError('Pole count does not cover denominator degree')
    intervals=sorted([(F(a),F(b)) for a,b in intervals])
    if any(intervals[j][1]>=intervals[j+1][0] for j in range(len(intervals)-1)):
        raise ValueError('Overlapping or duplicate root intervals')
    seq=integer_sturm(QQ) if d else None
    modules=[];base=I(R);negative=0;positive=0
    for interval in intervals:
        a,b=refine_interval(QQ,seq,interval,bits=cert.get('refinement_bits',256))
        root=I(a,b);rho=horner(rem,root)/horner(derivative(QQ),root)
        if rho.lo>0:
            kind='RC';u=rho;positive+=1
            vals={'R':(u/(-root)).serialize(),'C':(I(1)/u).serialize()}
        elif rho.hi<0:
            kind='RL';u=rho/root;negative+=1;base=base-u
            vals={'R':u.serialize(),'L':(u/(-root)).serialize()}
        else:raise ValueError('Residue sign unresolved; no feasibility conclusion')
        modules.append({'type':kind,'pole_interval':[str(a),str(b)],'residue_interval':rho.serialize(),
                        'components':vals,'exact_definition':'alpha is isolated root of reduced denominator; rho=rem(alpha)/QQprime(alpha); a=-alpha; RC u=rho; RL u=rho/alpha'})
    if not positive and d:
        # All RL sections: the residual series resistor is exactly core Z(0).
        base=I(R+rem[0]/QQ[0])
    if base.lo<0 or (base.lo==0 and base.hi!=0):raise ValueError('Series resistor not certified nonnegative; outside this sufficient chart')
    reactive=d+int(c0>0)+int(L>0)
    if reactive!=n:raise ValueError('Unexpected degree/reactive mismatch')
    return {'status':'PASS','minimum_reactive_count':n,'reactive_count':reactive,
            'series_resistor_interval':base.serialize(),'series_L':str(L),
            'series_C':str(1/c0) if c0 else None,'modules':modules,
            'global_minimum_proved':True,'route':'classical real-pole positive-section synthesis',
            'arithmetic':'standard-library Fraction, Sturm root count, outward dyadic intervals',
            'proof':'complete simple negative-pole coverage + residues + polynomial part + reduced-degree lower bound'}


def propose_real_pole_certificate(P,Q):
    import sympy as S
    PP,QQ,n,R,L,c0,rem,q=prepare(P,Q)
    if len(q)==1:intervals=[]
    else:
        s=S.Symbol('s');poly=S.Poly.from_list([S.Rational(x.numerator,x.denominator) for x in reversed(q)],s)
        isolated=poly.intervals(eps=S.Rational(1,16))
        if len(isolated)!=len(q)-1 or any(m!=1 for _,m in isolated):raise ValueError('Not all poles are real and simple')
        intervals=[[str(F(a)),str(F(b))] for (a,b),m in isolated]
    return {'format':'komorebi-real-pole-synthesis-v1','target':{'P':list(map(str,PP)),'Q':list(map(str,QQ))},
            'pole_intervals':intervals,'refinement_bits':256}


def synthesize_real_poles(P,Q):
    proof=propose_real_pole_certificate(P,Q)
    return {'certificate':proof,'verification':verify_real_pole_certificate(proof)}
