"""Author: Komorebi P. All-topology pure polynomial equality compiler.
Nonnegative branch parameters are squares. Binary gates bound physical storage.
The resulting system has degree <= 3. A restricted instance cannot prove a global
lower bound. This module does not silently assume the target is positive-real.
"""
from __future__ import annotations
from fractions import Fraction as F
from itertools import combinations
from exact_polynomials import *


def evalpoly(p,x):
    out=F(0)
    for c in reversed(p):out=out*x+rational(c)
    return out

def trim(p):
    p=list(map(rational,p))
    while len(p)>1 and not p[-1]:p.pop()
    return p

def compile_budget(spec):
    P=trim(spec['P']);Q=trim(spec['Q']);q=spec['q']
    if not isinstance(q,int) or isinstance(q,bool) or q<0:raise ValueError('Nonnegative integer budget required')
    if not any(Q) or not any(P):raise ValueError('Nonzero target required')
    n=max(len(P),len(Q))-1;bound=2*q+2
    m=spec.get('nodes',bound)
    if not isinstance(m,int) or not 2<=m<=bound:raise ValueError('Invalid node count')
    allowed=spec.get('allowed',None)
    if allowed is not None:
        allowed={tuple(x) for x in allowed}
        if any(t not in ('g','h','c') or not 0<=a<b<m for t,a,b in allowed):raise ValueError('Invalid allowed branch')
    kinds=tuple(spec.get('types',('g','h','c')))
    if len(set(kinds))!=len(kinds) or any(t not in ('g','h','c') for t in kinds):raise ValueError('Invalid signature')
    if q==0:kinds=tuple(t for t in kinds if t=='g')
    equations={};amps={};gates=[];edges=list(combinations(range(m),2))
    for typ in kinds:
        for a,b in edges:
            if allowed is not None and (typ,a,b) not in allowed:continue
            name=f'a_{typ}_{a}_{b}';x=var(name);amps[typ,a,b]=x
            if typ!='g':
                gate=f'b_{typ}_{a}_{b}';u=var(gate);gates.append(u)
                equations['binary_'+gate]=sub(square(u),u)
                equations['gate_'+name]=mul(sub(const(1),u),x)
    if q>0:
        # A real slack exists exactly when sum(bits)<=q.
        equations['storage_budget']=sub(add(*gates,square(var('storage_slack'))),const(q))
    samples=[];potentials={}
    for k in range(1,n+q+2):
        den=evalpoly(Q,F(k))
        if not den:raise ValueError('Target has a positive sample pole')
        Z=evalpoly(P,F(k))/den
        if Z<=0:raise ValueError('Target must be positive at each selected positive argument')
        samples.append((F(k),Z))
        for i in range(m):potentials[k,i]=const(0) if i==0 else const(Z) if i==1 else var(f'v_{k}_{i}')
        currents={i:{} for i in range(1,m)}
        for a,b in edges:
            y={}
            for typ,w in [('g',F(1)),('h',F(1,k)),('c',F(k))]:
                if (typ,a,b) in amps:y=add(y,scale(square(amps[typ,a,b]),w))
            dv=sub(potentials[k,a],potentials[k,b]);j=mul(y,dv)
            if a:currents[a]=add(currents[a],j)
            currents[b]=sub(currents[b],j)
        for i in range(1,m):equations[f'kcl_{k}_{i}']=sub(currents[i],const(int(i==1)))
    names=set().union(*(variables(p) for p in equations.values()))
    full=(m==bound and allowed is None and
          (set(kinds)=={'g'} if q==0 else set(kinds)=={'g','h','c'}))
    meta={'nodes':m,'complete_node_bound':bound,'degree_bound':n,'storage_budget':q,
        'sample_count':n+q+1,'variables':len(names),'equations':len(equations),
        'max_polynomial_degree':max(map(degree,equations.values()),default=0),
        'full_topology_coverage':full,'scope':'ALL RLC TOPOLOGIES' if full else 'RESTRICTED TOPOLOGY OR SIGNATURE'}
    return equations,meta,{'amplitudes':amps,'potentials':potentials,'samples':samples}

def check_circuit_refutation(spec,proof):
    equations,meta,_=compile_budget(spec)
    out=check_refutation(equations,proof)
    return {**out,**meta,'global_lower_bound':spec['q']+1 if meta['full_topology_coverage'] else None}

def monotonic_refutation(spec):
    """Generate an exact energy/SOS rejection for a signature-incompatible target.
    RC impedances decrease on the positive real axis. RL impedances increase.
    Uses no optimization, theorem from the supplied source, or numeric acceptance.
    """
    E,meta,data=compile_budget(spec);amps=data['amplitudes'];v=data['potentials']
    types={t for t,a,b in amps}
    if types<={'g','c'}:a,b=1,2
    elif types<={'g','h'}:a,b=2,1
    else:raise ValueError('Energy template requires RC-only or RL-only signature')
    if len(data['samples'])<2:raise ValueError('Two distinct samples required')
    D=data['samples'][a-1][1]-data['samples'][b-1][1]
    if D>=0:raise ValueError('No monotonicity contradiction at first two arguments')
    delta=-D;squares=[]
    for (typ,i,j),amp in amps.items():
        dv_a=sub(v[a,i],v[a,j]);dv_b=sub(v[b,i],v[b,j]);diff=sub(dv_a,dv_b)
        ya=F(1) if typ=='g' else F(a) if typ=='c' else F(1,a)
        yb=F(1) if typ=='g' else F(b) if typ=='c' else F(1,b)
        squares.append((ya/delta,mul(amp,diff)))
        if yb!=ya:
            if yb<ya:raise AssertionError('Wrong energy ordering')
            squares.append(((yb-ya)/delta,mul(amp,dv_b)))
    multipliers=[]
    for i in range(1,meta['nodes']):
        multipliers.append((f'kcl_{a}_{i}',scale(sub(v[a,i],scale(v[b,i],2)),-1/delta)))
        multipliers.append((f'kcl_{b}_{i}',scale(v[b,i],-1/delta)))
    proof=certificate(E,squares,multipliers)
    check_refutation(E,proof)
    return proof

def zero_storage_refutation(spec):
    if spec['q']!=0:raise ValueError('Only zero storage supported')
    E,meta,data=compile_budget(spec)
    if meta['nodes']!=2 or ('g',0,1) not in data['amplitudes']:raise ValueError('Expected complete zero-storage model')
    Zs=[Z for _,Z in data['samples']]
    pair=next(((i+1,j+1) for i in range(len(Zs)) for j in range(i+1,len(Zs)) if Zs[i]!=Zs[j]),None)
    if pair is None:raise ValueError('No nonconstant sample contradiction')
    a,b=pair;za,zb=Zs[a-1],Zs[b-1]
    # A*za+B*zb=0 and A+B=1 implies A E_a+B E_b=-1.
    A=-zb/(za-zb);B=za/(za-zb)
    proof=certificate(E,(),[(f'kcl_{a}_1',const(A)),(f'kcl_{b}_1',const(B))])
    check_refutation(E,proof)
    return proof
