#!/usr/bin/env python3
"""Author: Komorebi P. Certificate-first synthesis dispatcher.
Classical real-pole route, Hughes prior-art classification, certified local inverse,
then optional generic SMT search. Bare UNSAT NEVER raises a certified lower bound.
"""
from pathlib import Path
from fractions import Fraction as F
import argparse,json,sys,time
from real_algebraic import trim,gcd,divmod_poly
from real_pole_synthesis import synthesize_real_poles
from algebraic_witness import verify_algebraic_circuit
from solver_model_adapter import propose
B=Path(__file__).resolve().parents[1];OLD=B/'prior_release/smith_hughes_generalization'
sys.path.insert(0,str(OLD/'src'))

def minimum(P,Q,timeout_ms=3000,max_budget=None,generic=True):
    t0=time.perf_counter();P=trim(P);Q=trim(Q)
    if not any(P) or not any(Q):raise ValueError('Nonzero finite target required')
    g=gcd(P,Q)
    P=divmod_poly(P,g)[0];Q=divmod_poly(Q,g)[0];n=max(len(P),len(Q))-1;failures=[]
    try:
        r=synthesize_real_poles(P,Q)
        return {'status':'CERTIFIED_MINIMUM','route':'classical real-pole sections',
                'minimum_reactive_count':n,'seconds':time.perf_counter()-t0,**r}
    except ValueError as e:failures.append({'route':'real-pole chart','reason':str(e)})
    if n==2:
        import sympy as S
        from hughes_minimum import synthesize,s
        try:
            z=sum(S.Rational(c.numerator,c.denominator)*s**j for j,c in enumerate(P))/sum(S.Rational(c.numerator,c.denominator)*s**j for j,c in enumerate(Q))
            r=synthesize(z)
            branches=[]
            for typ,a,b,value in r['edges']:
                value=S.sympify(value)
                if not value.is_Rational:raise ValueError('Hughes adapter currently expects rational returned values')
                t={'R':'g','L':'h','C':'c'}[typ];val=1/value if typ!='C' else value
                branches.append({'type':t,'nodes':[a,b],'coefficient':[str(val)]})
            c={'format':'komorebi-algebraic-circuit-v1','target':{'P':list(map(str,P)),'Q':list(map(str,Q))},
               'storage_budget':r['minimum_reactive_count'],'field':{'polynomial':[0,1],'interval':[-1,1]},'branches':branches}
            check=verify_algebraic_circuit(c)
            return {'status':'CERTIFIED_MINIMUM','route':'Hughes published classification + independent upper witness',
                    'minimum_reactive_count':r['minimum_reactive_count'],'classification':r,'certificate':c,
                    'verification':check,'lower_bound_trust':'Hughes Theorems 4--6, not a newly generated polynomial refutation',
                    'seconds':time.perf_counter()-t0}
        except ValueError as e:failures.append({'route':'Hughes class','reason':str(e)})
    if n>=6:
        from fast_algebraic_inverse import extract_fast
        from local_core import certify_neighbourhood
        from recover_components import recover,verify_core_certificate
        try:
            sc=F(150)/Q[-1];Pn=[sc*z for z in P]+[F(0)]*(n+1-len(P));Qn=[sc*z for z in Q]+[F(0)]*(n+1-len(Q))
            r=extract_fast(Pn,Qn)
            if r['status']=='PASS':
                u=certify_neighbourhood()
                if u['status']!='PASS':raise ValueError('Uniform core certificate failed')
                c=recover(r);check=verify_core_certificate(c,r)
                return {'status':'CERTIFIED_MINIMUM','route':'Sturm-dyadic local inverse',
                        'minimum_reactive_count':n,'deflation':r,'uniform_core':u,'component_certificate':c,
                        'verification':check,'seconds':time.perf_counter()-t0}
            failures.append({'route':'local inverse','reason':r['status']})
        except ValueError as e:failures.append({'route':'local inverse','reason':str(e)})
    if not generic:return {'status':'UNKNOWN','known_lower_bound':n,'minimum_reactive_count':None,'route_attempts':failures}
    from budget_solver import run
    from boundary import upper_bound
    cap=n if max_budget is None else max_budget
    history=[]
    for q in range(n,cap+1):
        try:r,_=run(P,Q,q,timeout_ms=timeout_ms)
        except RuntimeError as e:return {'status':'UNKNOWN','minimum_reactive_count':None,'known_lower_bound':n,'reason':str(e),'route_attempts':failures}
        history.append(r)
        if r['status']=='sat':
            try:c=propose(P,Q,q,r['values']);checked=verify_algebraic_circuit(c)
            except (ValueError,TypeError,NotImplementedError) as e:
                return {'status':'UNVERIFIED_SAT','minimum_reactive_count':None,'known_lower_bound':n,'solver_history':history,'reason':str(e)}
            actual=checked['actual_storage'];minimal=(actual==n)
            return {'status':'CERTIFIED_MINIMUM' if minimal else 'CERTIFIED_UPPER_BOUND',
                    'minimum_reactive_count':actual if minimal else None,'known_lower_bound':n,'certified_upper_bound':actual,
                    'certificate':c,'verification':checked,'solver_history':history,'seconds':time.perf_counter()-t0}
        # A raw UNSAT remains a search hint. It is not an accepted lower bound.
        if r['status']!='unsat':break
    return {'status':'UNVERIFIED_UNSAT' if history and all(r['status']=='unsat' for r in history) else 'UNKNOWN',
            'minimum_reactive_count':None,'known_lower_bound':n,'route_attempts':failures,'solver_history':history,
            'note':'No bare solver UNSAT or timeout is promoted to an impossibility proof.',
            'theoretical_upper_bound_if_PR':upper_bound(n),'seconds':time.perf_counter()-t0}

if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('target');a.add_argument('--out');a.add_argument('--no-generic',action='store_true')
    a.add_argument('--timeout-ms',type=int,default=3000);a.add_argument('--max-budget',type=int)
    args=a.parse_args();target=json.loads(Path(args.target).read_text())
    r=minimum(target['P'],target['Q'],args.timeout_ms,args.max_budget,not args.no_generic)
    text=json.dumps(r,indent=2)
    if args.out:Path(args.out).write_text(text)
    else:print(text)
