# Handoff: exact circuit certificates and local inversion

**Author: Komorebi P.**  
**Date: 11 November 2026**

## Current mathematical state

The original degree-six target remains exactly closed at **q_min=6**, with 3L+3C+7R and no transformer. Do not revert to the superseded 6-versus-7 uncertainty. The original certificate is retained under `prior_release/smith_hughes_generalization/certified_seed/`.

The arbitrary-degree construction and local full-rank theorem remain valid. They do not imply every degree-n positive-real function has q_min=n. Hughes supplies exact degree-two counterexamples with q_min=5 and exceptional 3/4-storage cases.

The previous release's all-topology formula and local quantitative core certificate are retained. This continuation adds independent polynomial refutation and real-algebraic component checkers, an audited trust policy, and completed degree-ten/twelve/sixteen/twenty local tests.

## Distinguish the five kinds of outcome

1. An exact component witness proves an upper bound.
2. If its storage count equals reduced degree, the degree lower bound proves global storage minimum.
3. If it uses excess storage, a complete q-1 refutation or an applicable published theorem is still needed.
4. A restricted RC/RL or fixed-topology refutation is not a general RLC lower bound.
5. A solver UNSAT without a checked refutation is `UNVERIFIED_UNSAT`. UNKNOWN is never infeasible.

## What is really implemented

- General rational SOS/ideal identity checking, with equations regenerated from the target/budget/signature.
- Real algebraic component representation and exact signs/field nodal checking using standard Python only.
- Untrusted conversion of rational/root-object SMT models into the checked algebraic format.
- Automatic q=0 global refutations and arbitrary-node RC/RL monotonicity refutations.
- A two-sided minimum bundle API. Demonstrated at q=1 with a complete q=0 refutation.
- Classical real-pole positive-section synthesis and all nonzero degree-one positive-real cases.
- Dyadic/Sturm local extraction, fresh degree-ten core certification, and degree12/16/20 existence via uniform core.

## What is NOT implemented

There is no universal efficient mixed-RLC refutation search. Certificate-language completeness is classical and does not imply that practical proof discovery is solved. The generic compiler expects rational input coefficients. The general solver still times out even at some small orders. No new high-budget mixed-RLC global lower-bound certificate was produced here.

## Reproduction priority

Run portable replay/tests first. Run both integration partitions next. Read `RUN_MANIFEST.json` and `ENGINEERING_NOTES.md`, including failed runs. The fresh degree-ten component certificate must be checked against newly regenerated deflation enclosures, not trusted from JSON.

## Next substantive research directions

The best next target is a nontrivial mixed-RLC global lower budget with a generated exact polynomial refutation, not another restricted-signature example. Candidate approaches include a rational SOS/ideal search with degree escalation, symmetry-aware support partitions, and elimination yielding compact sign contradictions. Keep the complete-node bound and graph coverage explicit.

Other useful work: decompose universal search into certified analytic subclasses, tighten topology pruning without discarding singular realizations, generalize local charts to move poles beyond the fixed labelled brackets, and quantify complexity of the new exact arithmetic. Algebraic target coefficients need a target-field binding layer, not just component fields.

No publication or priority claim should be made without an independent literature audit. No source files were pushed to GitHub. Continue keeping exact logs, Markdown proofs and rejection controls with each release.
