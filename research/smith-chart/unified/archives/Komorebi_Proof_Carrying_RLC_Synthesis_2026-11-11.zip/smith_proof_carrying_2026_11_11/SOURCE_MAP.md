# Source and provenance map

**Author: Komorebi P.**

## User-provided circuit paper

Timothy H. Hughes, *Why RLC realizations of certain impedances need many more energy storage elements than expected*, IEEE Transactions on Automatic Control 62(9), 4333–4346 (2017). arXiv:1611.06258v2, 22 January 2018. https://arxiv.org/pdf/1611.06258

Printed pp4–5: Lemma3 and Theorems4–6 classify biquadratic minimum functions and supply 3/4/5-storage constructions. Printed p7: blocked resistors at a minimum frequency. These are Hughes's results. The new checker separately verifies the five-storage upper witness. Its matching global lower bound still comes from Hughes's theorem. The page-five and page-seven diagrams/text were inspected via PDF screenshots in this continuation.

## Classical real algebraic certificate framework

Pablo A. Parrilo, *Semidefinite programming relaxations for semialgebraic problems*, Mathematical Programming96 (2003),293–320. DOI10.1007/s10107-003-0387-5. Author-hosted primary paper: https://www.mit.edu/~parrilo/pubs/files/SDPrelaxations.pdf

Section4.2, Theorem4.6, explains Positivstellensatz infeasibility certificates. The equality-only identity used here is the real-Nullstellensatz specialization. Rational-coefficient existence is justified separately in THEOREMS_AND_PROOFS.md by real spectra/real-closed-field transfer. It is not an assertion that every particular numerical SOS Gram matrix admits same-degree rational rounding. No novel general real-algebraic theorem is claimed.

## Software documentation

SymPy's official number-fields documentation supplies the proposal conversion conventions for `primitive_element` and `to_number_field`: https://docs.sympy.org/latest/modules/polys/numberfields.html

Official Z3 documentation and API define exact algebraic reals and root-object expressions: https://microsoft.github.io/z3guide/docs/theories/Arithmetic/ and https://z3prover.github.io/api/html/group__capi.html

These are implementation references. The acceptance checks are performed in separate standard-library arithmetic, not by trusting the proposal libraries.

## Earlier project source

The retained `prior_release/smith_hughes_generalization/` tree contains the exact six-reactive seed, the quantitative coefficient-neighborhood certificate and the previous theorem/engineering notes. Its earlier all-topology interpolation proof and source-based Hughes constructions are retained. The new dispatcher supersedes its raw-UNSAT trust policy. The originals outside this package were not changed.

## Deductions and implementation developed here

The square-variable all-topology equality encoding, target/budget/scope-bound exact checking, explicit two-frequency energy proof objects, primitive-field circuit acceptance implementation, two-sided minimum interface, repaired local arithmetic and test records are this continuation's developments. Underlying algebraic geometry, monotonicity, Foster synthesis and primitive-element theory are classical. Historical priority for any combined formulation or implementation is not established.
