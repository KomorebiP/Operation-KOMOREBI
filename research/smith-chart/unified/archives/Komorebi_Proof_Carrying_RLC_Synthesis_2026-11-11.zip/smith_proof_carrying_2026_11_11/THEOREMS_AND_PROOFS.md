# Proof-carrying RLC synthesis
## Exact YES and NO certificates, and a repaired local inverse

**Author: Komorebi P.**  
**Date: 11 November 2026, America/Chicago**  
**Status: Research continuation. The verification gaps below are addressed. An efficient universal minimum-network search is not established.**

## 1. Scope and changes to the previous release

The objects are finite nonzero scalar driving-point impedances of ordinary transformer-free RLC one-ports. Present resistors, inductors and capacitors have finite strictly positive values. Wires can be contracted. Mutual inductance, transformers, controlled sources and negative components are excluded. The minimized quantity is the physical number of inductors and capacitors.

The previous release implemented a topology-complete bilinear feasibility formula, but independently checked only rational SAT witnesses. General algebraic SAT values and generic UNSAT results remained outside its independent checker. It also recorded a degree-ten algebraic-inverse timeout.

This release adds:

1. A rational-polynomial infeasibility checker and a circuit-to-polynomial compiler that binds a refutation to the actual target, budget and topology coverage.
2. A standard-library real-algebraic circuit checker. Components may be irrational, may share algebraic dependencies, and may generate hidden internal modes.
3. Exact energy-identity refutation generators for RC-only and RL-only signatures, plus a complete zero-storage refutation generator.
4. A two-sided minimum certificate interface. An upper witness at budget q and a complete lower-budget refutation at q-1 suffice.
5. A replacement local inverse using primitive Sturm sequences, dyadic root bisection and outward-rounded rational interval arithmetic. Independently specified targets at degrees 10, 12, 16 and 20 now pass.
6. A classical real-pole synthesis route, including all degree-one positive-real targets, that bypasses two previously timed-out generic cases.
7. A dispatcher that never reports a bare solver UNSAT as an independently certified lower bound.

The implementation of these certificate formats is not a claim to have invented the real Nullstellensatz, Sturm root isolation, primitive-element arithmetic, Foster synthesis, or Hughes's circuit classifications.

## 2. An all-topology polynomial equality system

Let Z=P/Q have rational coefficients and degree bound n=max(deg P,deg Q). Fix an integer storage budget q>=0. Use m=2q+2 node slots, with ground 0 and input 1, and K=n+q+1 distinct positive rational arguments sigma_k=k.

The input denominator must be nonzero at the selected arguments and the target value must be positive there. Reduced nonzero positive-real input has these properties. Invalid sample data are rejected rather than assigned an infeasibility certificate.

For every unordered pair e, introduce real amplitude variables r_e, l_e and c_e. Define the branch admittance

\[
y_e(s)=r_e^2+\frac{l_e^2}{s}+s c_e^2.
\]

The physical resistor conductance is r_e^2, reciprocal inductance is l_e^2, and capacitance is c_e^2. A zero amplitude means that the corresponding branch is absent. No positivity oracle is required.

For each reactive amplitude x, introduce a support selector b_x and require

\[
b_x^2-b_x=0,\qquad (1-b_x)x=0.
\]

With one real slack t, impose

\[
\sum_x b_x+t^2=q.
\]

Every selector is zero or one. Every nonzero reactive amplitude requires selector one. Hence the physical storage count is at most q. Conversely, any support of size at most q can be encoded, using t=sqrt(q-support size). Selecting an extra zero-amplitude branch only consumes budget and never permits more physical components. For q=0 the implementation omits all reactive amplitudes and selectors.

At sigma_k, set v_0=0, v_1=P(sigma_k)/Q(sigma_k), and impose for every non-ground node i

\[
E_{k,i}:=\sum_{j\ne i}y_{ij}(\sigma_k)(v_i-v_j)-\mathbf 1_{i=1}=0.
\]

These are rational polynomial equations of degree at most three. Selector and budget equations have degree at most two. The square substitution exchanges the earlier bilinear/nonnegative encoding for a pure polynomial equality system. It is useful for certificates, not asserted to make numerical search faster.

### Theorem 2.1. Exact equivalence

The complete equality system has a real solution if and only if the target has a transformer-free RLC realization using at most q reactive components.

**Proof of necessity.** Retain the two port terminals and every reactive endpoint of a realizing network. There are at most 2q+2 retained nodes. All other nodes belong only to the resistor network. Kron reduction replaces that resistor network by nonnegative conductances on the retained nodes. Same-type parallel components can be merged without increasing storage. Pad unused slots by isolated nodes. Choose square roots of all nonnegative branch parameters and their selectors. Positive real arguments turn all active components into positive conductances, so the required unit-current nodal solutions exist.

**Proof of sufficiency.** A real assignment gives nonnegative branch admittances. Delete absent branches and disconnected material. The port must connect to ground, since otherwise summing the nodal equations over the port component would give 0=1. The resulting RLC network has at most q reactive elements and rational degree at most q. Let its impedance be A/B. The exact equations give equality with P/Q at K distinct arguments. The polynomial AQ-BP has degree at most n+q and n+q+1 distinct roots, so it is identically zero. This reasoning remains valid with descriptor constraints, uncontrollable modes or unobservable modes. It does not assume a minimal state-space representation. QED.

A requested restriction on node count, allowed branches or component signature changes the scope of the formula. The checker recomputes its scope. It never reads a user-supplied `full_topology_coverage=true` flag as authority.

## 3. Independent infeasibility certificates

Let E_1,...,E_M be the compiled equations. An accepted refutation has the form

\[
\boxed{-1=\sum_\ell w_\ell S_\ell(x)^2+\sum_j A_j(x)E_j(x),\qquad w_\ell\in\mathbb Q_{\ge0}.}
\tag{3.1}
\]

All polynomial coefficients are rational. The checker expands the right side using Python integers and Fraction and requires exact coefficient equality with -1. It independently checks every weight is nonnegative. No floating-point residual, SDP eigenvalue tolerance or solver status is accepted as proof.

### Theorem 3.1. Soundness

If (3.1) holds, the equality system has no real solution.

**Proof.** At a hypothetical solution the equation-multiplier terms vanish, and the square terms are nonnegative. Their sum cannot be -1. QED.

### Theorem 3.2. Completeness of the certificate language

For a finite system of rational polynomial equalities with no real solution, a certificate of form (3.1) exists, with no a priori restriction on its degree or size.

This is the classical real Nullstellensatz, not a new circuit theorem. The rational-coefficient statement can also be seen algebraically: if -1 is not a sum of squares in the quotient Q[x]/(E), its real spectrum is nonempty, yielding a homomorphism into a real closed field. The images of x give a solution. Since real closed fields agree on existential sentences with rational coefficients, a real solution would then exist. Contraposition gives -1 as a sum of squares modulo the rational ideal. Lifting the equality from the quotient yields (3.1). Positive rational weights can be retained explicitly in a sound checker, or absorbed into finitely many rational squares.

There is no implication that a numerically computed fixed-degree Gram matrix can always be rounded to a rational certificate of the same degree. There is no claimed small uniform degree bound. The code checks exact identities and fails closed when a proposed one is wrong.

**Implemented scope.** `exact_polynomials.py` checks this general identity language. `polynomial_budget.py` regenerates the circuit system, checks the equation digest, and preserves topology scope. Certificate discovery is currently implemented for zero-storage contradictions and energy-signature contradictions. It is NOT a general automatic Positivstellensatz generator. This release does not provide a new polynomial refutation of every mixed-RLC lower budget in Hughes's classification.

## 4. A uniform energy-based refutation generator

The following identity gives useful exact exclusions without invoking a generic solver.

Take two exact real nodal systems

\[
Y_a v_a=e+e_a,\qquad Y_b v_b=e+e_b,
\]

where e is the unit-current port vector and e_a,e_b are the KCL residual vectors. Write Z_a=e^T v_a and Z_b=e^T v_b. Algebraic expansion gives

\[
\begin{aligned}
&(v_a-v_b)^TY_a(v_a-v_b)+v_b^T(Y_b-Y_a)v_b\\
&\quad=Z_a-Z_b+(v_a-2v_b)^T e_a+v_b^T e_b.
\end{aligned}
\tag{4.1}
\]

For an RC-only network, choose sigma_a<sigma_b. Every edge coefficient of Y_b-Y_a is nonnegative. For an RL-only network, reverse the argument order, so 1/sigma_b-1/sigma_a>0. After the amplitude-square substitution, both quadratic forms on the left are explicit positive rational weighted sums of polynomial squares.

If the target violates the corresponding monotonicity, Z_a-Z_b=-delta<0. Dividing (4.1) by delta and moving the residual terms gives exactly (3.1).

This proves, with explicit certificates, that RC-only impedances cannot increase on the positive real axis, and RL-only impedances cannot decrease. These monotonicity facts are classical. The implementation supplies their exact polynomial proof objects for arbitrary node counts. It is not a newly claimed physical law.

The release generates RC exclusions for Z=(s+1)/(s+2) and RL exclusions for Z=(s+3)/(s+2), at node bounds 4, 6, 8 and 14. These are signature exclusions. Both targets are realizable in the larger RLC class. The checker must not mislabel these proofs as global RLC impossibility.

## 5. Independent algebraic circuit witnesses

A witness contains a squarefree rational polynomial f(t), a rational interval isolating one real root theta, and a rational polynomial in theta for each component parameter. It also contains the target and the proposed storage budget.

The checker performs the following exact operations:

- Sturm counting verifies that the root interval contains exactly one root and neither endpoint is a root.
- Rational polynomial remainder arithmetic represents values in Q[t]/(f).
- Exact root refinement and interval evaluation establish signs of component values.
- Polynomial extended Euclid supplies inverses. A nonunit inverse causes rejection, not a numerical substitute.
- Exact Gaussian elimination solves each positive-argument nodal system.
- n+q+1 exact matches prove the full rational identity by Theorem 2.1's degree argument.

The checker does not need to prove f irreducible for soundness: accepting a zero remainder is sufficient at its isolated root. A reducible defining polynomial can cause conservative rejection when a required quotient-ring inverse is not a unit. For representation completeness one can use a primitive element's minimal polynomial.

### Theorem 5.1. Algebraic witnesses suffice for rational input

If the rational feasibility formula has a real solution, it has a real-algebraic solution. A finite set of real algebraic component values lies in one finite extension Q(theta). Hence it admits a finite witness in the stated representation. Real-algebraic sampling and the primitive-element theorem are classical results.

`solver_model_adapter.py` converts rational and root-object solver values into this representation using SymPy. This adapter is deliberately untrusted. An erroneous root selection, primitive element or component expression cannot establish a result unless the independent circuit checker subsequently verifies a positive network with the exact target response.

### Validated witnesses

1. Two RC sections with poles -3 +/- sqrt(2), plus a resistor, realize
   (2s^2+14s+20)/(s^2+6s+7) with minimum storage two.
2. One RC and one RL section with algebraic values realize
   (2s^2+12s+15)/(s^2+6s+7), also with minimum storage two.
3. A cubic algebraic field defined by theta^3-3theta+1=0 supplies a three-RC-section realization of
   (s^3+15s^2+69s+96)/(s^3+12s^2+45s+51), with minimum storage three.
4. Hughes's five-reactive realization of his degree-two example passes this checker, including its cancellations. The checker proves the UPPER bound five. The matching LOWER bound is Hughes's published theorem, not the degree test and not a new generic refutation.

## 6. A two-sided minimality certificate

### Theorem 6.1

To certify q_min=q, it is enough to provide:

1. A verified realization containing q reactive elements.
2. A verified complete infeasibility certificate for at most q-1 reactive elements.

**Proof.** Feasibility with at most q reactive elements is monotone in q. Excluding the entire q-1 budget also excludes every smaller budget. QED.

If q equals the reduced rational degree, exact polynomial gcd and the standard state-count bound already provide item 2. Separate refutations for all lower budgets are unnecessary.

`verify_minimality_bundle` checks the original target identity, actual storage count, lower-budget problem, exact refutation and complete topology coverage. A restricted refutation, different target or wrong budget is rejected. The demonstrated generic two-sided bundle is a one-reactive example with an independently checked zero-storage rejection. No higher-budget mixed-RLC global refutation is claimed in this release.

## 7. Repair of the local algebraic inverse

The unchanged earlier extraction did not produce a degree-ten result during the new bounded run. The replacement uses:

1. Exact polynomial gcds and primitive signed Sturm sequences.
2. A complete root count below -15 and disjoint quarter-unit brackets about the labelled extension poles -21,-22,... . Each bracket is verified to contain exactly one simple root. The count proves none were missed in the selected chart.
3. Exact dyadic bisection to width at most 2^-512.
4. Interval arithmetic on a 640-bit dyadic grid. Every rounding is integer floor/ceiling directed outward. This bounds denominator growth without changing proof semantics.
5. The same exact residue identities, algebraic deflation, and the independently replayed coefficient neighborhood of the degree-six core.

This is a stricter labelled local chart, not a global root-recognition algorithm. A root leaving its quarter-unit bracket returns failure of THIS chart, never general infeasibility.

Targets were specified by perturbing rational polynomial coefficients directly. The perturbation scale is 10^-(22+5k), where k=n-6. These are deliberately small local tests, not broad engineering specifications.

| Degree | Exact root/deflation time in recorded run | Maximum enclosed core coefficient deviation |
|---|---:|---:|
| 10 | about 0.34 s | below 1.098e-36 |
| 12 | about 0.75 s | below 1.964e-44 |
| 16 | about 2.44 s | below 1.059e-60 |
| 20 | about 7.32 s | below 1.743e-77 |

All lie in the previously certified 1e-13 core box, whose positive parameter neighborhood is replayed rather than assumed. The original target is checked coprime, so construction at its degree proves reactive minimality.

The degree-ten target additionally has a fresh 13-parameter component certificate in a cube of radius 1e-40. Its exact contraction bound is below 2.394e-33, and its center displacement is below 6.422e-11 times that radius. Degrees 12, 16 and 20 use the uniform core existence certificate; no separately optimized center is claimed for them.

## 8. Classical real-pole synthesis before generic search

Let a reduced target have only simple negative real finite poles, possibly one pole at zero, and polynomial part of degree at most one. Isolate all poles exactly and compute their residues. Positive residues give positive parallel RC sections. Negative residues give positive parallel RL sections after accounting for their positive feedthrough constants. A positive origin residue gives a series capacitor, and a nonnegative linear polynomial term gives a series inductor.

If the residual series resistance is certified nonnegative, partial fractions prove exact reconstruction. The construction has exactly the reduced rational degree in reactive components and is therefore storage-minimal. Failure of the residual-sign test is failure of a sufficient subclass, not a general impossibility result.

This route covers every nonzero rational positive-real target of degree at most one. It also covers a useful higher-degree class. The construction is classical Foster-type synthesis. The implementation independently verifies root coverage, signs and the residue identities.

The targets (s+3)/(s+2) and (2s^2+8s+7)/(s^2+3s+2), which timed out on the earlier generic route, now produce exact minimum-storage circuits directly. This is a hybrid algorithm improvement, not evidence that the unrestricted solver has become fast.

## 9. What remains open in this implementation

- Efficient unrestricted minimum synthesis for arbitrary rational positive-real targets remains unresolved. A fresh two-reactive generic SMT probe still returned UNKNOWN at its selected 500 ms limit.
- The general refutation LANGUAGE and CHECKER are implemented. General automatic discovery of large mixed-topology refutations is not.
- Primitive-element conversion can have expensive field-degree growth. It is a proposal route, not a scalability theorem.
- The generic compiler and circuit-witness input use rational target coefficients. Algebraic component values are supported. General algebraic target-coefficient input can be encoded mathematically, but is not exposed as a tested generic interface here.
- The local inverse is intentionally local. Its coefficient perturbations are not component manufacturing tolerances.
- All code remains ordinary Python, not a Lean or Coq formalization. Exact arithmetic and independent replay reduce trust in search code but do not eliminate ordinary implementation trust.
- No new historical-priority, SPICE, hardware, noise, power, tolerance or industrial-performance claim is made.

## 10. Sources

**Hughes.** Timothy H. Hughes, *Why RLC realizations of certain impedances need many more energy storage elements than expected*, IEEE Transactions on Automatic Control 62(9), 4333-4346 (2017), arXiv:1611.06258v2. The degree-versus-storage distinction and biquadratic minimum classification are retained from this source. Printed pages 4-5 contain Theorems 4-6; printed page 7 contains the blocked-resistor statement.

**Real-algebraic certificates.** Pablo A. Parrilo, *Semidefinite programming relaxations for semialgebraic problems*, Mathematical Programming 96, 293-320 (2003), DOI 10.1007/s10107-003-0387-5. Section 4.2, especially Theorem 4.6, supplies the classical Positivstellensatz framework. The polynomial identity verifier is an implementation of that framework, not a new general infeasibility theorem.

**Proposal infrastructure.** The official SymPy number-fields documentation describes primitive_element and to_number_field. The official Z3 API/guide describes exact real algebraic values and root objects. Neither proposal library's correctness is assumed by the standard-library circuit/refutation acceptance checks.

**Prior project package.** `prior_release/smith_hughes_generalization/` preserves the preceding release, including its seed and uniform-core certificates, source map and limitations. Its original search dispatcher is retained for provenance only. Use `src/synthesize_checked.py` in this release for the stricter acceptance policy.
