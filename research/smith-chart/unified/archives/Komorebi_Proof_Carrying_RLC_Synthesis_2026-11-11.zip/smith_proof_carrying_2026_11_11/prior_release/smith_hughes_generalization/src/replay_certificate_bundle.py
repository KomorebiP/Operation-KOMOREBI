#!/usr/bin/env python3
"""Author: Komorebi P. Replay certificates from independently supplied targets.
No numerical root solving. Recompute algebraic pole intervals before checking
core component certificates so the original target is bound to the proof.
"""
from pathlib import Path
import json
from local_core import setup,v,certify_neighbourhood
from algebraic_inverse import extract
from recover_components import verify_core_certificate
B=Path(__file__).resolve().parents[1]
if __name__=='__main__':
    c,*_=setup();seed=v.verify(c)
    local=certify_neighbourhood()
    if local['status']!='PASS':raise AssertionError('Uniform inverse failed')
    reports=[]
    for n in [6,7,8]:
        target=json.loads((B/f'examples/independent_degree_{n}_input.json').read_text())
        proved=extract(target['P'],target['Q'])
        if proved['status']!='PASS':raise AssertionError('Algebraic deflation failed')
        cert=json.loads((B/f'results/independent_degree_{n}_component_certificate.json').read_text())
        reports.append({'degree':n,'deflation_status':proved['status'],'component_status':verify_core_certificate(cert,proved)['status'],
                        'minimum_reactive_count':n})
    out={'author':'Komorebi P.','status':'PASS','seed':seed['status'],'uniform_inverse':local['status'],'independent_targets':reports,
         'claim':'The exact original rational targets were re-isolated and bound to the component existence certificates.'}
    (B/'results/bundle_replay.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
