"""Author: Komorebi P. Exact, uniform target-coefficient neighbourhood certificate.
The target is supplied independently, not generated from guessed components.
"""
from fractions import Fraction as F
from pathlib import Path
import importlib.util, json, math, time
BASE=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('seed_verifier',BASE/'certified_seed/src/verify_exact_six.py')
v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)

def setup():
    c=json.loads((BASE/'certified_seed/results/six_reactive_certificate.json').read_text())
    return c,list(map(F,c['center'])),[list(map(F,row)) for row in c['preconditioner']],v.regenerate()[0]

def certify_neighbourhood(radius=F(1,10**8),delta=F(1,10**13)):
    start=time.monotonic(); cert,x,M,terms=setup()
    f,J=v.evaluate(x,terms);MJ=v.matmul(M,J)
    defect=v.norm([[F(i==j)-MJ[i][j] for j in range(13)] for i in range(13)])
    eta=max(map(abs,v.mv(M,f)));mn=v.norm(M)
    b=[abs(z)+radius for z in x]
    # T=x-MF. Bound its Hessian directly after preconditioning.
    Hrows=[F(0)]*13
    K0=F(0);K1=F(0)
    for ids,coeff,origin,power in terms:
        prod=math.prod(b[j] for j in ids)
        grad=sum(prod/b[j] for j in ids)
        hess=sum(prod/(b[j]*b[k]) for j in ids for k in ids if j!=k)
        # A perturbation <=delta of every P/Q coefficient contributes at
        # most delta times this monomial to each residual coefficient.
        K0+=prod;K1+=grad
        for row in range(13):
            Hrows[row]+=abs(sum(M[row][i]*c for i,c in coeff))*hess
    H=max(Hrows)
    q=defect+radius*H+mn*delta*K1
    displacement=eta+mn*delta*K0
    good=min(x)>radius and q<1 and displacement+q*radius<radius
    report={'status':'PASS' if good else 'FAIL','author':'Komorebi P.',
      'component_radius':str(radius),'target_coefficient_radius':str(delta),
      'normalization':'Q leading coefficient fixed at 150; 7 P and 6 remaining Q coefficients vary independently',
      'exact_bounds':{k:str(z) for k,z in [('linear_defect',defect),('base_displacement',eta),('preconditioner_norm',mn),('preconditioned_Hessian',H),('coefficient_residual_bound',K0),('coefficient_Jacobian_bound',K1),('uniform_contraction',q),('uniform_displacement',displacement)]},
      'readable_bounds':{'q':float(q),'displacement_over_radius':float(displacement/radius),'H':float(H),'K0':float(K0),'K1':float(K1)},
      'arithmetic':'all acceptance inequalities exact fractions.Fraction','seconds':time.monotonic()-start}
    return report

def evaluate_target(x,P,Q,terms):
    new=[]
    for ids,_,origin,power in terms:
        poly,sgn=(Q,1) if origin=='N' else (P,-1)
        new.append((ids,tuple((power+j,sgn*c) for j,c in enumerate(poly)),origin,power))
    return v.evaluate(x,new)

if __name__=='__main__':
    out=certify_neighbourhood()
    (BASE/'results/local_neighbourhood.json').write_text(json.dumps(out,indent=2))
    print(json.dumps({k:z for k,z in out.items() if k!='exact_bounds'},indent=2))
