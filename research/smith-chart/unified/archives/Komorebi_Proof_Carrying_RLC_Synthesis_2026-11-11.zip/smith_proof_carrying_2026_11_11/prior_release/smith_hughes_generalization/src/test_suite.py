"""Author: Komorebi P. Reproducible exact regression and rejection tests."""
import unittest,json
from pathlib import Path
from fractions import Fraction as F
import sympy as S
from hughes_minimum import target,synthesize,identify,s
from local_core import certify_neighbourhood,v,setup
from algebraic_inverse import extract,I
from budget_solver import encode,run
from witness_check import verify,sexpr,rational
from boundary import upper_bound,resistor_conductance
from recover_components import verify_core_certificate
B=Path(__file__).resolve().parents[1]

class ExactResearchTests(unittest.TestCase):
    def test_seed_replay(self):
        c,*_=setup();self.assertEqual(v.verify(c)['status'],'PASS')
    def test_seed_rejection(self):
        c,*_=setup();c['center'][0]='-1'
        with self.assertRaises(AssertionError):v.verify(c)
    def test_uniform_local_box(self):
        r=certify_neighbourhood();self.assertEqual(r['status'],'PASS')
        self.assertLess(F(r['exact_bounds']['uniform_contraction']),F(236,1000))
        self.assertLess(F(r['exact_bounds']['uniform_displacement'])/F(r['component_radius']),F(643,1000))
    def test_oversized_target_box_rejected(self):
        self.assertEqual(certify_neighbourhood(delta=F(1,10**12))['status'],'FAIL')
    def test_hughes_all_cases(self):
        fixtures=[(S.Rational(1,2),1,3),(2,-1,3),(S.Rational(5,8),S.Rational(5,6),4),(S.Rational(8,5),-S.Rational(6,5),4),(S.Rational(8,5),-S.Rational(32,15),4),(S.Rational(5,8),S.Rational(15,32),4),(S.Rational(2,3),1,5),(S.Rational(3,2),-S.Rational(9,4),5)]
        for W,Fv,q in fixtures:
            with self.subTest(W=W,F=Fv):self.assertEqual(synthesize(target(1,1,W,Fv))['minimum_reactive_count'],q)
    def test_hughes_scaling(self):
        for K,w,W,Fv in [(S.Rational(3,2),S.Rational(4,3),S.Rational(2,3),1),(2,3,S.Rational(1,2),2)]:
            self.assertEqual(synthesize(target(K,w,W,Fv))['status'],'PASS')
    def test_minimum_class_rejection(self):
        with self.assertRaises(ValueError):identify((s*s+s+1)/(s*s+2*s+2))
    def test_independent_algebraic_targets(self):
        for n in [6,7,8]:
            a=json.loads((B/f'examples/independent_degree_{n}_input.json').read_text())
            r=extract(a['P'],a['Q']);self.assertEqual(r['status'],'PASS');self.assertEqual(r['minimum_reactive_count'],n)
    def test_recovered_component_certificates(self):
        for n in [6,7,8]:
            proposal=json.loads((B/f"examples/independent_degree_{n}.json").read_text())
            cert=json.loads((B/f"results/independent_degree_{n}_component_certificate.json").read_text())
            self.assertEqual(verify_core_certificate(cert,proposal)["status"],"PASS")
        cert["component_center"][0]="-1"
        with self.assertRaises(ValueError):verify_core_certificate(cert,proposal)
    def test_outside_chart_not_certified(self):
        p=list(map(F,v.P));q=list(map(F,v.Q));p[0]+=1
        self.assertNotEqual(extract(p,q)['status'],'PASS')
    def test_interval_safety(self):
        with self.assertRaises(ValueError):I(1)/I(-1,1)
        with self.assertRaises(ValueError):I(2,1)
        self.assertEqual((I(1,2)*I(-3,-2)).serialize(),['-6','-2'])
    def test_universal_encoding_dimensions(self):
        smt,names,meta=encode(v.P,v.Q,6)
        self.assertEqual(meta['node_bound'],14);self.assertEqual(meta['exact_sample_count'],13)
        self.assertTrue(meta['full_topology_coverage']);self.assertEqual(len(names),273)
        self.assertIn('(ite (> h_0_1 0) 1.0 0.0)',smt)
    def test_full_low_budget_solver(self):
        r,_=run([1],[2,1],1,timeout_ms=2000)
        self.assertEqual(r['status'],'sat')
        vals={k:rational(a) for k,a in sexpr(r['values'])}
        self.assertEqual(verify([1],[2,1],1,vals)['status'],'PASS')
        r,_=run([1],[2,1],0,timeout_ms=2000);self.assertEqual(r['status'],'unsat')
    def test_exact_witness_and_corruption(self):
        vals={'g_1_2':F(1),'c_1_2':F(1),'g_2_3':F(2),'c_2_3':F(1),'g_0_3':F(1,2)}
        self.assertEqual(verify([7,8,2],[2,3,1],2,vals)['status'],'PASS')
        vals['g_0_3']=F(1,2)+F(1,1000000)
        with self.assertRaises(ValueError):verify([7,8,2],[2,3,1],2,vals)
    def test_resistor_obstruction(self):
        self.assertEqual(resistor_conductance([(0,2,F(2)),(1,2,F(2))]),1)
        self.assertEqual(resistor_conductance([(0,2,F(2))]),0)
    def test_recursive_upper_bound(self):
        self.assertEqual([upper_bound(j) for j in range(7)],[0,1,5,7,15,19,35])
        for n in range(2,50):self.assertEqual(upper_bound(n),5+2*upper_bound(n-2))
        for n in range(20):
            for m in range(n+1):self.assertLessEqual(n-m+upper_bound(m),upper_bound(n))

if __name__=='__main__':
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(ExactResearchTests)
    with (B/'results/test_suite.log').open('w') as log:
        result=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
    summary={'author':'Komorebi P.','status':'PASS' if result.wasSuccessful() else 'FAIL',
             'test_methods':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
             'scope':'Exact checks and rejection controls; not an exhaustive large-order synthesis benchmark'}
    (B/'results/test_suite.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
    if not result.wasSuccessful():print((B/'results/test_suite.log').read_text());raise SystemExit(1)
