"""Author: Komorebi P. All-topology RLC synthesis as exact bilinear feasibility.
The theorem uses n+q+1 positive rational test frequencies and at most 2q+2 nodes.
Zero admittances mean missing branches. No positivity/identity claim uses floats.
"""
from __future__ import annotations
from fractions import Fraction as F
from itertools import combinations
from pathlib import Path
import json
from z3_bridge import solve

def rat(x):
    x=F(x)
    a=str(abs(x.numerator))
    out=a if x.denominator==1 else f'(/ {a} {x.denominator})'
    return f'(- {out})' if x<0 else out

def add(xs):
    xs=list(xs)
    return '0' if not xs else xs[0] if len(xs)==1 else '(+ '+' '.join(xs)+')'
def peval(p,s):return sum(F(x)*F(s)**i for i,x in enumerate(p))

def encode(P,Q,q, *,nodes=None,allowed=None,fixed=None,storage_count=True):
    """Full search if nodes omitted and allowed is None; restrictions recorded.
    allowed={(type,i,j),...}; type in g,h,c. fixed maps variable names to rationals.
    Fixed topology fixtures may bypass the storage counter only when their count
    is separately checked. Full mode always includes it.
    """
    P=list(map(F,P));Q=list(map(F,Q));n=max(len(P),len(Q))-1
    if q<0:raise ValueError('q must be nonnegative')
    m=2*q+2 if nodes is None else nodes
    if m<2 or m>2*q+2:raise ValueError('node count outside complete bound')
    edges=list(combinations(range(m),2));names=[];react=[];clauses=['(set-logic QF_NRA)']
    coeff={}
    for typ in ['g','h','c']:
        for a,b in edges:
            name=f'{typ}_{a}_{b}'
            if allowed is not None and (typ,a,b) not in allowed:coeff[typ,a,b]='0';continue
            coeff[typ,a,b]=name;names.append(name)
            clauses += [f'(declare-const {name} Real)', f'(assert (>= {name} 0))']
            if typ!='g':react.append(name)
            if fixed and name in fixed:clauses.append(f'(assert (= {name} {rat(fixed[name])}))')
    if storage_count:
        # Use Real-valued 0/1 to remain entirely in QF_NRA, no mixed integers.
        clauses.append(f'(assert (<= {add(f"(ite (> {name} 0) 1.0 0.0)" for name in react)} {q}))')
    elif len(react)>q:raise ValueError('No-storage-counter mode must have <=q reactive slots')
    for k in range(1,n+q+2):
        Z=peval(P,k)/peval(Q,k)
        if Z<=0:raise ValueError('Nonzero PR inputs must be positive on the positive real axis')
        def v(i):return '0' if i==0 else rat(Z) if i==1 else f'v_{k}_{i}'
        for i in range(2,m):
            clauses += [f'(declare-const {v(i)} Real)',f'(assert (>= {v(i)} 0))',f'(assert (<= {v(i)} {rat(Z)}))']
        currents={i:[] for i in range(1,m)}
        for a,b in edges:
            y=add([coeff['g',a,b],f'(* {rat(F(1,k))} {coeff["h",a,b]})',f'(* {k} {coeff["c",a,b]})'])
            if a:currents[a].append(f'(* {y} (- {v(a)} {v(b)}))')
            currents[b].append(f'(* {y} (- {v(b)} {v(a)}))')
        for i in range(1,m):clauses.append(f'(assert (= {add(currents[i])} {int(i==1)}))')
    meta={'degree_bound':n,'storage_budget':q,'node_bound':m,'exact_sample_count':n+q+1,
          'full_topology_coverage':nodes is None and allowed is None,'continuous_branch_variables':len(names),
          'equation_degree_at_most':2,'arithmetic':'rational SMT-LIB; sample equality is exact',
          'qualifier':'UNKNOWN on timeout is not infeasibility; SAT extraction requires witness checking'}
    return '\n'.join(clauses),names,meta

def run(P,Q,q,timeout_ms=5000,**kwargs):
    smt,names,meta=encode(P,Q,q,**kwargs)
    result=solve(smt,timeout_ms,names)
    return {**meta,**result},smt

if __name__=='__main__':
    BASE=Path(__file__).resolve().parents[1]
    fixtures=[('constant',[3],[1],0,{}),
        ('one_capacitor',[1],[2,1],1,{}),
        ('one_RC_series_R',[3,1],[2,1],1,{})]
    results={}
    for label,P,Q,q,kw in fixtures:
        r,smt=run(P,Q,q,timeout_ms=5000,**kw);results[label]=r
        (BASE/f'examples/{label}.smt2').write_text(smt+'\n(check-sat-using qfnra-nlsat)\n')
        print(label,r['status'],r['seconds'],flush=True)
    (BASE/'results/budget_solver.json').write_text(json.dumps(results,indent=2))
