"""Author: Komorebi P. Numerical proposal, exact rational acceptance for a
new independent target's algebraic core. Every acceptance bound is Fraction.
No numerical residual is used as an existence proof.
"""
from fractions import Fraction as F
from pathlib import Path
import json,math,mpmath as mp
from local_core import setup,v
B=Path(__file__).resolve().parents[1]

def dec(x,places=85):
    x=F(x);scale=10**places
    return F(x.numerator*scale//x.denominator,scale)
def fm(x):return mp.mpf(x.numerator)/x.denominator

def terms_for(P,Q,terms):
    return [(ids,tuple((power+j,c if origin=='N' else -c) for j,c in enumerate(Q if origin=='N' else P)),origin,power) for ids,_,origin,power in terms]

def mp_eval(x,terms):
    f=mp.matrix(13,1);J=mp.matrix(13,13)
    for ids,co,origin,power in terms:
        prod=mp.fprod(x[j] for j in ids)
        for i,c in co:
            z=fm(c)*prod;f[i]+=z
            for j in ids:J[i,j]+=z/x[j]
    return f,J

def verify_core_certificate(certificate,proposal):
    """Replay without numerical solving. Proposal contains exact core enclosures
    proved by algebraic_inverse; the caller must replay that deflation first.
    """
    P=list(map(F,certificate['core_P_center']));Q=list(map(F,certificate['core_Q_center']))
    x=list(map(F,certificate['component_center']));r=F(certificate['component_radius']);eps=F(certificate['core_uncertainty'])
    old,xold,M,terms=setup()
    if len(P)!=7 or len(Q)!=7 or len(x)!=13 or r<=0 or eps<0:raise ValueError('Invalid certificate dimensions or radii')
    if certificate['parameter_order']!=old['parameter_order'] or certificate['degree']!=proposal['degree']:raise ValueError('Certificate binding mismatch')
    for mids,key in [(P,'core_P_intervals'),(Q,'core_Q_intervals')]:
        for mid,(lo,hi) in zip(mids,proposal[key]):
            if not mid-eps<=F(lo)<=F(hi)<=mid+eps:raise ValueError('Core enclosure not covered')
    tt=terms_for(P,Q,terms);f,J=v.evaluate(x,tt)
    MJ=v.matmul(M,J);defect=v.norm([[F(i==j)-MJ[i][j] for j in range(13)] for i in range(13)])
    eta=max(map(abs,v.mv(M,f)));mn=v.norm(M)
    bb=[abs(a)+r for a in x];Hrows=[F(0)]*13;K0=K1=F(0)
    for ids,co,origin,power in tt:
        prod=math.prod(bb[j] for j in ids);K0+=prod;K1+=sum(prod/bb[j] for j in ids)
        hh=sum(prod/(bb[j]*bb[k]) for j in ids for k in ids if j!=k)
        for row in range(13):Hrows[row]+=abs(sum(M[row][i]*a for i,a in co))*hh
    contraction=defect+r*max(Hrows)+mn*eps*K1;displacement=eta+mn*eps*K0
    if not(min(x)>r and defect<1 and contraction<1 and displacement+contraction*r<r):raise ValueError('Exact contraction rejected')
    return {'status':'PASS','exact_contraction':str(contraction),'exact_displacement':str(displacement),
      'readable_contraction':float(contraction),'readable_displacement_over_radius':float(displacement/r),
      'minimum_parameter_lower':str(min(x)-r),'all_acceptance_arithmetic':'Fraction',
      'claim':'For every coefficient vector in the proved core interval box, one unique positive exact circuit root exists in this component cube.'}

def recover(proposal):
    if proposal['status']!='PASS':raise ValueError('Deflation is not certified')
    P=[dec((F(lo)+F(hi))/2) for lo,hi in proposal['core_P_intervals']]
    Q=[dec((F(lo)+F(hi))/2) for lo,hi in proposal['core_Q_intervals']]
    eps=F(1,10**55)
    old,x0,M,terms=setup();tt=terms_for(P,Q,terms)
    with mp.workdps(105):
        x=mp.matrix([fm(a) for a in x0]);steps=0
        for steps in range(8):
            f,J=mp_eval(x,tt)
            if max(abs(a) for a in f)<mp.mpf('1e-90'):break
            x-=mp.lu_solve(J,f)
        center=[dec(F(mp.nstr(a,100))) for a in x]
    certificate={'author':'Komorebi P.','degree':proposal['degree'],'core_P_center':list(map(str,P)),
       'core_Q_center':list(map(str,Q)),'core_uncertainty':str(eps),'component_center':list(map(str,center)),
       'component_radius':str(F(1,10**40)),'preconditioner':'retained exact seed preconditioner',
       'parameter_order':old['parameter_order'],'proposal_Newton_iterations':steps,
       'exact_component_definition':'Unique root of the core cofactor equations in the certified component cube, for the algebraic core defined by the input roots and exact deflation.'}
    certificate['verification']=verify_core_certificate(certificate,proposal)
    certificate['approximate_physical_values']=[float(1/a if j<10 else a) for j,a in enumerate(center)]
    return certificate

if __name__=='__main__':
    for n in [6,7,8]:
        p=json.loads((B/f'examples/independent_degree_{n}.json').read_text())
        c=recover(p);(B/f'results/independent_degree_{n}_component_certificate.json').write_text(json.dumps(c,indent=2))
        print(n,c['verification']['status'],c['verification']['readable_contraction'],c['verification']['readable_displacement_over_radius'],flush=True)
