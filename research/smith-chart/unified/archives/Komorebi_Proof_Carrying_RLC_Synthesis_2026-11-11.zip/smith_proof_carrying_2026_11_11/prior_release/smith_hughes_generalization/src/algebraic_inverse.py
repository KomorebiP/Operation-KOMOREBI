"""Author: Komorebi P. Certified algebraic-pole deflation into the six-state core.
Rational interval arithmetic + exact SymPy root isolation. No rational-pole assumption.
This is a local recognizer/synthesizer, not a claim to cover all positive-real inputs.
"""
from __future__ import annotations
from dataclasses import dataclass
from fractions import Fraction as F
from pathlib import Path
import json, sympy as S
from local_core import v,certify_neighbourhood

@dataclass(frozen=True)
class I:
    lo:F
    hi:F
    def __init__(self,lo,hi=None):
        lo=F(lo);hi=lo if hi is None else F(hi)
        if lo>hi:raise ValueError('Reversed interval')
        object.__setattr__(self,'lo',lo);object.__setattr__(self,'hi',hi)
    def __add__(self,o):
        o=asI(o);return I(self.lo+o.lo,self.hi+o.hi)
    __radd__=__add__
    def __neg__(self):return I(-self.hi,-self.lo)
    def __sub__(self,o):return self+-asI(o)
    def __rsub__(self,o):return asI(o)+-self
    def __mul__(self,o):
        o=asI(o);vals=[a*b for a in [self.lo,self.hi] for b in [o.lo,o.hi]]
        return I(min(vals),max(vals))
    __rmul__=__mul__
    def __truediv__(self,o):
        o=asI(o)
        if o.lo<=0<=o.hi:raise ValueError('Denominator interval contains zero')
        return self*I(1/o.hi,1/o.lo)
    def absmax(self):return max(abs(self.lo),abs(self.hi))
    def serialize(self):return [str(self.lo),str(self.hi)]

def asI(x):return x if isinstance(x,I) else I(x)
def horner(p,x):
    z=I(0)
    for c in reversed(p):z=z*x+asI(c)
    return z

def synthetic(p,alpha):
    """Quotient by s-alpha. For the true algebraic root the required remainder is zero."""
    if len(p)<2:raise ValueError('Constant polynomial')
    q=[I(0)]*(len(p)-1);q[-1]=asI(p[-1])
    for j in range(len(q)-2,-1,-1):q[j]=asI(p[j+1])+alpha*q[j+1]
    return q,asI(p[0])+alpha*q[0]

def extract(P,Q,core_delta=F(1,10**13),eps=F(1,10**75)):
    P=list(map(F,P));Q=list(map(F,Q));n=max(len(P),len(Q))-1
    if n<6 or len(P)!=len(Q) or Q[-1]!=150:raise ValueError('Requires degree>=6, biproper input with denominator leading coefficient 150')
    x=S.Symbol('s');Qp=S.Poly(sum(S.Rational(c.numerator,c.denominator)*x**j for j,c in enumerate(Q)),x)
    Pp=S.Poly(sum(S.Rational(c.numerator,c.denominator)*x**j for j,c in enumerate(P)),x)
    if S.gcd(Pp,Qp).degree()!=0:raise ValueError('Input is not reduced')
    intervals=Qp.intervals(eps=S.Rational(eps.numerator,eps.denominator))
    selected=[(I(F(a),F(b)),m) for (a,b),m in intervals if F(b)<-15]
    if len(selected)!=n-6 or any(m!=1 for _,m in selected):raise ValueError('Not in this labelled local pole chart')
    dp=[j*Q[j] for j in range(1,len(Q))]
    pp=list(map(I,P));qq=list(map(I,Q));modules=[]
    for root,m in selected:
        rho=horner(P,root)/horner(dp,root)
        if rho.lo>0:kind='RC';u=rho
        elif rho.hi<0:kind='RL';u=rho/root
        else:raise ValueError('Residue sign unresolved')
        if u.lo<=0:raise ValueError('Nonpositive gadget')
        qhat,remq=synthetic(qq,root)
        shifted=qhat if kind=='RC' else [I(0)]+qhat
        subtract=[asI(p)-(u*shifted[j] if j<len(shifted) else I(0)) for j,p in enumerate(pp)]
        phat,remp=synthetic(subtract,root)
        # Exact divisibility follows from the root and residue identities; intervals
        # supply consistency checks, not zero-equality acceptance by rounding.
        if not(remq.lo<=0<=remq.hi and remp.lo<=0<=remp.hi):raise AssertionError('Deflation interval contradiction')
        pp,qq=phat,qhat
        modules.append({'kind':kind,'pole_interval':root.serialize(),'residue_interval':rho.serialize(),
                        'u_interval':u.serialize(),'exact_definition':'alpha is the unique root of input Q in its isolating interval; rho=P(alpha)/Qprime(alpha); RC u=rho; RL u=rho/alpha'})
    if len(pp)!=7 or len(qq)!=7:raise AssertionError('Wrong core degree')
    deviations=[(a-I(b)).absmax() for a,b in zip(pp,v.P)]+[(a-I(b)).absmax() for a,b in zip(qq,v.Q)]
    ok=max(deviations)<=core_delta and qq[-1]==I(150)
    return {'status':'PASS' if ok else 'OUTSIDE_CERTIFIED_CHART','degree':n,'minimum_reactive_count':n if ok else None,
            'modules':modules,'core_P_intervals':[x.serialize() for x in pp], 'core_Q_intervals':[x.serialize() for x in qq],
            'max_core_coefficient_deviation':str(max(deviations)),
            'readable_max_core_deviation':float(max(deviations)),'allowed_core_deviation':str(core_delta),
            'proof':'Exact simple-pole residue identities, rational interval enclosures, uniform positive-core contraction, degree lower bound',
            'source_of_input':'independent coefficient perturbation, not circuit-generated',
            'algebraic_output':'Components specified by isolated input roots and the unique positive solution of the core polynomial equations'}

def extended(P,Q,kind,a):
    pp=[F(0)]*(len(P)+1);qq=[F(0)]*(len(Q)+1)
    for j,c in enumerate(P):pp[j]+=a*c;pp[j+1]+=c
    for j,c in enumerate(Q):qq[j]+=a*c;qq[j+1]+=c;pp[j+(kind=='RL')]+=c
    return pp,qq

if __name__=='__main__':
    BASE=Path(__file__).resolve().parents[1]
    report=certify_neighbourhood()
    if report['status']!='PASS':raise AssertionError('Core certificate failed')
    outcomes=[]
    for k in [0,1,2]:
        P=list(map(F,v.P));Q=list(map(F,v.Q))
        for j in range(k):P,Q=extended(P,Q,'RC' if j%2==0 else 'RL',21+j)
        # Perturb the rational coefficients directly; do not derive a target from components.
        eps=F(1,10**(22+5*k))
        P=[c+eps*(j+1)*(-1)**j for j,c in enumerate(P)]
        Q=[c+eps*(j+2)*(-1)**(j+1) if j<len(Q)-1 else c for j,c in enumerate(Q)]
        outcome=extract(P,Q)
        outcome['target_P_ascending']=list(map(str,P));outcome['target_Q_ascending']=list(map(str,Q))
        # Exact irreducible factor degrees document that the new poles need not be rational.
        s=S.Symbol('s');qp=S.Poly(sum(S.Rational(c.numerator,c.denominator)*s**j for j,c in enumerate(Q)),s)
        outcome['denominator_irreducible_factor_degrees']=[(f.degree(),e) for f,e in S.factor_list(qp)[1]]
        outcomes.append(outcome)
        (BASE/f'examples/independent_degree_{6+k}.json').write_text(json.dumps(outcome,indent=2))
        print('degree',6+k,outcome['status'],outcome['readable_max_core_deviation'],'factor degrees',outcome['denominator_irreducible_factor_degrees'],flush=True)
    (BASE/'results/algebraic_inverse.json').write_text(json.dumps(outcomes,indent=2))
