"""Author: Komorebi P. Hughes blocked-resistor consequences in any dimension."""
from fractions import Fraction as F
from pathlib import Path
import json
from witness_check import linear

def resistor_conductance(edges,port=1,ground=0):
    """Exact resistor-only effective conductance. Edges are (a,b,g), g>=0."""
    edges=[(a,b,F(g)) for a,b,g in edges if F(g)>0]
    reach={ground}
    while True:
        nxt=reach|{b for a,b,g in edges if a in reach}|{a for a,b,g in edges if b in reach}
        if nxt==reach:break
        reach=nxt
    if port not in reach:return F(0)
    interior=sorted(reach-{ground,port});idx={a:i for i,a in enumerate(interior)}
    A=[[F(0) for _ in interior] for _ in interior];rhs=[F(0) for _ in interior]
    for a,b,g in edges:
        if a not in reach:continue
        for i,j in [(a,b),(b,a)]:
            if i in idx:
                A[idx[i]][idx[i]]+=g
                if j in idx:A[idx[i]][idx[j]]-=g
                elif j==port:rhs[idx[i]]+=g
    vals={ground:F(0),port:F(1)};vals.update(zip(interior,linear(A,rhs) if interior else []))
    return sum(g*(vals[port]-vals[b if a==port else a]) for a,b,g in edges if port in [a,b])

def upper_bound(n):
    """Derived from Hughes Theorem 2 + a degree-accounted Foster preamble.
    Not claimed sharp or novel. Nonzero scalar positive-real algebraic input.
    """
    if not isinstance(n,int) or n<0:raise ValueError('Nonnegative integer degree required')
    return 5*(2**(n//2)-1) if n%2==0 else 6*2**(n//2)-5

if __name__=='__main__':
    B=Path(__file__).resolve().parents[1]
    c=json.loads((B/'certified_seed/results/six_reactive_certificate.json').read_text())
    # At every component vector in the new local cube, g >= center - 1e-8.
    r=F(1,10**8);g=list(map(F,c['center']))[:7]
    low=resistor_conductance([(a,b,x-r) for (a,b),x in zip(c['R_edges'],g)])
    assert low>0
    table={str(n):upper_bound(n) for n in range(13)}
    for n in range(2,13):assert upper_bound(n)==5+2*upper_bound(n-2)
    for n in range(13):
        for m in range(n+1):assert n-m+upper_bound(m)<=upper_bound(n)
    report={'status':'PASS','seed_has_resistor_only_port_path':True,
       'admittance_dissipation_floor_exact':str(low),'readable_floor':float(low),
       'statement':'Re Y(iw) >= G_eff(R-only) wherever the finite unit-voltage sinusoidal solution exists; hence no biquadratic minimum function is realized by a topology with a strictly positive resistor-only port path.',
       'uniform_reactive_upper_bound_table':table,
       'bound_provenance':'Derived from the five-storage sections in Hughes Figure 4 / Theorem 2 and an explicit degree-accounted Foster preamble; not a novelty claim.'}
    (B/'results/boundary_and_bounds.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
