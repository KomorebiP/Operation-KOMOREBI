#!/usr/bin/env python3
"""Author: Komorebi P.
Exact rational certificate for a minimum-six-reactive transformer-free RLC network.
Standard library only. No floating point in any acceptance decision.

The circuit has 7 positive resistors, 3 positive inductors, 3 positive capacitors.
All 13 circuit parameters are real algebraic numbers uniquely isolated by a cube.
The interval proof certifies a zero of all 13 coefficients of N*Q-D*P.
"""
from fractions import Fraction as F
from itertools import combinations
from pathlib import Path
import json, math, time
if not __debug__:
    raise RuntimeError("Do not use Python -O: exact certificate assertions must execute.")
BASE=Path(__file__).resolve().parents[1]
R_EDGES=[(0,3),(0,4),(1,5),(1,6),(2,5),(3,6),(4,7)]
L_EDGES=[(0,5),(2,3),(3,7)]
C_EDGES=[(0,6),(1,2),(4,5)]
EDGES=R_EDGES+L_EDGES+C_EDGES
EXP=[0]*7+[-1]*3+[1]*3
P=[75,335,1142,2200,2477,1385,450]
Q=[25,445,1250,1720,1375,795,150]

def forest_components(indices):
    parent=list(range(8))
    def find(x):
        while parent[x]!=x:x=parent[x]
        return x
    for k in indices:
        a,b=EDGES[k];a,b=find(a),find(b)
        if a==b:return None
        parent[a]=b
    return [find(i) for i in range(8)]

def regenerate():
    terms=[];nts=nfs=0
    for degree,sign,poly,origin in [(6,1,Q,'N'),(7,-1,P,'D')]:
        for ids in combinations(range(13),degree):
            cc=forest_components(ids)
            if cc is None:continue
            if degree==6:
                if cc[0]==cc[1]:continue
                assert len(set(cc))==2
                nfs+=1
            else:
                assert len(set(cc))==1
                nts+=1
            power=3+sum(EXP[k] for k in ids)
            assert 0<=power<=6
            coeff=tuple((power+j,sign*c) for j,c in enumerate(poly))
            terms.append((ids,coeff,origin,power))
    return terms,nts,nfs

def evaluate(x,terms):
    f=[F(0)]*13;J=[[F(0) for j in range(13)] for i in range(13)]
    for ids,co,origin,power in terms:
        value=math.prod(x[j] for j in ids)
        derivatives=[(j,value/x[j]) for j in ids]
        for i,c in co:
            f[i]+=c*value
            for j,dv in derivatives:J[i][j]+=c*dv
    return f,J

def norm(a):return max(sum(abs(x) for x in row) for row in a)
def matmul(a,b):return [[sum(x*y for x,y in zip(row,col)) for col in zip(*b)] for row in a]
def mv(a,b):return [sum(x*y for x,y in zip(row,b)) for row in a]

def polytrim(p):
    p=list(p)
    while len(p)>1 and p[-1]==0:p.pop()
    return p

def rem(a,b):
    a=polytrim(a);b=polytrim(b)
    while len(a)>=len(b) and any(a):
        d=len(a)-len(b);c=a[-1]/b[-1]
        for i,v in enumerate(b):a[i+d]-=c*v
        a=polytrim(a)
    return a

def gcd_degree(a,b):
    a=list(map(F,a));b=list(map(F,b))
    while any(b):a,b=b,rem(a,b)
    return len(polytrim(a))-1

def determinant(a):
    a=[list(map(F,row)) for row in a];out=F(1);n=len(a)
    for k in range(n):
        pivot=next((j for j in range(k,n) if a[j][k]),None)
        if pivot is None:return F(0)
        if pivot!=k:a[k],a[pivot]=a[pivot],a[k];out=-out
        v=a[k][k];out*=v
        for i in range(k+1,n):
            rat=a[i][k]/v
            for j in range(k+1,n):a[i][j]-=rat*a[k][j]
    return out

def resultant(a,b):
    aa=list(reversed(a));bb=list(reversed(b));m=len(a)-1;n=len(b)-1
    rows=[]
    for k in range(n):rows.append([0]*k+aa+[0]*(n-1-k))
    for k in range(m):rows.append([0]*k+bb+[0]*(m-1-k))
    return determinant(rows)

def independent_nodal_checks(terms):
    # Positive rational fixture unrelated to the certificate center.
    # This is a regression check of the tree expansion, not the existence proof.
    x=[F(i+2,i+3) for i in range(13)]
    for s in [F(1,7),F(1,3),F(1),F(2),F(5),F(11),F(17)]:
        Y=[[F(0) for _ in range(7)] for _ in range(7)]
        for j,(a,b) in enumerate(EDGES):
            y=x[j]*s**EXP[j]
            if a:Y[a-1][a-1]+=y
            if b:Y[b-1][b-1]+=y
            if a and b:Y[a-1][b-1]-=y;Y[b-1][a-1]-=y
        d=s**3*determinant(Y)
        minor=[[Y[i][j] for j in range(1,7)] for i in range(1,7)]
        n=s**3*determinant(minor)
        nn=dd=F(0)
        for ids,co,origin,power in terms:
            v=math.prod(x[j] for j in ids)*s**power
            if origin=='N':nn+=v
            else:dd+=v
        assert n==nn and d==dd
    return 7

def build_certificate():
    data=json.loads((BASE/'results/high_precision_root.json').read_text())
    # Exact terminating-decimal rationals, not binary floating point.
    def truncate(text,digits=90):
        val=F(text);scale=10**digits
        numerator=abs(val.numerator)*scale//val.denominator
        if val<0:numerator=-numerator
        return F(numerator,scale)
    x0=[truncate(x) for x in data['root']]
    M=[[truncate(v) for v in row] for row in data['inverse_jacobian']]
    certificate={'author':'Komorebi P.','radius':'1/100000000000000000000000000000000000000000000000000',
       'center':[str(x) for x in x0], 'preconditioner':[[str(x) for x in row] for row in M],
       'parameter_order':['g03','g04','g15','g16','g25','g36','g47','h05','h23','h37','C06','C12','C45'],
       'target_P_ascending':P,'target_Q_ascending':Q,
       'component_convention':'R=1/g, L=1/h, C=C, normalized units',
       'R_edges':R_EDGES,'L_edges':L_EDGES,'C_edges':C_EDGES,
       'claim':'Unique exact root in the stated cube, all components positive, input impedance P/Q; q_min=6.'}
    (BASE/'results/six_reactive_certificate.json').write_text(json.dumps(certificate,indent=2))
    return certificate

def verify(cert):
    start=time.time()
    assert cert['target_P_ascending']==P and cert['target_Q_ascending']==Q
    assert [tuple(e) for e in cert['R_edges']]==R_EDGES
    assert [tuple(e) for e in cert['L_edges']]==L_EDGES
    assert [tuple(e) for e in cert['C_edges']]==C_EDGES
    assert forest_components(tuple(range(7))) is not None
    assert len(set(forest_components(tuple(range(7)))))==1
    r=F(cert['radius']);x0=list(map(F,cert['center']));M=[list(map(F,row)) for row in cert['preconditioner']]
    assert len(x0)==13 and len(M)==13 and all(len(row)==13 for row in M)
    assert r==F(1,10**50)
    terms,nts,nfs=regenerate()
    assert nts==581 and nfs==389
    assert gcd_degree(P,Q)==0
    res=resultant(P,Q)
    assert res==48289705700056104960000000000
    nodal_tests=independent_nodal_checks(terms)
    f,J=evaluate(x0,terms)
    MJ=matmul(M,J)
    defect=norm([[F(i==j)-MJ[i][j] for j in range(13)] for i in range(13)])
    eta=max(map(abs,mv(M,f)))
    # Each x in the cube has |x_j|<=B. Every monomial is square-free,
    # degree 6 or 7. Its total Hessian absolute sum is <=d(d-1) B^(d-2).
    B=34
    assert max(abs(v)+r for v in x0)<B
    hrows=[0]*13
    for ids,co,origin,power in terms:
        d=len(ids)
        for i,c in co:hrows[i]+=abs(c)*d*(d-1)*B**(d-2)
    H=max(hrows)
    mnorm=norm(M)
    q=defect+mnorm*r*H
    minparam=min(v-r for v in x0)
    assert minparam>0
    assert defect<1
    assert q<1
    assert eta+q*r<r
    # Readable outward upper bounds, checked exactly, not rounded for acceptance.
    bounds={
        'residual_max_lt':F(1,10**80),
        'newton_displacement_eta_lt':F(1,10**80),
        'linear_defect_lt':F(1,10**80),
        'inverse_norm_lt':F(61),
        'contraction_q_lt':F(1,10**30),
        'minimum_parameter_gt':F(27,1000)
    }
    assert max(map(abs,f))<bounds['residual_max_lt']
    assert eta<bounds['newton_displacement_eta_lt']
    assert defect<bounds['linear_defect_lt']
    assert mnorm<bounds['inverse_norm_lt']
    assert q<bounds['contraction_q_lt']
    assert minparam>bounds['minimum_parameter_gt']
    report={'author':'Komorebi P.','status':'PASS','all_acceptance_arithmetic':'fractions.Fraction and Python integers',
        'n_equations':13,'n_variables':13,'n_tree_monomials':nts,'n_forest_monomials':nfs,
        'independent_exact_nodal_fixtures':nodal_tests,'target_resultant':str(res),
        'certificate_radius':str(r),'hessian_bound_integer':H,
        'strict_rational_bounds':{k:str(v) for k,v in bounds.items()},
        'proof_obligations':{'positive_cube':True,'invertible_preconditioner':True,'contraction':True,'self_mapping':True,'coprime_degree_six':True},
        'seconds':time.time()-start}
    (BASE/'results/verification_report.json').write_text(json.dumps(report,indent=2))
    print(json.dumps(report,indent=2))
    return report

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--build',action='store_true');args=p.parse_args()
    cert=build_certificate() if args.build else json.loads((BASE/'results/six_reactive_certificate.json').read_text())
    verify(cert)
