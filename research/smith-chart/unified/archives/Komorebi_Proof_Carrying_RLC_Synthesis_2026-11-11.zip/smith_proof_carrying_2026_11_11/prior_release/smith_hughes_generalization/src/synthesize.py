#!/usr/bin/env python3
"""Author: Komorebi P. Hybrid exact research synthesizer.
Input JSON: P,Q ascending rational coefficient arrays, as strings or integers.
Exact class and local proofs first; all-topology bilinear fallback afterward.
The fallback returns UNKNOWN on a timeout and NEVER treats it as impossibility.
"""
from pathlib import Path
from fractions import Fraction as F
import argparse,json,sympy as S
from hughes_minimum import synthesize as hughes,s
from algebraic_inverse import extract
from local_core import certify_neighbourhood
from budget_solver import run
from boundary import upper_bound
from recover_components import recover
from witness_check import verify,sexpr,rational

def minimum(P,Q,timeout_ms=5000,max_budget=None,skip_local=False):
    P=list(map(F,P));Q=list(map(F,Q))
    z=S.cancel(sum(S.Rational(c.numerator,c.denominator)*s**j for j,c in enumerate(P))/sum(S.Rational(c.numerator,c.denominator)*s**j for j,c in enumerate(Q)))
    pp,qq=map(lambda p:S.Poly(p,s),S.fraction(z));n=max(pp.degree(),qq.degree())
    if n==2:
        try:return {'route':'Hughes exact class','global_minimum_proved':True,**hughes(z)}
        except ValueError:pass
    if n>=6 and not skip_local:
        scale=S.Rational(150)/qq.LC()
        Pn=[F(scale*pp.nth(j)) for j in range(n+1)];Qn=[F(scale*qq.nth(j)) for j in range(n+1)]
        try:
            local=extract(Pn,Qn)
            if local['status']=='PASS':
                checked=certify_neighbourhood()
                if checked['status']!='PASS':raise AssertionError('Core replay failed')
                return {'route':'certified algebraic local inverse','global_minimum_proved':True,**local, 'core_component_certificate':recover(local)}
        except ValueError:pass
    P=[F(pp.nth(j)) for j in range(pp.degree()+1)];Q=[F(qq.nth(j)) for j in range(qq.degree()+1)]
    bound=upper_bound(n);cap=bound if max_budget is None else min(bound,max_budget)
    history=[]
    for q in range(n,cap+1):
        r,_=run(P,Q,q,timeout_ms=timeout_ms);history.append(r)
        if r['status']=='sat':
            checked=None
            try:checked=verify(P,Q,q,{k:rational(x) for k,x in sexpr(r['values'])})
            except (ValueError,TypeError):pass
            return {'route':'all-topology bilinear solver','status':'SAT','storage_budget':q,
                'minimum_reactive_count':q,'global_minimum_proved':q==n and checked is not None,
                'minimum_certification':'degree lower bound + independently checked witness' if q==n and checked else 'Relies on solver UNSAT results for lower budgets and solver SAT model; no exported independently checked UNSAT proof',
                'rational_witness_check':checked,'history':history}
        if r['status']!='unsat':
            return {'route':'all-topology bilinear solver','status':'UNKNOWN','global_minimum_proved':False,
                    'known_lower_bound':q,'theoretical_upper_bound_if_PR':bound,'history':history,
                    'reason':'First unresolved budget stops the minimality search; no timeout is counted as UNSAT.'}
    return {'route':'all-topology bilinear solver','status':'BUDGET_EXHAUSTED','global_minimum_proved':False,
        'known_lower_bound':cap+1,'history':history,'theoretical_upper_bound_if_PR':bound}

if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('target');a.add_argument('--out');a.add_argument('--timeout-ms',type=int,default=5000)
    a.add_argument('--max-budget',type=int);a.add_argument('--skip-local',action='store_true');x=a.parse_args()
    target=json.loads(Path(x.target).read_text());r=minimum(target['P'],target['Q'],x.timeout_ms,x.max_budget,x.skip_local)
    text=json.dumps(r,indent=2)
    if x.out:Path(x.out).write_text(text)
    else:print(text)
