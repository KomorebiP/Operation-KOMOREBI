# Source and contribution map

**Author: Komorebi P.**

Primary source: Timothy H. Hughes, arXiv:1611.06258v2, https://arxiv.org/pdf/1611.06258 . Printed page numbers are used. The provided 2018 revision was inspected, including circuit figures on pages 4 and 5 and the graph argument on pages 7 and 8.

| Source | What it supplies | Implementation or continuation |
|---|---|---|
| Definition 1, p. 3 | Minimum-function terminology and assumptions | Class recognition and explicit scope checks |
| Theorem 2, pp. 3–4, Figure 4 | Five-storage sections with two residual one-ports of degree at least two lower | RPFG constructor; derived conservative `B(n)` bound |
| Lemma 3, p. 4 | Parameterization by K, omega0, W, F | `identify()` exact coefficient recognizer |
| Theorem 4, p. 4, Figure 5 | Exactly-three storage exceptional cases | Cases a,b; positive exact topology checks |
| Theorem 5, p. 4, Figure 6 p. 5 | Exactly-four storage exceptional surfaces | Cases c,d,e,f; squared tests with sign conditions |
| Theorem 6, p. 5 | Generic minimum five and minimum two resistors | Exact class oracle and five-storage witness |
| Lemmas 9,11, p. 7 | Every resistor blocked at a minimum frequency | All-dimension resistor-path exclusion |
| Section II, p. 2 | Physical storage count bounds rational degree; hidden/ constrained states need not be removable | Lower bound and interpretation of exact interpolation |
| Appendix B | Kirchhoff/graph conventions and network equivalence | Nodal witness checks and source-ground conventions |

The resistor-only Dirichlet floor, exact `n+q+1` sample feasibility encoding, quantitative local coefficient cube, and certified algebraic-pole implementation are deductions/engineering developments made in this continuation. No claim of historical priority has been established for any of them.

The earlier project files `THEOREM_AND_PROOFS.md` and `ENGINEERING_NOTES.md` already contained the finite semialgebraic decision idea and the local full-rank lifting theorem. This release does not rebrand those as new. It adds a low-degree universal encoding, an executable solver route, explicit inverse bounds, algebraic pole handling, and independently specified target certificates.

The Z3 interface uses the documented C API `Z3_eval_smtlib2_string` and the `qfnra-nlsat` tactic. Documentation: https://z3prover.github.io/api/html/group__capi.html and https://microsoft.github.io/z3guide/docs/strategies/summary/ . The local system library version was queried, not inferred from the online documentation.
