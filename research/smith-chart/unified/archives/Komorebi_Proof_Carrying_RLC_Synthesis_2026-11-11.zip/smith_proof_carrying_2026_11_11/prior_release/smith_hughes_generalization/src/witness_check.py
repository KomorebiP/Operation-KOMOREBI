"""Author: Komorebi P. Solver-independent rational RLC witness checking.
A match at n+q+1 distinct positive rational points is conclusive by the degree
bound, unlike approximate frequency fitting. All arithmetic is exact Fraction.
"""
from fractions import Fraction as F
from pathlib import Path
import re,json
from budget_solver import peval

def sexpr(text):
    ts=re.findall(r'\(|\)|[^\s()]+',text);j=0
    def parse():
        nonlocal j
        if j>=len(ts):raise ValueError('Incomplete expression')
        t=ts[j];j+=1
        if t!='(':return t
        out=[]
        while j<len(ts) and ts[j]!=')':out.append(parse())
        if j==len(ts):raise ValueError('Unbalanced expression')
        j+=1;return out
    out=parse()
    if j!=len(ts):raise ValueError('Trailing tokens')
    return out

def rational(x):
    if isinstance(x,str):return F(x)
    op,*args=x;xs=list(map(rational,args))
    if op=='+':return sum(xs,F(0))
    if op=='-':return -xs[0] if len(xs)==1 else xs[0]-sum(xs[1:],F(0))
    if op=='/':return xs[0]/xs[1]
    if op=='*':
        z=F(1)
        for a in xs:z*=a
        return z
    raise ValueError('Algebraic/non-rational solver value needs a different exact checker')

def linear(A,b):
    A=[list(map(F,row))+[F(c)] for row,c in zip(A,b)];n=len(A)
    for k in range(n):
        p=next((i for i in range(k,n) if A[i][k]),None)
        if p is None:raise ValueError('Singular grounded matrix')
        A[p],A[k]=A[k],A[p];a=A[k][k]
        A[k]=[v/a for v in A[k]]
        for i in range(n):
            if i==k:continue
            b=A[i][k]
            if b:A[i]=[v-b*w for v,w in zip(A[i],A[k])]
    return [row[-1] for row in A]

def verify(P,Q,q,values):
    """values is a dict name->Fraction for g_i_j, h_i_j, c_i_j."""
    edges=[]
    for name,val in values.items():
        typ,a,b=name.split('_');a=int(a);b=int(b);val=F(val)
        if typ not in ['g','h','c'] or a==b or val<0:raise ValueError('Invalid branch')
        if val:edges.append((typ,a,b,val))
    reach={0}
    while True:
        new=reach|{b for _,a,b,_ in edges if a in reach}|{a for _,a,b,_ in edges if b in reach}
        if new==reach:break
        reach=new
    if 1 not in reach:raise ValueError('Port disconnected')
    edges=[e for e in edges if e[1] in reach and e[2] in reach]
    actual=sum(t!='g' for t,*_ in edges)
    if actual>q:raise ValueError('Storage budget exceeded')
    nodes=sorted(reach-{0});pos={a:i for i,a in enumerate(nodes)}
    n=max(len(P),len(Q))-1;tests=n+q+1
    for sf in range(1,tests+1):
        A=[[F(0) for _ in nodes] for _ in nodes];bvec=[F(int(a==1)) for a in nodes]
        for typ,a,b,val in edges:
            y=val if typ=='g' else val/F(sf) if typ=='h' else val*sf
            if a:A[pos[a]][pos[a]]+=y
            if b:A[pos[b]][pos[b]]+=y
            if a and b:A[pos[a]][pos[b]]-=y;A[pos[b]][pos[a]]-=y
        x=linear(A,bvec)
        if x[pos[1]]!=peval(P,sf)/peval(Q,sf):raise ValueError(f'Exact identity failed at sample {sf}')
    return {'status':'PASS','exact_positive_samples':tests,'actual_storage':actual,'actual_resistors':sum(t=='g' for t,*_ in edges),
      'proof':'positive RLC degree <= q plus n+q+1 exact distinct matches implies identical rational functions',
      'arithmetic':'Python Fraction','positive_branches':[[t,a,b,str(val)] for t,a,b,val in edges]}

if __name__=='__main__':
    B=Path(__file__).resolve().parents[1];r=json.loads((B/'results/budget_solver.json').read_text());outs={}
    specs={'constant':([3],[1],0),'one_capacitor':([1],[2,1],1),'one_RC_series_R_fixed':([3,1],[2,1],1)}
    for label,(P,Q,q) in specs.items():
        vals={name:rational(val) for name,val in sexpr(r[label]['values'])}
        outs[label]=verify(P,Q,q,vals)
    vals={'g_1_2':F(1),'c_1_2':F(1),'g_2_3':F(2),'c_2_3':F(1),'g_0_3':F(1,2)}
    outs['two_RC_explicit_witness']=verify([7,8,2],[2,3,1],2,vals)
    bad=vals.copy();bad['g_0_3']+=F(1,1000000)
    try:verify([7,8,2],[2,3,1],2,bad)
    except ValueError:outs['tampered_witness_rejected']=True
    else:raise AssertionError('Tamper not rejected')
    (B/'results/witness_checks.json').write_text(json.dumps(outs,indent=2));print(json.dumps(outs,indent=2))
