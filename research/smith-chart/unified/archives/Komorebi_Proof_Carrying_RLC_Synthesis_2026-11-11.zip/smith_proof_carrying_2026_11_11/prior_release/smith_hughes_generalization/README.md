# Komorebi: boundary-aware exact RLC synthesis

**Author: Komorebi P.**  
**Date: 11 November 2026**

This package develops the Smith-chart synthesis program using Timothy H. Hughes's paper, *Why RLC realizations of certain impedances need many more energy storage elements than expected*, arXiv:1611.06258v2.

## Results

1. **Hughes's complete biquadratic-minimum classification is implemented.** Given exact coefficients in that class, the program returns the correct storage minimum 3, 4 or 5, a positive circuit, and an independent exact nodal identity check. The theorem and topology formulas are Hughes's prior work.
2. **All-topology exact feasibility is encoded bilinearly.** For rational target degree `n` and storage budget `q`, at most `2q+2` node slots and `n+q+1` exact positive-frequency matches suffice. Nonnegative branch parameters and a support budget cover all topologies, without a manually enumerated topology list. SAT rational witnesses have an independent exact checker. General UNSAT results remain solver-dependent.
3. **A finite universal storage bound is derived from classical synthesis and Hughes's five-storage recursion.** `B(0)=0`, `B(1)=1`, `B(n)=5+2B(n-2)`. This is a conservative mathematical bound, not an efficient synthesis claim or a priority claim.
4. **The seed's local inverse is quantitative.** With denominator leading coefficient fixed at 150, every simultaneous perturbation of the other 13 target coefficients by at most `1e-13` is realized by a positive six-storage circuit within a component cube of radius `1e-8`.
5. **The rational-pole restriction is removed for the local inverse.** Exact real-algebraic root isolation and rational interval deflation are implemented. Independent degree-6, degree-7 and degree-8 coefficient targets passed. Their denominators are irreducible over the rationals. Newly recovered core components have separate positive exact-root certificates of radius `1e-40`.

The exact six-reactive seed certificate was replayed and remains valid. The source paper does not contradict it. It disproves the different assertion that every degree-`n` positive-real target has storage minimum `n`.

## Reproduction

Use Python 3.10 or newer, with SymPy and mpmath. The all-topology solver also requires a discoverable native Z3 library. This run used the system `libz3.so.4`, version 4.13.3.0, directly through its C API. No Z3 Python package was required.

```bash
python src/replay_certificate_bundle.py
python src/hughes_minimum.py
python src/witness_check.py
python src/test_suite.py
```

The first command independently replays the six-state seed, the uniform local inverse, and the three independent target certificates. It performs no numerical Newton solve. It recomputes exact algebraic root enclosures from the input before accepting each core certificate.

The full suite has **16 test methods**, with exact identities, all Hughes exception classes, scaled cases, independent-target inversion, solver fixtures, dimension counts, and deliberate rejection controls. All 16 passed in this release.

To reproduce the numerical proposal stage followed by exact certification:

```bash
python src/algebraic_inverse.py
python src/recover_components.py
```

## Supply an independent target

Input JSON uses ascending rational coefficient arrays:

```json
{"P":["2/3","1/2",1],"Q":["3/2","1/3",1]}
```

Run:

```bash
python src/synthesize.py examples/hughes_generic_input.json --out result.json
python src/synthesize.py examples/independent_degree_7_input.json --out local_result.json
python src/synthesize.py examples/one_RC_input.json --out small_result.json
```

The routes are: exact Hughes classifier, certified local algebraic inverse, and the all-topology bilinear fallback. `--skip-local` bypasses potentially expensive algebraic root isolation. `--timeout-ms` controls each fallback solve. `--max-budget` explicitly restricts the budget range. An unresolved budget returns `UNKNOWN`; the program does not skip it and then claim a globally minimum circuit at a larger budget.

Zero target impedance, ideal open-circuit input, non-algebraic coefficients, and arbitrary matrix-valued/multiport targets are outside this interface.

## What the output means

The local algebraic output specifies module poles by rational isolating intervals of exact input polynomials, module values by exact residue formulas, and the core components by a unique exact root in a positive rational cube. The returned physical-value decimals are approximations, not the exact certificate.

A generic SMT `sat` answer is not automatically an independently checked certificate. Rational branch values are passed through the independent exact nodal witness checker. Algebraic SMT models are retained but are not yet handled by that independent checker. Generic SMT `unsat` answers are not exported as independently replayable real-algebraic refutations.

## Important limits

The arbitrary-target feasibility specification is complete mathematically. The implementation is **not** an efficient universal minimum-circuit program. Unrestricted and fixed-topology examples still timed out. These are recorded, not converted to impossibility results. The independently tested target perturbations are deliberately small.

No new historical priority is asserted for the 3/4/5 classification, Foster preamble, RPFG synthesis, genericity concepts, or decidability. Our deductions and software contributions are separated from the source in `THEOREMS_AND_PROOFS.md` and `SOURCE_MAP.md`.

No external SPICE simulation or hardware validation was performed. No GitHub/site publication was performed.

## Files

- `THEOREMS_AND_PROOFS.md`: statements, proofs, assumptions and boundaries.
- `SOURCE_MAP.md`: paper-to-code provenance.
- `ENGINEERING_NOTES.md`: implementation details, failed attempts and trust boundaries.
- `HANDOFF.md`: exact continuation state and unresolved work.
- `src/`: exact classifiers, interval inverse, solver interface and validators.
- `examples/`: independent target inputs, proof enclosures, SMT-LIB fixtures.
- `results/`: actual reports, certificates and test logs.
- `certified_seed/`: retained original exact six-reactive certificate and verifier.
