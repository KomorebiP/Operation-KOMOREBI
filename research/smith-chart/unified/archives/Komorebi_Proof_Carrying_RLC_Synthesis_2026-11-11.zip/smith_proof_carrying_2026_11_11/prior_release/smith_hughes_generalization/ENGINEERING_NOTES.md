# Engineering notes and failure record

**Author: Komorebi P.**  
**Date: 11 November 2026**

## Arithmetic and trust

The retained seed verifier and all contraction acceptance tests use exact Python integers and `fractions.Fraction`. SymPy supplies polynomial reduction, exact real-root isolation and exact factorization. mpmath is used only to propose new core component centers. A new center is accepted only after a separate rational parameter-uncertain contraction test.

The all-topology fallback uses the system Z3 C library, version 4.13.3.0. It is loaded with ctypes through the documented SMT-LIB evaluation interface. A requested pip installation of `z3-solver` failed because the execution environment could not resolve the package index. Inspection found the already installed native library, and the C-API route succeeded. No downloaded binary was needed and none is bundled.

SAT rational models are checked with a separate Fraction nodal solver and the exact degree-limited interpolation theorem. General algebraic SAT model checking is not implemented. Generic UNSAT results are solver-trusted, not independent refutation certificates. Source-based Hughes lower bounds are mathematical uses of the cited published theorems.

## Complete vs restricted formulations

`budget_solver.encode()` defaults to `2q+2` node slots, every pair carrying optional g,h,c parameters, and a global support count at most q. This is the complete formulation. A supplied `nodes` limit or `allowed` set restricts the search and is recorded as such. A restricted SAT witness can still establish a global upper bound, but restricted UNSAT cannot establish a global lower bound.

The solver always uses exactly `n+q+1` distinct positive rational arguments. It does not infer exact identity from floating-point residuals. KCL at unit current forces the port to be connected to ground. Disconnected unused node slots are permitted and can be discarded. The formulation therefore does not have the spurious all-zero nodal-determinant solution that a careless coefficient-only system could admit.

## Observed solver outcomes

See `results/budget_solver.json` for full models and runtimes.

- Full all-topology constant input, budget 0: SAT; independent Fraction check passed.
- Full all-topology single parallel RC target, budget 1: SAT; independent Fraction check passed.
- The same nonconstant target with budget 0: UNSAT.
- Full all-topology series-resistor-plus-RC target at four node slots: UNKNOWN at 5 seconds.
- The same target at three node slots: UNKNOWN at 3 seconds.
- Its specified three-branch topology: SAT; independent Fraction check passed.
- A two-RC-series target with specified five-branch topology: UNKNOWN at 3 seconds. An explicitly supplied rational witness was independently verified separately. That witness is not a solver discovery.

The timeout values are experimental settings, not promised performance. UNKNOWN is never counted as infeasibility. The implementation remains a research prototype.

## Local inverse development

The first attempted coefficient box used component radius `1e-8` and coefficient radius `1e-12`. It FAILED: the certified center displacement exceeded the component radius. Reducing the coefficient radius to `1e-13` passed with contraction below 0.236 and displacement below 0.643 times the radius. This failed first trial is retained as a deliberate rejection test.

A crude uniform monomial bound based on the largest parameter was unnecessarily pessimistic. The successful verifier bounds preconditioned monomial Hessians at actual component bounds. It sums preconditioned coefficients before taking absolute values, which materially tightens the bound while remaining exact.

The independent input targets were made by direct rational coefficient perturbation. No new circuit was used to generate those targets. Degree-6, degree-7, and degree-8 cases passed exact root isolation, deflation, local recognition, and fresh component-center certification. The degree-7 and degree-8 denominator polynomials were exactly factored and are irreducible, confirming that the recovered added poles are not rational.

An exploratory run including a degree-10 algebraic target exceeded a 20-second command limit before producing a final certificate. It is NOT included among completed targets. The validated scope is the three saved targets. The formulas and recognizer are dimension-independent, but testing is finite and does not establish favorable scaling.

Recovered component cubes have radius `1e-40`. The input algebraic core is enclosed by rational coefficient boxes of radius `1e-55` about decimal-rational centers. The exact contraction proof covers every coefficient vector in those boxes, including the true algebraic core. `replay_certificate_bundle.py` regenerates the root enclosures from the exact input and checks the saved component certificate against the regenerated enclosure. It does not simply trust saved interval claims.

## Unsupported claims

No universal practical solver, new general q=degree theorem, historical priority, total-component minimum for the original seed, external SPICE result, hardware result, or robustness advantage is asserted. The derived exponential storage bound is conservative and not claimed new. The local coefficient radius is not an engineering tolerance specification.

No source files were uploaded to GitHub or changed in the user's Library. The deliverable is a new local research package.
