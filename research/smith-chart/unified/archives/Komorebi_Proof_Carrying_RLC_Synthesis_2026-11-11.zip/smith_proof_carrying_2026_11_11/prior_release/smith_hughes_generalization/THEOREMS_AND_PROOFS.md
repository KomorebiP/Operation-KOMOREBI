# Boundary-aware exact synthesis in arbitrary dimension

**Author: Komorebi P.**  
**Date: 11 November 2026**  
**Status: Research continuation with exact certificates, an executable all-topology feasibility encoding, and explicitly limited computational coverage.**

## 1. Scope and provenance

All networks are finite scalar one-ports made from ordinary positive resistors, inductors and capacitors. Ideal wires may be contracted. Ideal transformers, mutual inductance, controlled sources and negative elements are excluded. We minimize the physical number of inductors and capacitors, not the McMillan degree of a state-space representation. We match the driving-point impedance, not the entire internal behavior for arbitrary initial conditions.

The principal external source is Timothy H. Hughes, *Why RLC realizations of certain impedances need many more energy storage elements than expected*, IEEE Transactions on Automatic Control 62(9), 4333–4346 (2017), arXiv:1611.06258v2, 22 January 2018. Source: https://arxiv.org/pdf/1611.06258 . References to page numbers below use the printed 1–14 numbering of that version.

**Source-derived results.** Hughes's Lemma 3 and Theorems 4–6 completely classify minimum storage for biquadratic minimum functions. His Theorem 2 and Figure 4 give five-storage recursive synthesis sections with two lower-degree one-ports. Lemmas 9 and 11 give blocked-resistor constraints at a minimum frequency. These are prior work, not new Komorebi theorems.

**Earlier project results retained.** The exact degree-six seed and its positive thirteen-parameter certificate are replayed independently. The previous arbitrary-degree construction and local full-rank argument remain valid. They did not provide a numerical coefficient-neighborhood radius, algebraic-pole recovery, or executable general-topology feasibility solving.

**Deductions and implementation in this continuation.** We give a resistor-path exclusion and quantitative dissipation floor, a single all-topology bilinear formulation using exact interpolation, a finite degree-dependent storage upper bound obtained by composing the source's recursive sections with a degree-accounted Foster preamble, a quantitative uniform local inverse certificate, and certified recovery for independently specified rational targets with irrational algebraic poles. Historical priority is not claimed for these deductions or formulations.

## 2. Why equality between degree and storage cannot be universal

Hughes writes a biquadratic minimum function as

\[
H(s)=K\frac{s^2+\omega_0(1-W)F s/W+\omega_0^2W}
{s^2+\omega_0(1-W)s/F+\omega_0^2/W},
\]

where \(K,\omega_0>0\), and either \(0<W<1,F>0\) or \(W>1,F<0\). A minimum function is positive-real, has no poles or zeros on the imaginary axis or at infinity, and has zero real part at some nonzero imaginary frequency. At the distinguished frequency, \(H(i\omega_0)=iKF\ne0\).

Theorem 4 gives storage minimum three exactly on

\[
(a)\quad W=1/2,F>0,\qquad (b)\quad W=2,F<0.
\]

Outside these cases, Theorem 5 gives minimum four exactly on the following surfaces:

\[
\begin{array}{ll}
(c)&1/2<W<1,\quad F^2(1-W)^2=W^2(2W-1),\\
(d)&1<W<2,\quad F^2(2-W)=W(1-W)^2,\\
(e)&1<W<2,\quad F^2(1-W)^2=W^3(2-W),\\
(f)&1/2<W<1,\quad F^2(2W-1)=W^2(1-W)^2.
\end{array}
\]

The parameter sign restrictions select the correct square-root branches. In every other case, Theorem 6 gives minimum five. Two resistors are necessary and sufficient in all these classes. The lower bounds allow any finite number of resistors, not just a small finite topology census.

For the paper's example

\[
H_*(s)=\frac{s^2+s/2+2/3}{s^2+s/3+3/2},
\]

\(K=\omega_0=F=1,W=2/3\). None of (a)–(f) holds, so \(q_{\min}(H_*)=5\), although its rational degree is two. Our code reconstructs an exact five-storage, two-resistor RPFG network and verifies its impedance independently with weighted trees and forests.

For reference, one such circuit has port 1, ground 0, and these component values:

| Type | Edge | Value |
|---|---|---|
| L | 1–2 | 1 |
| R | 2–0 | 4/9 |
| R | 1–3 | 1 |
| L | 2–4 | 8/31 |
| L | 3–4 | 169/186 |
| C | 3–4 | 186/169 |
| C | 4–0 | 31/8 |

All quantities are normalized. The lower bound is Hughes's theorem. The exact upper-bound identity is independently replayed in `src/hughes_minimum.py`. The code recognizes arbitrary exact input coefficients in this class and constructs the appropriate three-, four-, or five-storage network, including all exceptional cases in the paper's Figures 5 and 6.

This does not contradict our degree-six closure: our impedance is a different target, with a different realizability geometry.

## 3. A dimension-independent resistor-path obstruction

### Theorem 3.1: resistor-path exclusion

If an RLC topology contains a path of strictly positive finite resistors connecting its two external terminals, it cannot realize a minimum function.

**Proof.** At a minimum frequency with nonzero finite driving-point impedance, Hughes's Lemmas 9 and 11 guarantee a nonzero sinusoidal driving-point trajectory, and every resistor is blocked. In particular its voltage is zero. The resistor-only path therefore forces the port voltage to be zero, contrary to the nonzero finite driving-point impedance and nonzero current. The number of reactive elements is irrelevant. \(\square\)

The seven resistor edges of our six-state seed form a connected spanning tree. Every series RC/RL extension of the earlier arbitrary-degree construction also has a resistor-only port path. Thus those fixed strictly positive topologies cannot cover Hughes's minimum-function class. A different topology, or a limiting parameter degeneration that removes a resistor path, is necessary. A nonsingular local coefficient map never implied global coverage.

### Theorem 3.2: quantitative admittance floor

Let \(G_R\) be the effective conductance of the resistor-only subnetwork between the external terminals, with \(G_R=0\) when those terminals are disconnected. At a real frequency where a finite unit-voltage sinusoidal solution exists,

\[
\operatorname{Re}Y(i\omega)\ge G_R.
\]

**Proof.** Ground one terminal and set the other terminal voltage to one. The complex power identity gives

\[
\operatorname{Re}Y(i\omega)=\sum_{e\in R}g_e|v_a-v_b|^2.
\]

Split internal potentials into real and imaginary parts. Their imaginary boundary values are both zero and contribute nonnegative dissipation. The real part of the sum is at least the Dirichlet minimum for the resistor-only graph, which is \(G_R\). \(\square\)

For every parameter vector in our newly certified seed cube of radius \(10^{-8}\), the exact calculation in `boundary.py` gives

\[
G_R>0.09695.
\]

Consequently that cube cannot approximate a minimum-function admittance at its minimum frequency with absolute admittance error less than 0.09695. This is a normalized mathematical bound for this parameter cube, not a hardware tolerance specification. It does not exclude other component regions or other topologies.

## 4. Exact all-topology synthesis without determinant expansion

Let the target be \(Z=P/Q\), with real rational coefficients, reduced degree \(n\), and \(Z(\sigma)>0\) for positive real \(\sigma\). Fix a proposed storage budget \(q\). For a nonzero positive-real target these conditions on positive \(\sigma\) hold automatically.

### Theorem 4.1: universal bilinear encoding

There is a quantifier-free real feasibility formulation, with Boolean support constraints and bilinear arithmetic equalities, that is satisfiable if and only if \(Z\) has a transformer-free positive RLC realization with **at most** \(q\) physical reactive elements. It uses

\[
m=2q+2\quad\text{node slots},\qquad K=n+q+1\quad\text{exact positive sample arguments}.
\]

Use ground node 0 and input node 1. For every unordered node pair \(e\), introduce nonnegative variables

\[
g_e\ge0,\quad h_e\ge0,\quad c_e\ge0.
\]

A positive \(g_e\) is a resistor of value \(1/g_e\), a positive \(h_e\) is an inductor of value \(1/h_e\), and a positive \(c_e\) is a capacitor of value \(c_e\). A zero variable means that branch is absent. Require

\[
\#\{e:h_e>0\}+\#\{e:c_e>0\}\le q.
\]

For distinct positive rational \(\sigma_k\), use unit input current and introduce internal potentials \(v^{(k)}\), with

\[
v_0^{(k)}=0,\qquad v_1^{(k)}=Z(\sigma_k).
\]

Require Kirchhoff's current equations at every non-ground node:

\[
\sum_{j\ne i}\left(g_{ij}+\frac{h_{ij}}{\sigma_k}+\sigma_kc_{ij}\right)
\left(v_i^{(k)}-v_j^{(k)}\right)=\mathbf1_{i=1}.
\tag{4.1}
\]

Optional but valid bounds are

\[
0\le v_i^{(k)}\le Z(\sigma_k).
\]

The arithmetic equations are bilinear in component parameters and potentials. The only topology choice is which branch parameters are zero. The support cardinality can be represented by Boolean conditions and real-valued zero-one `ite` terms, without introducing integer variables. The number of branch variables is \(3\binom{2q+2}{2}\). The formulation is finite and polynomial-sized in \(n+q\), but nonconvex and disjunctive. No tractability result follows from its bilinear form.

**Necessity and topology completeness.** Start from any realizing network with at most \(q\) reactive components. Contract wires and delete irrelevant disconnected material. Retain both terminals and every reactive endpoint, at most \(2q+2\) nodes. Eliminate every remaining resistor-only internal node by resistor-network Kron reduction. Its Schur complement is a passive resistor Laplacian on the retained vertices. Parallel components of the same type can be combined, never increasing the reactive count. Pad with isolated node slots. At every positive \(\sigma_k\), all branch conductances are nonnegative, the port component is connected, and a unit-current solution exists. The maximum principle supplies the stated potential bounds. Hence (4.1) is feasible.

**Sufficiency.** Any satisfying assignment defines a finite RLC graph. The port must be connected to ground: otherwise summing KCL over the component containing node 1 gives \(0=1\). Other disconnected components can be deleted. The connected port network has at most \(q\) reactive components, and its rational impedance \(\widehat P/\widehat Q\) has degree at most \(q\). It agrees with \(P/Q\) at all \(K\) positive arguments. Thus

\[
A(s)=\widehat P(s)Q(s)-\widehat Q(s)P(s)
\]

has degree at most \(n+q\), yet has \(n+q+1\) distinct roots. Therefore \(A\equiv0\). This proves the exact all-frequency identity. \(\square\)

This theorem does **not** turn approximate fitting into a proof. The matches must be exact, the network must have a certified physical storage budget, and all sample arguments must be distinct and avoid poles. Positive real arguments avoid every passive-network pole automatically. `witness_check.py` uses this theorem to verify rational circuit witnesses without trusting the solver.

The formulation includes singular and nonminimal physical realizations with hidden modes. It does not require a nonsingular component-to-coefficient Jacobian. That is essential for the Hughes boundary classes.

For real algebraic target coefficients, represent those coefficients by their defining polynomials and rational isolating data. The network equations remain bilinear conditional on the input values, but the input-defining algebraic equations can have higher degree. The current generic SMT exporter accepts rational coefficients. The local inverse below handles algebraic cores explicitly.

## 5. A finite degree-dependent upper bound

This section derives a convenient universal bound from the source, not a sharp or novel circuit-count formula.

### Lemma 5.1: degree-accounted Foster preamble

A nonzero rational positive-real function of degree \(n\) can be reduced to a constant or to a minimum function of degree \(m\le n\), using series/parallel resistor operations and at most \(n-m\) extracted reactive elements.

**Proof.** Positive-real imaginary-axis poles are simple with positive real residues. An infinity pole contributes \(Ls\) and costs one inductor. An origin pole contributes \(k/s\) and costs one capacitor. A conjugate pair at \(\pm i\omega\) contributes \(2rs/(s^2+\omega^2)\), realized by one parallel LC section. Subtracting each lossless pole contribution preserves positive-realness and reduces the reduced rational degree by at least its reactive cost. A boundary zero is treated by inversion and the same pole extraction, then reversing the inversion as a parallel operation.

When no boundary poles or zeros remain, the real part on the compactified imaginary axis is continuous and has a nonnegative minimum. If it already vanishes at a nonzero frequency, the function is a minimum function. Otherwise subtract its nonnegative minimum as a series resistor. If the residual is constant or zero, stop. If it has a boundary zero, invert and extract, decreasing degree. If it has no boundary zero, it is a minimum function. Each repetition that does not stop reduces degree; only pole extractions consume reactive components, and their costs are bounded by the accumulated degree decrease. \(\square\)

For algebraic inputs, pole locations, residues, and boundary minima are real algebraic data that can be determined by exact univariate polynomial/root and real-algebraic sign procedures. The unrestricted preamble is described here mathematically, not implemented as a production synthesis routine.

### Theorem 5.2: computable all-degree bound

Define

\[
B(0)=0,\qquad B(1)=1,\qquad B(n)=5+2B(n-2)\quad(n\ge2).
\]

Then every nonzero real-rational positive-real scalar impedance of degree \(n\) has a finite transformer-free realization with at most \(B(n)\) reactive elements. Explicitly,

\[
B(2k)=5(2^k-1),\qquad B(2k+1)=6\,2^k-5.
\]

**Proof.** Degree zero is a resistor. A degree-one positive-real impedance has an elementary one-reactive RC, RL, pure L or pure C realization. Apply Lemma 5.1 at higher degree. A remaining minimum function of degree \(m\) can be synthesized by Hughes's Theorem 2/Figure 4 using five reactive elements and two positive-real one-ports, each of degree at most \(m-2\). The reciprocal occurrence of the residual is synthesized separately, so no planar-duality assumption is needed. By induction the storage cost is at most

\[
(n-m)+5+2B(m-2)=(n-m)+B(m).
\]

The sequence \(B\) has successive increments at least one, so this is at most \(B(n)\). The explicit formulas follow by solving the two parity recurrences. \(\square\)

Examples are \(B(2)=5\), \(B(4)=15\), \(B(6)=35\), and \(B(8)=75\). These are safe universal bounds, not assertions that a typical target needs so many components. The degree-six seed still has exact minimum six.

### Corollary 5.3: finite minimum-storage specification

For algebraic positive-real input, test Theorem 4.1 for

\[
q=n,n+1,\ldots,B(n).
\]

With a complete real-closed-field decision procedure and unlimited resources, the first feasible budget is the exact minimum and yields algebraic component values. All lower-budget infeasibility decisions are part of the minimality proof. This is a mathematical finite algorithm, not a claim that the tested SMT implementation is efficient or always completes within a chosen timeout.

The previous project already had a finite semialgebraic decision argument. The improvement here is a concrete all-topology bilinear encoding, an explicit finite budget range, an executable solver interface, and a clear separation of solver trust from independently checked witnesses. It is not the first decidability result in network synthesis.

## 6. A quantitative inverse for the certified degree-six core

Use ascending coefficient vectors

\[
P_6=(75,335,1142,2200,2477,1385,450),\qquad
Q_6=(25,445,1250,1720,1375,795,150).
\]

The retained seed has thirteen parameters: seven resistor conductances, three reciprocal inductances, and three capacitances. Its rational certificate center is \(x_0\), and its retained rational preconditioner is \(M\). These are stored in `certified_seed/results/six_reactive_certificate.json`.

### Theorem 6.1: explicit open coefficient box

Fix the leading denominator coefficient at 150. Every simultaneous real perturbation of the seven numerator coefficients and six remaining denominator coefficients satisfying

\[
\|\Delta P\|_\infty\le10^{-13},\qquad
\|\Delta Q\|_\infty\le10^{-13}
\]

is realized by exactly one positive parameter vector in the component cube

\[
\|x-x_0\|_\infty\le10^{-8}.
\]

Each resulting impedance has reduced degree six and hence minimum reactive count six.

**Proof and numerical constants.** Let \(F(x;P,Q)\) be the thirteen coefficients of the tree/forest identity \(N(x,s)Q(s)-D(x,s)P(s)\). Set

\[
T_{P,Q}(x)=x-MF(x;P,Q).
\]

The verifier regenerates all 581 spanning-tree and 389 port-separating-forest monomials from the physical graph. It bounds the Hessian of \(MF\) directly, retaining the cancellations in the preconditioned coefficients before taking absolute values. For \(r=10^{-8}\) and \(\delta=10^{-13}\), all comparisons use exact `Fraction` arithmetic. The resulting uniform bounds are

\[
\sup_{x\text{ in cube}}\|DT_{P,Q}(x)\|_\infty<0.236,
\qquad
\|T_{P,Q}(x_0)-x_0\|_\infty<0.643r.
\]

Therefore \(T\) is a contraction and maps the cube strictly into itself, since \(0.236+0.643<1\). The cube is strictly positive. The preconditioner is invertible because the original \(\|I-MD_xF\|<1\) bound holds. Banach's theorem gives a unique exact root of all coefficient equations for every target in this box.

For clarity, the perturbation estimates used in the code are

\[
q\le d_0+rH_M+\|M\|\delta K_1,\qquad
\eta\le\eta_0+\|M\|\delta K_0.
\]

Here \(d_0=\|I-MD_xF(x_0;P_6,Q_6)\|\), \(\eta_0=\|MF(x_0;P_6,Q_6)\|\), \(H_M\) is the preconditioned Hessian bound, and \(K_0,K_1\) bound coefficient perturbations of the residual and its parameter Jacobian. Readable values are \(H_M<2.357\cdot10^7\), \(K_0<1057\), and \(K_1<14930\); the saved exact rationals determine acceptance.

Finally, no target in this box can have a numerator-denominator common factor. Such a factor would divide \(NQ-DP\) identically for every \(x\), forcing the thirteen-row parameter Jacobian to have deficient rank. The uniform contraction bound makes that Jacobian nonsingular. Both leading target coefficients remain nonzero, so reduced degree six follows. The physical six-reactive circuit attains the degree lower bound. \(\square\)

This radius is a coefficient-coordinate result in normalized units. It is not a claim of manufacturing robustness, an optimal neighborhood radius, or a dimension-uniform target perturbation radius after adding many poles.

## 7. Algebraic poles and independently specified targets

The earlier extractor required rational poles. The new procedure accepts rational polynomial input whose selected poles can be irrational real algebraic numbers.

Let \(\alpha<0\) be a simple root of the input denominator \(Q\), isolated in an exact rational interval. Define

\[
\rho=P(\alpha)/Q'(\alpha),\qquad a=-\alpha.
\]

If \(\rho>0\), use the RC section \(\rho/(s+a)\). If \(\rho<0\), use an RL section with \(u=\rho/\alpha>0\), whose impedance is \(us/(s+a)\). In either case subtracting the section cancels the chosen pole exactly. Polynomial division is justified by the defining root and residue identities, not by small numerical remainders.

Root isolation and interval residue evaluation certify negativity, simplicity, and the residue sign. Repeated interval synthetic division encloses the coefficients of the exact remaining core. If that entire enclosure lies in Theorem 6.1's box, existence of a positive core follows. Series assembly gives a circuit with exactly as many reactive components as the target's reduced degree, proving global reactive minimality for that input.

The implementation selects the labelled extension poles below -15. This is a local chart appropriate to our seed, whose poles are inside the old Cauchy bound of 13 in magnitude. Other pole configurations are not silently accepted.

### Independent tests and recovered components

Targets of degrees 6, 7, and 8 were specified by perturbing the exact polynomial coefficients, **not** by computing a response from new component values. Their denominators are exactly irreducible over the rationals of degrees 6, 7, and 8. Thus the added poles in the degree-seven and degree-eight tests really are irrational algebraic numbers.

The proved maximum core coefficient deviations were respectively at most

\[
7\cdot10^{-22},\qquad1.331\cdot10^{-25},\qquad3.323\cdot10^{-30},
\]

all below the uniform \(10^{-13}\) allowance. These are deliberately small perturbations, not a broad performance benchmark.

A numerical Newton solve proposed new component centers for each independently specified core. A **separate rational** parameter-uncertain contraction then proved an exact positive core solution in a cube of radius \(10^{-40}\) around each new center. It covers every possible core coefficient in the proved algebraic enclosure. The contraction bounds were below \(5.382\cdot10^{-19}\), \(4.871\cdot10^{-24}\), and \(1.142\cdot10^{-28}\), respectively. Center displacements were below \(6.422\cdot10^{-11}\) times that cube radius.

Exact component definitions combine the isolated algebraic pole roots, exact residue formulas, and the unique root of the core polynomial system in its certified positive cube. Decimal values are descriptive approximations only. `recover_components.py` replays the acceptance bounds without rerunning the numerical solve.

## 8. What has and has not closed

**Closed within the stated scopes:** the quantitative local inverse gap, the rational-pole-only limitation for the tested and recognized local family, independent-target core component certification, exact handling of the entire Hughes biquadratic-minimum classification, and the construction of an executable all-topology feasibility formulation with an explicit finite mathematical budget range.

**Not closed:** efficient universal minimum synthesis for arbitrary targets. The all-topology SMT fallback timed out on some small tests. It reports `UNKNOWN` and stops a minimality claim at the first unresolved budget. Generic UNSAT results currently rely on Z3; the package does not export and independently verify a general real-algebraic infeasibility proof. Rational SAT witnesses are independently checked. The Hughes lower bounds rely on the published theorems, not a new exhaustive solver run.

No physical hardware, external SPICE, noise, tolerance, thermal, parasitic, or manufacturing comparison was performed. No publication-priority claim is made. Nothing was published to GitHub or the reading site.
