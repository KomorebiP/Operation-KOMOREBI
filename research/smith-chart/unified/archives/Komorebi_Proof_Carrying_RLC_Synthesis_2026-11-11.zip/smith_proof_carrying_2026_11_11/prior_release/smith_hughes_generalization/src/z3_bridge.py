"""Author: Komorebi P. Minimal ctypes bridge to installed Z3, no Python wheel.
Only quantifier-free polynomial real arithmetic is used. A timeout is UNKNOWN.
"""
from __future__ import annotations
import ctypes as C
from ctypes.util import find_library
import time

class Z3Session:
    def __init__(self):
        name=find_library('z3')
        if not name: raise RuntimeError('Install libz3 or use the exported SMT-LIB with a suitable solver.')
        self.lib=C.CDLL(name)
        for n, rest, args in [
            ('Z3_mk_config',C.c_void_p,[]),('Z3_del_config',None,[C.c_void_p]),
            ('Z3_mk_context',C.c_void_p,[C.c_void_p]),('Z3_del_context',None,[C.c_void_p]),
            ('Z3_eval_smtlib2_string',C.c_char_p,[C.c_void_p,C.c_char_p]),
            ('Z3_get_full_version',C.c_char_p,[])]:
            f=getattr(self.lib,n);f.restype=rest;f.argtypes=args
        cfg=self.lib.Z3_mk_config();self.ctx=self.lib.Z3_mk_context(cfg);self.lib.Z3_del_config(cfg)
        self.version=self.lib.Z3_get_full_version().decode()
    def run(self,text:str)->str:
        if not self.ctx: raise RuntimeError('Closed session')
        return self.lib.Z3_eval_smtlib2_string(self.ctx,text.encode()).decode()
    def close(self):
        if self.ctx:self.lib.Z3_del_context(self.ctx);self.ctx=None
    def __enter__(self):return self
    def __exit__(self,*args):self.close()

def solve(smt:str, timeout_ms:int=10000, names:list[str]|None=None)->dict:
    start=time.monotonic()
    with Z3Session() as z:
        out=z.run(f'(set-option :timeout {timeout_ms})\n'+smt+'\n(check-sat-using qfnra-nlsat)\n')
        status=out.strip().splitlines()[-1]
        result={'solver':'Z3 '+z.version,'status':status,'raw_status':out,'seconds':time.monotonic()-start,
                'timeout_ms':timeout_ms,'trust':'SMT solver result, not an independently checked UNSAT proof'}
        if status=='sat':
            result['model']=z.run('(get-model)')
            if names: result['values']=z.run('(get-value ('+' '.join(names)+'))')
        elif status=='unknown':result['reason']=z.run('(get-info :reason-unknown)')
        return result

if __name__=='__main__':
    import json
    print(json.dumps(solve('(declare-const x Real) (assert (> x 0)) (assert (= (* x x) 2))',names=['x']),indent=2))
