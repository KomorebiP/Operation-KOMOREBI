"""Author: Komorebi P.
Exact implementation of Hughes arXiv:1611.06258v2 Lemma 3, Theorems 4--6.
The classification and network formulas are PRIOR ART, not Komorebi theorems.
The input class is biquadratic minimum functions, not all biquadratic PR functions.
"""
from __future__ import annotations
import sympy as S
from itertools import combinations
from pathlib import Path
import json
s=S.Symbol('s');R=S.Rational

def positive(x):
    v=S.simplify(x)
    if v.is_positive is not None:return bool(v.is_positive)
    raise ValueError('Exact sign unresolved; no floating acceptance is permitted')
def zero(x):return S.simplify(x)==0

def target(K,w,W,F):
    K,w,W,F=map(S.sympify,(K,w,W,F))
    return S.cancel(K*(s*s+w*(1-W)*F/W*s+w*w*W)/(s*s+w*(1-W)/F*s+w*w/W))

def identify(z):
    P,Q=map(lambda a:S.Poly(a,s),S.fraction(S.cancel(z)))
    if P.degree()!=2 or Q.degree()!=2:raise ValueError('Not reduced degree two with finite nonzero endpoints')
    K=P.LC()/Q.LC();a0=P.nth(0)/P.LC();b0=Q.nth(0)/Q.LC()
    a1=P.nth(1)/P.LC();b1=Q.nth(1)/Q.LC()
    if not all(positive(x) for x in [K,a0,b0,a1,b1]):raise ValueError('Not in the minimum-function class')
    w=S.sqrt(S.sqrt(a0*b0));W=S.sqrt(a0/b0)
    if zero(W-1):raise ValueError('Degenerate W=1')
    F=S.simplify(a1*W/(w*(1-W)))
    if not zero(z-target(K,w,W,F)):raise ValueError('Not a biquadratic minimum function')
    return tuple(map(S.simplify,(K,w,W,F)))

def classify(K,w,W,F):
    K,w,W,F=map(S.sympify,(K,w,W,F))
    if not positive(K) or not positive(w):raise ValueError('K and omega0 must be positive')
    low=positive(W) and positive(1-W) and positive(F)
    high=positive(W-1) and positive(-F)
    if not(low or high):raise ValueError('Not Hughes Lemma 3 parameters')
    if low and zero(W-R(1,2)):return 3,'a'
    if high and zero(W-2):return 3,'b'
    if low and positive(W-R(1,2)):
        if zero(F**2*(1-W)**2-W**2*(2*W-1)):return 4,'c'
        if zero(F**2*(2*W-1)-W**2*(1-W)**2):return 4,'f'
    if high and positive(2-W):
        if zero(F**2*(2-W)-W*(1-W)**2):return 4,'d'
        if zero(F**2*(1-W)**2-W**3*(2-W)):return 4,'e'
    return 5,'generic'

def network(K,w,W,F):
    K,w,W,F=map(S.sympify,(K,w,W,F));q,case=classify(K,w,W,F)
    phi=1-W;psi=1+W;eta=2*W-1;gamma=2-W
    if case=='a':
        es=[('L',1,2,K*F/w),('R',2,0,K/2),('R',1,3,K/2),('L',3,0,K*F/w),('C',2,3,1/(K*F*w))]
    elif case=='b':
        es=[('C',1,2,-1/(K*F*w)),('R',2,0,2*K),('R',1,3,2*K),('C',3,0,-1/(K*F*w)),('L',2,3,-K*F/w)]
    elif case=='c':
        es=[('L',1,2,K*F*phi/(W*w)),('C',1,2,eta/(K*F*phi*w)),('C',2,3,1/(K*F*w)),('R',2,0,K),('R',1,3,K*W**2/(phi*psi)),('L',3,0,K*F/w)]
    elif case=='d':
        es=[('L',1,2,K*F*gamma/(phi*w)),('C',2,3,phi/(K*F*w)),('R',3,0,-K*phi*psi),('R',1,4,K),('L',4,3,-K*F/w),('C',4,0,-1/(K*F*w))]
    elif case=='e':
        es=[('L',1,2,K*F*phi/(gamma*w)),('C',1,2,1/(K*F*phi*w)),('L',2,3,-K*F/w),('R',2,0,K*W**2),('R',1,3,-K*W**2/(phi*psi)),('C',3,0,-1/(K*F*w))]
    elif case=='f':
        es=[('L',1,2,K*F*W/(phi*w)),('C',2,3,phi/(K*F*eta*w)),('R',3,0,K*phi*psi),('R',1,4,K*W**2),('C',4,3,1/(K*F*w)),('L',4,0,K*F/w)]
    elif positive(F):
        mu=W*w/F;h=K*W;alpha=(F**2+W**2)*(1-W)*w/(2*W**2*F)
        chi=w*w+2*alpha*mu;ph=chi+mu*mu
        es=[('L',1,2,h/mu),('R',2,0,h*W),('R',1,3,h/W),('L',2,4,h*mu/chi),('L',3,4,2*alpha*h*ph/(w*w*chi)),('C',3,4,chi/(2*alpha*h*ph)),('C',4,0,chi/(h*mu*w*w))]
    else:
        old=network(K*W**2,w,1/W,-F/W**2)
        es=[('C' if t=='L' else 'L' if t=='C' else 'R',a,b,1/(x*w*w) if t!='R' else x) for t,a,b,x in old]
    es=[(t,a,b,S.simplify(x)) for t,a,b,x in es]
    if not all(positive(x) for _,_,_,x in es):raise AssertionError('Nonpositive component')
    if sum(t!='R' for t,*_ in es)!=q:raise AssertionError('Wrong storage count')
    return es

def impedance(edges):
    m=1+max(max(a,b) for _,a,b,_ in edges)
    adm=[1/x if t=='R' else 1/(s*x) if t=='L' else s*x for t,a,b,x in edges]
    totals=[]
    for size in [m-2,m-1]:
        total=0
        for ids in combinations(range(len(edges)),size):
            parent=list(range(m))
            def root(a):
                while parent[a]!=a:a=parent[a]
                return a
            ok=True
            for j in ids:
                _,a,b,_=edges[j];a,b=root(a),root(b)
                if a==b:ok=False;break
                parent[a]=b
            if not ok:continue
            if size==m-2 and root(0)==root(1):continue
            total+=S.prod(adm[j] for j in ids)
        totals.append(total)
    return S.cancel(totals[0]/totals[1])

def synthesize(z):
    par=identify(z);q,case=classify(*par);edges=network(*par)
    actual=impedance(edges)
    if not zero(actual-z):raise AssertionError('Nodal identity failed')
    return {'status':'PASS','input':str(S.cancel(z)),'parameters':dict(zip(['K','omega0','W','F'],map(str,par))),
            'minimum_reactive_count':q,'minimum_resistor_count':2,'case':case,
            'edges':[[t,a,b,str(x)] for t,a,b,x in edges],
            'lower_bound_source':'Hughes arXiv:1611.06258v2 Theorems 4--6',
            'upper_bound_check':'independent exact weighted spanning-tree/forest impedance identity',
            'claim':'Classification and topology formulas are Hughes prior work; software implementation and replay only.'}

if __name__=='__main__':
    B=Path(__file__).resolve().parents[1]
    pairs=[(R(1,2),1),(2,-1),(R(5,8),R(5,6)),(R(8,5),-R(6,5)),(R(8,5),-R(32,15)),(R(5,8),R(15,32)),(R(2,3),1),(R(3,2),-R(9,4))]
    reports=[]
    for W,F in pairs:
        report=synthesize(target(1,1,W,F));reports.append(report)
        print(W,F,report['case'],report['minimum_reactive_count'],flush=True)
    (B/'results/hughes_classification.json').write_text(json.dumps(reports,indent=2))
