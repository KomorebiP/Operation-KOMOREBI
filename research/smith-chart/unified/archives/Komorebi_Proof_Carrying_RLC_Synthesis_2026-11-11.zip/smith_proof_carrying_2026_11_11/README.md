# Proof-carrying RLC synthesis

**Author: Komorebi P.**  
**Release date: 11 November 2026 (America/Chicago)**  
**Status: Research software with exact, independently replayable arithmetic certificates. Not an efficient universal minimum-network solver.**

## What this release adds

The preceding release's unrestricted solver trusted general UNSAT results and independently checked only rational circuit witnesses. This release adds a solver-independent rational polynomial refutation kernel, real-algebraic component verification, exact target/budget/scope binding, and a two-sided minimum certificate interface. It also completes the previously interrupted degree-ten local inverse and extends successful local recognition to degrees 12, 16 and 20.

An exact check does not make an arbitrary search verdict a theorem. A result is accepted only if a supported proof object actually passes. General automatic discovery of mixed-RLC impossibility certificates remains unfinished. A fresh unrestricted degree-two probe still returned UNKNOWN at its selected timeout.

## Start here

From this directory, with Python 3:

```bash
python -S src/replay_portable_certificates.py
python -S src/test_portable.py
```

These two commands use only the Python standard library. `-S` disables ordinary site-package initialization. The recorded run independently replayed **18 certificate artifacts** and passed **30 portable test methods**, including deliberate corruptions and scope checks. These counts are different: certificate examples and test methods must not be added into one inflated "theorem count."

Proposal and integration paths additionally use SymPy and mpmath:

```bash
python -m pip install sympy mpmath
python src/test_integration.py --part 0
python src/test_integration.py --part 1
```

The two integration partitions each contain six methods, for **12 integration methods and 42 total test methods** in this release. Splitting the integration run avoids a short execution-window limit encountered during development. Both partitions completed successfully. The optional generic solver requires a discoverable native Z3 library. No executable binary, Python runtime or Z3 binary is bundled.

The original six-reactive seed and its quantitative core neighborhood can be replayed independently:

```bash
python prior_release/smith_hughes_generalization/src/replay_certificate_bundle.py
```

That earlier script replays the original seed, uniform core and its earlier independent degree-six, seven and eight targets. The new integration tests bind the new degree-ten component certificate to freshly recomputed pole/deflation intervals.

## Synthesize a target

Create a JSON file with **ascending-power exact rational coefficients**:

```json
{"P": [3, 1], "Q": [2, 1]}
```

This describes `(s+3)/(s+2)`. Use integers or rational strings such as `"2/3"`; do not use floating-point JSON coefficients for a proof obligation.

```bash
python src/synthesize_checked.py target.json --out answer.json
```

To disable the optional generic SMT fallback:

```bash
python src/synthesize_checked.py target.json --no-generic --out answer.json
```

To try budgets up to a chosen limit:

```bash
python src/synthesize_checked.py target.json --timeout-ms 3000 --max-budget 4 --out answer.json
```

The default generic attempt is at the target's reduced degree only. Increasing the maximum budget does not make unresolved smaller budgets infeasible. The classical and certified-local routes are attempted first.

## Result meanings

| Result | Meaning |
|---|---|
| `CERTIFIED_MINIMUM` | A checked construction and a valid lower bound agree. The result records the lower-bound source. |
| `CERTIFIED_UPPER_BOUND` | A checked construction exists, but minimum storage is not established. |
| `UNVERIFIED_SAT` | The solver proposed feasibility, but the independent witness check did not complete successfully. No circuit theorem follows. |
| `UNVERIFIED_UNSAT` | The solver reported infeasibility without an accepted independent refutation. No improved certified lower bound follows. |
| `UNKNOWN` | The attempted routes did not settle the problem. Timeouts are in this category. |

A bare solver UNSAT result is never promoted to a verified impossibility result. A successful refutation of an RC-only, RL-only, fixed-edge or restricted-node problem is not a lower bound for unrestricted RLC synthesis.

## Files and proof responsibilities

- `THEOREMS_AND_PROOFS.md`: exact statements, proofs, prior-art attribution and limitations.
- `ENGINEERING_NOTES.md`: implementation trust, test scope, timings and actual failure record.
- `SOURCE_MAP.md`: source-derived results versus deductions and implementation.
- `HANDOFF.md`: the state another session should resume from.
- `src/exact_polynomials.py`: rational sparse polynomial and sum-of-squares refutation checker.
- `src/polynomial_budget.py`: complete or explicitly restricted circuit equality system, plus proof generators for zero-storage and signature exclusions.
- `src/real_algebraic.py`, `src/algebraic_witness.py`: standard-library algebraic signs, root isolation, field arithmetic, nodal solves and exact circuit verification.
- `src/solver_model_adapter.py`: untrusted conversion of solver rational/algebraic values into the independently checked format.
- `src/real_pole_synthesis.py`: classical sufficient real-pole synthesis route and exact verification.
- `src/fast_algebraic_inverse.py`, `src/dyadic_intervals.py`: repaired local pole extraction and outward rational interval deflation.
- `src/synthesize_checked.py`: certificate-first dispatcher with stricter solver trust policy.
- `examples/`: exact proof objects and independently perturbed local input targets.
- `results/`: recorded acceptance and failure logs. `RUN_MANIFEST.json` summarizes complete runs without counting interrupted attempts as passes.
- `prior_release/`: retained earlier source and certificates. Use the new dispatcher, not the older dispatcher, for the stricter acceptance policy.

## Mathematical scope

An upper witness matches the scalar driving-point impedance. It does not assert equality of all internal behaviors or hardware performance. All present components are positive finite ordinary R, L and C. No transformers, mutual inductances, controlled sources or negative elements are permitted.

For rational target input, the real-algebraic witness and polynomial-refutation languages are mathematically adequate for YES and NO decisions at a fixed storage budget. This is based on classical real algebraic geometry. The release implements acceptance checking, not a complete efficient proof-discovery engine.

The demonstrated global polynomial lower-budget refutation is the zero-storage case. Higher-budget generated exclusions in this package are **RC-only or RL-only**, not general mixed-RLC impossibility proofs. Hughes's five-reactive minimum is retained from his published theorem, with an independently checked upper witness here.

Local degree-10/12/16/20 targets were perturbed directly in rational coefficient space. Their perturbations are deliberately tiny. These tests establish valid local examples, not wide industrial coverage. The degree-ten input has a fresh component certificate of radius `1e-40`. Degrees 12, 16 and 20 use the replayed uniform degree-six core existence certificate after exact deflation.

No historical-priority claim, external SPICE run, hardware test, tolerance advantage, power/noise improvement or general minimum-total-component theorem is made.
