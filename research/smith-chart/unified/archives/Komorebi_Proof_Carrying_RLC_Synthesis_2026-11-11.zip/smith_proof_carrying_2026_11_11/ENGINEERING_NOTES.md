# Engineering notes and actual failure record

**Author: Komorebi P.**  
**Date: 11 November 2026**

## 1. Trust separation

The polynomial/refutation and algebraic circuit acceptance kernels use the Python standard library, integer arithmetic and `fractions.Fraction`. Algebraic roots are bound by defining rational polynomials and exact Sturm isolating intervals. Circuit verification uses exact nodal equations and the degree-limited interpolation theorem. It is not an approximate frequency sweep.

SymPy, numerical proposals, primitive-element conversion and SMT search are outside the portable acceptance kernel. A proposal can be wrong and will establish nothing unless an independent exact check passes. The local degree-six acceptance stage reuses the prior project's exact rational contraction verifier; the whole local path is not claimed third-party-free because the retained infrastructure imports SymPy/mpmath.

This is ordinary Python verification, not Lean/Coq formalization. Trust remains in the implementation, interpreter and stated mathematical arguments. "Independent" means separate acceptance calculations rather than trusting the search's residual or SAT label, not a second human author's audit.

## 2. Refutation semantics

An accepted identity is

`-1 = sum(weight * polynomial^2) + sum(multiplier * compiled_equation)`.

Weights must be nonnegative rationals. Every coefficient is checked exactly. The circuit compiler regenerates the equations from the target, budget and permitted graph class; the proof binds to their canonical digest. Scope is recomputed rather than read from a certificate flag.

This is a general certificate language, but the automatic generators are limited to zero-storage and two-frequency RC/RL energy contradictions. No general high-degree mixed-RLC refutation generator has been completed. Real Nullstellensatz completeness supplies existence in principle, not feasible certificate size or discovery time.

The square-variable equality compiler has degree at most three. It does not claim better solver complexity than the earlier bilinear-plus-inequality encoding. It exists to remove sign side conditions from the algebraic refutation kernel.

## 3. Late scope bug found and fixed

A final audit found that the compiler's zero-storage scope flag originally treated any unrestricted-node, unspecified-edge-list problem as complete, even when the caller explicitly removed the resistor signature. With no branch types, the equation `-1=0` is indeed infeasible, but it cannot exclude a positive constant resistor in the full RLC class.

The completeness condition now explicitly requires resistor branches at budget zero. The new test `test_zero_budget_no_resistors_is_restricted` builds this exact counterexample, accepts its restricted refutation and rejects its interpretation as a global lower bound. This increased the portable suite from 29 to 30 methods. No released result in this continuation relies on the erroneous scope flag.

The local extractor also now rejects a caller-supplied core allowance larger than the actually certified `1e-13` coefficient box. A test deliberately requests `1e-12` and verifies rejection.

## 4. Algebraic components

Each component parameter is a rational polynomial in one isolated real algebraic root. Present branches must have strictly positive values. The checker verifies support, actual storage and connectivity and matches the target at enough exact positive arguments.

The quotient ring representation can conservatively reject a reducible defining polynomial when an inverse is not a unit. This is not an unsound acceptance. A primitive element's irreducible minimal polynomial suffices for the mathematical representation theorem. Field degree growth and primitive-element discovery remain practical costs.

A first cubic example used the wrong sign when translating its defining root relation into constant coefficients: it proposed numerator constant 98 and denominator constant 53 instead of 96 and 51. The independent checker rejected it at the first exact sample. The corrected circuit is checked, and the wrong pair is retained as an explicit rejection test. No near-match was accepted.

A Z3-style exact root-object model containing square roots was converted through the untrusted adapter and checked successfully. This exercises algebraic model conversion, not a claim that the generic solver discovered all examples in this package. Several witnesses were deliberately constructed to test the checker.

## 5. Local inverse: failures and repair

The unchanged previous extractor did not finish the degree-ten target in a bounded 45-second development run. Its log contains only the start marker, not a completed certificate. A separate diagnostic profiler repeatedly sampled the old root-isolation/comparison path and ended in a segmentation fault. This diagnostic failure is recorded; it is not counted as evidence of a unique mathematical cause or as a proof result.

The replacement removes that path from acceptance and controls denominator growth. It uses exact sign-preserving primitive Sturm sequences, dyadic bisection, and outward rounding onto a fixed 640-bit dyadic grid. Every root bracket and full root count in the selected extension region is checked.

Recorded root/deflation times, excluding unrelated setup and fresh component recovery:

| Degree | Recorded seconds | Core deviation bound |
|---|---:|---:|
| 10 | about 0.343 | below 1.098e-36 |
| 12 | about 0.746 | below 1.964e-44 |
| 16 | about 2.437 | below 1.059e-60 |
| 20 | about 7.321 | below 1.743e-77 |

These are one-environment observations, not promised runtimes. Inputs are independently perturbed rational polynomials but use deliberately tiny perturbations `10^-(22+5(n-6))`. They are not arbitrary distant design targets. A quarter-unit bracket about each labelled extension pole is part of the local chart. Failure outside the chart is not infeasibility.

The degree-ten target has a fresh thirteen-parameter core certificate of radius `1e-40`, exact contraction below `2.394e-33`, and displacement below `6.422e-11` times its radius. Degrees 12, 16 and 20 use the original uniform core existence certificate after exact interval deflation; no fresh optimized component centers are claimed for them.

## 6. Classical routes and remaining generic failure

A direct real-pole route now solves `(s+3)/(s+2)` and `(2s^2+8s+7)/(s^2+3s+2)` with exact minimum storage one and two. These cases previously timed out in generic searches. The improvement comes from using a classical analytic subclass before generic search, not from making the unrestricted search efficient.

A new unrestricted degree-two target `(s^2+s+1)/(s^2+2s+2)`, budget two, still returned UNKNOWN under its selected 500 ms native Z3 limit. The recorded runtime was about 0.566 seconds, reason "canceled". It is not a nonexistence proof. See `results/generic_solver_probe.json`; repeated timings may vary.

The dispatcher now preserves the reduced-degree lower bound when generic UNSAT lacks a checked polynomial refutation. It may continue searching higher budgets for an upper witness, but does not call that witness minimum merely because earlier solver calls said UNSAT.

## 7. Completed and interrupted tests

Completed current suite: 30 portable methods and two six-method integration partitions, 42 methods total. All passed. The portable replay separately checks 18 certificate artifacts. Assertions inside a method are not presented as separate theorems.

A combined integration attempt exceeded the execution window before producing a final summary. Its incomplete log is retained in `results/failures/`. A subsequent ad hoc import smoke check from the package root initially omitted `src` from the module path and raised `ModuleNotFoundError`; the corrected invocation and three dispatcher smoke cases passed. This shell invocation error did not invalidate the already completed integration partition. The final two partitions each completed and have JSON summaries and logs. Only those complete runs count toward the 42-method result.

Integration coverage includes original seed replay, the uniform core, the earlier independent degree-six/seven/eight inputs under the replacement extractor, degree-ten fresh component certification, degrees12/16/20 local extraction, first-order routes, Hughes's published class, actual algebraic model conversion and mock-based tests of UNSAT/timeout trust policy. Mock tests are identified as policy tests; the separately recorded real SMT probe is not mocked.

## 8. Still not done

General automatic mixed-RLC refutation discovery, scalable unrestricted topology search, a general algebraic-target-coefficient API, low-complexity primitive-element conversion, and industrial engineering validation remain unfinished. No external SPICE or hardware test was run. No files were published to GitHub or saved into the user's persistent Library.
