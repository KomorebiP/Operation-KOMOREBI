# Changelog

**Author: Komorebi P.**

## 2026-11-11: proof-carrying continuation

Added standard-library rational polynomial refutations, real-algebraic circuit witnesses, primitive-element model adapter, two-sided minimum bundles, classical real-pole synthesis and a certificate-first dispatcher. Added exact energy refutation generators with explicit restricted scope. Replaced the slow local pole path with Sturm/dyadic arithmetic and completed independent degrees10/12/16/20. Generated a fresh degree-ten core certificate.

The final audit fixed a q=0 signature-coverage bug and prevented unsupported enlargement of the certified local coefficient radius. Added rejection regressions. Final suite: 30 portable plus 12 integration test methods. Portable examples: 18 artifacts. Preserved previous source/certificates and actual failed/unknown run records.

Not added: a practical universal optimizer, automatic general mixed-RLC refutations, independent generic solver proof extraction, hardware validation or historical novelty claims.
