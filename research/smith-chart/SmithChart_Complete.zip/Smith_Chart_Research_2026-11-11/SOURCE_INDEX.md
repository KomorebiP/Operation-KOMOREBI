# Source index

Author: Komorebi P.

This index lists the files actually supplied with the 11 November 2026 reading. Only the current exact certificate is claimed as freshly replayed here. The earlier directories preserve recovered sources and records, not a guarantee that every historical builder runs unchanged.

## Current exact construction

Replayed on 11 November 2026, including the new exact interval margins.

- [README.md](reproduction/exact_seven/README.md)
- [dark_pole_interval_margins.json](reproduction/exact_seven/data/dark_pole_interval_margins.json)
- [dark_solution_high_precision.json](reproduction/exact_seven/data/dark_solution_high_precision.json)
- [independent_nodal_check.json](reproduction/exact_seven/data/independent_nodal_check.json)
- [original_cubic_high_precision.json](reproduction/exact_seven/data/original_cubic_high_precision.json)
- [seven_reactive_exact_certificate.json](reproduction/exact_seven/data/seven_reactive_exact_certificate.json)
- [check_dark_mode_rank.py](reproduction/exact_seven/src/check_dark_mode_rank.py)
- [generate_exact_systems.py](reproduction/exact_seven/src/generate_exact_systems.py)
- [make_figures.py](reproduction/exact_seven/src/make_figures.py)
- [regenerate_dark_system.py](reproduction/exact_seven/src/regenerate_dark_system.py)
- [verify_exact.py](reproduction/exact_seven/src/verify_exact.py)
- [verify_interval_margins.py](reproduction/exact_seven/src/verify_interval_margins.py)
- [verify_nodal.py](reproduction/exact_seven/src/verify_nodal.py)

## Earlier core calculations

Recovered from the embedded downloads in the prior reading. Earlier run counts are historical.

- [Smith_Chart_Extended_Transformerfree_Decision.md](reproduction/earlier_core/Smith_Chart_Extended_Transformerfree_Decision.md)
- [Smith_Chart_Six_State_Invariant_Continuation.md](reproduction/earlier_core/Smith_Chart_Six_State_Invariant_Continuation.md)
- [q6_5node_canonical_topologies.json](reproduction/earlier_core/q6_5node_canonical_topologies.json)
- [smith_chart_extended.py](reproduction/earlier_core/smith_chart_extended.py)
- [smith_extended_figures_full.py](reproduction/earlier_core/smith_extended_figures_full.py)
- [smith_fejer_minimal_reactive.cir](reproduction/earlier_core/smith_fejer_minimal_reactive.cir)
- [smith_mask_checks.py](reproduction/earlier_core/smith_mask_checks.py)
- [smith_order_growth_checks.py](reproduction/earlier_core/smith_order_growth_checks.py)
- [smith_order_growth_figures.py](reproduction/earlier_core/smith_order_growth_figures.py)
- [smith_q6_graph_pruning.py](reproduction/earlier_core/smith_q6_graph_pruning.py)
- [smith_q6_invariant_certificates.json](reproduction/earlier_core/smith_q6_invariant_certificates.json)
- [smith_q6_invariant_certificates.py](reproduction/earlier_core/smith_q6_invariant_certificates.py)
- [smith_realization_ac_validate.py](reproduction/earlier_core/smith_realization_ac_validate.py)
- [smith_realization_checks.py](reproduction/earlier_core/smith_realization_checks.py)
- [smith_realization_figures.py](reproduction/earlier_core/smith_realization_figures.py)
- [smith_six_state_checks.py](reproduction/earlier_core/smith_six_state_checks.py)
- [smith_transformerfree_decision.py](reproduction/earlier_core/smith_transformerfree_decision.py)
- [smith_transformerfree_figures.py](reproduction/earlier_core/smith_transformerfree_figures.py)
- [try_six_transformerfree_search.py](reproduction/earlier_core/try_six_transformerfree_search.py)

## Six-element signatures and graph restrictions

Recovered source and recorded outputs. No complete six-element decision is claimed.

- [README_Six_State_Unpublished.md](reproduction/six_state/README_Six_State_Unpublished.md)
- [Smith_Chart_Extended_Six_State_Invariants.md](reproduction/six_state/Smith_Chart_Extended_Six_State_Invariants.md)
- [Smith_Chart_Six_State_Continuation_Audit.md](reproduction/six_state/Smith_Chart_Six_State_Continuation_Audit.md)
- [Smith_Chart_Six_State_Invariant_Continuation.md](reproduction/six_state/Smith_Chart_Six_State_Invariant_Continuation.md)
- [order_growth_section.md](reproduction/six_state/order_growth_section.md)
- [q6_5node_canonical_topologies.json](reproduction/six_state/q6_5node_canonical_topologies.json)
- [q6_canonical_fits.py](reproduction/six_state/q6_canonical_fits.py)
- [q6_canonical_fits_0_75.json](reproduction/six_state/q6_canonical_fits_0_75.json)
- [q6_canonical_fits_75_168.json](reproduction/six_state/q6_canonical_fits_75_168.json)
- [q6_grad_search.py](reproduction/six_state/q6_grad_search.py)
- [q6_refine_best.py](reproduction/six_state/q6_refine_best.py)
- [q6_refined_7.json](reproduction/six_state/q6_refined_7.json)
- [six_state_combiner_section.md](reproduction/six_state/six_state_combiner_section.md)
- [smith_mask_checks.py](reproduction/six_state/smith_mask_checks.py)
- [smith_order_growth_checks.py](reproduction/six_state/smith_order_growth_checks.py)
- [smith_q6_graph_pruning.json](reproduction/six_state/smith_q6_graph_pruning.json)
- [smith_q6_graph_pruning.py](reproduction/six_state/smith_q6_graph_pruning.py)
- [smith_q6_invariant_certificates.json](reproduction/six_state/smith_q6_invariant_certificates.json)
- [smith_q6_invariant_certificates.py](reproduction/six_state/smith_q6_invariant_certificates.py)
- [smith_q6_invariant_figures.py](reproduction/six_state/smith_q6_invariant_figures.py)
- [smith_realization_checks.py](reproduction/six_state/smith_realization_checks.py)
- [smith_six_state_checks.py](reproduction/six_state/smith_six_state_checks.py)
- [smith_transformerfree_decision.py](reproduction/six_state/smith_transformerfree_decision.py)
- [transformerfree_decision_section.md](reproduction/six_state/transformerfree_decision_section.md)

## Pole-pair extraction and local obstruction

Recovered source and recorded outputs for the two extraction stages.

- [Smith_Chart_Double_Extraction_Audit.md](reproduction/double_extraction/Smith_Chart_Double_Extraction_Audit.md)
- [Smith_Chart_Extended_Double_Extraction.md](reproduction/double_extraction/Smith_Chart_Extended_Double_Extraction.md)
- [Smith_Chart_Double_Extraction_Continuation.md](reproduction/double_extraction/current_work/Smith_Chart_Double_Extraction_Continuation.md)
- [Smith_Chart_Exact_Pole_Split_Continuation.md](reproduction/double_extraction/current_work/Smith_Chart_Exact_Pole_Split_Continuation.md)
- [smith_double_extraction_browser_check.py](reproduction/double_extraction/current_work/smith_double_extraction_browser_check.py)
- [smith_q6_double_extraction_certificate.json](reproduction/double_extraction/current_work/smith_q6_double_extraction_certificate.json)
- [smith_q6_double_extraction_certificate.py](reproduction/double_extraction/current_work/smith_q6_double_extraction_certificate.py)
- [smith_q6_double_extraction_figures.py](reproduction/double_extraction/current_work/smith_q6_double_extraction_figures.py)
- [smith_q6_pole_split_certificate.json](reproduction/double_extraction/current_work/smith_q6_pole_split_certificate.json)
- [smith_q6_pole_split_certificate.py](reproduction/double_extraction/current_work/smith_q6_pole_split_certificate.py)
- [smith_q6_pole_split_figures.py](reproduction/double_extraction/current_work/smith_q6_pole_split_figures.py)

## Frequency-anchor and passivity continuation

Recovered source and recorded exact calculations.

- [Smith_Chart_Coupled_Continuation_Audit.md](reproduction/coupled_continuation/Smith_Chart_Coupled_Continuation_Audit.md)
- [Smith_Chart_Extended_Four_Anchor_Continuation.md](reproduction/coupled_continuation/Smith_Chart_Extended_Four_Anchor_Continuation.md)
- [Smith_Chart_Coupled_Continuation_README.md](reproduction/coupled_continuation/coupled_continuation/Smith_Chart_Coupled_Continuation_README.md)
- [Smith_Chart_Four_Anchor_Continuation.md](reproduction/coupled_continuation/coupled_continuation/Smith_Chart_Four_Anchor_Continuation.md)
- [smith_q6_anchor_figures.py](reproduction/coupled_continuation/coupled_continuation/smith_q6_anchor_figures.py)
- [smith_q6_four_anchor_certificates.json](reproduction/coupled_continuation/coupled_continuation/smith_q6_four_anchor_certificates.json)
- [smith_q6_four_anchor_certificates.py](reproduction/coupled_continuation/coupled_continuation/smith_q6_four_anchor_certificates.py)
- [smith_q6_double_extraction_certificate.py](reproduction/coupled_continuation/prior_checks/smith_q6_double_extraction_certificate.py)
- [smith_q6_pole_split_certificate.py](reproduction/coupled_continuation/prior_checks/smith_q6_pole_split_certificate.py)

## Cubic extraction and numerical predecessor

Historical cubic certificate and numerical four-reactive search sources; the later exact package supersedes the candidate status.

- [Smith_Chart_Cubic_Certified_Continuation.md](reproduction/exact_cubic_continuation/Smith_Chart_Cubic_Certified_Continuation.md)
- [Smith_Chart_Cubic_Exact_Continuation_Audit.md](reproduction/exact_cubic_continuation/Smith_Chart_Cubic_Exact_Continuation_Audit.md)
- [Smith_Chart_Extended_Cubic_Exact_Continuation.md](reproduction/exact_cubic_continuation/Smith_Chart_Extended_Cubic_Exact_Continuation.md)
- [certify_cubic.py](reproduction/exact_cubic_continuation/certify_cubic.py)
- [certify_cubic_complement.py](reproduction/exact_cubic_continuation/certify_cubic_complement.py)
- [cubic_complement_PR_certificate.json](reproduction/exact_cubic_continuation/cubic_complement_PR_certificate.json)
- [cubic_contraction_certificate.json](reproduction/exact_cubic_continuation/cubic_contraction_certificate.json)
- [cubic_solution_approx.json](reproduction/exact_cubic_continuation/cubic_solution_approx.json)
- [derive_cubic.py](reproduction/exact_cubic_continuation/derive_cubic.py)
- [make_cubic_figures.py](reproduction/exact_cubic_continuation/make_cubic_figures.py)
- [q4_complement_solution_approx.json](reproduction/exact_cubic_continuation/q4_complement_solution_approx.json)
- [q4_graph_symbolic.py](reproduction/exact_cubic_continuation/q4_graph_symbolic.py)
- [refined_B_q4.json](reproduction/exact_cubic_continuation/refined_B_q4.json)
- [solve_cubic_exact.py](reproduction/exact_cubic_continuation/solve_cubic_exact.py)
- [solve_q4_complement.py](reproduction/exact_cubic_continuation/solve_q4_complement.py)
- [sparse_best.json](reproduction/exact_cubic_continuation/sparse_best.json)

## Reading build and new visual

- [build_reading.py](build_reading.py)
- [make_reading_map.py](reproduction/make_reading_map.py)
- [reading.css](assets/reading.css)
- [reading.js](assets/reading.js)

The embedded MathJax renderer is retained from the recovered HTML. The mathematical plots and circuit diagrams are generated with Python.

The unrecovered 171-check historical chapter suite and the separate earlier research notes named in the provenance narrative are not claimed to be included.

## New theorem note (11 November 2026)

- `Smith_Order_Separation_Theorem_Unpublished.md`: full theorem, proof, exact norm, passivity margin, and pole-gap certificate.
- `reproduction/new_order_separation/check_order_gap.py`: finite-N independent diagnostic and exact Fraction checkpoints.
- `reproduction/new_order_separation/plot_order_gap.py`: Python source generating Figure 42.
- `figures/42_exponential_order_gap.svg` and `.png`: vector and raster figures.
- `audit/New_Arbitrary_Order_Theorem_Audit_2026-11-11.md`: verification scope, novelty boundary and the unchanged six-versus-seven gap.
