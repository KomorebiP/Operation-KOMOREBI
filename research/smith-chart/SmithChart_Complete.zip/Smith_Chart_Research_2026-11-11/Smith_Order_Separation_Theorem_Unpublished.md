# Smith chart: exact–approximate reactive-order separation

**Author:** Komorebi P.  
**11 November 2026 · Unpublished theorem note**

This note isolates the new general construction from the extended reading. It is not a claim of historical novelty or a solution of the six-versus-seven element synthesis problem. The proof is self-contained; the diagnostic program and Python figure are provided in the companion package.

## Theorem, proof, and uniform certificates

**Author: Komorebi P. · 11 November 2026 · Unpublished mathematical continuation.**  
**Result status:** an elementary general theorem with a sharp norm formula, proved below and checked independently in Python. Its historical novelty has **not** been established. It is separate from the unresolved transformer-free six-versus-seven reactive-element question for \(Z_6\).

### Uniformly stable, strictly passive responses of arbitrarily high exact order

Fix a real \(a\) with \(0<|a|<1\) and \(0<\rho<1/2\). For every integer \(N\ge4\), put \(\omega=e^{2\pi i/N}\) and

\[
 w_k=\frac{1+2\rho\cos(2\pi k/N)}{N}>0,\quad
 F_a(u)=\frac{a+u}{1+au},\quad
 G_{N,a}(t)=\sum_{k=0}^{N-1}w_kF_a(\omega^kt).
\]

All the weights are positive and sum to one. Their cyclic moments \(\mu_m=\sum_kw_k\omega^{km}\) satisfy \(\mu_m=1\) for \(m\equiv0\pmod N\), \(\mu_m=\rho\) for \(m\equiv\pm1\pmod N\), and \(\mu_m=0\) otherwise. In particular \(\mu_1=\rho\) and \(\mu_2=0\).

**Theorem (arbitrarily high exact order, exponentially accurate passive one-state reduction).** For every \(N\ge4\):

1. \(G_{N,a}\) is a real-rational Schur function, strictly contractive on the closed disk. Its reduced rational degree is **exactly \(N\)**.
2. Setting \(q=-at\), the following *exact* rational identity holds:

\[
 \boxed{G_{N,a}(t)=a+(1-a^2)t\frac{\rho+\rho q^{N-2}+q^{N-1}}{1-q^N}.}
 \tag{A1}
\]

3. The degree-one limit \(G_{*,a}(t)=a+(1-a^2)\rho t\) is Schur. Moreover the full-disk approximation error is **sharp**:

\[
 \boxed{\left\|G_{N,a}-G_{*,a}\right\|_{H^\infty(\mathbb D)}=
 \frac{(1-a^2)|a|^{N-2}\bigl[\rho(1+a^2)+|a|\bigr]}{1-|a|^N}.}
 \tag{A2}
\]

4. Let \(z_{N,a}(s)=(1+G_{N,a}(t(s)))/(1-G_{N,a}(t(s)))\), \(t(s)=(s-1)/(s+1)\). It is real-rational, strictly positive-real, and has degree \(N\). Thus **every exact ideal RLC realization requires at least \(N\) independent reactive elements**, whereas \(z_{*,a}\) can be realized with one inductor and positive resistors.

**Proof.** Each \(F_a\) is a disk automorphism and the \(w_k\) form a positive, real-symmetric probability mask. Their convex average is Schur and has real coefficients. On the boundary, the distinct arguments \(\omega^kt\) have distinct images under the injective automorphism, so the positive average has modulus strictly smaller than one; compactness gives strict closed-disk contractivity. For \(a\ne0\), the \(N\) terms have distinct simple poles at \(-1/(a\omega^k)\), with nonzero residues; no other term has a pole at the same location. Therefore their sum has exactly \(N\) simple poles and no pole at infinity, giving degree \(N\).

Expand \(F_a(u)=a+(1-a^2)\sum_{m\ge1}(-a)^{m-1}u^m\). Filtering by the above moments and summing the three geometric progressions yields (A1). Subtracting the affine limit gives

\[
 G_{N,a}(t)-G_{*,a}(t)
 =(1-a^2)t\frac{q^{N-2}(\rho+q+\rho q^2)}{1-q^N}.
 \tag{A3}
\]

The triangle inequality on \(|t|\le1\) gives the right-hand side of (A2) as an upper bound. At \(t=-\operatorname{sgn}(a)\), we have \(q=|a|\), all factors are aligned, and the upper bound is attained as a boundary supremum. This proves sharpness. Because \(|a|+(1-a^2)\rho<1\), the affine limit is strictly Schur. Möbius changes of variable and value preserve the reduced rational degree, and the Cayley transform maps strict Schur functions to strictly positive-real impedances. The state-degree bound supplies \(N\) necessary reactive elements; the affine limit maps to a positive first-order RL impedance. This proves all claims. \(\square\)

### A rational certificate with a uniform stability gap

Choose \(a=1/3\) and \(\rho=1/4\). The limiting one-state impedance is

\[
 G_*(t)=\frac13+\frac29t,
 \qquad z_*(s)=\frac{7s+5}{2s+4}=\frac54+\frac94\frac{s}{s+2}.
 \tag{A4}
\]

This is exactly a series resistor \(R_s=5/4\) followed by a parallel resistor \(R_p=9/4\) and inductor \(L=9/8\), in normalized impedance and time units. All three components are positive. Equation (A2) simplifies to

\[
 \boxed{E_N:=\|G_N-G_*\|_{H^\infty}=
 \frac{44}{81}\frac{3^{-(N-2)}}{1-3^{-N}}.}
 \tag{A5}
\]

For example, \(E_4=11/180\), \(E_{10}=1/12078\), and \(E_{20}=1/713205900\). Exact reactive-order lower bounds grow as \(N\), while this one-reactive approximation becomes exponentially accurate on the **entire disk**.

The sharp error is also a uniform passivity certificate. Since \(E_N\le E_4=11/180\),

\[
 |G_N(t)|\le\frac59+\frac{11}{180}=\frac{37}{60}
 \qquad(|t|\le1),
\]

which implies the \(N\)-independent impedance bound

\[
 \boxed{\operatorname{Re}z_N(s)\ge\frac{23}{97}>0\qquad(\operatorname{Re}s>0).}
 \tag{A6}
\]

There is also a **uniform pole gap**, not merely stability for each \(N\). On the larger disk \(|t|\le3/2\), we have \(|q|\le1/2\), \(|G_*|\le2/3\), and from (A3), for every \(N\ge4\),

\[
 |G_N-G_*|\le
 \frac{(8/9)(3/2)(1/2)^2(1/4+1/2+1/16)}{1-1/16}
 =\frac{13}{45}.
\]

Therefore \(|G_N|\le43/45<1\) throughout \(|t|\le3/2\). The impedance \(z_N\) has **no pole** in this disk. Under \(s=(1+t)/(1-t)\), every finite pole of \(z_N\) consequently satisfies

\[
 \boxed{\operatorname{Re}s\le-\frac15,}
 \tag{A7}
\]

in normalized Laplace-frequency units. Finally, the Cayley difference formula bounds the *impedance* error:

\[
 \boxed{\|z_N-z_*\|_{H^\infty(\mathbb C_+)}\le\frac{270}{23}E_N.}
 \tag{A8}
\]

Thus the family simultaneously has unbounded exact storage-order lower bounds, an exponential one-state approximation rate, a common strict-positive-real margin, and a common pole-stability gap. The high-order behavior is **not** caused by poles converging to the imaginary axis.

![Python-generated mathematical plot of the sharp reflection error against the exact reactive lower bound.](figures/42_exponential_order_gap.svg)

*Figure 42. Sharp, analytical H-infinity reflection errors from equation (A5), displayed on a logarithmic scale. Each point represents a positive cyclic mask with exact rational degree N; the same one-inductor RL impedance approximates every point.*

**Interpretation and novelty boundary.** This explicitly separates exact reactive complexity from passive full-frequency approximation complexity. The proof is self-contained and does not establish historical priority. Degree discontinuities, model reduction, rational approximation, and positive-real synthesis have classical precedents. The new candidate contribution is this **specific closed-form passive cyclic family with an attained exponential error bound and simultaneous uniform passivity and stability certificates**. It deserves an independent literature comparison before publication; it does **not** settle the six-reactive physical-synthesis problem for \(Z_6\).

**Reproduction.** The accompanying `reproduction/new_order_separation/check_order_gap.py` verifies finite-N moment identities, rational values at the equality point, the one-inductor circuit, and numerical samples as diagnostics. The theorem itself follows from the displayed geometric series and inequalities, not from finite testing.
