# Smith Chart Research: Consolidated Collection

**Author: Komorebi P.**  
**Collected:** 11 November 2026  
**Status:** Unpublished research. No public GitHub / .io changes.

## Suggested reading path

1. **Smith_Chart_Extended_Seven_Reactive_Exact.html**: complete self-contained reading edition with Smith-chart geometry, cyclic packets, passivity, interpolation, physical RLC synthesis, and the latest arbitrary-order separation theorem. This is the primary entry point; figures and mathematical rendering are embedded.
2. **Smith_Order_Separation_Theorem_Unpublished.md**: stand-alone statement and proof of exact-versus-approximate reactive-order separation. Has a sharp H-infinity reflection error and uniform passivity and stability bounds.
3. **IDEAS_AND_BOUNDARIES.md**: evidence-based register of theorems, constructions, conjectures, and open research routes.
4. **Smith_Chart_Extended_Seven_Reactive_Exact.md**: editable reading source, with references to figures/ and reproduction/.
5. **reproduction/exact_seven/README.md**: exact rational existence certificate for 7-reactive physical RLC synthesis. See source scripts and JSON data there.
6. **reproduction/new_order_separation/check_order_gap.py**: finite diagnostic verifier of the new general theorem, which is mathematically proved in the note.
7. **SOURCE_INDEX.md**: all historical and current checker/source groups, including exact cubic, six-state exploration, and coupled completion.
8. **audit/**: proof audit scope, previous literature/novelty notes, static reading checks, and a record of the browser testing limitation.
9. **PACKAGE_VALIDATION.json** and **MANIFEST.sha256**: integrity and packaging reports.

## Important distinctions

- The degree-six target has **an exact transformer-free 7-reactive construction** (4L + 3C + 14 positive resistors). Its minimum reactive count is **between 6 and 7**. Six-reactive transformer-free realization is neither proved nor disproved.
- The arbitrary-N order-separation theorem is a **different family**, not a proof of the missing degree-six circuit.
- A numerical fit is not an exact circuit existence proof; a fixed rational certificate for algebraic root existence is stronger than a frequency-sweep check. Historical fitting experiments are retained as such.
- Neither a Lean formalization, new hardware test, complete literature-priority clearance, nor fresh browser-rendered layout validation is claimed.

## Quick checks

From the extracted archive root:

```bash
python reproduction/new_order_separation/check_order_gap.py
cd reproduction/exact_seven
python src/generate_exact_systems.py
python src/verify_exact.py
python src/check_dark_mode_rank.py
python src/verify_interval_margins.py
python src/verify_nodal.py
```

The circuit checks can require Python, SymPy, NumPy, and mpmath. See their README for requirements and interpretations. The PDF/graphics were not AI-generated; all diagrams in the reading were drawn by Python code.
