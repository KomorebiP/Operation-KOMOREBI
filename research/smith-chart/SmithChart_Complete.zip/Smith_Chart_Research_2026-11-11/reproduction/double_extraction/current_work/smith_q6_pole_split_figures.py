#!/usr/bin/env python3
"""Python-only figures for unpublished Smith chart pole-splitting note.
Author: Komorebi P.
"""
from pathlib import Path
import numpy as np, matplotlib.pyplot as plt
from matplotlib.patches import Arc, Circle
OUT=Path(__file__).resolve().parent/'figures';OUT.mkdir(exist_ok=True)
GREEN='#294c40';BLUE='#406e94';GOLD='#b17c37';RED='#9c5843';INK='#24382d';MUTED='#637268'
plt.rcParams.update({'font.family':'DejaVu Sans','axes.titlesize':15,'axes.labelsize':11,'font.size':10,'figure.facecolor':'#fffdf8','axes.facecolor':'#fffdf8','axes.edgecolor':'#acb7aa','grid.alpha':.2})
fig,ax=plt.subplots(figsize=(10.0,5.6));ax.set_aspect('equal');ax.axis('off');ax.set_xlim(-2.0,5.25);ax.set_ylim(-1.6,3.9)
def line(x1,y1,x2,y2,**kw):ax.plot([x1,x2],[y1,y2],color=INK,lw=2.2,solid_capstyle='round',**kw)
def boxlabel(x,y,s,fc='#fffdf8'):
 ax.text(x,y,s,ha='center',va='center',fontsize=9,color=INK,bbox={'facecolor':fc,'edgecolor':'none','pad':3})
def resistor_h(x1,x2,y,name,val):
 width=.58;mid=(x1+x2)/2;line(x1,y,mid-width/2,y);ax.add_patch(plt.Rectangle((mid-width/2,y-.18),width,.36,facecolor='#e9e4d7',edgecolor=INK,lw=1.75));line(mid+width/2,y,x2,y);boxlabel(mid,y+.38,f'{name} ≈ {val}')
def resistor_v(x,y1,y2,name,val):
 mid=(y1+y2)/2;length=.45;line(x,y1,x,mid+length/2);ax.add_patch(plt.Rectangle((x-.17,mid-length/2),.34,length,facecolor='#e9e4d7',edgecolor=INK,lw=1.75));line(x,mid-length/2,x,y2);boxlabel(x-.78,mid,f'{name}\n≈ {val}')
def coil_h(x1,x2,y):
 n=5;rad=.115; total=.23*n; mid=(x1+x2)/2;left=mid-total/2;line(x1,y,left,y)
 for i in range(n):ax.add_patch(Arc((left+rad+i*2*rad,y),2*rad,2*rad,theta1=0,theta2=180,color=INK,lw=2.0))
 line(left+total,y,x2,y)
def cap_v(x,y1,y2):
 mid=(y1+y2)/2;line(x,y1,x,mid+.12);line(x,mid-.12,x,y2);line(x-.22,mid+.12,x+.22,mid+.12);line(x-.22,mid-.12,x+.22,mid-.12)
# Nodes and rails
line(0,2,0,2.65);line(0,2,0,1.35);line(3.6,2,3.6,2.65);line(3.6,2,3.6,1.35)
resistor_h(0,3.6,2.65,'R_A','2.4584');coil_h(0,3.6,1.35);boxlabel(1.8,.96,'L ≈ 0.64517')
line(3.6,2,3,2);line(3.6,2,4.3,2);line(3.6,-1,3,-1);line(3.6,-1,4.3,-1)
resistor_v(3,2,-1,'R_B','3.2330');cap_v(4.3,2,-1);boxlabel(4.65,.6,'C ≈ 5.25071')
line(0,2,-1.5,2);line(-1.5,2,-1.5,1.7);resistor_v(-1.5,1.7,-1,'R_G','20.9333');line(-1.5,-1,3.6,-1)
for x,y,l in [(0,2,'1'),(3.6,2,'2'),(3.6,-1,'0')]:
 ax.add_patch(Circle((x,y),.075,facecolor=GREEN,edgecolor=GREEN,zorder=10));ax.text(x+.12,y-.18,f'Node {l}',color=GREEN,fontsize=10,fontweight='bold')
ax.text(-.05,2.22,'Input port',color=GREEN,fontsize=11,ha='right',fontweight='bold')
ax.text(2.05,-1.3,'Return / ground',color=MUTED,fontsize=10,ha='center')
fig.suptitle('Exact two-reactive transformer-free section',x=.52,y=.96,fontsize=16,color=INK)
ax.text(1.85,3.53,'Three resistors · one inductor · one capacitor · algebraically certified',ha='center',color=MUTED,fontsize=10)
fig.savefig(OUT/'27_exact_two_state_triangle.png',dpi=190,bbox_inches='tight');fig.savefig(OUT/'27_exact_two_state_triangle.svg',bbox_inches='tight');plt.close(fig)
# Poles and frequency diagram
P=np.array([450,1385,2477,2200,1142,335,75.]);D=np.array([150,795,1375,1720,1250,445,25.]);roots=np.roots(D)
realroots=sorted([p.real for p in roots if abs(p.imag)<1e-8]);complexroots=sorted([p for p in roots if p.imag>1e-8],key=lambda v:v.imag)
fig,ax=plt.subplots(figsize=(9.2,4.6));ax.axhline(0,color='#b6c2b7',lw=1.2);ax.axvline(0,color='#b6c2b7',lw=1.2)
for rt in realroots:ax.scatter(rt,0,color=GREEN,s=125,marker='s',edgecolors='#fffdf8',linewidths=1.7,zorder=6)
for root in [complexroots[0],complexroots[0].conjugate()]:ax.scatter(root.real,root.imag,color=BLUE,s=105,edgecolors='#fffdf8',linewidths=1.3,zorder=6)
for root in [complexroots[1],complexroots[1].conjugate()]:ax.scatter(root.real,root.imag,color=GOLD,s=105,edgecolors='#fffdf8',linewidths=1.3,zorder=6)
ax.scatter([],[],marker='s',color=GREEN,label='Exact two-state extracted section')
ax.scatter([],[],marker='o',color=BLUE,label='Four-state remainder: lower-frequency pair')
ax.scatter([],[],marker='o',color=GOLD,label='Four-state remainder: higher-frequency pair')
ax.set(xlim=(-3.8,.25),ylim=(-1.56,1.56),xlabel='Real part of pole',ylabel='Imaginary part of pole',title='Pole groups of the filtered degree-six impedance')
ax.grid(True);ax.legend(fontsize=9,loc='upper left');fig.tight_layout();fig.savefig(OUT/'28_pole_pair_split.png',dpi=190);fig.savefig(OUT/'28_pole_pair_split.svg');plt.close(fig)
# Passivity traces
residues=[np.polyval(P,z)/np.polyval(np.polyder(D),z) for z in realroots]
w=np.geomspace(.001,100,1500);s=1j*w
Z6=np.polyval(P,s)/np.polyval(D,s)
Z2=2.2+sum(A/(s-pole) for A,pole in zip(residues,realroots))
Z4=Z6-Z2
fig,ax=plt.subplots(figsize=(9.5,4.8))
for Z,lbl,color in [(Z2,'Certified degree-two RLC section',GREEN),(Z4,'Certified positive-real degree-four remainder',BLUE),(Z6,'Original degree-six target',GOLD)]:
 ax.plot(w,Z.real,label=lbl,lw=2,color=color)
ax.axhline(0,color=RED,linestyle='--',lw=1);ax.set_xscale('log');ax.set(xlabel='Normalized angular frequency',ylabel='Real part of normalized impedance',title='Positive-real splitting of the six-state target')
ax.set_ylim(-.1,4.4);ax.grid(True);ax.legend(loc='upper right',fontsize=9);fig.tight_layout();fig.savefig(OUT/'29_passive_split_frequency.png',dpi=190);fig.savefig(OUT/'29_passive_split_frequency.svg');plt.close(fig)
print('Generated three plots in',OUT)
