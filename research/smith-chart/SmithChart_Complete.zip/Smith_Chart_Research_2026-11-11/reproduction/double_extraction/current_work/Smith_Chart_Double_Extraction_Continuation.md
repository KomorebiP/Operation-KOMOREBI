# A second exact RLC extraction and the nonregular pole-pair barrier

**Author: Komorebi P.**  
**Status:** Unpublished research note, 9 November 2026.  
**Scope:** A constructive transformer-free realization of a degree-four portion of the same degree-six target. The full six-reactive-element existence question remains unresolved. All visual figures in this section are generated using Python.

## Exact decomposition into three quadratic pole groups

Recall the positive-real impedance

\[
Z_6(s)=\frac{450s^6+1385s^5+2477s^4+2200s^3+1142s^2+335s+75}{5(30s^6+159s^5+275s^4+344s^3+250s^2+89s+5)}.
\]

The denominator has two distinct negative real roots and two distinct conjugate nonreal pole pairs. For each nonreal upper-half-plane pole \(\zeta\), define its exact residue \(A_\zeta=P(\zeta)/D'(\zeta)\), where \(P,D\) are the exact polynomials above. Combining the conjugate residues yields coefficients

\[
p=-2\operatorname{Re}\zeta,\quad q=|\zeta|^2,\quad a=2\operatorname{Re}A_\zeta,\quad b=-2\operatorname{Re}(A_\zeta\overline{\zeta}).
\]

Thus the exact pole-pair contribution is \((as+b)/(s^2+ps+q)\). This definition, rather than rounded coefficients, is used in all certificates.

Let \(Z_{\rm real,r}\) denote the real-pole section constructed in the preceding chapter, with constant resistance \(r\in[213/100,11/5]\). Order the nonreal pole pairs by increasing positive imaginary part and denote their strictly proper contributions by \(T_{\rm mid}\) and \(T_{\rm high}\). Then

\[
\boxed{Z_6(s)=Z_{\rm real,r}(s)+T_{\rm mid}(s)+\big[(3-r)+T_{\rm high}(s)\big].}
\]

The first term has an exact positive one-L/one-C transformer-free realization for every \(r\) in the interval, already certified. We now construct a second such circuit for \(T_{\rm mid}\), with **zero** constant feedthrough.

![Exact allocation: two solved pole pairs and one outstanding high-frequency pair](figures/31_series_split_status.png)

## Exact transformer-free synthesis of the middle pole pair

For the lower nonreal pole pair, interval-verified coefficients satisfy

| Exact coefficient | Approximate value |
|:--|--:|
| \(p\) | 1.264171323567376 |
| \(q\) | 0.527631229674494 |
| \(a\) | 0.105233907980455 |
| \(b\) | 0.046021275795695 |

The target is

\[
\boxed{T_{\rm mid}(s)=\frac{as+b}{s^2+ps+q}.}
\]

Consider a grounded three-node circuit. Between the input and ground, place conductance \(G\) in parallel with capacitor \(c\). Connect the input to an internal node through conductance \(A\). From the internal node to ground, place conductance \(B\) in parallel with an inductor of inverse inductance \(\ell\) (admittance \(\ell/s\)). Its input impedance is

\[
Z_{\rm mid,circuit}(s)=\frac{(A+B)s+\ell}{c(A+B)s^2+[G(A+B)+c\ell+AB]s+\ell(G+A)}.
\]

Choose \(G=1\), and define

\[
\begin{aligned}
h&=q/b,\\
A&=h-G,\\
X&=(p-aG-b/a)/a,\\
B&=AX/(A-X),\\
c&=1/a,\\
\ell&=(b/a)(A+B).
\end{aligned}
\]

These formulas satisfy exactly

\[
\boxed{Z_{\rm mid,circuit}(s)=T_{\rm mid}(s).}
\]

**Proof.** Divide the circuit numerator and denominator by \(c(A+B)\). The coefficient of \(s\) in the numerator becomes \(1/c=a\). The constant term becomes \(\ell/[c(A+B)]=b\). The denominator constant is \(\ell(G+A)/[c(A+B)]=b(G+A)=q\). The denominator linear coefficient is

\[
G/c+\ell/(A+B)+AB/[c(A+B)]
=aG+b/a+aAB/(A+B)=p,
\]

by the defining equation \(AB/(A+B)=X\). This is a rational identity for arbitrary nondegenerate \(p,q,a,b,G\). No approximation enters the algebra. ∎

Outward-rounded root-isolation intervals establish \(a,b,h-G,X,A-X,B,c,\ell>0\) for our algebraic coefficients. The same calculation verifies \(ap-b>0\) and \(bq>0\), so \(T_{\rm mid}\) is positive-real: the real part of its boundary values has numerator \((ap-b)\omega^2+bq>0\).

![Second exact transformer-free one-inductor / one-capacitor network](figures/30_middle_pole_rlc_triangle.png)

| Element | Algebraically exact value | Approximate normalized value |
|:--|:--|--:|
| Resistor \(R_G\), input to ground | \(1/G\) | 1.00000000 |
| Resistor \(R_A\), input to internal | \(1/A\) | 0.09555715 |
| Resistor \(R_B\), internal to ground | \(1/B\) | 0.05027419 |
| Capacitor, input to ground | \(c=1/a\) | 9.50264054 |
| Inductor, internal to ground | \(L=1/\ell\) | 0.07532766 |

The two nonoverlapping pole pairs have total reduced rational degree four. Connecting their explicitly synthesized two-reactive circuits in **series** realizes their sum exactly with two inductors and two capacitors. Thus the minimum reactive order of this **particular degree-four subnetwork** is four, since its rational degree is four.

## The remaining pair is positive-real but nonregular

Write the upper nonreal pole-pair remainder as

\[
Z_{\rm high,r_h}(s)=r_h+\frac{a_hs+b_h}{s^2+p_hs+q_h},\quad r_h=3-r\in[4/5,87/100].
\]

Here \((p_h,q_h,a_h,b_h)\) are algebraic and approximately

\[
(p_h,q_h,a_h,b_h)\approx (0.5588166854,1.3621478393,0.5774941299,-0.9367979986).
\]

The prior quadratic positivity test, verified again using outward-rounded intervals on seven rational subintervals, proves **strict positive-realness** for every allowed \(r_h\).

However, classical biquadratic **regularity** fails. For

\[
Z(s)=\frac{As^2+Bs+C}{Ds^2+Es+F},
\]

one regularity classification uses \(\Delta=AF-CD\) and

\[
\lambda_1=E(BF-CE)-F\Delta,\quad
\lambda_2=B(AE-BD)-A\Delta.
\]

The classical cases when \(\Delta>0\) require \(\lambda_1\geq0\) or \(\lambda_2\geq0\). In our high pole-pair family, \(\Delta=-b_h>0\) and exact cancellation gives

\[
\boxed{\lambda_1=p_h(a_hq_h-b_hp_h)+q_hb_h<0,}
\]

\[
\boxed{\lambda_2=r_h(b_h-a_hp_h)-a_h^2<0\qquad(r_h\geq0).}
\]

The sign certificates are exact intervals. Hence the high section is **nonregular for every nonnegative constant allocation for which it is positive-real**, not merely for the displayed interval.

By the established Jiang–Smith series-parallel classification, **no series-parallel one-inductor/one-capacitor circuit realizes this remainder**. Nonregularity **by itself** does not rule out exceptional bridges; the next section establishes their exclusion using the stronger classical bridge criterion. A different six-state circuit that mixes all pole groups remains possible. The classification is classical, and applying it to this algebraic family is the present calculation, not a new general network theorem.

![Classical biquadratic regularity inequalities, evaluated for the high-frequency pole pair](figures/32_high_pair_regularity_barrier.png)

## Full two-reactive bridge obstruction for the last pole pair

The remaining question for this pole-separated approach can actually be settled **negatively**, using the classical Reichert theorem and the exceptional-bridge conditions in the Ladenheim catalogue. Reichert's theorem states that a transformer-free biquadratic realization with two reactive elements and arbitrarily many resistors can always be reduced to at most three resistors. Among those five-element networks, the only nonregular realizations belong to the exceptional bridge class \(V_H\).

Write \(A=r_h\), \(B=r_hp_h+a_h\), \(C=r_hq_h+b_h\), \(D=1\), \(E=p_h\), \(F=q_h\). The established bridge criterion when \(\Delta=AF-CD>0\) requires \(\mu_1\ge0\) **and** that the signs of \(\lambda_1,\lambda_2,\rho_1\) are not all the same, apart from a degenerate all-zero case. Its invariants, defined in standard terms, are

\[
\begin{aligned}
K&=\Delta^2-(AE-BD)(BF-CE),\\
\rho_1&=-K+2CD\Delta,\\
\mu_1&=K-4CD(2AF-2CD-BE).
\end{aligned}
\]

For this exact pole pair, the formulas simplify to

\[
\boxed{K=b_h^2+a_h(a_hq_h-b_hp_h)>0,}
\]

\[
\boxed{\rho_1(r_h)=-K-2b_h(r_hq_h+b_h),}
\]

\[
\boxed{\mu_1(r_h)=K+4(r_hq_h+b_h)(2b_h+a_hp_h+r_hp_h^2).}
\]

The rational root isolation and outward-rounded interval calculations certify that

\[
\rho_1(13/10)<-0.0716,
\qquad \mu_1(13/10)<-2.1852,
\qquad \mu_1(3)<-6.1020.
\]

Moreover, \(\rho_1'(r_h)=-2b_hq_h>0\), so \(\rho_1<0\) for every \(r_h\le13/10\). We already proved \(\lambda_1<0\) and \(\lambda_2<0\) for every \(r_h\ge0\). Hence all three requisite signs agree throughout \([0,13/10]\), and the exceptional-bridge condition fails.

On \([13/10,3]\), \(\mu_1\) is a strictly convex quadratic with leading coefficient \(4q_hp_h^2>0\). A convex function lies at or below the chord between its endpoints, which are both strictly negative here. Thus \(\mu_1<0\) throughout \([13/10,3]\), again contradicting the exceptional-bridge condition. When the numerator constant \(r_hq_h+b_h\) is negative, the candidate is not even positive-real. At the zero boundary, its small-frequency real part is negative, independently excluding passivity.

**Certified obstruction.** For every \(0\le r_h\le3\), the last pole-pair impedance

\[
Z_{\rm high,r_h}(s)=r_h+\frac{a_hs+b_h}{s^2+p_hs+q_h}
\]

**cannot be realized by any transformer-free RLC network having only two reactive elements**, no matter how many resistors it uses. This is an application of a classical necessary-and-sufficient classification to one explicitly given algebraic family. It is not a newly discovered general theorem about biquadratics.

![Classical bridge-realizability invariants cover the entire physically possible constant allocation](figures/33_bridge_exclusion_full_budget.png)

Since \(Z_6(\infty)=3\), the nonnegative feedthrough allocations of three independently passive proper pole-pair subnetworks sum to three. Thus the high-pole section necessarily has \(r_h\in[0,3]\). The other two pole pairs require at least two reactive elements each by degree, while the last now requires at least three. Therefore:

\[
\boxed{\text{Every independently passive, three-pole-pair series realization requires at least 7 reactive elements.}}
\]

This is an **exact class-specific lower bound**. It does *not* establish a seven-reactive upper bound for this construction, nor does it rule out a completely different six-reactive-element network that couples the pole groups internally.

The criterion and Reichert reduction are documented in Alessandro Morelli's 2019 Cambridge thesis, Section 3.2 and Tables 5.9–5.10, building on Jiang and Smith's biquadratic synthesis classification. The inequalities are independently certified for our target in the supplementary script.

## Exact outcome and boundaries

| Question | Result |
|:--|:--|
| Construct the real-pole two-reactive section with strictly positive components | Proven for \(r\in[2.13,2.20]\) in the previous chapter |
| Construct the first nonreal pole-pair section with one L and one C | Proven by exact algebraic circuit identity and strict interval positivity |
| Construct a transformer-free four-reactive circuit for their series sum | Proven; its reactive order is minimal for that degree-four sum |
| Prove the remaining high-pole section positive-real throughout \(r_h\in[0.80,0.87]\) | Proven |
| Exclude two-reactive **series-parallel** realizations of the high-pole section | Proven via classical regularity inequalities |
| Construct or exclude a two-reactive bridge realization of the high-pole section for any passive allocation \(0\le r_h\le3\) | **Proved impossible** by the classical bridge criterion |
| Construct or exclude a six-reactive transformer-free network for \(Z_6\) **without** enforcing an independent pole-pair series split | **Unresolved** |

The reproducible Python script `smith_q6_double_extraction_certificate.py` checks the new symbolic identity and the outward-rounded algebraic inequalities. It is independent of the earlier 86-check extraction-family certificate. The four new figures and circuit schematic were made with Python/Matplotlib.

The literature comparison materially limits novelty claims. Existing necessary and sufficient criteria for two-reactive transformer-free synthesis predate this calculation; see Jiang and Smith, *Regular positive-real functions and five-element network synthesis* (IEEE Transactions on Automatic Control, 2011), DOI [10.1109/TAC.2010.2077810](https://doi.org/10.1109/TAC.2010.2077810), and Morelli, *Synthesis of electrical and mechanical networks of restricted complexity* (2019), available from [Cambridge University Repository](https://api.repository.cam.ac.uk/server/api/core/bitstreams/0008b1b9-9d58-4813-8e97-1db41532cc8c/content). The exact polynomial and its matching circuit values have not been found in the targeted references, but **publication priority is not established**.

**Next decisive step:** abandon independent pole-by-pole series synthesis at six reactive elements and instead solve the coupled six-state nodal cofactor equations. Any exact six-reactive transformer-free realization must mix the pole contributions in its internal circuit topology. The previous 168 five-node graph classes remain candidates, not proofs.
