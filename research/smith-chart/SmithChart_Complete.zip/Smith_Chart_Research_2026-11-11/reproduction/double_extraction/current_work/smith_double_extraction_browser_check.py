"""Offline browser render checks of newest unpublished edition. Author: Komorebi P."""
import json,sys
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path('/mnt/data/smith_revision')
html=(ROOT/'Smith_Chart_Extended_Double_Extraction.html').read_text()
widths=[int(x) for x in (sys.argv[1].split(',') if len(sys.argv)>1 else ['390'])]
results=[]
with sync_playwright() as pw:
 browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage','--disable-gpu'])
 for width in widths:
  page=browser.new_page(viewport={'width':width,'height':900},device_scale_factor=1)
  errs=[];page.on('pageerror',lambda e:errs.append(str(e)))
  page.set_content(html,wait_until='domcontentloaded',timeout=45000)
  page.wait_for_function('window.MathJax && MathJax.startup && MathJax.startup.promise',timeout=30000)
  page.evaluate('() => MathJax.startup.promise')
  page.evaluate("() => [...document.querySelectorAll('img')].forEach(im=>im.loading='eager')")
  page.wait_for_function("() => [...document.querySelectorAll('img')].every(im=>im.complete&&im.naturalWidth>0)",timeout=20000)
  d=page.evaluate('''() => {
    let root=document.getElementById('a-second-exact-rlc-extraction-and-the-nonregular-pole-pair-barrier');
    let elems=[...document.querySelectorAll('[data-newmath]')], imgs=[...document.querySelectorAll('img[data-source-file^="figures/"]')],tables=[...document.querySelectorAll('.table-wrap table')];
    let unlinked=[...document.querySelectorAll('a[href^="#"]')].filter(a=>!document.getElementById(decodeURIComponent(a.hash.slice(1)))).map(a=>a.hash).slice(0,8);
    return {new_section:!!root,docwidth:document.documentElement.scrollWidth,viewportwidth:document.documentElement.clientWidth,
     new_math:elems.length,new_math_rendered:elems.filter(el=>!!el.querySelector('mjx-container')).length,
     math_errors:document.querySelectorAll('mjx-merror').length,
     figures:imgs.length,figures_good:imgs.filter(im=>im.complete&&im.naturalWidth>0).length,
     tables:tables.length, table_rows_unlabeled:tables.flatMap(t=>[...t.querySelectorAll('tbody tr')].filter(tr=>[...tr.cells].some(td=>!td.hasAttribute('data-label')))).length,
     missing_links:unlinked,
     new_section_display:root?.getBoundingClientRect().width
    };
  }''')
  d['width']=width;d['errors']=errs
  print(json.dumps(d,indent=2),flush=True)
  if width in (390,1440):
   page.locator('#a-second-exact-rlc-extraction-and-the-nonregular-pole-pair-barrier').screenshot(path=str(ROOT/f'Smith_Double_Extraction_Section_{width}.png'),timeout=30000)
  results.append(d);page.close()
 browser.close()
assert all(d['new_section'] and d['docwidth']<=d['viewportwidth']+1 and d['new_math']==d['new_math_rendered'] and d['math_errors']==0 and d['figures']==d['figures_good']==33 and d['tables']>=17 and d['table_rows_unlabeled']==0 and not d['missing_links'] and not d['errors'] for d in results), 'browser check failure'
print('SUCCESS: Browser responsive checks pass')
(ROOT/'Smith_Double_Extraction_Browser_Results.json').write_text(json.dumps(results,indent=2))
