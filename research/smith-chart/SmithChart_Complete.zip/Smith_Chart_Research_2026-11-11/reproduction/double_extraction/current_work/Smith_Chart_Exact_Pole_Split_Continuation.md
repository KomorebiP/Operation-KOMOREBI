# Exact pole-pair splitting and a continuous transformer-free extraction family

**Author: Komorebi P.**  
**Research status:** Unpublished, 9 November 2026.  
**Scope:** A mathematically certified reduction of the degree-six transformer-free circuit synthesis question, not its complete resolution. All figures are generated in Python.

## The original degree-six synthesis target

The target of the preceding Smith chart investigation is

\[
Z_6(s)=\frac{450s^6+1385s^5+2477s^4+2200s^3+1142s^2+335s+75}{5(30s^6+159s^5+275s^4+344s^3+250s^2+89s+5)}.
\]

The numerator and denominator are relatively prime. Its McMillan degree is six and any conventional lumped RLC one-port therefore requires at least six independent reactive states. Earlier work gave a six-reactive realization with an ideal transformer-based combiner, but **not** an exact transformer-free six-reactive network.

## A real pole-pair decomposition

Let \(P\) and \(D\) denote the numerator and full denominator above. The polynomial \(D\) has exactly two distinct negative real roots \(\alpha<\beta<0\) and two nonreal complex-conjugate pairs. All are simple.

Define the residues

\[
A=\frac{P(\alpha)}{D'(\alpha)},\qquad B=\frac{P(\beta)}{D'(\beta)},
\]

and the real quadratic and numerator coefficients

\[
p=-(\alpha+\beta),\quad q=\alpha\beta,\quad a=A+B,\quad b=-(A\beta+B\alpha).
\]

Then for any real \(r\), the real-pole section is defined **exactly** by

\[
\boxed{Z_{2,r}(s)=r+\frac{as+b}{s^2+ps+q}.}
\]

The remaining section \(Z_{4,r}=Z_6-Z_{2,r}\) has degree exactly four, with poles equal to the two retained complex-conjugate pairs. The identity is exact by partial fractions, since \(Z_6(\infty)=3\). The coefficients, displayed solely for orientation, are

| Real-pole section parameter | Approximate value |
|:--|--:|
| \(p\) | 3.47701199106231 |
| \(q\) | 0.231896402301099 |
| \(a\) | −7.34939470450779 |
| \(b\) | 0.139256919027936 |

No rounded coefficient is used to define the circuit in the proof.

![Exact pole groups, generated using Python and Matplotlib](figures/28_pole_pair_split.png)

## Proving that the fourth-order remainder is passive

For any real quadratic section

\[
T(s)=r+\frac{as+b}{s^2+ps+q},\qquad p,q,r>0,
\]

set \(u=\omega^2\). Direct calculation gives

\[
\operatorname{Re}T(i\omega)
=\frac{ru^2+Mu+C}{(q-u)^2+p^2u},
\]

where

\[
M=r(p^2-2q)+ap-b,\qquad C=q(rq+b).
\]

Thus \(C>0\) and either \(M\geq0\) or \(4rC-M^2>0\) (when \(M<0\)) certify strict boundary positive-realness. Because all poles lie in the open left half-plane, the maximum/minimum principle then establishes positive-realness throughout \(\operatorname{Re}s>0\).

The two conjugate-pole sections have exact coefficients obtained from their algebraic pole residues. Give the first the constant \(r_1=1/20\), and the second \(r_2=59/20-r\). Their constants sum to \(3-r\). For all

\[
\boxed{\frac{213}{100}\leq r\leq \frac{11}{5}},
\]

we have \(r_2\geq3/4\). The certificate script verifies that the first section is positive-real at \(r_1=1/20\), and the second at \(r_2=3/4\). Increasing the second constant cannot invalidate passivity. Therefore **\(Z_{4,r}\) is positive-real throughout the whole displayed interval**.

The high-frequency constant of \(Z_{4,r}\) is \(3-r\). In the illustrative case \(r=11/5\) it is \(4/5\). No transformer-free four-reactive realization is claimed here.

![Positive-real boundary traces for the two sections, generated using Python](figures/29_passive_split_frequency.png)

## Exact transformer-free synthesis of the two-reactive section

Consider a three-node circuit with port node 1, internal node 2, and ground node 0. There is a resistor of conductance \(G\) directly between port and ground, a resistor of conductance \(A_c\) in parallel with an inductor between nodes 1 and 2, and a resistor of conductance \(B_c\) in parallel with a capacitor between nodes 2 and 0. Write the inductor's admittance as \(\ell/s\) and the capacitor's as \(cs\). All five parameters \(G,A_c,B_c,\ell,c\) must be positive.

Its exact driving-point impedance, calculated by series/parallel reduction or a nodal cofactor, is

\[
Z_{\triangle}(s)=
\frac{cs^2+(A_c+B_c)s+\ell}
{c(G+A_c)s^2+[G(A_c+B_c)+A_cB_c+\ell c]s+\ell(G+B_c)}.
\]

Define the following positive quantities from \(p,q,a,b,r\):

\[
k=\frac1r,\qquad h=\frac1{r+b/q},\qquad
T=p+\frac ar,\qquad W=q+\frac br.
\]

For any \(G\) satisfying

\[
\boxed{
E(G)=kpT(k+h-2G)-(kh-G^2)T^2-W(k+h-2G)^2=0,
}
\]

set

\[
\boxed{
A_c=k-G,\quad B_c=h-G,\quad
c=\frac{k+h-2G}{T},\quad \ell=cW.
}
\]

Matching the coefficient of \(s^2\), then the constant coefficient, and finally the coefficient of \(s\), proves identically that \(Z_{\triangle}=Z_{2,r}\). In other words, \(E(G)=0\) is not an approximate fitting condition: it is exactly the remaining nodal polynomial identity.

**Theorem (uniform positive extraction).** For every real \(r\in[213/100,11/5]\), there exists a \(G\) strictly between 0 and \(h\) satisfying \(E(G)=0\). The above expressions then give a positive, transformer-free network with one inductor and one capacitor, realizing \(Z_{2,r}\) exactly. Moreover, \(Z_{4,r}=Z_6-Z_{2,r}\) remains positive-real and has degree four.

**Proof.** With the coefficients \(p,q,a,b\) defined by the exact algebraic poles, rational root isolation and interval arithmetic establish \(k>h>0\), \(T>0\), \(W>0\), and

\[
\boxed{E(0)<0<E(h)}
\]

uniformly for \(r\in[213/100,11/5]\). In the reproducible certificate, the \(0.07\)-wide interval is divided into 70 exact rational subintervals of width \(1/1000\). Every outward-rounded enclosure certifies those strict signs and the necessary positivity conditions. In particular, the largest interval upper bound recorded for \(E(0)\) is below \(-0.0223\), and the smallest lower bound for \(E(h)\) exceeds \(0.00127\). Continuity supplies a root in \((0,h)\) by the intermediate value theorem. The component formulas are positive on this open interval. Their symbolic coefficient matching proves the exact circuit identity. The preceding positive-real certificate proves the statement about the remainder. ∎

The degree-two section has two distinct uncancelled poles and therefore **cannot** be realized with fewer than two reactive elements. The constructed two-reactive network is minimum in that precise sense.

![Python-drawn exact transformer-free RLC topology](figures/27_exact_two_state_triangle.png)

### A concrete component certificate at \(r=11/5\)

A rational isolating bracket for the positive algebraic root is

\[
\boxed{\frac{4777}{100000}<G<\frac{4778}{100000}.}
\]

The exact interval evaluation shows \(E(4777/100000)<0\) and \(E(4778/100000)>0\). The resulting approximate normalized components are shown below. Exact values are defined by the preceding algebraic equations, not by these rounded numbers.

| Branch or element | Exact definition | Approximate normalized value |
|:--|:--|--:|
| Direct port-to-ground resistor | \(1/G\) | 20.93331601 |
| Port-to-internal-node resistor | \(1/(k-G)\) | 2.45836323 |
| Internal-node-to-ground resistor | \(1/(h-G)\) | 3.23303769 |
| Inductor between port and internal node | \(1/(cW)\) | 0.64516837 |
| Capacitor between internal node and ground | \(c\) | 5.25070881 |

In one physical scaling with \(Z_0=50\,\Omega\), \(\tau=1\,\mathrm{ns}\), normalized values give resistances multiplied by \(50\,\Omega\), inductance multiplied by \(Z_0\tau=50\,\mathrm{nH}\), and capacitance multiplied by \(\tau/Z_0=20\,\mathrm{pF}\). All elements are strictly passive and finite.

## What is now closed and what remains open

| Scope | Status |
|:--|:--|
| Decompose \(Z_6\) into a degree-two and degree-four section, each positive-real for every \(r\) in a continuous interval | **Proved** |
| Give a minimum-two-reactive, transformer-free RLC circuit for the degree-two section over the interval | **Proved constructively** |
| Give a transformer-free four-reactive RLC circuit for the remainder \(Z_{4,r}\) for at least one allowed \(r\) | **Open in this work** |
| Conclude a six-reactive, transformer-free realization of the original degree-six target | **Not yet proved** |
| Establish that the general technique or these instances have research publication priority | **Not established** |

The latest numerical fourth-order topology search did **not** obtain an exact residual identity. Its best recorded maximum scaled discrepancy was about \(6.3\times10^{-4}\) at \(r=2.15\) in one exploratory run. This is not a nonexistence proof and is intentionally excluded from theorem statements.

The most useful next calculation is to solve the four-reactive nodal cofactor equations for \(Z_{4,r}\) **with \(r\) left as a tunable real parameter in the certified interval**, rather than fixing \(r\) before searching. The one-parameter freedom offers additional room for a positive network solution without sacrificing exactness of the first section.

## Verification and literature boundaries

The provided program `smith_q6_pole_split_certificate.py` uses SymPy's exact real/complex root isolation and outward-rounded `mpmath.iv` interval evaluation. It checks the algebraic pole allocation, positive-real quadratic tests, and the triangle's sign-changing polynomial equation, including 70 interval subproofs of the uniform theorem. The figure generator uses only NumPy and Matplotlib.

The method builds on classical network synthesis, positive-real functions, partial fractions, rational root isolation, and low-order RLC realizability. The particular construction and interval family are derived here, but originality compared with the complete literature has not been established. Relevant known results include the synthesis criteria of Chen and Smith for one-inductor/one-capacitor realizations (see the discussion in [Synthesis of biquadratic impedances with at most four passive elements](https://www.sciencedirect.com/science/article/abs/pii/S0016003213003852)), and Hughes' [transformer-free network synthesis thesis](https://www.repository.cam.ac.uk/items/0db868a3-5c51-4e0f-98ac-ae821db31fdc).

**Boundary:** No new general RLC realization theorem, no universal circuit-order minimization theorem, no proof of transformer-free six-reactive feasibility, and no SPICE or hardware validation is claimed.
