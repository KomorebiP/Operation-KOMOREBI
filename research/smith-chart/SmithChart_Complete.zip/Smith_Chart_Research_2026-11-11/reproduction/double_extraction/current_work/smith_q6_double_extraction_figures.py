#!/usr/bin/env python3
"""Python-only figures for the second algebraically exact RLC extraction. Author: Komorebi P."""
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Circle, Arc, FancyBboxPatch
from matplotlib.colors import to_rgb
ROOT=Path(__file__).resolve().parent/'figures';ROOT.mkdir(exist_ok=True)
INK='#233930';GREEN='#2b6655';BLUE='#376d9c';GOLD='#b48740';RED='#9f594f';PAPER='#fffefb';MUTED='#54685f'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'figure.facecolor':PAPER,'axes.facecolor':PAPER,'savefig.facecolor':PAPER})
# Exact 1 L 1 C network drawing. node1 is input top, node2 internal right, node0 bottom.
fig,ax=plt.subplots(figsize=(10.2,6.2));ax.axis('off');ax.set(xlim=(-1,10),ylim=(-1.1,5.3));ax.set_aspect('equal')
def line(x1,y1,x2,y2,width=2):ax.plot([x1,x2],[y1,y2],color=INK,lw=width,solid_capstyle='round',zorder=2)
def node(x,y):ax.add_patch(Circle((x,y),.07,fc=GREEN,ec=GREEN,zorder=7))
def res_h(x1,x2,y,label):
 mid=(x1+x2)/2;d=.38;line(x1,y,mid-d,y);line(mid+d,y,x2,y);ax.add_patch(Rectangle((mid-d,y-.17),2*d,.34,fc='#f0e9d9',ec=INK,lw=1.8,zorder=4));ax.text(mid,y+.4,label,ha='center',va='center',fontsize=10,color=INK)
def res_v(x,y1,y2,label,side=-1):
 mid=(y1+y2)/2;d=.35;line(x,y1,x,mid+d);line(x,mid-d,x,y2);ax.add_patch(Rectangle((x-.17,mid-d),.34,2*d,fc='#f0e9d9',ec=INK,lw=1.8,zorder=4));ax.text(x+side*.45,mid,label,ha='right' if side<0 else 'left',va='center',fontsize=10,color=INK)
def cap_v(x,y1,y2,label):
 mid=(y1+y2)/2;line(x,y1,x,mid+.12);line(x,mid-.12,x,y2);line(x-.24,mid+.12,x+.24,mid+.12,2.3);line(x-.24,mid-.12,x+.24,mid-.12,2.3);ax.text(x+.45,mid,label,ha='left',va='center',fontsize=10,color=BLUE)
def coil_v(x,y1,y2,label):
 mid=(y1+y2)/2;d=.63;line(x,y1,x,mid+d);line(x,mid-d,x,y2)
 for v in np.linspace(mid-d+.095,mid+d-.095,5):ax.add_patch(Arc((x+.13,v),.28,.24,theta1=80,theta2=280,ec=INK,lw=2))
 ax.text(x+.38,mid,label,ha='left',va='center',fontsize=10,color=GREEN)
# port & series middle network
line(0,4.2,2.5,4.2);line(2.5,4.2,5.15,4.2);line(5.15,4.2,7.5,4.2)
res_h(2.6,5.0,4.2,'R_A')
# top loop actual connection port1 -> Res A -> node2
line(0,0,7.5,0);line(7.5,4.2,7.5,0)
# G and capacitor from port node to ground: branches are at x 1.35 and x 2.35, but bypass resistor A top edge starts 2.6; need port rail to branches.
# correct visual: port rail from (0,4.2) to (2.5,4.2); R_A between 2.6..5.0; node2 rail from 5.15..7.5
# Direct G resistor and C connect port rail to ground rail left of R_A.
res_v(1.1,4.2,0,'R_G',side=-1)
cap_v(2.1,4.2,0,'C')
# internal node2 -> ground: resistor and inductor
res_v(6.1,4.2,0,'R_B',side=-1)
coil_v(7.5,4.2,0,'L')
for x,y,lab in [(0,4.2,'Input (1)'),(5.15,4.2,'Internal (2)'),(0,0,'Return (0)'),(7.5,0,'Ground (0)')]:
 node(x,y);ax.text(x+.12,y+.23,lab,fontsize=9,color=GREEN,fontweight='bold')
ax.set_xlim(-2.2,10.8)
fig.suptitle('Exact transformer-free circuit for the complex pole pair',fontsize=16,color=INK,x=.51,y=.97)
ax.text(3.8,4.93,'One inductor · one capacitor · three resistors · no ideal transformer',ha='center',fontsize=10,color=MUTED)
ax.text(4,-.75,'R_G=1   R_A≈0.09556   R_B≈0.05027   L≈0.075328   C≈9.50264  (normalized)',ha='center',color=MUTED,fontsize=8.8)
fig.savefig(ROOT/'30_middle_pole_rlc_triangle.png',dpi=190,bbox_inches='tight');fig.savefig(ROOT/'30_middle_pole_rlc_triangle.svg',bbox_inches='tight');plt.close(fig)
# composition overview
fig,ax=plt.subplots(figsize=(12.8,3.35));ax.set(xlim=(0,13.5),ylim=(0,3.3));ax.axis('off')
labels=[('Real pole pair','Exact 1L + 1C',GREEN),('Lower complex pair','Exact 1L + 1C',BLUE),('Upper complex pair','PR, nonregular',GOLD)]
for j,(name,claim,color) in enumerate(labels):
 x=.23+j*4.33
 bx=FancyBboxPatch((x,.76), (3.7 if j<2 else 3.9),1.95,boxstyle='round,pad=.1,rounding_size=.18',fc='#faf9f4',ec=color,lw=2.2)
 ax.add_patch(bx)
 ax.text(x+.19,2.24,name,color=INK,fontweight='bold',fontsize=13)
 ax.text(x+.19,1.72,claim,color=color,fontsize=11,fontweight='bold')
 ax.text(x+.19,1.25,'3 positive resistors' if j<2 else 'Bridge feasibility open',color=MUTED,fontsize=10)
 if j<2:ax.text(x+3.84,1.65,'+',color=INK,fontsize=20,fontweight='bold')
ax.text(6.45,.17,'The complete six-reactive transformer-free circuit is not established.',ha='center',fontsize=10,color=RED)
fig.suptitle('Exact pole-pair splitting: two circuits solved, one outstanding',fontsize=16,color=INK,y=.99)
fig.savefig(ROOT/'31_series_split_status.png',dpi=180,bbox_inches='tight');fig.savefig(ROOT/'31_series_split_status.svg',bbox_inches='tight');plt.close(fig)
# Regularity test on high pair for all positive feedthrough values.
p=.5588166853703168153;q=1.3621478392757889;a=.5774941298606671;b=-.9367979985749979
r=np.linspace(.7,1.15,500)
l1=p*(a*q-b*p)+q*b
l2=r*(b-a*p)-a*a
fig,ax=plt.subplots(figsize=(9.2,4.75))
ax.plot(r,r*0+l1,color=GREEN,lw=2.5,label=r'$\lambda_1<0$ for all $r\geq0$')
ax.plot(r,l2,color=BLUE,lw=2.5,label=r'$\lambda_2=r(b-ap)-a^2<0$')
ax.axhline(0,color=RED,lw=1.7,ls='--',label='Regularity threshold')
ax.axvspan(.8,.87,fc=GOLD,alpha=.14,label='Certified split interval')
ax.set(xlabel='Constant resistance allocated to last pole pair',ylabel='Classical regularity inequality',title='A nonregular positive-real biquadratic')
ax.grid(alpha=.16);ax.legend(frameon=False,loc='lower left',fontsize=9)
fig.tight_layout();fig.savefig(ROOT/'32_high_pair_regularity_barrier.png',dpi=190);fig.savefig(ROOT/'32_high_pair_regularity_barrier.svg');plt.close(fig)
print('Python generated three new PNG and SVG figures.')
# New 2026-11-09: rigorous domain-cover obstruction to exceptional VH bridges.
r=np.linspace(.68,3,550)
K=b*b+a*(a*q-b*p)
mu=K+4*(r*q+b)*(2*b+a*p+r*p*p)
rho=-K-2*b*(r*q+b)
fig,ax=plt.subplots(figsize=(10.1,5.2))
ax.axhline(0,color=RED,ls='--',lw=1.5)
ax.axvspan(.68,1.3,color=BLUE,alpha=.075)
ax.axvspan(1.3,3,color=GOLD,alpha=.08)
ax.plot(r,rho,color=BLUE,lw=2.5,label=r'$\rho_1(r)$ — negative up to $r=1.3$')
ax.plot(r,mu,color=GREEN,lw=2.5,label=r'$\mu_1(r)$ — negative for $1.3\leq r\leq3$')
ax.axvline(1.3,color=INK,alpha=.7,lw=1.25,ls=':')
ax.text(.75,6.2,'Bridge fails\nfrom three negative signs',color=BLUE,fontsize=10,fontweight='bold',ha='left')
ax.text(1.45,6.2,'Bridge fails\nbecause $\mu_1<0$',color=GREEN,fontsize=10,fontweight='bold',ha='left')
ax.plot([1.3,3],[-2.185255660068,-6.102031184545],linestyle='none',marker='o',ms=6,color=GREEN)
ax.set_xlim(.68,3);ax.set_ylim(-8,9)
ax.set(xlabel=r'Nonnegative high-pole constant allocation $r_h$',ylabel='Classical five-element synthesis invariant',title='All passive three-pole-pair allocations exclude a two-reactive bridge')
ax.grid(alpha=.15)
ax.legend(frameon=False,loc='upper left',bbox_to_anchor=(0,0.18),fontsize=9)
fig.tight_layout();fig.savefig(ROOT/'33_bridge_exclusion_full_budget.png',dpi=190);fig.savefig(ROOT/'33_bridge_exclusion_full_budget.svg');plt.close(fig)
print('Generated exact-bridge-obstruction diagnostic figure (qualitative display).')
