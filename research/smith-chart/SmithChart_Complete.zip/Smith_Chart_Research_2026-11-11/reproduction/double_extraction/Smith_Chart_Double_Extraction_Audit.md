# Smith chart: exact double extraction and bridge obstruction audit

Author: Komorebi P.  
Date: 2026-11-09  
Status: Unpublished. No changes to public GitHub or .io.

## Mathematical outcomes

1. Given the specific degree-six positive-real target in the integrated manuscript, the real-pole quadratic has an exact transformer-free 1L+1C circuit for all extraction constants r in [213/100, 11/5]. The original extraction-family certificate isolates the circuit's positive algebraic conductance root and verifies the complementary positive-real remainder by interval methods.
2. The lower-frequency nonreal pole pair admits a second exact 1L+1C transformer-free circuit. All five component values have explicit algebraic formulas in the exact quadratic numerator/denominator coefficients. A wholly symbolic SymPy computation verifies the circuit identity for arbitrary nondegenerate formal coefficients; outward-rounded enclosures establish all component values strictly positive for the given algebraic pole pair.
3. The high-frequency nonreal pole pair, when assigned nonnegative high-frequency resistance r_h, fails the classic regularity test for all such r_h, whenever positive-real.
4. A sharper two-reactive obstruction applies **throughout the available budget 0 <= r_h <= 3**. For r_h <= 13/10 the three required bridge signs lambda1, lambda2, rho1 are all negative whenever the function is positive-real, and for 13/10 <= r_h <= 3 the bridge invariant mu1 is strictly negative. Positive root isolation confirms all requisite strict inequalities. The argument uses Reichert's reduction to a 3-resistor circuit and the classical Ladenheim V_H criterion; **these are not novel general theorems**.
5. Accordingly, any independently passive, pole-separating series construction of the target requires at least 2+2+3=7 reactive elements. **This is NOT a seven-reactive construction or a no-go theorem for a coupled six-reactive RLC network.** The general six-reactive transformer-free case remains undecided.

## Independent verification

- `current_work/smith_q6_pole_split_certificate.py`: **86/86** exact/interval checks passed.
- `current_work/smith_q6_double_extraction_certificate.py`: **37/37** exact/interval checks passed; includes symbolic nodal identity, middle-section passivity, and full-budget exceptional-bridge exclusion.
- Browser rendering: Chromium/Playwright checks passed at **320, 390, 768, and 1440 px**. All **33** embedded figures rendered, all **17** tables received cell labels, and **193** new mathematics expressions (across the two newest sections) rendered without MathJax error. No page-wide horizontal overflow, reported JavaScript page error, or broken section anchor.
- The HTML includes vector illustrations embedded as data URIs, generated with Matplotlib. No AI image generation was used.
- No external circuit simulator or hardware was tested. The exact circuit identities do not rely on a SPICE fit.
- An attempted automated screenshot of the cited PDF source was blocked by the provider. The bridge condition and Reichert statement were checked against the indexed text of the Morelli thesis, especially Table 5.9 and Table 5.10; a manual publisher-PDF proofread of the sign-convention transcription remains prudent before public submission.

## Classical sources relevant to originality

- Alessandro Morelli, *Synthesis of electrical and mechanical networks of restricted complexity*, University of Cambridge doctoral thesis, 2019, Sections 3.2 and 5.5, Tables 5.9 and 5.10. https://api.repository.cam.ac.uk/server/api/core/bitstreams/0008b1b9-9d58-4813-8e97-1db41532cc8c/content
- Jason Zheng Jiang and Malcolm C. Smith, *Regular positive-real functions and five-element network synthesis for electrical and mechanical networks*, IEEE Transactions on Automatic Control, 56(6), 1275–1290, 2011. DOI: 10.1109/TAC.2010.2077810
- Kai Wang, Michael Z. Q. Chen and Yinlong Hu, *Synthesis of Biquadratic Impedances with At Most Four Passive Elements*, 2014: https://hub.hku.hk/bitstream/10722/200660/1/Content.pdf

## Remaining work

- The complete target's degree is six; a single mixed-mode network with three inductors and three capacitors might exist despite the failure of independent pole-pair series synthesis. The current exact obstruction does not decide that.
- Test exact nodal cofactor identities on the surviving five-node and higher-node 3L+3C network topologies, using positive-value real algebraic feasibility. A verified exact feasible witness or a complete infeasibility certificate is still missing.
- Existing symbolic identities and example-specific certificates are not, by themselves, evidence of priority or field-wide novelty. The distinct contribution, if any, must be established against the full synthesis literature and demonstrated beyond an isolated example.
