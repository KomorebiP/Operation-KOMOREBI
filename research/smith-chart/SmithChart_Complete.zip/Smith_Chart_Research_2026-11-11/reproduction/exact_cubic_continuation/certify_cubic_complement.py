#!/usr/bin/env python3
"""Exact rational positivity certificate for remaining cubic positive-real summand.
Author: Komorebi P. Independent of numerical frequency sampling."""
from fractions import Fraction as F
import sympy as sp,json,math
from pathlib import Path
p=Path(__file__).resolve().parent
data=json.loads((p/'cubic_solution_approx.json').read_text())
x0=[F(v) for v in data['approximations_65digits']]
r=F(1,10**23)
b0,b1,b2=x0[3:6];v0,v1,v2=x0[9:12]
# Define symbolic exact cubic numerator Re((4/5 B+V) B_conj) along s=iω.
B0,B1,B2,V0,V1,V2=sp.symbols('B0 B1 B2 V0 V1 V2')
X=sp.symbols('X');rb=sp.Rational(4,5)
Be=B0-B2*X;Bo=B1-X;Ne=rb*Be+V0-V2*X;No=rb*Bo+V1
pr=sp.Poly(sp.expand(Ne*Be+X*No*Bo),X)
vals=dict(zip([B0,B1,B2,V0,V1,V2],[b0,b1,b2,v0,v1,v2]))
allvars=[B0,B1,B2,V0,V1,V2];mins=[];maxs=[]
for i in range(4):
 expr=pr.nth(i)
 val=F(str(expr.subs({y:sp.Rational(v.numerator,v.denominator) for y,v in vals.items()}))) if False else None
 # exact rational eval
 for y,v in vals.items():expr=expr.subs(y,sp.Rational(v.numerator,v.denominator))
 value=F(int(expr.p),int(expr.q))
 # conservative exact derivative bound over cube, using integer max modulus M_j.
 poly=sp.Poly(pr.nth(i),*allvars,domain='QQ');mi=[math.ceil(abs(vals[t]))+1 for t in allvars];g=F(0)
 for ex,co in poly.terms():
  co=F(int(co.p),int(co.q))
  for k,e in enumerate(ex):
   if e==0:continue
   term=abs(co)*e
   for j,pow in enumerate(ex):
    h=pow-(k==j)
    if h>0:term*=mi[j]**h
   g+=term
 lower=value-g*r; upper=value+g*r
 mins.append(lower);maxs.append(upper)
 print('c',i,'center',float(value),'rigorous enclosure ±',float(g*r))
assert mins[0]>F(25,1000)
assert mins[1]>F(173,1000)
assert mins[2]>-F(654,1000)
assert mins[3]>F(799,1000)
assert 4*F(173,1000)*F(799,1000) > F(654,1000)**2
# cubic denominator B(s) is Hurwitz by exact intervals, and B0,B1,B2 positive.
assert b0-r>F(92,1000)
assert b1-r>F(1400,1000)
assert b2-r>F(626,1000)
assert (b1-r)*(b2-r)>(b0+r)
print('STRICT POSITIVE-REAL COMPLEMENT CERTIFICATE PASSED')
print('minimum SOS linear coeff',float(F(173,1000)-F(654,1000)**2/(4*F(799,1000))))
(p/'cubic_complement_PR_certificate.json').write_text(json.dumps({'status':'proved positive real by rational coefficient bounds and Hurwitz cubic',
 'coefficient_intervals':[[str(a),str(b)] for a,b in zip(mins,maxs)],'SOS_lower_polynomial': '799/1000 * x *(x-654/1598)^2 + (173/1000 - (654/1000)^2/(4*799/1000)) * x + 25/1000',
 'strictly_positive':True},indent=2))
