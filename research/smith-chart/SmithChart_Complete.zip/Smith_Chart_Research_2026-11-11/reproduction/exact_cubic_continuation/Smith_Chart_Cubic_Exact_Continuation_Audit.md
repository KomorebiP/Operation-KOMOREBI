# Smith chart cubic continuation: verification audit

**Author:** Komorebi P.  
**Date:** November 9, 2026  
**Publication:** Unpublished; public GitHub/.io untouched.

## Exactly certified

1. A 19-variable, 19-equation polynomial system with rational coefficients encodes the two cubic denominator factors, the proper partial-fraction split and the seven-component RLC circuit identity.
2. An exact rational contraction bound with radius `1/10^23` proves that the system has a unique real zero in the specified box. All seven component parameters remain strictly positive; the circuit has minimum reactive order three for the chosen cubic.
3. The other cubic has a Hurwitz denominator and strictly positive boundary real part, certified by rational coefficient inequalities and a sum-of-squares lower polynomial.
4. The full target decomposes exactly as the sum of these two cubic positive-real impedances.

## Numerical only

A two-L/two-C, five-node circuit for the complementary cubic attained sampled scaled error approximately 1.54e-12; a fixed-coordinate high-precision algebraic fit attained polynomial residual approximately 2.33e-58. The active Jacobian was essentially singular, condition number ~4.4e33. **This does not certify exact seven-reactive realizability.** No six-reactive transformer-free existence or impossibility result follows.

## Reproduction

Run `python solve_cubic_exact.py`, `python certify_cubic.py`, `python certify_cubic_complement.py`, and `python make_cubic_figures.py` with Python, SymPy, mpmath, NumPy, SciPy and Matplotlib. `certify_cubic.py` uses exact Python Fractions for every inequality on which the contraction proof relies. It is not a finite frequency sweep. The graphical files are made only with Python.

## Novelty and limitations

These statements are algebraic and exact for a specific rational impedance. The general ideas of positive-real synthesis, cubic realization, and quantitative fixed-point certification are established. No novelty relative to the full RLC synthesis literature, practical SPICE correspondence, component-tolerance robustness, or hardware validation is claimed. The main unresolved target is exact six-reactive transformer-free synthesis of the original degree-six impedance.

## Browser and packaging QA

The first integrated mobile preview failed at 320 and 390 px because the new coefficient and component tables each had an intrinsic width near 520 px. Their mobile presentation was changed to responsive labeled rows, and the complete offline edition was rebuilt. Final Chromium checks passed at 320, 390, 768 and 1440 px with 1,370 rendered MathJax containers, 38 loaded figures, 19 responsive tables, zero MathJax errors, zero reported JavaScript errors, no broken fragment links, and no root-level horizontal overflow. These checks use Chromium's `page.set_content` on local HTML bytes and do not test remote deployment.

The two core exact certificates were also rerun from the portable source directory after path normalization. Both passed. The final research archive includes those proof inputs as well as the numerically fitted, but **uncertified**, four-reactive candidate. The public site remains untouched.
