from mpmath import mp
import sympy as sp
from pathlib import Path
import json
BASE=Path(__file__).resolve().parent
mp.dps=75
s=sp.symbols('s'); xx=sp.symbols('a0 a1 a2 b0 b1 b2 x0 x1 x2 y0 y1 y2 gA gB gC gD hL1 hL2 hC')
AA=s**3+xx[2]*s**2+xx[1]*s+xx[0];BB=s**3+xx[5]*s**2+xx[4]*s+xx[3];UU=xx[8]*s**2+xx[7]*s+xx[6]; VV=xx[11]*s**2+xx[10]*s+xx[9]
a,b,c,d,u,v,w=xx[12:]
Nnet=w*(a+c+d)*s**3+(a*b+a*d+b*c+b*d+c*d+v*w)*s**2+(a*u+b*v+c*u+d*u+d*v)*s+u*v
Dnet=w*(a*b+a*c+a*d+b*c+b*d)*s**3+(a*b*c+a*c*d+a*u*w+a*v*w+b*c*d+b*v*w+c*u*w+d*u*w)*s**2+(a*b*v+a*c*u+a*d*v+b*d*v+c*d*u+u*v*w)*s+u*v*(a+d)
P=450*s**6+1385*s**5+2477*s**4+2200*s**3+1142*s**2+335*s+75
Q=150*s**6+795*s**5+1375*s**4+1720*s**3+1250*s**2+445*s+25
H=sp.expand((P-3*Q)/150);r=sp.Rational(11,5)
F=[]
for i in range(6):F.append(sp.expand(AA*BB-Q/150).coeff(s,i))
for i in range(6):F.append(sp.expand(UU*BB+VV*AA-H).coeff(s,i))
for i in range(7):F.append(sp.expand(Nnet*AA-Dnet*(r*AA+UU)).coeff(s,i))
assert len(F)==19
roots=[mp.mpc(str(sp.re(z)),str(sp.im(z))) for z in sp.nroots(Q,n=68,maxsteps=300)]
pr=sorted(roots,key=lambda z:z.real);print('roots',*[mp.nstr(t,16) for t in pr]);
low=[z for z in roots if mp.mpf('0.1')<abs(z.imag)<mp.mpf('0.7')]
hi=[z for z in roots if abs(z.imag)>1]
fast=min(roots,key=lambda z:z.real);slow=max(roots,key=lambda z:z.real)
def conv(x,y):
 r=[mp.mpf(0)]*(len(x)+len(y)-1)
 for i,v in enumerate(x):
  for j,w in enumerate(y):r[i+j]+=v*w
 return r
def factor(rs):
 q=[mp.mpf(1)]
 for z in rs:q=conv(q,[-z,mp.mpf(1)])
 return [mp.re(z) for z in q]
A=factor([fast]+low);B=factor([slow]+hi)
print('A',*[mp.nstr(t,30) for t in A]);print('B',*[mp.nstr(t,30) for t in B]);
Hcoef=[mp.mpf(str(H.coeff(s,i))) for i in range(6)]
mat=mp.matrix(6,6)
for j in range(3):
 for i in range(4):mat[i+j,j]=B[i];mat[i+j,j+3]=A[i]
UV=mp.lu_solve(mat,mp.matrix(Hcoef)); U=list(UV[:3]);V=list(UV[3:]);print('U',*[mp.nstr(t,30) for t in U]);print('V',*[mp.nstr(t,30) for t in V]);
f7=sp.lambdify(xx, F[12:],'mpmath')
init=[mp.mpf(str(x)) for x in json.loads((BASE/'sparse_best.json').read_text())['g']+json.loads((BASE/'sparse_best.json').read_text())['h']]
x0=A[:3]+B[:3]+U+V+init
out=mp.findroot(lambda *comps: mp.matrix(f7(*(x0[:12]+list(comps)))),init,solver='mdnewton',tol=mp.mpf('1e-63'),maxsteps=80,verify=True)
x0=x0[:12]+list(out)
print('CIRCUIT COMPONENTS (conductances, admittances):',*[mp.nstr(t,45) for t in x0[12:]])
f19=sp.lambdify(xx,F,'mpmath')
fvals=f19(*x0);print('max residual',max(abs(t) for t in fvals))
J=sp.Matrix(F).jacobian(xx);jf=sp.lambdify(xx,J,'mpmath');JM=jf(*x0)
print('J condition ∞',mp.norm(JM,'inf')*mp.norm(JM**-1,'inf'))
# prove strict positive real via numerical samples, to be superseded by exact rational Krawczyk of F19
assert all(y>0 for y in x0[12:])
(BASE/'cubic_solution_approx.json').write_text(json.dumps({"variables":list(map(str,xx)),"approximations_65digits":[mp.nstr(t,68) for t in x0],"max_residual":mp.nstr(max(abs(t) for t in fvals),10)},indent=2))
# dump exact polynomial expression vector and Jacobian to serialize
import pickle
with open(str(BASE/'cubic_symbolic.pkl'),'wb') as g:pickle.dump((xx,F,J),g)
print('saved')
