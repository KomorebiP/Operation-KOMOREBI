# Smith chart: exact cubic extraction and a seven-reactive candidate

**Author:** Komorebi P.  
**Date:** 2026-11-09  
**Status:** Unpublished research continuation. Exact results are distinguished from numerical candidates.

## Target and the new decomposition

We continue with the exact normalized positive-real driving-point impedance

\[
Z_6(s)=\frac{450s^6+1385s^5+2477s^4+2200s^3+1142s^2+335s+75}{150s^6+795s^5+1375s^4+1720s^3+1250s^2+445s+25}.
\]

There are **monic real cubic polynomials** \(A,B\) and **real quadratic polynomials** \(U,V\), defined without numerical approximation by

\[
150A(s)B(s)=Q_6(s),\qquad U(s)B(s)+V(s)A(s)=\frac{P_6(s)-3Q_6(s)}{150},
\]

and isolated by the exact rational contraction certificate below, such that

\[
\boxed{Z_6(s)=Z_A(s)+Z_B(s)},\quad
Z_A(s)=\frac{11}{5}+\frac{U(s)}{A(s)},\quad
Z_B(s)=\frac45+\frac{V(s)}{B(s)}.
\]

The pole groups are the stable real pole near \(-3.408987\) and the pair near \(-0.632086\pm0.357909i\) for \(A\), and the real pole near \(-0.068025\) and pair near \(-0.279408\pm1.133172i\) for \(B\).

Approximate coefficients in ascending powers of \(s\), with the exact meanings supplied by the polynomial equations:

| Polynomial | Constant | Linear | Quadratic | Cubic |
|:--|--:|--:|--:|--:|
| \(A\) | 1.7986879882 | 4.8371748026 | 4.6731582960 | 1 |
| \(B\) | 0.0926601321 | 1.4001613547 | 0.6268417040 | 1 |
| \(U\) | -3.8218317148 | -9.1279955606 | -7.4354828288 | — |
| \(V\) | 0.1968831915 | -0.7906000057 | 0.7688161621 | — |

## Theorem 1: minimum-reactive, transformer-free realization of the first cubic

Ground node 0 and drive at node 1, with internal nodes 2 and 3. The following *positive* elements constitute a transformer-free RLC one-port:

| Edge | Component | Normalized value (approximate) |
|:--|:--|--:|
| 0–2 | resistor | 8.5046466683 |
| 0–3 | resistor | 2.9645719657 |
| 0–3 | inductor | 0.6451433297 |
| 1–2 | resistor | 0.0388450324 |
| 1–2 | inductor | 0.0632799527 |
| 1–3 | capacitor | 10.2037581680 |
| 2–3 | resistor | 0.0758824815 |

In terms of resistor conductances \(a,b,c,d\), inductor admittance coefficients \(u=1/L_{03}\), \(v=1/L_{12}\), and capacitance \(w=C_{13}\), the exact nodal cofactor impedance is \(N(s)/D(s)\), where

\[
\begin{aligned}
N(s)={}&w(a+c+d)s^3
 +(ab+ad+bc+bd+cd+vw)s^2\\
&+(au+bv+cu+du+dv)s+uv,\\
D(s)={}&w(ab+ac+ad+bc+bd)s^3\\
&+(abc+acd+auw+avw+bcd+bvw+cuw+duw)s^2\\
&+(abv+acu+adv+bdv+cdu+uvw)s+uv(a+d).
\end{aligned}
\]

The exact algebraic component values are the unique positive solution of the following **19 polynomial equations in the certified rational box**: six coefficients of \(AB=Q_6/150\), six of \(UB+VA=(P_6-3Q_6)/150\), and seven of

\[
\boxed{N(s)A(s)-D(s)\left(\tfrac{11}{5}A(s)+U(s)\right)=0.}
\]

The companion `certify_cubic.py` evaluates the equations and their Jacobian at a 47-digit rational center. It constructs a rational approximate inverse \(M\), a **rational** Hessian bound, and proves that the Newton-like map \(x\mapsto x-MF(x)\) contracts a cube of radius \(10^{-23}\) strictly into itself. Specifically, its verified bounds include

\[
\|M\|_\infty<2220,\quad
\|D^2F\|_\infty<60951,\quad
\|I-MDF(x_0)\|_\infty<1.23\cdot10^{-27},
\]

\[
\|MF(x_0)\|_\infty<4.76\cdot10^{-46},\qquad
q<1.36\cdot10^{-15},\qquad
\|MF(x_0)\|_\infty+q10^{-23}<10^{-23}.
\]

Because \(I-MDF(x_0)\) is strictly contractive, \(M\) is invertible. The Banach fixed-point theorem therefore yields a genuine exact root \(F(x)=0\), not just a near-fit. All seven physical component values are positive throughout the certified cube. Since \(A\) has degree three with no cancellation, the circuit uses the minimum possible **three** reactive elements for \(Z_A\). This is a mathematical existence and minimal-reactive-order certificate; it is not a hardware test or a proof of research novelty.

![Circuit topology generated in Python](figures/37_cubic_transformerfree_schematic.png)

## Theorem 2: the complementary cubic is strictly positive-real

The denominator \(B(s)=s^3+b_2s^2+b_1s+b_0\) is Hurwitz: the certified coefficients satisfy \(b_j>0\) and \(b_2b_1>b_0\).

Put \(x=\omega^2\ge0\). A direct exact computation gives

\[
\operatorname{Re}Z_B(i\omega)=
\frac{c_3x^3+c_2x^2+c_1x+c_0}{|B(i\omega)|^2},
\]

where rational interval evaluation on the same certified algebraic solution proves

\[
c_0>0.025,\quad c_1>0.173,\quad c_2>-0.654,\quad c_3>0.799.
\]

The lower comparison polynomial is strictly positive for all \(x\ge0\), since

\[
\begin{aligned}
&0.799x^3-0.654x^2+0.173x+0.025\\
&=0.799x\left(x-\frac{0.654}{2(0.799)}\right)^2
+\left(0.173-\frac{0.654^2}{4(0.799)}\right)x+0.025>0.
\end{aligned}
\]

Consequently \(Z_B\) is strictly positive-real, so both terms of the exact series decomposition are physically passive immittances. **Positive realness does not, by itself, guarantee three-reactive transformer-free realizability of \(Z_B\).**

![Exact passive series decomposition generated in Python](figures/38_passive_cubic_decomposition.png)

## Seven-reactive numerical candidate, not an existence proof

A separate five-node network with ten positive resistors, two inductors and two capacitors was fitted to \(Z_B\). Its reactive edges are inductors on 2–4 and 0–3, and capacitors on 3–4 and 1–2. The best recorded sampled scaled complex-response error is approximately \(1.54\times10^{-12}\). A high-precision constrained solve reduces the polynomial identity residual to about \(2.33\times10^{-58}\), while keeping positive components.

**This is not a certified circuit.** The coefficient-equation Jacobian is nearly singular (its chosen active-coordinate condition number is about \(4.4\times10^{33}\)). The elementary contraction check used for the first cubic cannot establish the existence of an exact positive root here. Neither a complete seven-reactive construction nor a six-reactive impossibility certificate follows from these fits.

## Status and originality

- **Proved:** an exact passive split of \(Z_6\) into two cubic positive-real functions, and a **minimum-three-reactive transformer-free** circuit for the first cubic.
- **Not proved:** a three-reactive realization of the second cubic, an exact four-reactive realization of it, or a globally minimum six- or seven-reactive transformer-free realization of \(Z_6\).
- **Originality:** no priority claim. Third-order passive-network synthesis and algebraic existence certification have substantial prior literature. The particular polynomial circuit and certified extraction should be compared against the 2017 bicubic synthesis literature and subsequent classifications before any research novelty claim.

### Reproducibility

The `solve_cubic_exact.py`, `certify_cubic.py` and `certify_cubic_complement.py` files contain the exact definitions and full rational inequalities. They are intended to be rerun in that order after generating `cubic_symbolic.pkl`. The network is independently generated by `derive_cubic.py`. `q4_graph_symbolic.py` and `solve_q4_complement.py` document the numerical-only four-reactive continuation. All diagrams were made with Python and Matplotlib.

### Reference points

- Zhang, Jiang, Wang, and Neild (2017), *Synthesis of essential-regular bicubic impedances*, DOI 10.1002/cta.2342.
- Hughes, Morelli, and Smith (2019), *On a concept of genericity for RLC networks*, DOI 10.1016/j.sysconle.2019.104562.
- Prior unpublished Smith chart extended editions and their exact checkers are the internal baseline for this instance-specific continuation.
