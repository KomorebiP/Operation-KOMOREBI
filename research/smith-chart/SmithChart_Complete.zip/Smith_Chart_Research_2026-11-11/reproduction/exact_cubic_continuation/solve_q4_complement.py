#!/usr/bin/env python3
import sympy as sp, pickle, json, numpy as np
from scipy.linalg import qr
from mpmath import mp
from pathlib import Path
p=Path(__file__).resolve().parent;mp.dps=100
with open(p/'q4_network_polys.pkl','rb') as f:vars,N,D,edges,reacts=pickle.load(f)
first=json.loads((p/'cubic_solution_approx.json').read_text())
coeff=[mp.mpf(v) for v in first['approximations_65digits']]
B=coeff[3:6]+[mp.mpf(1)];V=coeff[9:12];rb=mp.mpf(4)/5
T=[rb*B[i]+(V[i] if i<3 else 0) for i in range(4)]
rec=json.loads((p/'refined_B_q4.json').read_text());x0=[mp.mpf(str(v)) for v in rec['g']+rec['h']]
F=[]
for i in range(8):
 left=sum(N[j]*sp.Symbol('b'+str(i-j)) for j in range(5) if 0<=i-j<=3) # easier numeric using separate polys
 # symbolic target coefficients as symbols: (B0,B1,B2,B3),(T0,T1,T2,T3)
Bsym=sp.symbols('B0:4');Tsym=sp.symbols('T0:4');
F=[]
for i in range(8):
 F.append(sp.expand(sum(N[j]*Bsym[i-j]-D[j]*Tsym[i-j] for j in range(5) if 0<=i-j<=3)))
print('target B',*[mp.nstr(t,14) for t in B]);print('target numerator',*[mp.nstr(t,14) for t in T],flush=True)
func=sp.lambdify(vars+Bsym+Tsym,F,'mpmath');J=sp.Matrix(F).jacobian(vars);jfunc=sp.lambdify(vars+Bsym+Tsym,J,'mpmath')
args=x0+B+T
f0=mp.matrix(func(*args));J0=jfunc(*args);print('initial scaled coefficient residual',mp.nstr(max(abs(v) for v in f0),20),flush=True)
Jf=np.array([[float(J0[i,j]*x0[j]) for j in range(14)] for i in range(8)])
# scale rows by max coeff derivatives so QR picks independent columns robustly
row_scale=np.linalg.norm(Jf,axis=1);JJ=Jf / row_scale[:,None]
rank=np.linalg.matrix_rank(JJ,1e-8);print('QR rank relative tol',rank,'singularvals',np.linalg.svd(JJ,compute_uv=False),flush=True)
Q,R,order=qr(JJ,mode='economic',pivoting=True);picked=sorted(map(int,order[:8]));print('picked',picked,flush=True)
fix=[i for i in range(14) if i not in picked]
assert len(picked)==8
fixedvals=[x0[i] for i in fix]
# solve with all other variables fixed positive rational approximations.
def selected_func(*z):
 vals=list(x0)
 for i,v in zip(picked,z):vals[i]=v
 return mp.matrix(func(*(vals+B+T)))
try:
 sol=mp.findroot(selected_func,tuple(x0[i] for i in picked),solver='mdnewton',tol=mp.mpf('1e-60'),maxsteps=90,verify=True)
except Exception as ex:
 print('FINDROOT ERROR',type(ex).__name__,str(ex)[:800]);raise
res=list(x0)
for i,v in zip(picked,sol):res[i]=v
ff=func(*(res+B+T));print('final coefficient residual',mp.nstr(max(abs(v) for v in ff),20),flush=True)
print('min physical value',mp.nstr(min(res),20));print('components',*[mp.nstr(t,30) for t in res],flush=True)
assert all(z>0 for z in res)
Jfinal=jfunc(*(res+B+T))
Ja=mp.matrix([[Jfinal[i,j] for j in picked] for i in range(8)])
print('J active condition inf',mp.nstr(mp.norm(Ja,'inf')*mp.norm(Ja**-1,'inf'),15))
(p/'q4_complement_solution_approx.json').write_text(json.dumps({'variable_names':list(map(str,vars)),'active_indices':picked,'fixed_indices':fix,'approximations_85digits':[mp.nstr(t,85) for t in res], 'max_coefficient_residual':mp.nstr(max(abs(v) for v in ff),15),'topology':{'reactive_edges':reacts,'all_resistor_edges':edges}},indent=2))
with open(p/'q4_symbolic.pkl','wb') as f:pickle.dump((vars,N,D,edges,reacts,Bsym,Tsym,F,picked,fix),f)
