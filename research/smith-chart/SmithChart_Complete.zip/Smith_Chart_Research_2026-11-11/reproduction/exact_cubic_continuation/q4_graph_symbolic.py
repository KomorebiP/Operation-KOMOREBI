#!/usr/bin/env python3
"""Exact weighted-spanning-tree and two-forest polynomial representation.
Author: Komorebi P.
"""
import sympy as sp,itertools,pickle
from pathlib import Path
p=Path(__file__).resolve().parent
s=sp.symbols('s')
g=sp.symbols('g0:10');h=sp.symbols('h0:4');unknown=g+h
n=5;edges=list(itertools.combinations(range(n),2))
reacts=[('L',8),('L',2),('C',9),('C',4)]
ye=[]
for k in range(len(edges)):
 q=g[k]
 for idx,(kind,i) in enumerate(reacts):
  if k==i:q+=h[idx]/s if kind=='L' else h[idx]*s
 ye.append(q)
def comps(sel):
 parents=list(range(n));
 def find(i):
  while i!=parents[i]:i=parents[i]
  return i
 for k in sel:
  u,v=edges[k];parents[find(u)]=find(v)
 return len(set(find(v) for v in range(n))),find(0)!=find(1)
trees=[subset for subset in itertools.combinations(range(10),4) if comps(subset)[0]==1]
forests=[subset for subset in itertools.combinations(range(10),3) if comps(subset)==(2,True)]
print('trees',len(trees),'root separating forests',len(forests),flush=True)
def edge_product_poly(subset):
 coeff={0:sp.Integer(1)}
 for idx in subset:
  src={0:g[idx]}
  for k,(kind,ei) in enumerate(reacts):
   if ei==idx:src[1 if kind=='C' else -1]=h[k]
  out={}
  for d1,v in coeff.items():
   for d2,w in src.items():out[d1+d2]=out.get(d1+d2,0)+v*w
  coeff=out
 return coeff

def compile_polys(sels):
 out={i:0 for i in range(5)}
 for sel in sels:
  coeff=edge_product_poly(sel)
  for k,v in coeff.items():out[k+2]+=v
 return [sp.expand(out[i]) for i in range(5)]
D=compile_polys(trees);N=compile_polys(forests)
print('monomials D',*[len(sp.Poly(e,unknown).terms()) for e in D]);print('monomials N',*[len(sp.Poly(e,unknown).terms()) for e in N]);
with open(p/'q4_network_polys.pkl','wb') as f:pickle.dump((unknown,N,D,edges,reacts),f)
print('saved')
