#!/usr/bin/env python3
"""Exact rational contraction certificate for a 19-equation passive circuit system.
Author: Komorebi P. Tests mathematical existence, not uniqueness of global synthesis.
"""
from fractions import Fraction as F
import sympy as sp, pickle, json, math
from mpmath import mp
from pathlib import Path
p=Path(__file__).resolve().parent
xx,exprs,_=pickle.load(open(p/'cubic_symbolic.pkl','rb'))
data=json.loads((p/'cubic_solution_approx.json').read_text());mp.dps=90
# Choose rational center accurate to 45 significant figures; all 19 variables nonzero.
def rational_sig(s,n=47):
 m=mp.mpf(s);return F(mp.nstr(m,n))
center=[rational_sig(v) for v in data['approximations_65digits']]
assert all(x!=0 for x in center)
terms=[];maxdegree=0
for expr in exprs:
 poly=sp.Poly(expr,*xx,domain='QQ'); t=[]
 for e,c in poly.terms():
  c=F(int(c.p),int(c.q)); e=tuple(int(a) for a in e)
  t.append((e,c));maxdegree=max(maxdegree,sum(e))
 terms.append(t)
print('num terms',sum(len(x) for x in terms),'maximum total degree',maxdegree,flush=True)
num=len(xx)
maxpow=max(max(e) for t in terms for e,c in t)
powers=[[v**i for i in range(maxpow+1)] for v in center]
val=[F(0) for i in range(num)];jac=[[F(0) for j in range(num)] for i in range(num)]
for i,row in enumerate(terms):
 for ex,c in row:
  t=c
  for j,n in enumerate(ex):
   if n:t*=powers[j][n]
  val[i]+=t
  for j,n in enumerate(ex):
   if n:jac[i][j]+=t*n/center[j]
print('evaluated exact function/Jac',flush=True)
JJ=mp.matrix([[mp.mpf(v.numerator)/v.denominator for v in row] for row in jac]);
Bmp=JJ**-1
# Approximate inverse as rational with 31 significant digits. B must be invertible (contractivity proof implies it).
B=[[rational_sig(mp.nstr(Bmp[i,j],35),31) for j in range(num)] for i in range(num)]
q0=F(0);bnorm=F(0);b_err=F(0)
for i in range(num):
 residual=F(0);norm=F(0);row_norm=F(0)
 for j in range(num):
  residual+=B[i][j]*val[j]
  row_norm+=abs(B[i][j])
  # matrix error i,j
  entry=sum((B[i][k]*jac[k][j] for k in range(num)),F(0))
  norm+=abs((F(1) if i==j else F(0))-entry)
 b_err=max(b_err,abs(residual));q0=max(q0,norm);bnorm=max(bnorm,row_norm)
print('b_err',float(b_err),'q0',float(q0),'Bnorm',float(bnorm),flush=True)
# Rigorous global bound on infinity-matrix-norm of Hessians over the whole box.
# Mi is strictly larger than every |coordinate| in the box, so |monomial| derivative
# bounded by the product of integer Mi-powers.
Mi=[math.ceil(abs(v))+1 for v in center]
H=F(0)
for eq in terms:
 rowH=F(0)
 for e,c in eq:
  nz=[j for j,k in enumerate(e) if k]
  for j in nz:
   for k in nz:
    mult=e[j]*(e[k]-(j==k))
    if mult==0:continue
    bound=abs(c)*mult
    for a,exp in enumerate(e):
     q=exp-(a==j)-(a==k)
     if q>0:bound*=Mi[a]**q
    rowH+=bound
 H=max(H,rowH)
print('Hessian bound',float(H),flush=True)
r=F(1,10**23)
q=q0+bnorm*H*r
print('q bound',float(q),'b+qr/r',float(b_err/r+q),flush=True)
assert q < F(1)
assert b_err+q*r <r
print('EXACT RATIONAL CONTRACTION CERTIFICATE PASSED',flush=True)
# Exact certificate digest
certificate={
 'status':'proved: existence of exact positive-algebraic solution in rational box',
 'number_of_unknowns':num,
 'number_of_equations':len(exprs),
 'total_monomials':sum(map(len,terms)),
 'maximum_total_degree':maxdegree,
 'rational_box_radius':str(r),
 'min_component_lower_bound':str(min(center[12:])-r),
 'max_numerical_abs_residual_at_center':float(max(abs(t) for t in val)),
 'B_norm_upper':float(bnorm),
 'Hessian_norm_bound':float(H),
 'contractivity_q_upper':float(q),
 'offset_over_radius':float(b_err/r),
 'exact_pass':True,
 'topology':{'nodes':'0 ground, 1 input, 2 and 3 internal','resistors':'0-2, 0-3, 1-2, 2-3','inductors':'0-3, 1-2','capacitor':'1-3'},
 'target':'constant 11/5 plus the real -3.40899 pole and the complex -0.63209 ±0.35791i pair',
 'limits':'Does not construct other cubic summand or full transformer-free six-state impedance',
}
(p/'cubic_contraction_certificate.json').write_text(json.dumps(certificate,indent=2))
