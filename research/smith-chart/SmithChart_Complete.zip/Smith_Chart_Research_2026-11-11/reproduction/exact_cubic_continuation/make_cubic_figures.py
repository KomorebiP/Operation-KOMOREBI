#!/usr/bin/env python3
"""Python / Matplotlib scientific figures for unpublished Smith chart cubic extraction.
Author: Komorebi P. No generated imagery.
"""
from pathlib import Path
import json, numpy as np, matplotlib.pyplot as plt
from matplotlib.patches import Circle,FancyArrowPatch
p=Path(__file__).resolve().parent
(p/'figures').mkdir(exist_ok=True)
sol=list(map(float,json.loads((p/'cubic_solution_approx.json').read_text())['approximations_65digits']))
a,b,c,d,u,v,w=sol[12:];A=np.array(sol[0:3]+[1.]); B=np.array(sol[3:6]+[1.]);U=np.array(sol[6:9]);V=np.array(sol[9:12]);
pos={0:(0,0),1:(0,2.6),2:(2.6,2.0),3:(5.2,.3)}
fig,ax=plt.subplots(figsize=(12.2,5.8));ax.set_aspect('equal');ax.set_xlim(-.8,6.15);ax.set_ylim(-1.0,3.25);ax.axis('off')
# Branch curves separate the resistor and inductor parallel paths.
def line(p0,p1,name,rad=0,ofs=(0,0),lw=2):
 x,y=pos[p0]; xx,yy=pos[p1]
 patch=FancyArrowPatch((x,y),(xx,yy),arrowstyle='-',connectionstyle=f'arc3,rad={rad}',linewidth=lw,color='0.30',shrinkA=20,shrinkB=20)
 ax.add_patch(patch)
 mid=np.array([(x+xx)/2,(y+yy)/2])+np.array(ofs)
 ax.text(*mid,name,fontsize=8.4,bbox=dict(boxstyle='round,pad=.25',fc='white',ec='0.82'),ha='center',va='center')
line(0,2,f'R = {1/a:.5g}',ofs=(-.36,-.28))
line(0,3,f'R = {1/b:.5g}',rad=.28,ofs=(-.8,-.42))
line(0,3,f'L = {1/u:.5g}',rad=-.32,ofs=(.3,-.45))
line(1,2,f'R = {1/c:.5g}',rad=-.26,ofs=(.1,.42))
line(1,2,f'L = {1/v:.5g}',rad=.30,ofs=(.12,-.35))
line(1,3,f'C = {w:.5g}',rad=.18,ofs=(.45,.3))
line(2,3,f'R = {1/d:.5g}',ofs=(.25,.24))
for i,(x,y) in pos.items():
 ax.add_patch(Circle((x,y),radius=.135,facecolor='white',edgecolor='0.20',linewidth=2,zorder=10))
 ax.text(x,y,str(i),ha='center',va='center',fontsize=10,weight='bold',zorder=11)
ax.text(-.13,-.40,'0 = ground',fontsize=10,weight='semibold')
ax.text(-.26,3.03,'1 = input',fontsize=10,weight='semibold')
fig.suptitle('Exact cubic extraction: transformer-free 4R + 2L + 1C network',fontsize=13)
fig.text(.5,.035,'Dimensionless s and Z₀ = 1; exact component values are algebraic, labels are rounded.',ha='center',fontsize=9)
fig.savefig(p/'figures'/'37_cubic_transformerfree_schematic.png',dpi=170,bbox_inches='tight')
fig.savefig(p/'figures'/'37_cubic_transformerfree_schematic.svg',bbox_inches='tight');plt.close(fig)

freq=np.geomspace(.006,100,800)
s=1j*freq
za=2.2+np.polyval(U[::-1],s)/np.polyval(A[::-1],s)
zb=.8+np.polyval(V[::-1],s)/np.polyval(B[::-1],s)
P=np.array([450,1385,2477,2200,1142,335,75.]);Q=np.array([150,795,1375,1720,1250,445,25.]);zt=np.polyval(P,s)/np.polyval(Q,s)
assert np.max(np.abs(za+zb-zt))<1e-9
fig,ax=plt.subplots(figsize=(9.5,4.9))
ax.semilogx(freq,za.real,label='Certified 2L+1C cubic',lw=2)
ax.semilogx(freq,zb.real,label='Strictly positive-real cubic remainder',lw=2)
ax.semilogx(freq,zt.real,label='Original degree-six response',ls='--',lw=1.8)
ax.set_xlabel('Dimensionless angular frequency ω');ax.set_ylabel('Re Z(iω), normalized')
ax.set_title('Exact passive series decomposition of the filtered LC response');ax.grid(True,which='both',alpha=.18);ax.legend(fontsize=9);fig.tight_layout()
fig.savefig(p/'figures'/'38_passive_cubic_decomposition.png',dpi=180,bbox_inches='tight')
fig.savefig(p/'figures'/'38_passive_cubic_decomposition.svg',bbox_inches='tight');plt.close(fig)
print('two PNG and two SVG figures created')
