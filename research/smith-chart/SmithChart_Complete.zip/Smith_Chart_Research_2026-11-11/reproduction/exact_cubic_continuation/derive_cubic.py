import sympy as s
from pathlib import Path
z=s.symbols('s'); a,b,c,d,u,v,w=s.symbols('a b c d u v w',positive=True)
# edges: a on 0-2, b+u/s on 0-3, c+v/s on 1-2, d on 2-3, cap w*s 1-3
Y=s.zeros(3)
for (i,j),g in [((0,2),a),((0,3),b+u/z),((1,2),c+v/z),((1,3),w*z),((2,3),d)]:
 if i>0:Y[i-1,i-1]+=g
 if j>0:Y[j-1,j-1]+=g
 if i>0 and j>0:Y[i-1,j-1]-=g;Y[j-1,i-1]-=g
Q=s.factor(Y.det()*z**2)
P=s.factor(Y.minor_submatrix(0,0).det()*z**2)
Z=s.factor(P/Q)
print('Z=',Z)
print('N=',s.collect(s.expand(P),z))
print('D=',s.collect(s.expand(Q),z))
open(str(Path(__file__).resolve().parent/'cubic_network_formula.txt'),'w').write('Numerator='+str(s.expand(P))+'\nDenominator='+str(s.expand(Q))+'\n')
