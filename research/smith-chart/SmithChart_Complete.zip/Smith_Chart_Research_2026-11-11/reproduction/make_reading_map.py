"""Create the reading map from stated component counts, using Matplotlib.
Author: Komorebi P.  This explanatory figure is not a circuit certificate.
"""
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Circle

ROOT = Path(__file__).resolve().parents[1]
DEST = ROOT / 'figures'
DEST.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans', 'svg.fonttype':'none', 'font.size':12})
paper, ink, teal, blue, amber = '#faf8f1', '#233d32', '#2f6e5d', '#486b99', '#916625'
fig, ax = plt.subplots(figsize=(12.4,7.1), dpi=180)
fig.patch.set_facecolor(paper)
ax.set_facecolor(paper)
ax.set_xlim(0,12.4); ax.set_ylim(0,7.1); ax.axis('off')
ax.text(.35,6.65,'Seven reactive elements, six visible degrees',size=22,color=ink,weight='bold')
ax.text(.35,6.17,'Exact series construction for the degree-six impedance',size=13,color='#5c6a62')

def box(x,y,w,h,fc,edge):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.03,rounding_size=.12',
                              linewidth=1.3,facecolor=fc,edgecolor=edge))

box(.95,3.25,4.65,2.35,'#eaf1e9',teal)
box(6.8,3.25,4.65,2.35,'#edf0f6',blue)
ax.text(1.2,5.2,'SECTION A',color=teal,size=11,weight='bold')
ax.text(7.05,5.2,'SECTION B',color=blue,size=11,weight='bold')
ax.text(1.2,4.68,'2 inductors + 1 capacitor',color=ink,size=15,weight='bold')
ax.text(7.05,4.68,'2 inductors + 2 capacitors',color=ink,size=15,weight='bold')
ax.text(1.2,4.15,'4 positive resistors',color=ink,size=13)
ax.text(7.05,4.15,'10 positive resistors',color=ink,size=13)
ax.text(1.2,3.59,r'$Z_A(s)$ has reduced degree 3',color=teal,size=13)
ax.text(7.05,3.59,r'$Z_B(s)$ has reduced degree 3',color=blue,size=13)

for lo,hi in [(0.35,.95),(5.6,6.8),(11.45,12.05)]:ax.plot([lo,hi],[4.33,4.33],color=ink,lw=1.8)
ax.add_patch(Circle((.35,4.33),.055,fc=ink));ax.add_patch(Circle((12.05,4.33),.055,fc=ink))
ax.add_patch(Circle((6.2,4.33),.055,fc=ink))
ax.text(.35,3.9,r'$1_A$',ha='center',size=12,color=ink)
ax.text(6.2,3.94,r'$0_A=1_B$',ha='center',size=12,color=ink)
ax.text(12.05,3.9,r'$0_B$',ha='center',size=12,color=ink)
ax.text(6.2,3.57,'join',ha='center',size=10,color='#66736b')

box(.95,.7,10.5,1.95,'#fffaf0','#d5c7ac')
ax.text(1.22,2.23,'ONE EXACT COMMON FACTOR IN SECTION B',color=amber,size=10.5,weight='bold')
ax.text(1.22,1.66,r'$\dfrac{N(s)}{D(s)}=\dfrac{c(s-s_0)T(s)}{c(s-s_0)B(s)}=\dfrac{T(s)}{B(s)}$',color=ink,size=19)
ax.text(7.7,1.68,'Physical reactive count: 7',color=ink,size=12.5,weight='bold')
ax.text(7.7,1.17,'Observable degree: 3 + 3 = 6',color=ink,size=12.5)
ax.text(1.22,.98,'Cancellation is a port property. No physical element is removed.',color='#6d624d',size=11)
ax.text(.35,.22,'Circuit counts: exact construction in the reading.  All quantities shown are normalized.',size=9.5,color='#66736b')
fig.subplots_adjust(left=0,right=1,top=1,bottom=0)
for ext in ['png','svg']:
    fig.savefig(DEST/f'41_storage_and_observable_order.{ext}',dpi=210,facecolor=paper)
print('Created construction map (PNG and SVG).')
