#!/usr/bin/env python3
"""Reproduce exact rational identities and diagnostic boundary checks.
Author: Komorebi P.
Scope: finite sample regression tests; the infinite-N theorem is proved in the manuscript.
"""
from fractions import Fraction as Q
import math, cmath

A=Q(1,3)
RHO=Q(1,4)

def exact_error(n):
    return Q(44,81)*Q(1,3**(n-2))/(1-Q(1,3**n))

def closed(n,t):
    a=float(A); rho=float(RHO)
    q=-a*t
    return a+(1-a*a)*t*(rho+rho*q**(n-2)+q**(n-1))/(1-q**n)

def average(n,t):
    a=float(A); rho=float(RHO)
    return sum((1+2*rho*math.cos(2*math.pi*k/n))/n*(a+cmath.exp(2j*math.pi*k/n)*t)/(1+a*cmath.exp(2j*math.pi*k/n)*t) for k in range(n))

def limit(t):
    return float(A)+(1-float(A)**2)*float(RHO)*t

assert exact_error(4)==Q(11,180)
assert exact_error(5)==Q(2,99)
assert exact_error(6)==Q(11,1638)
assert exact_error(10)==Q(1,12078)
assert exact_error(20)==Q(1,713205900)
assert Q(5,4)+Q(9,4)*Q(1,3)==Q(2,1)  # one-RL impedance at s=1
assert Q(5,4)+Q(9,4)==Q(7,2)  # limit at s=infinity
assert Q(5,9)+exact_error(4)==Q(37,60)
assert (1-Q(37,60))/(1+Q(37,60))==Q(23,97)
assert Q(2,3)+Q(13,45)==Q(43,45)

for n in range(4,31):
    assert exact_error(n)>0
    if n>4: assert exact_error(n)<exact_error(n-1)
    for k in range(73):
        t=cmath.exp(2j*math.pi*k/73)
        assert abs(average(n,t)-closed(n,t))<4e-14
        assert abs(closed(n,t)-limit(t))<float(exact_error(n))+5e-14
    if n<27:
        assert abs(closed(n,-1)-limit(-1))-(float(exact_error(n)))<5e-14
        assert abs(abs(closed(n,-1)-limit(-1))-float(exact_error(n)))<1e-13
print('PASS: exact rational reference values, physical RL, positivity margins, finite-n cyclic identity, and sharp boundary diagnostic')
