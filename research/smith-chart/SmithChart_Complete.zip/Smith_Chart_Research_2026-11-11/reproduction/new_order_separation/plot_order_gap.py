#!/usr/bin/env python3
"""Python-generated vector figure for the Smith chart reading. Author: Komorebi P."""
from fractions import Fraction
from pathlib import Path
import matplotlib.pyplot as plt
import numpy as np
root=Path(__file__).resolve().parents[2]
n=np.arange(4,41)
y=np.array([float(Fraction(44,81)*Fraction(1,3**(int(i)-2))/(1-Fraction(1,3**int(i)))) for i in n])
fig, ax=plt.subplots(figsize=(11.2,5.2),dpi=150)
ax.semilogy(n,y,'o-',lw=2.2,ms=4.5,label='Exact full-disk reflection error')
ax.semilogy(n,44/81 * 3.0**(-(n-2)),'--',lw=1.25,label='Exponential leading term')
for point in [10,20,30]:
    yy=y[point-4]
    ax.annotate(f'N = {point}\n{yy:.2g}',(point,yy),xytext=(8 if point<40 else -67,16),textcoords='offset points', fontsize=9)
ax.set_ylim(1e-20,2)
ax.set_xlim(3.3,41)
ax.set_xlabel('Necessary reactive storage elements in exact realization, N',fontsize=11)
ax.set_ylabel(r'Sharp $H^\infty$ reflection error vs. one-state RL',fontsize=11)
ax.set_title('Exact order increases while passive approximation error vanishes exponentially',fontsize=12,pad=13)
ax.grid(alpha=.25,which='both')
ax.legend(frameon=False,loc='lower left')
ax.text(.985,.96,'One fixed passive RL approximant for all N ≥ 4\nUniform Re z ≥ 23/97  ·  Pole gap Re s ≤ −1/5',transform=ax.transAxes,va='top',ha='right',fontsize=9.5,bbox=dict(boxstyle='round,pad=.4',facecolor='white',edgecolor='.8'))
fig.tight_layout()
for ext in ['svg','png']:
    fig.savefig(root/'figures'/f'42_exponential_order_gap.{ext}',bbox_inches='tight')
plt.close(fig)
