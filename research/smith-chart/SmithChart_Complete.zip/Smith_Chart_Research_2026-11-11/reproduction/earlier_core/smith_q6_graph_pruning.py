#!/usr/bin/env python3
"""Combinatorial pre-screening of six-reactive RLC topologies, allowing L/C overlap on each edge but no redundant same-type duplicate.
Author: Komorebi P.
The program counts only necessary graph criteria. Passing is NOT sufficiency.
"""
import itertools,json
from pathlib import Path

def partition(n,selected):
 parent=list(range(n));rank=[0]*n
 def root(x):
  while parent[x]!=x:
   parent[x]=parent[parent[x]];x=parent[x]
  return x
 cycle=False
 for a,b in selected:
  ra,rb=root(a),root(b)
  if ra==rb:cycle=True;continue
  if rank[ra]<rank[rb]:ra,rb=rb,ra
  parent[rb]=ra
  if rank[ra]==rank[rb]:rank[ra]+=1
 return [root(i) for i in range(n)],cycle

def count(n):
 pairs=list(itertools.combinations(range(n),2));countall=0;flag_counts={'no_port_short':0,'also_no_L_or_C_cycle':0,'also_endpoint_slope_visibility':0};examples={}
 for lid in itertools.combinations(range(len(pairs)),3):
  LC=[pairs[k] for k in lid]; lp,lcycle=partition(n,LC)
  for cid in itertools.combinations(range(len(pairs)),3):
   countall+=1;CC=[pairs[k] for k in cid];cp,ccycle=partition(n,CC)
   if lp[0]==lp[1] or cp[0]==cp[1]:continue
   flag_counts['no_port_short']+=1
   if lcycle or ccycle:continue
   flag_counts['also_no_L_or_C_cycle']+=1
   if all(lp[a]==lp[b] for a,b in CC) or all(cp[a]==cp[b] for a,b in LC):
    examples.setdefault('endpoint_slope_reject',{'L_edges':LC,'C_edges':CC})
    continue
   flag_counts['also_endpoint_slope_visibility']+=1
   examples.setdefault('passes_all',{'L_edges':LC,'C_edges':CC})
 return {'nodes':n,'total_all_3L3C_placements_allowing_LC_overlap':countall,**flag_counts,'examples':examples}

if __name__=='__main__':
 r=[count(n) for n in (4,5,6)]
 fn=Path(__file__).with_name('smith_q6_graph_pruning.json');fn.write_text(json.dumps(r,indent=2))
 for v in r:print(v['nodes'], {key:value for key,value in v.items() if isinstance(value,int)})
