#!/usr/bin/env python3
"""Exact physical realization of a filtered Smith-chart Schur response.
Author: Komorebi P.

All algebraic identities use SymPy with rational coefficients. A rational
interval enclosure verifies that the algebraically defined component values
are strictly positive. Numerical plots are only supporting diagnostics.
"""
from __future__ import annotations
import json
from fractions import Fraction
from pathlib import Path
import sympy as S

ROOT = Path(__file__).resolve().parent
s, t, p, b, Z0, tau = S.symbols('s t p b Z0 tau', real=True)
R = S.Rational
G = p**3-7*p**2+7*p-3
P = 9*s**3+14*s**2+11*s+2
Qden = s**3+7*s**2+7*s+3
checks=[]

def check(name, expr, target=0, modulus=None):
    d=S.cancel(expr-target)
    if modulus is None:
        ok=S.cancel(d)==0
    else:
        num=S.cancel(d).as_numer_denom()[0]
        ok=S.rem(S.Poly(num,p),S.Poly(modulus,p)).is_zero
    checks.append({'name':name,'passed':bool(ok),'method':'rational-polynomial remainder' if modulus is not None else 'symbolic exact'})
    if not ok:
        raise AssertionError(name+': '+str(d))

def truth(name, ok):
    checks.append({'name':name,'passed':bool(ok),'method':'exact integer/rational verification'})
    if not ok: raise AssertionError(name)

# 1. The cyclic Fejer average is a convex combination of real-symmetric
#    rotations, preserving the Schur ball and real coefficients.
a=R(1,3)
f=lambda x: (a+x)/(1+a*x)
ff=S.factor(R(1,2)*f(t)+R(1,4)*f(S.I*t)+R(1,4)*f(-S.I*t))
T=(s-1)/(s+1)
Zfej=S.factor((1+ff.subs(t,T))/(1-ff.subs(t,T)))
Zorig=S.factor((1+f(T))/(1-f(T)))
check('Single-inductor starting impedance z_original=2s',Zorig,2*s)
check('Fejer filtered z has exact cubic ratio', Zfej,P/Qden)
check('Fejer reflection is real rational',ff,S.conjugate(ff))
check('Fejer weights sum to one',R(1,2)+R(1,4)+R(1,4),1)
check('Fejer gain of t is one half',R(1,2)*t+R(1,4)*S.I*t-R(1,4)*S.I*t,R(1,2)*t)

# Exact positive-real boundary formula for all real normalized frequencies.
omega=S.symbols('omega',real=True)
Zjw=S.cancel((P/Qden).subs(s,S.I*omega))
ReZjw=S.cancel((Zjw+S.conjugate(Zjw))/2)
PR=((3*(1+omega**2)**2*(2+3*omega**2)) /
     ((3-7*omega**2)**2+(7*omega-omega**3)**2))
check('Exact positive-real boundary formula', ReZjw,PR)
# The positive numerator is explicit. Denominator cannot vanish for real omega.
truth('Imaginary-axis denominator has no real zeros',
      S.gcd(S.Poly(3-7*omega**2,omega),S.Poly(7*omega-omega**3,omega))==1)

# 2. Irreducible cubic, exactly one real pole and a nonreal conjugate pair.
check('Resultant of numerator and denominator is 2916',S.resultant(P,Qden,s),2916)
check('Denominator cubic discriminant -684',S.discriminant(Qden,s),-684)
truth('Numerator and denominator have gcd one',S.gcd(P,Qden)==1)

# 3. Isolate p, the positive number such that -p is the unique real pole.
left,right=R(5899687,1000000),R(5899688,1000000)
truth('Cubic root interval lower sign',G.subs(p,left)<0)
truth('Cubic root interval upper sign',G.subs(p,right)>0)
truth('p-cubic discriminant <0, so unique real root', S.discriminant(G,p)<0)

# Factor Qden = (s+p)(s²+u s+v). Exact equalities hold modulo G(p).
u=7-p
v=3/p
qpoly=s**2+u*s+v
check('Exact denominator factorization', (s+p)*qpoly,Qden,G)
# Pole extraction: Rp1 || (Lp1 s) gives Rp1*s/(s+p), where Lp1=Rp1/p.
res=P.subs(s,-p)/qpoly.subs(s,-p)
Rp1=S.factor(-res/p)
Lp1=Rp1/p
A=9-Rp1
C0=R(2)/p
B=S.factor(14-Rp1*u-p*A)
second=A*s**2+B*s+C0
check('Exactly decompose cubic via extracted RL pole',Rp1*s*qpoly+(s+p)*second,P,G)
D=S.factor(B-A*u)
E=S.factor(C0-A*v)
check('Remainder after series resistor extraction',second-A*qpoly,D*s+E)

# Synthesis of Z_two=A + [Rp2 || (Rell+Lell*s) || 1/(Ccap*s)].
# To avoid confusing impedance and admittance, use branch =
#   1 / (1/Rp2 + 1/(Rell+Lell*s) + Ccap*s).
q=S.factor(E/D)
Ccap=1/D
Rp2=S.factor(D/(u-q))
Lell=S.factor(D/(v-q*(u-q)))
Rell=S.factor(q*Lell)
branch=S.factor(1/(1/Rp2+1/(Rell+Lell*s)+Ccap*s))
check('Exact parallel RLC three-branch identity',branch,(D*s+E)/qpoly)
Zbuilt=S.factor(Rp1*(Lp1*s)/(Rp1+Lp1*s) + A + branch)
check('Complete exact circuit impedance equals filtered impedance', Zbuilt,P/Qden,G)
check('Extracted RL branch correct',Rp1*(Lp1*s)/(Rp1+Lp1*s),Rp1*s/(s+p))
check('No cancellation in extracted two-factor denominator',S.gcd(P,Qden),1)

# Positivity certificate using exact rational interval arithmetic. No float
# is used to decide whether a component is positive.
class Iv:
    def __init__(self,lo,hi=None):
        self.lo=Fraction(lo); self.hi=Fraction(lo if hi is None else hi)
        assert self.lo<=self.hi
    def __add__(self,o):
        o=iv(o);return Iv(self.lo+o.lo,self.hi+o.hi)
    __radd__=__add__
    def __neg__(self):return Iv(-self.hi,-self.lo)
    def __sub__(self,o):return self+(-iv(o))
    def __rsub__(self,o):return iv(o)+(-self)
    def __mul__(self,o):
        o=iv(o); cand=[a*b for a in (self.lo,self.hi) for b in (o.lo,o.hi)]
        return Iv(min(cand),max(cand))
    __rmul__=__mul__
    def __truediv__(self,o):
        o=iv(o)
        assert o.lo>0 or o.hi<0, 'interval division by interval containing 0'
        return self * Iv(1/o.hi,1/o.lo)
    def __rtruediv__(self,o):return iv(o)/self
    def __pow__(self,n):
        assert isinstance(n,int) and n>=0
        if n==0:return Iv(1)
        if n%2==0:
            if self.lo<=0<=self.hi:return Iv(0,max(self.lo**n,self.hi**n))
            return Iv(min(self.lo**n,self.hi**n),max(self.lo**n,self.hi**n))
        return Iv(self.lo**n,self.hi**n)
    def positive(self):return self.lo>0
    def as_dict(self):return {'lower':str(self.lo),'upper':str(self.hi),'lo_decimal':round(float(self.lo),10),'hi_decimal':round(float(self.hi),10)}

def iv(o):return o if isinstance(o,Iv) else Iv(o)
Piv=Iv(Fraction(5899687,1000000),Fraction(5899688,1000000))
Uiv=7-Piv
Viv=3/Piv
# res = (-49p²+52p-25)/(3p²-14p+7), valid after p³ reduction.
NUM=49*Piv**2-52*Piv+25
DEN=3*Piv**2-14*Piv+7
R1iv=NUM/(Piv*DEN)
L1iv=R1iv/Piv
Aiv=9-R1iv
C0iv=2/Piv
Biv=14-R1iv*Uiv-Piv*Aiv
Div=Biv-Aiv*Uiv
Eiv=C0iv-Aiv*Viv
qiv=Eiv/Div
Rp2iv=Div/(Uiv-qiv)
Lelliv=Div/(Viv-qiv*(Uiv-qiv))
Relliv=qiv*Lelliv
Ccapiv=1/Div
ivals={'p':Piv,'u':Uiv,'v':Viv,'pole_residue_denom':DEN,
       'pole_residue_numerator':NUM,'R_parallel_1':R1iv,'L_parallel_1':L1iv,
       'R_series':Aiv,'D':Div,'E':Eiv,'q':qiv,
       'R_parallel_2':Rp2iv,'R_series_inductor':Relliv,
       'L_series_inductor':Lelliv,'C_shunt':Ccapiv,
       'u_minus_q':Uiv-qiv,'v_minus_q_u_minus_q':Viv-qiv*(Uiv-qiv)}
for name,val in ivals.items(): truth('Certified strictly positive interval: '+name,val.positive())

# The general one-degree circuit family Gamma=b*t, -1<b<1.
Z_b=S.factor((1+b*T)/(1-b*T))
check('Linear reflected load impedance',Z_b,((1+b)*s+1-b)/((1-b)*s+1+b))
Rs=(1-b)/(1+b)
Rbranch=4*b/(1-b**2)
Lbranch=4*b/(1+b)**2
check('General RL impedance b in (0,1)',Rs+1/(1/Rbranch+1/(Lbranch*s)),Z_b)
# For b=-c, capacitor branch; expected Rseries and Rp||C.
c=S.symbols('c', real=True)
RsC=(1-c)/(1+c)
RpC=4*c/(1-c**2)
CapC=(1+c)**2/(4*c)
check('General RC impedance b=-c in (-1,0)',RsC+1/(1/RpC+CapC*s),Z_b.subs(b,-c))

root=float(S.nroots(G,n=30)[0])
# SymPy ordering can vary; choose the unique real root by imaginary part.
roots=S.nroots(G,n=30)
root=float(S.re([x for x in roots if abs(float(S.im(x)))<1e-20][0]))
values={name:float(S.N(ex.subs(p,root),15)) for name,ex in
        {'R_parallel_1':Rp1,'L_parallel_1':Lp1,'R_series':A,
         'R_parallel_2':Rp2,'R_series_inductor':Rell,
         'L_series_inductor':Lell,'C_shunt':Ccap}.items()}
result={'author':'Komorebi P.','subject':'Finite passive circuit synthesis for a Fejer-filtered pure inductor',
        'passed':len(checks),'total':len(checks),'checks':checks,
        'exact':{'z_original':'2*s','z_filtered':str(P/Qden),
                 'discriminant':str(S.discriminant(Qden,s)),'resultant':str(S.resultant(P,Qden,s)),
                 'unique_real_p_is_root_of':str(G)},
        'normalized_components':values,
        'isolation':{'left':str(left),'right':str(right)},
        'certified_component_intervals':{k:v.as_dict() for k,v in ivals.items()},
        'interpretation':'3 reactive elements are sufficient and necessary (McMillan degree 3). No claim of minimum total element count.'}
(ROOT/'smith_realization_checks.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print('PASS',len(checks),'/',len(checks))
print('Exact target z(s)=',P,'/',Qden)
print('Unique real p approximately',root)
for k,v in values.items():print(k,':',f'{v:.11f}')
