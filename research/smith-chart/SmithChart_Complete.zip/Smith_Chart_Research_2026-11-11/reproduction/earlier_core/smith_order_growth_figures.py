#!/usr/bin/env python3
"""Three mathematical figures for the unpublished Smith chart order-growth study.
All art is generated entirely in Python/Matplotlib. Author: Komorebi P.
"""
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Circle
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'figures'; OUT.mkdir(parents=True,exist_ok=True)
INK='#163449'; MID='#637a88'; TEAL='#0e7283'; GOLD='#c1813b'; DARK='#35576b'; PALE='#d7e6ea'; VIOLET='#6a5897'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'text.color':INK,'axes.labelcolor':INK,'axes.edgecolor':MID,'axes.titlesize':11,'figure.facecolor':'white','savefig.facecolor':'white','svg.fonttype':'none'})

def save(fig,name):
    fig.savefig(OUT/(name+'.svg'),bbox_inches='tight',pad_inches=.22)
    fig.savefig(OUT/(name+'.png'),dpi=180,bbox_inches='tight',pad_inches=.22)
    plt.close(fig)
    print('CREATED',name)

def f(a,t):return (a+t)/(1+a*t)

def fejer(H,t):return .5*H(t)+.25*H(1j*t)+.25*H(-1j*t)

def fig13():
    fig,axs=plt.subplots(1,2,figsize=(13.4,5.25),gridspec_kw={'width_ratios':[.92,1.08]})
    ax=axs[0];xs=np.array([0,1]);w=.26
    r=ax.bar(xs-w/1.8,[1,2],width=w,color=GOLD,label='Before filtering',zorder=3)
    g=ax.bar(xs+w/1.8,[3,6],width=w,color=TEAL,label='Safe Fejér filtering',zorder=3)
    ax.set_ylim(0,7.6);ax.set_yticks(range(0,8));ax.set_xticks(xs,['Pure inductor\n(a = 1/3)','Series LC\n(a = 1/3, b = 1/2)']);ax.set_ylabel('Exact rational degree');ax.set_title('Reactive-order lower bounds',loc='left',weight='bold')
    ax.grid(axis='y',alpha=.18,zorder=0)
    for bar in [*r,*g]:ax.text(bar.get_x()+bar.get_width()/2,bar.get_height()+.13,f'{int(bar.get_height())}',ha='center',va='bottom',weight='bold',fontsize=12)
    ax.legend(loc='upper left',frameon=False,fontsize=9)
    ax=axs[1]
    aa=np.linspace(.0001,.965,400)
    upper=[]
    for a in aa:
        poles=np.roots([1-a*a,5*a*a+2*a+5,7*(1-a*a),3*a*a-2*a+3]);pole=max(poles,key=lambda x:x.imag)
        upper.append(pole)
    upper=np.array(upper)
    ax.axvline(0,color=GOLD,ls='--',lw=1.1,label='Imaginary-frequency axis')
    ax.plot(upper.real,upper.imag,color=TEAL,lw=2.2,label='Upper conjugate pole')
    ax.plot(upper.real,-upper.imag,color=TEAL,lw=2.2,alpha=.65,label='Lower conjugate pole')
    for a,label,shift in [(.04,'a = 0.04',(5,-15)),(1/3,'a = 1/3',(4,12)),(.65,'a = 0.65',(5,12)),(.9,'a = 0.90',(-85,-12))]:
        roots=np.roots([1-a*a,5*a*a+2*a+5,7*(1-a*a),3*a*a-2*a+3]);pole=max(roots,key=lambda x:x.imag)
        ax.scatter(pole.real,pole.imag,color=GOLD,s=34,edgecolor='white',linewidth=.8,zorder=4)
        ax.annotate(label,(pole.real,pole.imag),xytext=shift,textcoords='offset points',fontsize=9,color=INK)
    ax.scatter([-1],[0],marker='x',s=58,color=VIOLET,zorder=5,label='a → 0 cancellation point')
    ax.set(xlim=(-1.16,.085),ylim=(-.72,.75),xlabel='Real part of complex-frequency pole',ylabel='Imaginary part of pole')
    ax.set_title('The extra conjugate pole pair',weight='bold',loc='left')
    ax.grid(alpha=.16);ax.legend(loc='lower left',fontsize=8,frameon=False)
    fig.suptitle('A safe cyclic mask changes exact circuit complexity',weight='bold',fontsize=15,y=1.015)
    fig.text(.50,-.02,'The third (real) pole is omitted from the pole-trajectory panel to retain a readable scale.',ha='center',size=9,color=MID)
    fig.tight_layout();save(fig,'13_order_growth_and_poles')

def fig14():
    aa=np.linspace(-.95,.95,321)
    t=np.exp(1j*np.linspace(0,2*np.pi,1801))
    bound=[];sample=[]
    for a in aa:
        bound.append(.75*((1-abs(a))/(1+abs(a)))**2)
        g=fejer(lambda tt:f(a,tt),t)
        sample.append(float(np.min(1-abs(g)**2)))
    fig,ax=plt.subplots(figsize=(11.7,5.2))
    ax.plot(aa,sample,c=TEAL,lw=2.4,label='Boundary minimum from sampled angles')
    ax.fill_between(aa,bound,sample,color=TEAL,alpha=.10)
    ax.plot(aa,bound,c=GOLD,lw=2.8,label='Certified lower bound for every angle')
    ax.scatter([1/3],[9/25],color=VIOLET,edgecolor='white',linewidth=.9,zorder=5,s=65)
    ax.annotate('a = 1/3: exact minimum = 9/25',(1/3,9/25),xytext=(20,22),textcoords='offset points',size=10,color=VIOLET,arrowprops=dict(arrowstyle='-',color=VIOLET,lw=1))
    ax.scatter([1/3],[3/16],color=GOLD,s=35,edgecolor='white',linewidth=.7,zorder=5)
    ax.set(xlim=(-.96,.96),ylim=(0,1),xlabel='Inductor automorphism parameter a',ylabel='1 − |Γ|² on the unit-circle frequency boundary')
    ax.grid(alpha=.19)
    ax.set_title('Universal dissipation margin versus sampled behavior',weight='bold',loc='left')
    ax.legend(loc='upper left',frameon=False)
    fig.text(.52,-.018,'The upper curve is numerical context, not a rigorous envelope; the lower curve is proved analytically.',ha='center',size=9,color=MID)
    fig.tight_layout();save(fig,'14_uniform_dissipation_margin')

def fig15():
    w=np.r_[0,np.geomspace(1e-4,1e4,2500)]
    s=1j*w
    t=(s-1)/(s+1)
    F=lambda t:f(1/3,t)*f(1/2,t)
    G=fejer(F,t)
    Z=(1+G)/(1-G)
    theta=np.linspace(0,2*np.pi,700)
    fig,axs=plt.subplots(1,2,figsize=(13.1,5.5),gridspec_kw={'width_ratios':[1,1.1]})
    ax=axs[0]
    ax.plot(np.cos(theta),np.sin(theta),c=MID,lw=1.0,label='Passive disk boundary')
    ax.axhline(0,c=PALE,lw=1);ax.axvline(0,c=PALE,lw=1)
    ax.plot(F(t).real,F(t).imag,c=GOLD,lw=2.0,label='Original lossless series LC')
    ax.plot(G.real,G.imag,c=TEAL,lw=2.6,label='Safe filtered reflection')
    for ix in [0,330,940,1550,2450]: ax.scatter(G[ix].real,G[ix].imag,c=TEAL,s=27,edgecolor='white',linewidth=.6,zorder=4)
    ax.set(aspect='equal',xlim=(-1.12,1.12),ylim=(-1.13,1.13),xlabel='Re Γ(jω)',ylabel='Im Γ(jω)')
    ax.set_title('Lossless boundary → passive interior',loc='left',weight='bold');ax.legend(loc='lower left',frameon=False,fontsize=8)
    ax=axs[1]
    ax.semilogx(w[1:],Z.real[1:],c=TEAL,lw=2.7,label='Filtered Re z(jω)')
    ax.axhline(0,color=GOLD,ls='--',lw=1.2,label='Original lossless Re z = 0')
    ax.set(xlim=(w[1],w[-1]),ylim=(-.12,max(3.35,np.max(Z.real)*1.05)),xlabel='Dimensionless angular frequency ωτ',ylabel='Normalized input resistance Re(Z)/Z₀')
    ax.set_title('Strictly positive resistance after filtering',loc='left',weight='bold');ax.grid(alpha=.18,which='both');ax.legend(loc='lower right',frameon=False,fontsize=9)
    fig.suptitle('Exact degree-six filtered response from a two-reactive-element series LC',weight='bold',fontsize=14.5,y=1.012)
    fig.text(.5,-.014,'Example input at Z₀ = 50 Ω and τ = 1 ns: 60 nH in series with 100 pF. Plots show an ideal rational circuit model.',ha='center',size=9,color=MID)
    fig.tight_layout();save(fig,'15_filtered_series_lc')


def fig16():
    from matplotlib.gridspec import GridSpec
    from matplotlib.patches import Rectangle, Arc
    fig=plt.figure(figsize=(13.8,6.1));gs=GridSpec(2,2,figure=fig,width_ratios=[1.00,1.13],hspace=.35,wspace=.25)
    ax=fig.add_subplot(gs[:,0]);ax.set_aspect('equal');ax.set_xlim(.0,11.3);ax.set_ylim(-2.3,2.8);ax.axis('off')
    def wire(x1,y1,x2,y2,col=INK):ax.plot([x1,x2],[y1,y2],color=col,lw=2,solid_capstyle='round')
    def dot(x,y):ax.add_patch(Circle((x,y),.06,color=INK,zorder=5))
    def box(x1,x2,y,text):
        wire(x1,y,(x1+x2)/2-.52,y);wire((x1+x2)/2+.52,y,x2,y)
        ax.add_patch(Rectangle(((x1+x2)/2-.52,y-.17),1.04,.34,facecolor='#e8f1f3',edgecolor=INK,linewidth=1.7,zorder=5))
        ax.text((x1+x2)/2,y+.40,text,ha='center',va='bottom',fontsize=10.4,weight='semibold')
    def coil(x1,x2,y,text):
        wire(x1,y,(x1+x2)/2-.82,y);wire((x1+x2)/2+.82,y,x2,y)
        for i in range(4):ax.add_patch(Arc(((x1+x2)/2-.82+(i+.5)*1.64/4,y),width=1.64/4,height=.48,theta1=0,theta2=180,linewidth=2,color=INK))
        ax.text((x1+x2)/2,y+.40,text,ha='center',va='bottom',fontsize=10.4,weight='semibold')
    ax.text(.1,2.63,'Certified one-inductor passive substitute',size=14,weight='bold')
    ax.text(.1,2.20,'50 Ω reference  •  τ = 1 ns  •  a = 1/3',size=10.4,color=MID)
    wire(.7,0,1.1,0);box(1.1,3.9,0,'Rₛ = 40 Ω');wire(3.9,0,4.35,0)
    wire(4.35,-1.05,4.35,1.0);wire(4.35,0,4.35,-1.05)
    wire(9.5,-1.05,9.5,1.0);wire(9.5,1.0,9.5,0)
    box(4.35,9.5,1.0,'Rₚ = 360 Ω');coil(4.35,9.5,-1.05,'L = 72 nH')
    wire(9.5,0,10.55,0)
    for x in [4.35,9.5]:dot(x,0)
    for x in [.7,10.55]:ax.add_patch(Circle((x,0),.085,edgecolor=INK,facecolor='white',linewidth=2))
    ax.text(5.8,-1.88,'Rₛ + (Rₚ || L)',ha='center',color=TEAL,weight='bold',fontsize=12)
    ax.text(5.8,-2.25,'Ideal lumped one-port, not a measured device',ha='center',color=MID,fontsize=9)

    w=np.geomspace(1e-5,1e5,3000)
    ss=1j*w;tt=(ss-1)/(ss+1)
    F=lambda t:(1/3+t)/(1+t/3)
    G=fejer(F,tt);H=1/3+4*tt/9
    Z=(1+G)/(1-G);ZH=(1+H)/(1-H)
    a1=fig.add_subplot(gs[0,1])
    a1.semilogx(w,abs(G-H),lw=2.5,color=TEAL,label='Exact |Γ − Γ₁|')
    a1.axhline(4/45,color=GOLD,ls='--',lw=1.7,label='Sharp maximum: 4/45')
    a1.set(xlim=(1e-5,1e5),ylim=(-.005,.105),ylabel='Absolute reflection error')
    a1.set_title('Small error on the Smith disk',loc='left',weight='bold')
    a1.grid(alpha=.17,which='both');a1.legend(loc='center right',frameon=False,fontsize=9)

    a2=fig.add_subplot(gs[1,1],sharex=a1)
    a2.semilogx(w,abs(Z-ZH),lw=2.5,color=VIOLET,label='Exact |z − z₁|')
    a2.axhline(1,color=GOLD,ls='--',lw=1.7,label='Sharp supremum: 1')
    a2.set(xlim=(1e-5,1e5),ylim=(-.055,1.12),xlabel='Dimensionless angular frequency ωτ',ylabel='Normalized impedance error')
    a2.set_title('Larger error in impedance coordinates',loc='left',weight='bold')
    a2.grid(alpha=.17,which='both');a2.legend(loc='center right',frameon=False,fontsize=9)
    fig.suptitle('Exact three-state RLC response versus a certified one-state passive approximation',weight='bold',fontsize=15,y=1.005)
    fig.tight_layout(rect=[0,0,1,.99]);save(fig,'16_passive_one_state_approximation')

if __name__=='__main__':
    fig13();fig14();fig15();fig16()
