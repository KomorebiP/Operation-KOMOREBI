#!/usr/bin/env python3
"""Exact and deterministic checks for the unpublished extended Smith-chart reading edition.

Requires SymPy. No network or remote data. Writes one JSON receipt plus a hand-worked CSV.
Checks are finite witnesses; analytic theorems require their written proofs.
"""
from __future__ import annotations
from fractions import Fraction
from pathlib import Path
import argparse, csv, json, hashlib
from sympy import Matrix, Rational as Q, I, sqrt, symbols, diag, simplify, factor, eye
from sympy.matrices import MatrixBase

checks=[]
rows=[]
def check(name, actual, expected=0, scope='exact algebra'):
    residual = simplify(actual-expected)
    result = bool(residual.is_zero_matrix) if isinstance(residual,MatrixBase) else bool(residual == 0)
    checks.append({'name':name,'passed':bool(result),'residual':str(residual),'scope':scope})
    if not result: raise AssertionError(f'{name}: got {actual}, expected {expected}, residual {residual}')

def gamma(z,z0): return simplify((z-z0)/(z+z0))
def impedance(g,z0): return simplify(z0*(1+g)/(1-g))
def zpacket(t,n,j): return (1+t**n)/(1-t**n) if j==0 else 2*t**j/(1-t**n)
def ypacket(t,n,j):
    if n%2==0: return (-1)**j*zpacket(t,n,j)
    return (1-t**n)/(1+t**n) if j==0 else 2*(-1)**j*t**j/(1+t**n)
def twoport_packet(a,b,d,t,n,j):
    if j==0: return a+b*d**(n-1)*t**n/(1-(d*t)**n)
    return b*d**(j-1)*t**j/(1-(d*t)**n)

def kernel(s,c):
    return Matrix(len(s),len(s),lambda i,j:(1-c[i]*c[j])/(s[i]+s[j]))
def minors2(P):
    return [simplify(P.extract([i,j],[i,j]).det()) for i,j in [(0,1),(0,2),(1,2)]]

def run():
    z0=Q(50); Z=Q(25)+25*I
    g=gamma(Z,z0)
    check('Example reflection coefficient',g,(-1+2*I)/5)
    gin=simplify(-I*g)
    check('One-eighth-wavelength line phase',gin,(2+I)/5)
    check('One-eighth-wavelength input impedance',impedance(gin,z0),100+50*I)
    check('Passive-disk identity',1-(g* g.conjugate()),4*Q(25,50)/((Z/z0+1)*(Z/z0+1).conjugate()))
    r,x=Q(1,2),Q(1,2)
    u,v=simplify(g.as_real_imag()[0]),simplify(g.as_real_imag()[1])
    check('Resistance circle equation',(u-r/(1+r))**2+v**2,1/(1+r)**2)
    check('Reactance circle equation',(u-1)**2+(v-1/x)**2,1/x**2)
    rows.append(('load_gamma','25 + 25i ohms','50 ohms',str(g)))
    rows.append(('line_lam8','gamma_L',str(g),str(gin)))
    rows.append(('line_input','gamma_in',str(gin),'100 + 50i ohms'))

    t=Q(1,2)
    check('N=3 impedance packet 0',zpacket(t,3,0),Q(9,7))
    check('N=3 impedance packet 1',zpacket(t,3,1),Q(8,7))
    check('N=3 impedance packet 2',zpacket(t,3,2),Q(4,7))
    check('N=3 impedance reconstruction',sum(zpacket(t,3,j) for j in range(3)),3)
    check('N=3 admittance packet 0',ypacket(t,3,0),Q(7,9))
    check('N=3 admittance packet 1',ypacket(t,3,1),-Q(8,9))
    check('N=3 admittance packet 2',ypacket(t,3,2),Q(4,9))
    check('N=3 admittance reconstruction',sum(ypacket(t,3,j) for j in range(3)),Q(1,3))
    check('Odd-order parity lift j=1',ypacket(t,3,1),-(zpacket(t,6,1)-zpacket(t,6,4)))
    check('N=2 impedance-admittance even packet',zpacket(t,2,0),Q(5,3))
    check('N=2 impedance-admittance odd packet',zpacket(t,2,1),Q(4,3))
    check('N=2 inversion identity',impedance(-Q(1,2),1),Q(1,3))
    for n in (2,3,4,5,8,12):
        check(f'Geometric packet reconstruction N={n}',sum(zpacket(t,n,j) for j in range(n)),3)
        for j in range(n):
            check(f'Exact two-child refinement N={n},j={j}',zpacket(t,n,j),zpacket(t,2*n,j)+zpacket(t,2*n,j+n))
    rows.extend(('impedance_packet_n3',f'j={j}','t=1/2',str(zpacket(t,3,j))) for j in range(3))

    # Parseval energy of the order-three impedance packets at rho = 1/2.
    check('Angular H2 energy of packet zero',1+4*(Q(1,2)**6)/(1-Q(1,2)**6),Q(67,63))
    check('Angular H2 energy of packet one',4*(Q(1,2)**2)/(1-Q(1,2)**6),Q(64,63))
    check('Angular H2 energy of packet two',4*(Q(1,2)**4)/(1-Q(1,2)**6),Q(16,63))
    check('Total angular H2 energy',Q(67+64+16,63),Q(7,3))

    # Noncommuting passive 4-port with a 2-by-2 scalar-load termination.
    I2=eye(2); B=I2/3; C=B
    D=diag(Q(1,3),-Q(1,4))
    T=Matrix([[0,Q(1,2)],[Q(1,2),0]])
    Qmat=D*T
    assert D*T != T*D
    check('Noncommuting matrix coupling Q^2',Qmat**2,-I2/48)
    full=B*T*(I2-Qmat).inv()*C
    even=B*T*Qmat*(I2-Qmat**2).inv()*C
    odd=B*T*(I2-Qmat**2).inv()*C
    check('Matrix packet even exact',even,diag(-Q(1,147),Q(4,441)))
    check('Matrix packet odd exact',odd,Matrix([[0,Q(8,147)],[Q(8,147),0]]))
    check('Matrix full reconstruction',full,even+odd)
    check('Matrix full exact value',full,Matrix([[-Q(1,147),Q(8,147)],[Q(8,147),Q(4,441)]]))
    rows.append(('matrix_noncommuting', 'D diagonal,T swap', 'order 2',str(full)))

    # Lossless reciprocal two-port S = [[1/2,sqrt(3)/2],[sqrt(3)/2,-1/2]].
    S=Matrix([[Q(1,2),sqrt(3)/2],[sqrt(3)/2,-Q(1,2)]])
    check('Lossless S^*S=I',sum(abs(v) for v in (S.T*S-eye(2))),0)
    tl=Q(3,4); pp=[simplify(twoport_packet(Q(1,2),Q(3,4),-Q(1,2),tl,3,j)) for j in range(3)]
    for j,val in enumerate((Q(310,539),Q(288,539),-Q(108,539))): check(f'Lossless two-port packet j={j}',pp[j],val)
    check('Truncated reflection exceeds unity',pp[0]+pp[1],Q(598,539))
    check('Truncated impedance negative',impedance(pp[0]+pp[1],1),-Q(1137,59))
    check('Full lossless reflection',sum(pp),Q(10,11))
    rows.append(('lossless_truncation','P0+P1',str(pp[0]+pp[1]),str(impedance(pp[0]+pp[1],1))))
    # Safe packet-mask family: a coset modulo 3 within six residues.
    p6=[simplify(twoport_packet(Q(1,2),Q(3,4),-Q(1,2),tl,6,j)) for j in range(6)]
    for j in range(3):
        check(f'Coset packet identity N=6 -> N=3, residue {j}',p6[j]+p6[j+3],pp[j])
    check('Unsafe union of two safe cosets',sum(p6[j] for j in (0,1,3,4)),Q(598,539))
    check('Safe coset j=0 plus j=3',p6[0]+p6[3],Q(310,539))
    check('Safe coset j=1 plus j=4',p6[1]+p6[4],Q(288,539))
    rows.extend([('safe_mask','J={0,3}','N=6, t=3/4',str(p6[0]+p6[3])),
                 ('safe_mask','J={1,4}','N=6, t=3/4',str(p6[1]+p6[4])),
                 ('unsafe_union','J={0,1,3,4}','N=6, t=3/4',str(sum(p6[j] for j in (0,1,3,4))))])


    # Passive two-port nonidentifiability at t=1/2, N=3.
    for sign,d,b,expected in [('+',Q(1,2),Q(63,160),Q(21,80)),('-',-Q(1,2),Q(65,160),Q(13,80))]:
        p=[simplify(twoport_packet(0,b,d,t,3,j)) for j in range(3)]
        check(f'Ambiguous network {sign} observed P0',p[0],Q(1,80))
        check(f'Ambiguous network {sign} observed P1',p[1],Q(1,5))
        check(f'Ambiguous network {sign} missing P2',p[2],Q(1,20) if sign=='+' else -Q(1,20))
        check(f'Ambiguous network {sign} response',sum(p),expected)
        # S = [[0,c],[c,d]] and |c|²=b; exact positive semidefiniteness.
        Sm=Matrix([[0,sqrt(b)],[sqrt(b),d]]);P=eye(2)-Sm.T*Sm
        assert P[0,0]>=0 and P[1,1]>=0 and simplify(P.det())>=0
        check(f'Ambiguous {sign} contractive principal minors',max(0,-P[0,0])+max(0,-P[1,1])+max(0,-simplify(P.det())))
    check('Ambiguity minimax lower bound',Q(21,80)-Q(13,80),Q(1,10))

    # Direct two-node Pick kernel and packet-coordinate certificate, independent of the witness.
    KK=Matrix([[Q(4,3),Q(4,5)],[Q(4,5),Q(4,3)]])
    UU=Matrix([[1,1],[1,-1]])/sqrt(2)
    LL=diag(Q(32,15),Q(8,15))
    CC=Matrix([[0,Q(1,4)],[Q(1,4),0]])
    VV=diag(Q(1,4),-Q(1,4))
    cert=LL-CC*LL*CC.T
    check('Two-node packet Pick complement',cert,diag(Q(21,10),Q(2,5)))
    check('Pick and packet complements are Fourier conjugates',
          simplify(UU.T*(KK-VV*KK*VV)*UU),cert)
    rows.append(('two_node_Pick','N=2,rho=1/2,F=t/2','p0=0,p1=1/4',str(cert)))

    # Exact Pick-matrix uniqueness witness from the finite orbit.
    xx,yy=symbols('x y',real=True)
    lam=diag(Q(12288,3367),Q(6912,3367),Q(3888,3367))
    p=[Q(310,539),Q(288,539),xx+I*yy]
    C=Matrix(3,3,lambda a,b:p[(a-b)%3]);M=lam-C*lam*C.conjugate().T
    u=Matrix([3,8,0]);v=Matrix([-9,0,64]);H=593*u*u.T+3*v*v.T
    expected=-Q(337121280,3367)*((xx+Q(108,539))**2+yy**2)
    check('Finite orbit uniqueness sum-of-squares witness',simplify((H*M).trace()),expected)
    M0=M.subs({xx:-Q(108,539), yy:0});check('Unique Schur data Pick rank',M0.rank(),1)
    rows.append(('Pick_uniqueness','p0=310/539, p1=288/539','N=3,rho=3/4','p2=-108/539'))
    # Exact spectral-gap robustness of a completed cyclic orbit.
    rho=Q(1,2); n=3
    lam_max=n/(1-rho**(2*n))
    lam_min=n*rho**(2*(n-1))/(1-rho**(2*n))
    orbit_mag=Q(1,2)
    margin=(1-orbit_mag**2)*lam_min
    packet_error=Q(1,100)
    orbit_error=n*packet_error
    perturbation_bound=lam_max*(2*orbit_mag*orbit_error+orbit_error**2)
    check('Orbit Szego kernel maximum eigenvalue',lam_max,Q(64,21))
    check('Orbit Szego kernel minimum eigenvalue',lam_min,Q(4,21))
    check('Constant Schur Pick spectral gap',margin,Q(1,7))
    check('Packet-error propagation to orbit values',orbit_error,Q(3,100))
    check('Completed Pick matrix perturbation bound',perturbation_bound,Q(412,4375))
    check('Strict passivity margin survives perturbations',int(bool(perturbation_bound<margin)),1)
    rows.append(('Pick_robustness','N=3,rho=1/2, F=1/2','each packet error <= 1/100',
                 f'perturbation <= {perturbation_bound}; gap = {margin}'))


    # Schwarz Pick / frequency certificates.
    s=[Q(1),Q(2)];cs=[Q(1,4),Q(3,4)]
    check('Incompatible two-frequency Pick determinant',kernel(s,cs).det(),-Q(407,18432))
    check('Opposite-sign frequency Pick determinant',kernel(s,[Q(1,4),-Q(3,4)]).det(),-Q(1943,18432))
    s3=[Q(1),Q(2),Q(3)];c3=[Q(1,20),Q(1,6),Q(1,20)]
    P3=kernel(s3,c3)
    check('Triple nonlocal Pick determinant',P3.det(),-Q(3981887,82944000000))
    for i,(value,detval) in enumerate(zip(minors2(P3),[Q(12397,1036800),Q(53067,2560000),Q(343,320000)])):
        check(f'Triple every pair positive minor {i+1}',value,detval)
        assert value>0
    rows.append(('Pick_triple','pairwise positive','negative 3x3 determinant',str(P3.det())))

    def cstar(s): return simplify(4*(s+2)*(25*s+3)/((7*s+5)*(17*s+39)))
    for sv,cv in ((1,Q(1,2)),(2,Q(848,1387)),(3,Q(2,3))): check(f'Passive rational completion at s={sv}',cstar(Q(sv)),cv)
    check('Frequency interval radius',Q(893,1387)-Q(848,1387),Q(45,1387))

    # Sharp bidisk pure-character obstruction and approximation correction.
    rho=q=Q(1,2); a=Q(1,3)
    check('Separate slice bound, |a| ≤ rho',int(bool(a<=rho)),1)
    check('Separate slice bound, |a| ≤ q',int(bool(a<=q)),1)
    check('Joint threshold violated',int(bool(a>rho*q)),1)
    check('Sharp minimal node correction',a-rho*q,Q(1,12))
    # Reciprocity square-root obstruction: first load derivative z/4 has simple zero.
    z=symbols('z');b=z/4
    check('Odd multiplicity derivative obstruction',b.diff(z).subs({z:0}),Q(1,4))
    check('Sharp reciprocal approximation floor (rho=1/2,tau=2/3)',Q(1,4)*Q(1,2)*Q(2,3),Q(1,12))
    rows.append(('bidisk_obstruction','rho=1/2, q=1/2','a=1/3', 'minimum max error = 1/12'))

    # Nonlinear coordinate-conserving residue selection: degrees add mod N.
    check('Nonlinear mod-three product selection', (2+2)%3,1)
    return checks,rows

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path(__file__).resolve().parents[1]/'verification/smith-chart-extended');args=p.parse_args()
    checks,rows=run();args.output.mkdir(parents=True,exist_ok=True)
    data={'scope':'Finite exact rational and algebraic fixtures. Analytic theorem proofs are in the reading edition.',
          'pass':sum(x['passed'] for x in checks),'total':len(checks),'checks':checks}
    (args.output/'results.json').write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
    with (args.output/'worked_values.csv').open('w',newline='',encoding='utf8') as f:
        w=csv.writer(f);w.writerow(['calculation','input','setting','exact_result']);w.writerows(rows)
    print(f"PASS: {data['pass']}/{data['total']} exact checks. Outputs in {args.output}")
if __name__=='__main__': main()
