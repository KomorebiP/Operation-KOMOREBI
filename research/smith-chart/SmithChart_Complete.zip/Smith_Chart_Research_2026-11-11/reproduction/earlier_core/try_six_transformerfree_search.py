#!/usr/bin/env python3
"""HEURISTIC ONLY: search degree-six topology; not an existence/nonexistence proof.
Author: Komorebi P.
"""
import numpy as np
from scipy.optimize import least_squares
import itertools,json,time
from pathlib import Path
rng=np.random.default_rng(53218)
P=np.array([450,1385,2477,2200,1142,335,75.],float)
D=5*np.array([30,159,275,344,250,89,5.],float)
w=np.logspace(-2.1,2.2,15)
ss=np.r_[1j*w,[0.5+0j,2+0j]]
target=np.polyval(P,ss)/np.polyval(D,ss)
weights=1/(1+abs(target))

def solve_net(x,n,edges,react):
    g=np.exp(np.clip(x[:len(edges)],-27,25))
    c=np.exp(np.clip(x[len(edges):],-27,25))
    edge_adm=g[None,:]+np.zeros((len(ss),len(edges)),complex)
    aa=np.zeros((len(ss),n-1,n-1),complex)
    for e,(a,b) in enumerate(edges):
        for i,sgni in ((a,1),(b,-1)):
            if i==0:continue
            for j,sgnj in ((a,1),(b,-1)):
                if j==0:continue
                aa[:,i-1,j-1] +=g[e]*sgni*sgnj
    for v,(type_,ei) in zip(c,react):
        a,b=edges[ei]
        adm=v*ss if type_=='C' else v/ss
        for i,sgni in ((a,1),(b,-1)):
            if i==0:continue
            for j,sgnj in ((a,1),(b,-1)):
                if j==0:continue
                aa[:,i-1,j-1] +=adm*sgni*sgnj
    try:
        vec=np.zeros((len(ss),n-1,1),complex);vec[:,0,0]=1
        sol=np.linalg.solve(aa,vec)
        return sol[:,0,0]
    except np.linalg.LinAlgError:return np.full(len(ss),1e5,dtype=complex)

def residual(x,n,edges,react):
    z=solve_net(x,n,edges,react)
    e=(z-target)*weights
    return np.r_[e.real,e.imag]

res=[];best=1e4; t0=time.monotonic()
for k in range(160):
   n=5 if k<80 else 6
   edges=list(itertools.combinations(range(n),2))
   pos=rng.choice(len(edges),size=6,replace=False)
   nl=2+(k%3)
   react=[(t,int(i)) for t,i in zip(['L']*nl+['C']*(6-nl),pos)]
   x0=rng.normal(0,1.5,size=len(edges)+6)
   opt=least_squares(residual,x0,args=(n,edges,react),max_nfev=330,ftol=1e-10,xtol=1e-10,gtol=1e-10)
   err=float(np.max(abs((solve_net(opt.x,n,edges,react)-target)*weights)))
   record={'network':k,'nodes':n,'err':err,'types':react,'real_parameter_values':list(np.exp(opt.x)),'nfev':opt.nfev}
   if err<best:
       best=err;print('BEST',k,'max scaled error',err,'elapsed',round(time.monotonic()-t0,1),flush=True)
       Path(__file__).with_name('try_six_transformerfree_best.json').write_text(json.dumps(record,indent=2))
   if err<0.005:res.append(record)
   if k%20==19:
       print('completed',k+1,'best=',best,'elapsed=',round(time.monotonic()-t0,1),flush=True)
       Path(__file__).with_name('try_six_transformerfree_search.json').write_text(json.dumps({'status':'numerical heuristic only, no exact solution asserted','best_error':best,'near_misses':res},indent=2))
print('final best',best)
