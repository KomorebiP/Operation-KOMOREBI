#!/usr/bin/env python3
"""Matplotlib-only supporting visuals, author Komorebi P."""
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import AutoMinorLocator
import networkx as nx
P=Path(__file__).parent/'figures';P.mkdir(parents=True,exist_ok=True)
# Exact expression: derivative of M(a,b) with respect to a.
a=np.linspace(0.001,6,600);b=np.linspace(0.001,20,680)
A,B=np.meshgrid(a,b);Z=2*(B+1)**2/(A+B+2)**2
fig,ax=plt.subplots(figsize=(8.4,5.7))
mesh=ax.contourf(A,B,Z,levels=np.linspace(0,2,25),cmap='viridis',extend='max')
con=ax.contour(A,B,Z,levels=[1],linewidths=2.3,colors=['white']);ax.clabel(con,fmt={1:'unit sensitivity bound'},fontsize=9,inline=True)
ax.plot([1],[10],marker='o',markeredgecolor='white',markersize=9)
ax.annotate('Exact witness: (a, b) = (1, 10)\nSensitivity = 242/169 > 1',xy=(1,10),xytext=(2.4,15.7),arrowprops={'arrowstyle':'->'},fontsize=10,ha='left')
ax.set(xlabel='Resistance a (normalized)',ylabel='Resistance b (normalized)',title='Universal resistive-combiner obstruction')
fig.colorbar(mesh,ax=ax,pad=.025,label='∂M(a,b) / ∂a')
ax.grid(alpha=.12);ax.set_xlim(0,6);ax.set_ylim(0,20)
fig.tight_layout();fig.savefig(P/'19_resistive_mixer_obstruction.png',dpi=200);fig.savefig(P/'19_resistive_mixer_obstruction.svg');plt.close(fig)
# Kron graph normal form: resistor-only elimination with exact conductances.
fig,ax=plt.subplots(1,2,figsize=(10.5,4.2))
orig=nx.Graph();orig.add_edges_from([(1,3),(2,3),(0,3),(2,0),(1,0)])
red=nx.Graph();red.add_edges_from([(1,2),(1,0),(2,0)])
pa={0:(-1.05,-1),1:(-1.05,1),2:(1.05,1),3:(0,0)}
pb={0:(-1.05,-1),1:(-1.05,1),2:(1.05,1)}
for panel,G,pos,title in [(ax[0],orig,pa,'Before: resistor-only node 3'),(ax[1],red,pb,'After: Kron reduction')]:
 nx.draw_networkx_nodes(G,pos,ax=panel,node_size=900,node_color='#DFE8DA',edgecolors='#325443')
 nx.draw_networkx_labels(G,pos,ax=panel,font_size=12,font_weight='bold')
 nx.draw_networkx_edges(G,pos,ax=panel,width=2.6,edge_color='#547263')
 panel.set_title(title,fontsize=12,pad=10)
 panel.set_xlim(-1.7,1.7);panel.set_ylim(-1.45,1.5);panel.axis('off')
ax[0].text(.04,.03,'g13 = 2   g23 = 3   g03 = 5\nC20 = 2   h10 = 3',transform=ax[0].transAxes,fontsize=10,ha='left',va='bottom',bbox={'facecolor':'white','alpha':.85,'edgecolor':'none'})
ax[1].text(.04,.03,'g12 = 3/5   g10 = 1   g20 = 3/2\nC20 = 2   h10 = 3',transform=ax[1].transAxes,fontsize=10,ha='left',va='bottom',bbox={'facecolor':'white','alpha':.85,'edgecolor':'none'})
fig.suptitle('The port impedance is exactly unchanged',y=1.02,fontsize=14)
fig.tight_layout();fig.savefig(P/'20_kron_node_elimination.png',dpi=200,bbox_inches='tight');fig.savefig(P/'20_kron_node_elimination.svg',bbox_inches='tight');plt.close(fig)
print('Generated exact-formula visuals 19 and 20')
