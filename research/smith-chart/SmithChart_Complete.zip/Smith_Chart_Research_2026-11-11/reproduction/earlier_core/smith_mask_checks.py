#!/usr/bin/env python3
"""Exact verification of universal cyclic-mask criterion and worked Smith example.
Author: Komorebi P.
Requires SymPy. Finite checks do not replace theorem's proof.
"""
from __future__ import annotations
import json
from pathlib import Path
from sympy import symbols, Rational as Q, I, simplify, conjugate, Matrix, eye

ROOT = Path(__file__).resolve().parent
T = symbols('t', real=True)
a = symbols('a', real=True)
W = [1, I, -1, -I]
UNSAFE_M = [Q(1), Q(1), Q(0), Q(1)]
SAFE_M = [Q(1), Q(1, 2), Q(0), Q(1, 2)]
UNSAFE_W = [Q(3, 4), Q(1, 4), Q(-1, 4), Q(1, 4)]
SAFE_W = [Q(1, 2), Q(1, 4), Q(0), Q(1, 4)]
checks=[]

def check(name, got, expected=0):
    diff=simplify(got-expected)
    success=bool(diff==0)
    checks.append({'name':name,'passed':success,'observed':str(simplify(got)),'expected':str(expected)})
    if not success:
        raise AssertionError(f'{name}: got {got}, expected {expected}; difference {diff}')

def packet_gains(weights):
    return [simplify(sum(weights[k]*W[k]**j for k in range(4))) for j in range(4)]

def weights_from_gains(gains):
    return [simplify(sum(gains[j]*W[k]**(-j) for j in range(4))/4) for k in range(4)]

def apply_weights(f, weights, point):
    return simplify(sum(weights[k]*f(point*W[k]) for k in range(4)))

for typ,m,w in [('unsafe',UNSAFE_M,UNSAFE_W),('safe',SAFE_M,SAFE_W)]:
    for j,(x,y) in enumerate(zip(packet_gains(w),m)):
        check(f'{typ}: forward DFT gain {j}',x,y)
    for k,(x,y) in enumerate(zip(weights_from_gains(m),w)):
        check(f'{typ}: inverse DFT weight {k}',x,y)
    check(f'{typ}: weights sum 1',sum(w),1)
    check(f'{typ}: constant unchanged',apply_weights(lambda z:Q(1),w,T),1)
    for j in range(4):
        check(f'{typ}: monomial degree {j}',apply_weights(lambda z,j=j:z**j,w,T),m[j]*T**j)

check('unsafe: total variation 3/2',sum(abs(x) for x in UNSAFE_W),Q(3,2))
check('safe: total variation 1',sum(abs(x) for x in SAFE_W),1)
check('unsafe: negative rotation weight',UNSAFE_W[2],Q(-1,4))
check('safe: all nonnegative',sum(int(bool(x<0)) for x in SAFE_W),0)
check('hard negative mass',sum(abs(x) for x in UNSAFE_W if x<0),Q(1,4))
check('optimal repair difference',sum(abs(x-y) for x,y in zip(UNSAFE_W,SAFE_W)),Q(1,2))
check('operator excess equals repair cost',sum(abs(x) for x in UNSAFE_W)-1,Q(1,2))
check('Fejer repair zeroes the negative node',SAFE_W[2],0)
check('Fejer preserved probability sum',sum(SAFE_W),1)


f=lambda z:(a+z)/(1+a*z)
rr=Q(99,100); aa=Q(9,10)
original=simplify(f(rr).subs(a,aa))
unsafe=simplify(apply_weights(f,UNSAFE_W,T).subs({a:aa,T:rr}))
safe=simplify(apply_weights(f,SAFE_W,T).subs({a:aa,T:rr}))
check('original at 99/100',original,Q(1890,1891))
check('hard mask exact reflection',unsafe,Q(537154524810,369752957839))
check('safe mask exact reflection',safe,Q(3380183640,3392228971))
check('hard mask exceeds unit bound',int(bool(unsafe>1)),1)
check('safe mask below unit bound',int(bool(-1<safe<1)),1)
check('hard mask negative normalized impedance',simplify((1+unsafe)/(1-unsafe)), Q(-906907482649,167401566971))
check('safe mask positive impedance',int(bool((1+safe)/(1-safe)>0)),1)
check('hard minus safe pointwise error <= norm distance',int(bool(0<unsafe-safe<Q(1,2))),1)

x,y=symbols('x y', real=True)
z=x+I*y
flam=lambda z:(a+z)/(1+a*z)
# Algebraic identity for a disk automorphism; a real and 0<a<1.
check('Blaschke disk identity',simplify((1-flam(z)*conjugate(flam(z)))*((1+a*z)*(1+a*conjugate(z)))
                                            -(1-a*a)*(1-z*conjugate(z))),0)

# Canonical real-analytic (real coefficient) property of the rotated averages.
for w,name in [(UNSAFE_W,'unsafe'),(SAFE_W,'safe')]:
    F=apply_weights(f,w,T)
    check(name+': real rational response on real t',simplify(F-conjugate(F)),0)

z_fun=lambda z:(1+z)/(1-z)
filt_z=simplify(apply_weights(z_fun,SAFE_W,Q(1,2)))
filt_gamma=simplify(apply_weights(lambda z:z,SAFE_W,Q(1,2)))
check('direct positive-real filtering',filt_z,Q(9,5))
check('filtered reflection',filt_gamma,Q(1,4))
check('Cayley of filtered reflection',simplify((1+filt_gamma)/(1-filt_gamma)),Q(5,3))
check('noncommutation at t=1/2',filt_z-(1+filt_gamma)/(1-filt_gamma),Q(2,15))

# Exact identity for an analytic positive-real scalar map z(t): real part
# of a probability-weighted sum is a probability-weighted sum of real parts.
# The general proof is by positivity/convexity, not these finite witnesses.
for r in [Q(0),Q(1,4),Q(1,2),Q(3,4),Q(99,100)]:
    check(f'Fejer positive-real check at t={r}', int(bool(simplify(apply_weights(z_fun,SAFE_W,r))>0)),1)

# Matrix-valued test: reflection function times a fixed unitary matrix.
M=Matrix([[0,1],[1,0]])
# Verify the matrix fixture is unitary before using it in the filtered test.
for i in range(2):
    for j in range(2):
        check(f'matrix unitary fixture ({i},{j})', (M.T*M)[i,j],eye(2)[i,j])
# Compare the filtered responses entrywise.
for i in range(2):
    for j in range(2):
        check(f'matrix filtered equality ({i},{j})',(safe*M)[i,j]-(safe if M[i,j] else Q(0)),0)

n_pass=sum(row['passed'] for row in checks)
result={'author':'Komorebi P.','subject':'Universal cyclic packet masks','passed':n_pass,'total':len(checks),
        'example':{'N':4,'a':'9/10','radius':'99/100','original':str(original),'unsafe_reflection':str(unsafe),
                   'safe_reflection':str(safe),'unsafe_impedance':str(simplify((1+unsafe)/(1-unsafe)))},'checks':checks}
(ROOT/'smith_mask_checks.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(f'PASS: {n_pass}/{len(checks)} exact checks')
for name,value in [('F',original),('T_unsafe F',unsafe),('T_safe F',safe)]:
    print(name, '=', value, '(%.12f)'%float(value))
