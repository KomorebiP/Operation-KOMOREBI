#!/usr/bin/env python3
"""Exact passive six-state Smith-chart combiner derivation.
Author: Komorebi P.
This is an ideal multiport transformer + resistor + RLC construction.
It is NOT a transformer-free RLC synthesis or hardware validation.
"""
from pathlib import Path
import json
import sympy as S
import numpy as np
ROOT=Path(__file__).resolve().parent
s,t,x,u=S.symbols('s t x u',real=True)
Q=S.Rational
checks=[]
def check(name,actual,expected=0):
    residual=S.cancel(actual-expected) if not isinstance(actual,S.MatrixBase) else actual-expected
    if not (residual==S.zeros(*residual.shape) if isinstance(residual,S.MatrixBase) else residual==0): raise AssertionError(name+' residual='+str(residual))
    checks.append({'test':name,'passed':True})
def condition(name,truth):
    if not bool(truth):raise AssertionError(name)
    checks.append({'test':name,'passed':True})

f=lambda w:((2*w+1)*(3*w+1))/((w+2)*(w+3))
F=S.factor(f(t))
H=S.factor((f(S.I*t)+f(-S.I*t))/2)
G=S.factor(Q(1,2)*(F+H))
T=(s-1)/(s+1)
z=lambda g:S.factor((1+g)/(1-g))
check('Conjugate rotation sum has real rational polynomial',H,6*(1-t*t)**2/((t*t+4)*(t*t+9)))
check('Filtered three rotation decomposition',G,Q(1,2)*F+Q(1,2)*H)
check('F is a two-state lossless series LC',z(F.subs(t,T)),Q(6,5)*s+1/(5*s))

# H(t) is a four-state passive branch: a lossless LC parallel tank
# in series with a 1-ohm-normalized shunt resistor, across a lossy series RLC.
lt,ct=Q(48,35),Q(35,48)
rs,ls,cs=Q(25,24),Q(35,48),Q(48,35)
tank=1/(1/(lt*s)+ct*s)
series_rlc=rs+ls*s+1/(cs*s)
shunt=1/(1+1/series_rlc)
zH=S.factor(tank+shunt)
zH_poly=(25*s**4+70*s**3+146*s**2+70*s+25)/(5*(s*s+1)*(5*s*s+14*s+5))
check('Tank has exact parallel LC rational form',tank,Q(48,35)*s/(s*s+1))
check('RLC series branch shunted by unit resistor',shunt,5*(7*s*s+10*s+7)/(7*(5*s*s+14*s+5)))
check('H composite network equals conjugate packet Cayley impedance',zH,z(H.subs(t,T)))
check('H has exact polynomial formula',zH,zH_poly)
check('H exact decomposition via lossless and dissipative term',zH,1+Q(48,35)*s/(s*s+1)-Q(48,7)*s/(5*s*s+14*s+5))
numH,denH=S.fraction(S.cancel(zH_poly))
condition('H numerator and denominator are coprime',S.gcd(numH,denH)==1)
condition('H has reduced degree four',S.degree(numH,s)==4 and S.degree(denH,s)==4)
for nm,val in [('Lt',lt),('Ct',ct),('Rs',rs),('Ls',ls),('Cs',cs)]:condition('Positive RLC element '+nm,val>0)

# Scattering coupler for three equal-normalized ports: an ideal bright-mode
# transformer plus a matched dark-mode resistor. All ports use same Z0.
k=1/S.sqrt(2)
Sm=S.Matrix([[0,k,k],[k,0,0],[k,0,0]])
E=S.eye(3)-Sm.T*Sm
check('Coupler real symmetric reciprocity',Sm,Sm.T)
check('Coupler dissipates only dark mode',E,S.Matrix([[0,0,0],[0,Q(1,2),-Q(1,2)],[0,-Q(1,2),Q(1,2)]]))
check('Coupler scattering passivity spectrum',S.det(E),0)
condition('Coupler passivity E is rank-one PSD',E.rank()==1 and (E[1,1]>0) and (E[2,2]>0))
check('Coupler short circuit in output-output scattering',Sm[1,1]+Sm[1,2]+Sm[2,1]+Sm[2,2],0)
# Full terminated reflection: S00+S0L diag(F,H) (I-SLL diag)^(-1) SL0.
Gammas=S.diag(F,H)
S0L=S.Matrix([[Sm[0,1],Sm[0,2]]])
SL0=S.Matrix([[Sm[1,0]],[Sm[2,0]]])
SLL=Sm[1:3,1:3]
Gin=S.factor((S0L*Gammas*(S.eye(2)-SLL*Gammas).inv()*SL0)[0])
check('Terminated one-port reflection is exact Fejer target',Gin,G)
A,B=S.symbols('A B')
ZA,ZB=S.symbols('ZA ZB')
check('General bimodal reflection-to-impedance formula',
      z(( (ZA-1)/(ZA+1) + (ZB-1)/(ZB+1) )/2),
      (2*ZA*ZB+ZA+ZB)/(ZA+ZB+2))
zF=z(F.subs(t,T))
zG=z(G.subs(t,T))
zG_composition=S.factor((2*zF*zH+zF+zH)/(zF+zH+2))
check('Realization composition obeys exact impedance identity',zG,zG_composition)
P=450*s**6+1385*s**5+2477*s**4+2200*s**3+1142*s*s+335*s+75
D=5*(30*s**6+159*s**5+275*s**4+344*s**3+250*s*s+89*s+5)
check('Final combined six-state impedance equals degree-six target',zG,P/D)
condition('Final numerator denominator are coprime',S.gcd(P,D)==1)
condition('Combined minimal dynamic order exactly six',S.degree(P,s)==6 and S.degree(D,s)==6)
check('DC impedance of combined network',zG.subs(s,0),3)
check('High frequency impedance of combined network',S.limit(zG,s,S.oo),3)

# Transformer/resistor terminal model and power identity.
v0,v1,v2,i0,i1,i2,Z0=S.symbols('v0 v1 v2 i0 i1 i2 Z0',real=True)
# Bright transformer: v0=(v1+v2)/sqrt2, i0=-(i1+i2)/sqrt2;
# dark resistor of 2 Z0 between physical output terminals 1 and 2:
# i1-i2=(v1-v2)/Z0.
itrans=-(i1+i2)/S.sqrt(2)
vtrans=(v1+v2)/S.sqrt(2)
power=S.factor((v0*i0+v1*i1+v2*i2).subs({v0:vtrans,i0:itrans}).subs(i1,(i1+i2)/2+(v1-v2)/(2*Z0)))
# Direct independent modal power certificate: v_d i_d=(v1-v2)^2/(2Z0).
check('Power dissipation under transformer and bridge-resistor constraints',
      S.factor((vtrans*itrans+v1*i1+v2*i2).subs(i1,i2+(v1-v2)/Z0)),
      (v1-v2)**2/(2*Z0))

# Strong frequency-uniform passivity certificate, using Bernstein positivity
# on [-2,0] and [0,2] for x=t+t^{-1}=2cos(theta).
num,den=S.fraction(S.together(G))
def edge_energy(poly):
    p=S.expand(poly*poly.subs(t,1/t))
    n=S.degree(poly,t)
    coeff=lambda j:p.coeff(t,j)
    result=coeff(0)
    for j in range(1,n+1):result+=2*coeff(j)*S.chebyshevt(j,x/2)
    return S.factor(result)
mod_num=edge_energy(num)
mod_den=edge_energy(den)
N=864*x**6+5040*x**5+11538*x**4+2555*x**3-28126*x*x-3360*x+57600
Dd=4*(2*x+5)*(3*x+10)*(4*x*x+9)*(9*x*x+64)
check('Schur boundary squared numerator',mod_num,N)
check('Schur boundary squared denominator',mod_den,Dd)
check('Boundary power gap factorization',Dd-N,75*(50*x**4+595*x**3+1458*x*x+1120*x+768))
B=S.factor(Q(16,25)*Dd-N)
berstein=[]
for lo,hi,n in [(-2,0,8),(0,2,6)]:
    pp=S.Poly(S.expand(B.subs(x,lo+(hi-lo)*u)),u)
    d=pp.degree();co=[pp.nth(j) for j in range(d+1)]
    cc=[S.factor(sum(co[j]*S.binomial(ii,j)/S.binomial(n,j) for j in range(min(ii,d)+1))) for ii in range(n+1)]
    condition(f'All exact Bernstein coefficients positive on [{lo},{hi}] elevated degree {n}',all(c>0 for c in cc))
    check(f'Bernstein reconstruction exact on [{lo},{hi}]',
          S.expand(sum(cc[j]*S.binomial(n,j)*u**j*(1-u)**(n-j) for j in range(n+1))),
          S.expand(B.subs(x,lo+(hi-lo)*u)))
    berstein.append({'interval':[lo,hi],'degree':n,'min_coeff':str(min(cc)),
                     'coefficients':[str(c) for c in cc]})
# 4/5 bound strictly for |t|=1 then by maximum modulus on |t|<=1.
# Therefore Re zG>=(1-r)/(1+r)=1/9 in normalized units.
check('Cayley resistance margin r=4/5', (1-Q(4,5))/(1+Q(4,5)),Q(1,9))

# Float grid only corroborates the exact identities; never used to decide proof.
ww=np.linspace(0,np.pi,8001)
f_fun=S.lambdify(t,F,'numpy');h_fun=S.lambdify(t,H,'numpy');g_fun=S.lambdify(t,G,'numpy')
vals=np.exp(1j*ww)
maxabs=float(np.max(np.abs(g_fun(vals))))
assert maxabs<.8,maxabs
freq=np.r_[0,np.geomspace(1e-5,1e5,1500)]
ss=1j*freq
zF_func=S.lambdify(s,zF,'numpy');zH_func=S.lambdify(s,zH,'numpy');zG_func=S.lambdify(s,zG,'numpy')
# At s=0 branch zF(s) has physical infinity; compare directly using reflection.
rr=ss[1:]
zFv=zF_func(rr);zHv=zH_func(rr)
zcomposed=(2*zFv*zHv+zFv+zHv)/(zFv+zHv+2)
zdirect=zG_func(rr)
scaled_err=float(np.max(np.abs(zcomposed-zdirect)/(1+np.abs(zdirect))))
assert scaled_err<5e-9,scaled_err
summary={
    'author':'Komorebi P.',
    'status':'unpublished; ideal static transformer-and-resistor combiner plus exactly 6 RLC energy-storage elements, not a transformer-free RLC-only netlist',
    'checks':len(checks),'all_passed':True,'details':checks,
    'H_realization':{'L_tank':'48/35','C_tank':'35/48','R_shunt':'1','R_series':'25/24','L_series':'35/48','C_series':'48/35'},
    'F_realization':{'L_series':'6/5','C_series':'5'},
    'coupler_scattering':str(Sm),
    'bridge_resistance_reference_units':'2',
    'degree':{'F':2,'H':4,'G':6},
    'universal_reflection_bound':'abs(G)<=4/5 on closed disk',
    'uniform_input_resistance_bound':'Re z >= 1/9 on Re s>=0',
    'bernstein_certificates':berstein,
    'numerical_sanity':{'grid_points':len(freq)-1,'max_relative_impedance_error':scaled_err,'sampled_max_abs_reflection':maxabs},
    'remaining_gap':'Produce an explicit transformer-free resistor-inductor-capacitor one-port with exactly 6 reactive elements and check robustness under tolerances.'
}
(ROOT/'smith_six_state_checks.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print('EXACT CHECKS',len(checks),'PASS')
print('H(s)=',zH)
print('Zsix(s)=',zG)
print('Bernstein minimum coefficients:',[(q['interval'],q['min_coeff']) for q in berstein])
print('grid max scaled error=',scaled_err,'sample max abs reflection=',maxabs)
