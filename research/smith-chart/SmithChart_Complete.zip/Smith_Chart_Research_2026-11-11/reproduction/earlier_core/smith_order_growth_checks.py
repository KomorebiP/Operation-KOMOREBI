#!/usr/bin/env python3
"""Exact algebraic tests for cyclic-order growth and dissipation.

Author: Komorebi P.
Assumptions and proofs are recorded in order_growth_section.md.
This script is a symbolic regression suite, not a formal proof assistant.
"""
from __future__ import annotations
from pathlib import Path
import json
import numpy as np
import sympy as sp

ROOT = Path(__file__).resolve().parent
s,t,a,x = sp.symbols('s t a x',real=True)
q=sp.Rational
checks=[]
def check(name,actual,expected=0):
    if sp.simplify(actual-expected)!=0:
        raise AssertionError(f'{name}: computed {sp.factor(actual)}, expected {sp.factor(expected)}')
    checks.append({'name':name,'status':'passed','actual':str(sp.factor(actual)) if len(str(actual))<160 else '[long exact expression]'})

def frac(z):
    return sp.fraction(sp.cancel(z))
def f(u,v):return (u+v)/(1+u*v)
def fil(h):return sp.Rational(1,2)*h+sp.Rational(1,4)*(h.subs(t,sp.I*t)+h.subs(t,-sp.I*t))
def halfplane(h):return sp.cancel(h.subs(t,(s-1)/(s+1)))
def impedance(h):return sp.cancel((1+h)/(1-h))

Fa=f(a,t)
G=sp.factor(fil(Fa))
G_closed=(2*a+(1+a*a)*t+a*(1+a*a)*t*t+2*a*a*t**3)/(2*(1+a*t)*(1+a*a*t*t))
check('closed form of three-rotation Fejer Schur function',G,G_closed)

N=(3*a*a+2*a+3)*s**3+7*(1-a*a)*s**2+(5*a*a-2*a+5)*s+(1-a*a)
D=(1-a*a)*s**3+(5*a*a+2*a+5)*s**2+7*(1-a*a)*s+(3*a*a-2*a+3)
za=(1+a)*N/((1-a)*D)
check('general parametric filtered impedance',impedance(halfplane(G)),za)
check('input inductive impedance',impedance(halfplane(Fa)),(1+a)*s/(1-a))
check('exact cubic numerator denominator resultant',sp.resultant(N,D,s),131072*a**6)
quartic=7*a**4+44*a**3+330*a*a+44*a+7
check('exact denominator cubic discriminant',sp.discriminant(D,s),-64*a*a*quartic)
check('quartic positive sum of squares',quartic,7*(a*a+1+sp.Rational(22,7)*a)**2+sp.Rational(1728,7)*a*a)

# Real-rational Hurwitz property from the cubic Routh condition.
B=5*a*a+2*a+5; C=7*(1-a*a); A=1-a*a; D0=3*a*a-2*a+3
check('denominator Hurwitz determinant',sp.expand(B*C-A*D0),16*(1-a*a)*(2*a*a+a+2))
check('positive Routh quadratic',2*a*a+a+2,2*(a+sp.Rational(1,4))**2+sp.Rational(15,8))

# Sharp positive-real boundary identity, with |D_a(i w)|^2 denominator.
Ni=(1+a)*N.subs(s,sp.I*x)
Di=(1-a)*D.subs(s,sp.I*x)
Re_num=sp.factor((Ni*sp.conjugate(Di)+sp.conjugate(Ni)*Di)/2)
PR_num=(1-a*a)**2*(1+x*x)**2*((3*a*a+2*a+3)*x*x+(3*a*a-2*a+3))
check('strict boundary positive-real numerator',Re_num,PR_num)
check('positive quadratic at high frequency',3*a*a+2*a+3,3*(a+sp.Rational(1,3))**2+sp.Rational(8,3))
check('positive quadratic at zero frequency',3*a*a-2*a+3,3*(a-sp.Rational(1,3))**2+sp.Rational(8,3))

# Special state-collapse case and exact duality.
z0=sp.factor(za.subs(a,0))
check('a=0 two-factor cancellation',z0,(3*s+1)/(s+3))
check('a=1/3 matches previously synthesized cubic',za.subs(a,q(1,3)),(9*s**3+14*s**2+11*s+2)/(s**3+7*s*s+7*s+3))
check('frequency inversion and impedance reciprocal duality',za.subs(a,-a),1/za.subs(s,1/s))
check('a=0 reduces to one RL branch',z0,q(1,3)+(q(8,3)*q(8,9)*s)/(q(8,3)+q(8,9)*s))

# Lossless degree-two LC initial response and its degree-six filtered impedance.
F2=sp.factor(f(q(1,3),t)*f(q(1,2),t))
z2=impedance(halfplane(F2))
check('degree-two allpass reflection',F2,(2*t+1)*(3*t+1)/((t+2)*(t+3)))
check('original lossless series LC',z2,(6*s*s+1)/(5*s))
G2=sp.factor(fil(F2))
Z2=impedance(halfplane(G2))
P2=450*s**6+1385*s**5+2477*s**4+2200*s**3+1142*s*s+335*s+75
D2=30*s**6+159*s**5+275*s**4+344*s**3+250*s*s+89*s+5
check('exact degree-six Fejer LC output',Z2,P2/(5*D2))
check('LC filter output denominator irreducibility by gcd degree',sp.degree(sp.gcd(P2,D2),s),0)
check('LC filtered DC normalization',Z2.subs(s,0),3)
check('LC filtered high-frequency normalization',sp.limit(Z2,s,sp.oo),3)
check('unital rotation weights',q(1,2)+q(1,4)+q(1,4),1)
check('four-phase first harmonic multiplier',q(1,2)+q(1,4)*sp.I+q(1,4)*(-sp.I),q(1,2))
check('phase-distance variance',1-q(1,2)**2,q(3,4))
check('at a=1/3 guaranteed 1-minus-abs-G-square margin',q(3,4)*((1-q(1,3))/(1+q(1,3)))**2,q(3,16))
check('at a=1/3 guaranteed normalized resistance',q(3,16)/4,q(3,64))

# Rotation-pole residues for general real a with |a|<1 and a != 0.
check('Blaschke partial-fraction identity',Fa,1/a+((a*a-1)/a)/(1+a*t))
for k,lam,weight in [(0,sp.Integer(1),q(1,2)),(1,sp.I,q(1,4)),(3,-sp.I,q(1,4))]:
    residual=sp.factor(sp.limit((t+1/(a*lam))*weight*f(a,lam*t),t,-1/(a*lam)))
    check(f'rotation {k} has nonzero symbolic pole residue',residual,weight*(a*a-1)/(a*a*lam))

# An exact sharp H-infinity certificate for the previously synthesized a=1/3 case.
# On |t|=1 put X=t+t^-1=2cos(theta), so -2<=X<=2.
X=sp.symbols('X',real=True)
Fa13=sp.factor(G.subs(a,q(1,3)))
num13,den13=sp.fraction(Fa13)
def boundary_laurent(expr):
    expr=sp.expand(expr*expr.subs(t,1/t))
    c=lambda j:sp.expand(expr).coeff(t,j)
    return sp.factor(c(0)+c(1)*X+c(2)*(X*X-2)+c(3)*(X**3-3*X))
module=sp.factor(boundary_laurent(num13)/boundary_laurent(den13))
num_mod=27*X**3+90*X**2+144*X+160
den_mod=(3*X+10)*(9*X*X+64)
check('closed boundary reflection squared modulus at a=1/3',module,num_mod/den_mod)
check('sharp 4/5 reflection bound factorization',q(16,25)*den_mod-num_mod,q(3,25)*(2-X)*((9*X+24)**2+464))
check('sharp bound equality at t=1',module.subs(X,2),q(16,25))
check('DC resistor value for synthesized cubic',za.subs(a,q(1,3)).subs(s,0),q(2,3))
xo=sp.symbols('xo',real=True,nonnegative=True)
Domega=(3-7*xo)**2+xo*(7-xo)**2
Nomega=3*(1+xo)**2*(2+3*xo)
check('sharp Re z(jw)>=2/3',3*Nomega-2*Domega,xo*(25*xo*xo+2*xo+49))
# Independent real-axis positive-real certificate for the filtered series LC.
H=900*xo**4-323*xo**3-141*xo**2+307*xo+25
re_lc_num=sp.factor((P2.subs(s,sp.I*x)*D2.subs(s,-sp.I*x)+P2.subs(s,-sp.I*x)*D2.subs(s,sp.I*x))/2)
check('LC boundary positive-real numerator',re_lc_num,15*(1+x*x)**2*H.subs(xo,x*x))
bern=[25,q(407,4),155,104,768]
check('LC quartic 0<=x<=1 Bernstein positivity expansion',H,sp.Add(*[bern[j]*sp.binomial(4,j)*xo**j*(1-xo)**(4-j) for j in range(5)]))
y=sp.symbols('y',real=True,nonnegative=True)
check('LC quartic x>=1 shifted positive coefficients',H.subs(xo,1+y),900*y**4+3277*y**3+4290*y*y+2656*y+768)

# A degree-one passive approximant, with sharp all-disk H-infinity reflection error.
b=(1-a*a)/2
H=a+b*t
check('first-order Fejer mode matching',sp.diff(G,t).subs(t,0),(1-a*a)/2)
check('affine Schur approximant at origin',H.subs(t,0),a)
check('exact rational remainder',G-H,a*a*(1-a*a)*t**3*(1-a*t)/(2*(1+a*t)*(1+a*a*t*t)))
for n,m in [(1,sp.Rational(1,2)),(2,0),(3,sp.Rational(1,2)),(4,1),(5,sp.Rational(1,2)),(6,0),(7,sp.Rational(1,2)),(8,1)]:
    actual=sp.simplify(sp.Rational(1,2)+sp.Rational(1,4)*(sp.I**n+(-sp.I)**n))
    check(f'Fourier Fejer multiplier m_{n}',actual,m)
r=sp.symbols('r',real=True,positive=True)
exact_error=r*r*(1+r)**2/(2*(1+r*r))
series_error=(1-r*r)*(r*r/2+r**3+r**4/2)/(1-r**4)
check('closed geometric-series sharp reflection error',series_error,exact_error)
check('Schur radius gap of one-state approximant',1-r-(1-r*r)/2,(1-r)**2/2)
check('sharp reflection error at a=1/3',exact_error.subs(r,sp.Rational(1,3)),sp.Rational(4,45))
check('sharp reflection error at a=1/10',exact_error.subs(r,sp.Rational(1,10)),sp.Rational(121,20200))

ZH=impedance(halfplane(H))
ZHclosed=((1+a+b)*s+(1+a-b))/((1-a-b)*s+(1-a+b))
check('degree-one positive-real impedance',ZH,ZHclosed)
rs=(1+a)**2/((1-a)*(a+3))
rp=8*(1+a)/((1-a)**2*(a+3))
ell=8*(1+a)/((1-a)*(a+3)**2)
check('exact series R + parallel RL approximant',ZH,rs+rp*ell*s/(rp+ell*s))
check('example approximant impedance at a=1/3',ZH.subs(a,sp.Rational(1,3)),(8*s+4)/(s+5))
check('example one-reactive normalized Rs',rs.subs(a,sp.Rational(1,3)),sp.Rational(4,5))
check('example one-reactive normalized Rp',rp.subs(a,sp.Rational(1,3)),sp.Rational(36,5))
check('example one-reactive normalized inductor',ell.subs(a,sp.Rational(1,3)),sp.Rational(36,25))
check('example reflection error saturation at t=-1',abs(sp.factor((G-H).subs(a,sp.Rational(1,3)).subs(t,-1))),sp.Rational(4,45))

# Exact absolute impedance error in normalized ohms: sharp H-infinity norm = 1.
zfull=za.subs(a,sp.Rational(1,3))
zh=ZH.subs(a,sp.Rational(1,3))
zdiff=sp.factor(zfull-zh)
check('factorization of exact one-state impedance error',zdiff,(s-1)**3*(s+2)/((s+5)*(s**3+7*s*s+7*s+3)))
qomega=sp.symbols('qomega',nonnegative=True,real=True)
check('sharp normalized impedance error frequency gap',
      (qomega+25)*(qomega**3+35*qomega**2+7*qomega+9)-(qomega+1)**3*(qomega+4),
      53*qomega**3+867*qomega*qomega+171*qomega+221)
check('sharp impedance error limit at infinite frequency',sp.limit(zdiff,s,sp.oo),1)

# Numerical cross-checks separated from exact symbolic tests.
frequencies=np.r_[0,np.geomspace(1e-6,1e6,3001)]
ss=1j*frequencies
T=(ss-1)/(ss+1)
fej=lambda H: .5*H(T)+.25*H(1j*T)+.25*H(-1j*T)
ind=lambda z0,U:(z0+U)/(1+z0*U)
LC=lambda U:ind(1/3,U)*ind(1/2,U)
GG=fej(LC)
Znum=(1+GG)/(1-GG)
Zpoly=np.polyval([450,1385,2477,2200,1142,335,75],ss)/(5*np.polyval([30,159,275,344,250,89,5],ss))
max_residual=float(np.max(abs(Znum-Zpoly)/(1+abs(Zpoly))))
assert max_residual < 2e-10,max_residual
assert np.all(Znum.real > 0)
margin_a=q(1,3)
W=np.exp(1j*np.linspace(0,2*np.pi,4001))
G1=.5*ind(float(margin_a),W)+.25*(ind(float(margin_a),1j*W)+ind(float(margin_a),-1j*W))
certified_delta=float(q(3,16))
assert np.min(1-np.abs(G1)**2)>=certified_delta-1e-10
assert np.min((1+G1).real*0+np.real((1+G1)/(1-G1)))>=float(q(3,64))-1e-10

result={
    'author':'Komorebi P.',
    'scope':'Exact algebraic fixtures plus finite frequency/boundary samples; not Lean formal proof or hardware validation.',
    'symbolic_checks':len(checks),
    'symbolic_status':'all passed',
    'details':checks,
    'LC_numeric_grid_size':len(ss),
    'LC_numeric_max_scaled_error':max_residual,
    'LC_numeric_min_real_impedance':float(Znum.real.min()),
    'Fejer_a_1_over_3_boundary_samples':len(W),
    'Fejer_a_1_over_3_boundary_min_1_minus_abs_G_sq':float(np.min(1-np.abs(G1)**2)),
    'rigorous_a_1_over_3_lower_bound':str(q(3,16)),
    'physical_spice_simulation':'not performed',
    'approximation_example_max_reflection_error':'4/45',
    'approximation_example_max_impedance_error_in_Z0_units':'1',
}
(ROOT/'smith_order_growth_checks.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(f"PASS {len(checks)}/{len(checks)} exact assertions")
print('LC filtered degree 6, numeric max scaled error',max_residual)
print('LC min sampled normalized resistance',Znum.real.min())
print('Fejer a=1/3 min sampled boundary variance',np.min(1-np.abs(G1)**2))
