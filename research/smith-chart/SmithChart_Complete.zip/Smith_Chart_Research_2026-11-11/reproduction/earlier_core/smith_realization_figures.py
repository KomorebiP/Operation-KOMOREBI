#!/usr/bin/env python3
"""Render original mathematical Smith-chart and passive-circuit diagrams.
Author: Komorebi P. All artwork is generated with Python/Matplotlib.
"""
from pathlib import Path
import json
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, Rectangle, Arc
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'figures'; OUT.mkdir(exist_ok=True)
vals=json.loads((ROOT/'smith_realization_checks.json').read_text())['normalized_components']
R1=vals['R_parallel_1'];L1=vals['L_parallel_1'];Rs=vals['R_series'];Rp=vals['R_parallel_2'];Rl=vals['R_series_inductor'];L=vals['L_series_inductor'];C=vals['C_shunt']
fg='#162e41'; metal='#406176'; accent='#116d78'; gold='#b26425'; dash='#a8b9c4'; purple='#6f538f'
plt.rcParams.update({'font.size':10,'font.family':'DejaVu Sans','svg.fonttype':'none','savefig.facecolor':'white','axes.edgecolor':metal,'axes.labelcolor':fg,'text.color':fg})


def wire(ax,xa,ya,xb,yb,clr=fg,lw=2):ax.plot([xa,xb],[ya,yb],c=clr,lw=lw,solid_capstyle='round')
def node(ax,x,y):ax.add_patch(Circle((x,y),.052,color=fg,zorder=10))
def resistor(ax,xa,xb,y,label):
  xm=(xa+xb)/2; width=.85
  wire(ax,xa,y,xm-width/2,y);wire(ax,xm+width/2,y,xb,y)
  ax.add_patch(Rectangle((xm-width/2,y-.16),width,.32,edgecolor=fg,facecolor='#e5f0f2',linewidth=1.7,zorder=5))
  ax.text(xm,y+.33,label,ha='center',va='bottom',size=10,weight='semibold')
def inductor(ax,xa,xb,y,label):
  xm=(xa+xb)/2;w=1.16
  wire(ax,xa,y,xm-w/2,y);wire(ax,xm+w/2,y,xb,y)
  start=xm-w/2
  for k in range(4):ax.add_patch(Arc((start+(k+.5)*w/4,y),width=w/4,height=.40,theta1=0,theta2=180,linewidth=1.9,color=fg))
  ax.text(xm,y+.33,label,ha='center',va='bottom',size=10,weight='semibold')
def capacitor(ax,xa,xb,y,label):
  xm=(xa+xb)/2
  wire(ax,xa,y,xm-.1,y);wire(ax,xm+.1,y,xb,y)
  wire(ax,xm-.10,y-.33,xm-.10,y+.33,clr=fg,lw=2)
  wire(ax,xm+.10,y-.33,xm+.10,y+.33,clr=fg,lw=2)
  ax.text(xm,y+.49,label,ha='center',va='bottom',size=10,weight='semibold')

def schematic():
 fig,ax=plt.subplots(figsize=(15.2,5.9));fig.patch.set_facecolor('white');ax.set_aspect('equal')
 ax.set_xlim(0,15.6);ax.set_ylim(-2.35,3.3);ax.axis('off')
 ax.text(.3,3.1,'Transformer-free passive realization of the filtered reflection response',size=16,weight='bold')
 ax.text(.3,2.72,'Seven components   •   two inductors + one capacitor   •   three reactive states',size=11,color=metal)
 # inlet to first parallel stage
 wire(ax,.3,0,1.05,0);ax.add_patch(Circle((.3,0),.085,edgecolor=fg,facecolor='white',linewidth=2))
 for y in [0.85,-.85]:wire(ax,1.05,0,1.05,y);wire(ax,4.25,y,4.25,0)
 resistor(ax,1.05,4.25,.85,f'r₁ = {R1:.4f}')
 inductor(ax,1.05,4.25,-.85,f'ℓ₁ = {L1:.4f}')
 wire(ax,4.25,0,4.68,0)
 resistor(ax,4.68,6.38,0,f'rₛ = {Rs:.4f}')
 wire(ax,6.38,0,6.83,0)
 # three-branch second block
 for y in [1.4,-1.4]:wire(ax,6.83,0,6.83,y);wire(ax,14.6,y,14.6,0)
 resistor(ax,6.83,14.6,1.4,f'rₚ = {Rp:.4f}')
 wire(ax,6.83,0,7.15,0)
 resistor(ax,7.15,9.42,0,f'rℓ = {Rl:.4f}')
 wire(ax,9.42,0,10.0,0)
 inductor(ax,10.0,14.6,0,f'ℓ₂ = {L:.4f}')
 capacitor(ax,6.83,14.6,-1.4,f'c = {C:.4f}')
 wire(ax,14.6,0,15.22,0);ax.add_patch(Circle((15.22,0),.085,edgecolor=fg,facecolor='white',linewidth=2))
 for x,y in [(1.05,0),(4.25,0),(6.83,0),(14.6,0)]:node(ax,x,y)
 ax.text(2.65,-2.08,'Block A: R || L',ha='center',weight='semibold',color=accent)
 ax.text(10.7,-2.08,'Block B: R || (R + L) || C',ha='center',weight='semibold',color=accent)
 ax.text(0.3,-2.44,'Dimensionless elements:  r = R/Z₀,  ℓ = L/(Z₀τ),  c = C Z₀/τ.  Blocks A, rₛ and B connect in series.',size=9,color=metal)
 fig.tight_layout(rect=[0,0,1,.99]);return fig

def freq_and_disk():
 w=np.r_[0,np.geomspace(1e-4,1e3,1200)]
 ss=1j*w
 tt=(ss-1)/(ss+1)
 F=(1/3+tt)/(1+tt/3)
 FF=.5*F + .25*((1/3+1j*tt)/(1+1j*tt/3)+(1/3-1j*tt)/(1-1j*tt/3))
 Z=(9*ss**3+14*ss**2+11*ss+2)/(ss**3+7*ss**2+7*ss+3)
 fig,axs=plt.subplots(1,2,figsize=(13.2,5.6),gridspec_kw={'width_ratios':[1,1.18]})
 ax=axs[0];theta=np.linspace(0,2*np.pi,800);ax.plot(np.cos(theta),np.sin(theta),c=fg,lw=1.3,label='|Γ| = 1 boundary')
 ax.axhline(0,color=dash,lw=.8);ax.axvline(0,color=dash,lw=.8)
 ax.plot(F.real,F.imag,c=gold,lw=2.5,alpha=.85,label='Original ideal inductance')
 ax.plot(FF.real,FF.imag,c=accent,lw=2.7,label='Safe Fejér reconstruction')
 for ii in [0,100,400,850]: ax.scatter(FF[ii].real,FF[ii].imag,s=26,c=accent,edgecolors='white',linewidths=.8,zorder=4)
 ax.set_xlim(-1.12,1.12);ax.set_ylim(-1.15,1.15);ax.set_aspect('equal');ax.set_xlabel('Real Γ(jω)');ax.set_ylabel('Imaginary Γ(jω)');ax.set_title('Reflection is strictly inside the disk',weight='semibold',size=12)
 ax.legend(loc='lower left',fontsize=8,framealpha=.9)
 ax=axs[1];ax.semilogx(w[1:],Z.real[1:],c=accent,lw=2.7,label='Re zFej(jω)')
 ax.axhline(0,c=gold,ls='--',lw=1.4,label='Re zoriginal(jω) = 0')
 ax.axhline(2/3,c=dash,ls=':',lw=1.1,label='DC resistance = 2/3')
 ax.set_xlim(w[1],w[-1]);ax.set_ylim(-.4,9.5)
 ax.grid(alpha=.24,which='both');ax.set_xlabel('Dimensionless angular frequency ωτ');ax.set_ylabel('Normalized resistance Re Z/Z₀')
 ax.set_title('Lossless input acquires dissipation',size=12,weight='semibold');ax.legend(loc='upper left',fontsize=9)
 fig.suptitle('Passivity is retained, but the physical response and required storage change',weight='bold',size=15,y=1.01)
 fig.tight_layout();return fig

for base,make in [('11_exact_passive_rlc_schematic',schematic),('12_smith_disk_and_passivity_trace',freq_and_disk)]:
 fig=make();fig.savefig(OUT/f'{base}.svg',bbox_inches='tight',pad_inches=.16);fig.savefig(OUT/f'{base}.png',dpi=185,bbox_inches='tight',pad_inches=.16);plt.close(fig)
 print('CREATED',base)
