#!/usr/bin/env python3
"""Independent numerical AC cross-check and optional SPICE netlist emission.
Author: Komorebi P. Does not invoke SPICE; algebraic identity is checked in
smith_realization_checks.py. Uses NumPy and built-in JSON.
"""
import json
from pathlib import Path
import numpy as np

root=Path(__file__).resolve().parent
v=json.loads((root/'smith_realization_checks.json').read_text())['normalized_components']
ra=v['R_parallel_1']; la=v['L_parallel_1']; rs=v['R_series'];rp=v['R_parallel_2'];rl=v['R_series_inductor'];lb=v['L_series_inductor'];cb=v['C_shunt']
Z0=50.0;tau=1e-9
freqs=np.r_[0.0,np.geomspace(1e5,1e11,1400)]
s=1j*(2*np.pi*freqs*tau)
# Independent branch admittance formulas; limit s->0 correctly.
a=ra*la*s/(ra+la*s)
b=1/(1/rp+1/(rl+lb*s)+cb*s)
z_circuit=a+rs+b
z_target=(9*s**3+14*s**2+11*s+2)/(s**3+7*s**2+7*s+3)
err=np.abs(z_circuit-z_target)
rel=err/(1+np.abs(z_target))
gamma=(z_circuit-1)/(z_circuit+1)
assert np.max(rel)<2e-12, ('Numeric network response mismatch',float(np.max(rel)))
assert np.min(z_circuit.real)>0,('Nonpositive real part',float(np.min(z_circuit.real)))
assert np.max(abs(gamma))<1,('Nonpassive reflection amplitude',float(np.max(abs(gamma))))
phys={'R1_ohm':ra*Z0,'L1_nH':la*Z0*tau*1e9,'Rs_ohm':rs*Z0,
      'Rp_ohm':rp*Z0,'Rell_ohm':rl*Z0,'Lell_nH':lb*Z0*tau*1e9,
      'C2_pF':cb*tau/Z0*1e12}
netlist=f'''* Smith chart: minimal reactive-order Fejer-filtered inductor
* Author: Komorebi P.
* Reference impedance Z0 = {Z0:g} Ohm, tau = {tau*1e9:g} ns.
* Original impedance: Z_original = 2 Z0 tau s_phys = 100 nH ideal L.
* The filtered response is a DIFFERENT passive one-port.
* Its driving impedance is Z0 * (9s^3+14s^2+11s+2)/(s^3+7s^2+7s+3), s=tau*s_phys.
* Input AC current 1 A, direction from ground to input; V(in) is Z(in).
Itest 0 in 0 AC 1
* Block A: resistor || inductor
R1 in n1 {phys['R1_ohm']:.12g}
L1 in n1 {phys['L1_nH']:.12g}n
* Series resistor
Rs n1 n2 {phys['Rs_ohm']:.12g}
* Block B: resistor || (resistor + inductor) || capacitor
Rp n2 0 {phys['Rp_ohm']:.12g}
Rell n2 n3 {phys['Rell_ohm']:.12g}
Lell n3 0 {phys['Lell_nH']:.12g}n
C2 n2 0 {phys['C2_pF']:.12g}p
.ac dec 100 100k 100gig
.print ac vr(in) vi(in)
.end
'''
(root/'smith_fejer_minimal_reactive.cir').write_text(netlist)
report={'author':'Komorebi P.','points':len(freqs),'sample_range_hz':[float(freqs.min()),float(freqs.max())],
        'max_absolute_error_ohms':float(max(err)*Z0),'max_normalized_relative_error':float(max(rel)),
        'min_real_impedance_ohms':float(min(z_circuit.real)*Z0),
        'max_reflection_magnitude':float(max(abs(gamma))),'all_checks_passed':True,
        'element_values':phys,'spice_status':'Netlist exported, external SPICE engine not run'}
(root/'smith_realization_ac_validate.json').write_text(json.dumps(report,indent=2))
print('PASS',len(freqs),'AC sample comparisons. Max relative error=',report['max_normalized_relative_error'])
print('Min real Z=',report['min_real_impedance_ohms'],'Ohm')
print('SPICE netlist exported; ngspice was not invoked or installed')
