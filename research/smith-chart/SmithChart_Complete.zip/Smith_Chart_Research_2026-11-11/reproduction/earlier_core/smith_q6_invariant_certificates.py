#!/usr/bin/env python3
"""Exact invariants and graph constraints for six-reactive-element RLC synthesis.

Author: Komorebi P.

These are necessary conditions, not proof of q=6 transformer-free
realizability or nonrealizability.
"""
from pathlib import Path
import json
import sympy as sp
from smith_q6_graph_pruning import count,partition

s=sp.symbols('s', real=True)
P=450*s**6+1385*s**5+2477*s**4+2200*s**3+1142*s**2+335*s+75
D=5*(30*s**6+159*s**5+275*s**4+344*s**3+250*s**2+89*s+5)
Z=sp.cancel(P/D)
Q=sp.Rational
checks=[]
def check(n,condition):
    assert bool(condition),n
    checks.append(n)

def sylvester(A,B):
    A=list(sp.Poly(A,s).all_coeffs());B=list(sp.Poly(B,s).all_coeffs());n=max(len(A),len(B))-1
    A=[sp.Integer(0)]*(n+1-len(A))+A
    B=[sp.Integer(0)]*(n+1-len(B))+B
    check('Sylvester numerator and denominator padded to common degree',len(A)==len(B))
    result=[1];dets=[]
    for k in range(1,n+1):
        S=sp.zeros(2*k)
        for j in range(k):
            for col in range(2*k):
                t=col-j
                S[2*j,col]=B[t] if 0<=t<len(B) else 0
                S[2*j+1,col]=A[t] if 0<=t<len(A) else 0
        det=sp.factor(S.det(method='domain-ge'))
        dets.append(det)
        sign=int(sp.sign(det))
        if sign==0:
            last=max(i for i,val in enumerate(result) if val)
            j=k-last
            sign=(-1)**(j*(j-1)//2)*result[last]
        result.append(sign)
    return result,dets

check('P/Q coprime',sp.gcd(P,D)==1)
check('Z degree six',sp.degree(P,s)==6 and sp.degree(D,s)==6)
signs,dets=sylvester(P,D)
check('Exact six-step Sylvester signs',signs==[1,-1,-1,1,1,1,-1])
check('No zero Sylvester subdeterminants',all(d!=0 for d in dets))
inductors=sum(x*y<0 for x,y in zip(signs,signs[1:]))
capacitors=sum(x*y>0 for x,y in zip(signs,signs[1:]))
check('Forced three L and three C',inductors==3 and capacitors==3)
check('Z0=3',Z.subs(s,0)==3)
check('Zinf=3',sp.limit(Z,s,sp.oo)==3)
check('Z(i)=1+2i',sp.simplify(Z.subs(s,sp.I)-(1+2*sp.I))==0)
check('Failed Foster shunt is exact',sp.simplify((1/Z-Q(1,3)).subs(s,sp.I)+Q(2,15)+Q(2,5)*sp.I)==0)
check('Z derivative at DC',sp.diff(Z,s).subs(s,0)==-40)
check('Z high-freq derivative coefficient',sp.limit(s*s*sp.diff(Z,s),s,sp.oo)==Q(20,3))
poly=3750*s**10+12360*s**9+31679*s**8+70780*s**7+111388*s**6+111300*s**5+64642*s**4+16020*s**3-3314*s**2-3260*s-625
check('Exact derivative polynomial',sp.cancel(sp.diff(Z,s)-40*poly/D**2)==0)
coeffs=sp.Poly(poly,s).all_coeffs(); nonzero=[int(sp.sign(c)) for c in coeffs if c!=0]
check('Exactly one Descartes variation',sum(a!=b for a,b in zip(nonzero,nonzero[1:]))==1)
left,right=Q(3353104,10000000),Q(3353105,10000000)
check('Exact root bracket signs',poly.subs(s,left)<0<poly.subs(s,right))
check('Exactly one positive real derivative zero',poly.subs(s,0)<0 and sp.LC(sp.Poly(poly,s))>0)
# Necessary resistor inequalities from positive real decomposition.
for w in (Q(3,5),Q(9,10)):
    val=sp.simplify(Z.subs(s,sp.I*w))
    reZ=sp.factor(sp.re(sp.expand_complex(val)))
    reY=sp.factor(sp.re(sp.expand_complex(1/val)))
    check('Boundary Re Z is positive at w='+str(w),reZ>0)
    check('Boundary Re Y is positive at w='+str(w),reY>0)

# Independent fixture check for Sylvester sign convention.
S1L,Ldets=sylvester(s,sp.Integer(1))
S1C,Cdets=sylvester(sp.Integer(1),s)
check('Inductor classified as one L',S1L==[1,-1])
check('Capacitor classified as one C',S1C==[1,1])
SF,Fdets=sylvester(6*s*s+1,5*s)
check('Series LC requires one L and one C',sum(a!=b for a,b in zip(SF,SF[1:]))==1)
# 2L+2C circuit for H.
PH=25*s**4+70*s**3+146*s**2+70*s+25
DH=5*(s*s+1)*(5*s*s+14*s+5)
SH,Hdets=sylvester(PH,DH)
check('Four-state H has 2L 2C sign signature',sum(a*b<0 for a,b in zip(SH,SH[1:]))==2 and sum(a*b>0 for a,b in zip(SH,SH[1:]))==2)
# independent checks on exact topological enum and orbit quotient
c4,c5,c6=[count(n) for n in [4,5,6]]
check('n4 enumeration total',c4['total_all_3L3C_placements_allowing_LC_overlap']==400)
check('n4 has no independent compliant 3L3C placement',c4['also_endpoint_slope_visibility']==0)
check('n5 enumeration 14,400',c5['total_all_3L3C_placements_allowing_LC_overlap']==14400)
check('n5 no-port-short 3249',c5['no_port_short']==3249)
check('n5 no-cycle 2500',c5['also_no_L_or_C_cycle']==2500)
check('n5 slope-visible 1934',c5['also_endpoint_slope_visibility']==1934)
check('n6 slope-visible 80,232',c6['also_endpoint_slope_visibility']==80232)
canonical=json.loads(Path(__file__).with_name('q6_5node_canonical_topologies.json').read_text())
check('n5 symmetry classes 168',len(canonical)==168)
check('n5 orbit sizes total 1,934',sum(c['orbit_size'] for c in canonical)==1934)
check('n5 all class orbit sizes divide 12',all(12%x['orbit_size']==0 for x in canonical))
# Current exploration is not a decision certificate.
fits=[]
for low,high in [(0,75),(75,168)]:
    f=Path(__file__).with_name(f'q6_canonical_fits_{low}_{high}.json')
    if f.exists():fits+=json.loads(f.read_text())['cases']
check('All 168 orbit classes fitted at least once',len(fits)==168 and {x['id'] for x in fits}==set(range(168)))

result={
    'author':'Komorebi P.',
    'scope':'Necessary exact invariants for six-reactive transformer-free RLC realization',
    'status':'q=6 transformer-free feasibility UNDECIDED',
    'sylvester_determinants':[str(v) for v in dets],
    'sylvester_signs':signs,
    'forced_element_counts':{'inductors':inductors,'capacitors':capacitors},
    'exact_endpoint_values':{'Z(0)':'3','Z(infty)':'3','Z(i)':'1+2i','Zprime(0)':'-40','limit_s2Zprime(infty)':'20/3'},
    'slope_zero_bracket':[str(left),str(right)],
    'graph_counts':[c4,c5,c6],
    'five_node_classes':len(canonical),
    'numerical_fits':{'trialled_representatives':len(fits),'best_error':min(x['error'] for x in fits),'not_a_proof':True},
    'checks':checks,'count':len(checks)
}
Path(__file__).with_name('smith_q6_invariant_certificates.json').write_text(json.dumps(result,indent=2))
print(f'{len(checks)} exact/census/regression checks passed; forced 3 L + 3 C; five-node classes={len(canonical)}')
print('Sylvester signs:',signs)
print('Five-node numerical best:',result['numerical_fits']['best_error'])
print('Transformer-free existence is NOT determined.')
