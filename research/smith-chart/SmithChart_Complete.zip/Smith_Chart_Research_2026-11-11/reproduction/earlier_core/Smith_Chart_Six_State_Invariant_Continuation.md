# Six reactive elements: signatures, graph obstructions, and a finite topology catalogue

**Author: Komorebi P.**  
**Research status: unpublished, 8 November 2026.**  
**Main unresolved question:** whether the particular positive-real degree-six impedance below admits a **transformer-free** realization with exactly six independent inductors and capacitors. This note establishes new necessary restrictions for that fixed problem. It does **not** settle its feasibility.

## Precise target

The impedance obtained from the three-phase passive Fejér filtering of the lossless series-LC reflection function is

\[
Z_6(s)=\frac{450s^6+1385s^5+2477s^4+2200s^3+1142s^2+335s+75}{5(30s^6+159s^5+275s^4+344s^3+250s^2+89s+5)}.
\]

Its numerator and denominator are coprime and have degree six. Any exact RLC realization therefore needs at least six independent reactive elements. The previously verified two-state LC plus four-state RLC construction attains this degree with an **ideal transformer-based** lossless-combining network. It does not solve the transformer-free restriction.

## Theorem A: the six-state component signature is forced

Let \(a_6,\ldots,a_0\) and \(b_6,\ldots,b_0\) be the coefficients of the numerator and denominator, respectively. For \(k=1,\ldots,6\) construct the classical \(2k\times2k\) Sylvester matrix \(S_{2k}\) whose first two rows are

\[
(b_6,b_5,\ldots,b_{7-2k}),\qquad (a_6,a_5,\ldots,a_{7-2k}),
\]

and whose subsequent pairs shift these rows one column to the right, filling any absent negative-degree coefficient with zero. The exact determinant signs are

\[
\operatorname{sgn}(1,\det S_2,\det S_4,\det S_6,\det S_8,\det S_{10},\det S_{12})=(+,-,-,+,+,+,-).
\]

There are three sign variations and three sign permanences. The classical extended Cauchy-index/Sylvester-counting theorem therefore implies the following **necessary** result:

> If a transformer-free resistor–inductor–capacitor one-port realizes \(Z_6\) using exactly six reactive elements, then it uses exactly **three inductors and three capacitors**.

This calculation applies an existing theorem in network synthesis; it is **not** a novel general theorem. Its sign convention was independently checked on a pure inductor, a pure capacitor, the source series-LC impedance, and the existing four-reactive-element \(H\) branch. The \(H\) example requires the prescribed zero-determinant sign convention.

![Exact Sylvester signs, calculated in Python](figures/23_sylvester_reactive_signature.svg)

## Theorem B: no four-node six-state topology exists

Number the port node 1, ground node 0, and any internal nodes 2 onward. For a conventional lumped network with independent L/C components, let \(G_L\) consist of the three inductor edges and \(G_C\) of the three capacitor edges.

Because \(Z_6(0)=Z_6(\infty)=3\), \(G_L\) cannot contain a path from 1 to 0 (which would short the port at DC), and \(G_C\) cannot contain such a path (which would short the port as \(s\to\infty\)). If any same-type reactive edges form a cycle, the corresponding reactive variables satisfy a loop constraint and the driving-point rational degree is **strictly less** than the total six reactive elements. Thus each same-type graph must be a forest in any degree-six, six-element realization.

A forest on four vertices with three edges is a spanning tree, and hence connects 0 to 1. That contradicts the required finite nonzero DC impedance. **At least five network nodes, counting the port and ground, are necessary.** This lower bound assumes ordinary independent ideal L/C components without mutual inductance or ideal transformers; adding arbitrary resistors does not circumvent it.

## Theorem C: a unique real-Laplace reactive-sensitivity crossing

For any connected transformer-free one-port, drive one ampere at an arbitrary **positive real Laplace argument** \(s>0\). All ideal branch admittances are then positive real. Differentiating the grounded nodal matrix \(Y(s)\) shows

\[
Z'(s)=-v(s)^{\mathsf T}Y'(s)v(s)
=\sum_{\ell\in L} L_\ell I_\ell(s)^2-\sum_{c\in C} C_c V_c(s)^2.
\tag{A}
\]

Here \(I_\ell(s)\) and \(V_c(s)\) are real branch currents and voltages under the unit-current port excitation at the **real** parameter \(s\). This is an exact circuit-sensitivity identity, **not** a time-averaged sinusoidal energy equality.

For this target,

\[
Z_6'(0)=-40,\qquad \lim_{s\to\infty}s^2Z_6'(s)=\frac{20}{3}.
\]

Consequently the capacitive term dominates at the DC limit, and the appropriately scaled inductive term dominates at the high-frequency Laplace limit. Explicitly,

\[
\sum_C C_cV_c(0)^2-\sum_L L_\ell I_\ell(0)^2=40,
\qquad
\sum_L\frac{V_\ell(\infty)^2}{L_\ell}-\sum_C\frac{I_c(\infty)^2}{C_c}=\frac{20}{3}.
\]

The rational derivative has the form

\[
Z_6'(s)=\frac{40J(s)}{D(s)^2},\quad
J(s)=3750s^{10}+12360s^9+31679s^8+70780s^7+111388s^6+111300s^5+64642s^4+16020s^3-3314s^2-3260s-625,
\]

where \(D(s)\) denotes the full denominator of \(Z_6\). The descending coefficient signs of \(J\) change **once**. Since \(J(0)<0\) and its leading coefficient is positive, Descartes' rule and the intermediate value theorem give **exactly one** positive root. Its certified rational bracket is

\[
\boxed{0.3353104<s_*<0.3353105.}
\]

At this single real-Laplace value, any exact circuit must satisfy

\[
\boxed{\sum_L L_\ell I_\ell(s_*)^2=\sum_C C_c V_c(s_*)^2.}
\]

This does not by itself determine topology, but supplies an exact frequency-wide sensitivity identity against which a proposed network can be checked.

![Positive-real-axis impedance and unique derivative crossover, plotted in Python](figures/24_unique_reactive_sensitivity_crossover.svg)

## Theorem D: low/high endpoint visibility prunes reactive graphs

If every capacitor has both endpoints in the same connected component of the **inductor-only** subgraph, all its voltages vanish at DC. Formula (A) would give \(Z_6'(0)\ge0\), contradicting \(-40\). Therefore **some capacitor must bridge distinct inductor-short components**. Dually, **some inductor must bridge distinct capacitor-short components** in the high-frequency limit, or the coefficient \(20/3\) would have the wrong sign.

We enumerated all ways of placing three distinct L edges and three distinct C edges among node pairs. L and C are permitted to share an edge; duplicates of the **same** reactive type on one pair are excluded because they can be combined without increasing rational degree.

| Exact labelled reactive-graph count | Four nodes | Five nodes | Six nodes |
|:--|--:|--:|--:|
| Initial placements | 400 | 14,400 | 207,025 |
| No L/C-only port shorts | 4 | 3,249 | 92,416 |
| Also no same-type cycles | 0 | 2,500 | 82,944 |
| Also both endpoint slope signs possible | 0 | **1,934** | **80,232** |

For five nodes, quotienting the 1,934 survivors by permutations of the three internal-node labels and exchange of the two external terminals produces exactly **168 distinct reactive-placement classes**. The classes retain **arbitrary resistor conductances between any node pair** and are therefore a complete *reactive-placement* catalogue under the stated constraints, not a complete classification of positive component solutions.

![Python-generated five-node pruning counts](figures/25_five_node_exact_topology_pruning.svg)

![Python-generated example of a rejected and a still-possible reactive placement](figures/26_reactive_endpoint_graph_examples.svg)

## Additional all-frequency constraints on exposed resistors

If a resistor \(R_s\) is attached **in series with the entire remaining passive network**, then \(R_s\le\operatorname{Re}Z_6(i\omega)\) at every real \(\omega\). Choosing the rational sample \(\omega=3/5\) yields the exact necessary bound

\[
\boxed{R_s\le\frac{6206853}{25267405}\approx0.245647.}
\]

Similarly, if \(R_p\) is attached **in parallel across the entire remaining passive one-port**, passivity implies \(1/R_p\le \operatorname{Re}(1/Z_6(i\omega))\). At \(\omega=9/10\),

\[
\boxed{R_p\ge\frac{34799940603159}{6501829077953}\approx5.35233.}
\]

These are normalized resistance values, not ohms until a reference \(Z_0\) is chosen. They only constrain directly exposed top-level resistors, not arbitrary interior resistors. An especially simple excluded topology is \(R_p=3\) in parallel with three series-RLC resonators: at \(s=i\), the remainder would require negative conductance \(-2/15\).

## Computation and status

The new code `smith_q6_invariant_certificates.py` regenerates the exact Sylvester determinants, derivative polynomial, rational brackets, graph counts, symmetry orbit totals, and simple resistor bounds. It passes **39 exact/census/regression checks**. The earlier five independent test suites were rerun and passed **216/216 checks** in their respective reported scopes. Total across these distinct suites: **255 passing checks**. None substitutes for a universal quantifier-elimination run.

The new *numerical* one-start search fitted all 168 five-node orbit representatives. Its best sampled discrepancy was about \(1.135\times10^{-3}\). A separate exploratory seven-node fit reached approximately \(6.01\times10^{-5}\) on a different sampling grid. These are **not** algebraic identities; neither a near-match nor a numerical optimizer's failure proves feasibility or impossibility.

**Unresolved:** no exact transformer-free circuit with exactly six reactive elements was constructed, and no exhaustive impossibility certificate over five or more nodes was obtained. The graph restrictions narrow the search but leave five-node and higher-node candidates.

**Next constructive target:** take the 168 five-node classes, encode the nodal cofactor identity with three L and three C and nonnegative resistor conductances, use exact algebraic elimination to resolve any selected class, and only claim a circuit after its rational identity and all component signs are proven. To exclude the full \(q=6\) case would still require a certificate over every permissible node count, up to the previously established 14-node normal form.

### References and scope of originality

- T. H. Hughes, *On the Synthesis of Passive Networks without Transformers* (University of Cambridge, 2014), chapters on extended Cauchy index and minimal reactive counts.
- A. Morelli, *Synthesis of Electrical and Mechanical Networks of Restricted Complexity* (University of Cambridge, 2019), Section 3.3 (Sylvester determinant-count theorem, including zero sign convention).
- The earlier unpublished Smith chart physical-realization and transformer-free decision notes, which supply the exact rational target, ideal-transformer witness, and finite cofactor feasibility reduction.

**Priority:** the classical counting theorem, nodal sensitivity identity, graph cycle constraints, and real algebraic feasibility concepts are established ingredients. Their computed consequences for this particular rational target are independently reproducible calculations; no claim of general mathematical novelty or publication priority is made.
