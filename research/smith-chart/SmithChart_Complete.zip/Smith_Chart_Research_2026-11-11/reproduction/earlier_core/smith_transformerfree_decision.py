#!/usr/bin/env python3
"""Exact polynomial encoding of transformer-free passive RLC synthesis.

Author: Komorebi P.

Provides a *finite semialgebraic encoding* for each fixed reactive-element
budget q. Quantifier elimination (CAD, or an equivalent complete real-algebraic
decision method) is REQUIRED to decide feasibility in general. This script
does not include a CAD solver and DOES NOT resolve the six-reactive-element
feasibility problem for the published example.

For each network: all nodes and edges are labelled. Node 0 is ground and node 1
is the driving terminal. Resistor edges use conductance g >= 0, capacitor edges
use admittance c*s (c > 0) and inductor edges use admittance h/s (h=1/L>0).
"""
from __future__ import annotations
import itertools
import json
from pathlib import Path
import sympy as sp

s=sp.Symbol('s')


def node_pairs(n):
    return list(itertools.combinations(range(n),2))


def laplacian_admittance(n,edges):
    """Return grounded admittance matrix for edge triples (u,v,Y_edge(s))."""
    mat=sp.zeros(n-1)
    for u,v,admittance in edges:
        if u==v or not (0<=u<n and 0<=v<n):
            raise ValueError('Each edge needs two different valid nodes')
        for x,signx in ((u,1),(v,-1)):
            if x==0:continue
            for y,signy in ((u,1),(v,-1)):
                if y==0:continue
                mat[x-1,y-1]+=signx*signy*admittance
    return mat


def impedance_cofactors(n,edges):
    """Return numerator/cofactor and determinant, with Z=N/D."""
    if n<2:raise ValueError('Need port node 1 and grounded node 0')
    y=laplacian_admittance(n,edges)
    denom=sp.factor(y.det(method='berkowitz'))
    numerator=sp.factor(y.minor_submatrix(0,0).det(method='berkowitz')) if n>2 else sp.Integer(1)
    return sp.factor(numerator),sp.factor(denom)


def impedance(n,edges):
    num,den=impedance_cofactors(n,edges)
    return sp.cancel(num/den)


def check_witness(name,target,n,edges,n_reactives):
    seen=sum(1 for _,_,a in edges if sp.sympify(a).has(s))
    assert seen==n_reactives, (name,seen,n_reactives)
    for u,v,ad in edges:
        coeff=sp.factor(ad/s) if ad.has(s) and sp.cancel(ad/s).has(s)==False else None
        if ad.has(s):
            good=(sp.simplify(ad/s)>0 if sp.simplify(ad/s).is_number and not ad.has(1/s) and sp.simplify(ad/s).is_positive else
                  sp.simplify(ad*s).is_positive)
            assert good is True or good==sp.true,(name,ad)
        else:assert ad>=0,(name,ad)
    n0,d0=impedance_cofactors(n,edges)
    assert sp.cancel(target*d0-n0)==0,(name,'incorrect exact impedance')
    assert sp.simplify(d0.subs(s,1))>0,(name,'disconnected network')
    return {'name':name,'nodes':n,'reactives':seen,'impedance':str(sp.cancel(n0/d0)),
            'determinant_at_s1':str(sp.simplify(d0.subs(s,1)))}


def symbolic_template(target_num,target_den,n,reactives):
    """Build equations for a fixed reactive placement: [(kind,u,v),...].

    The returned polynomial coefficient equations, together with g>=0,
    c>0, h>0 and D(s=1)>0, are necessary and sufficient for that topology.
    We provide no claim of CAD feasibility unless a solver is run.
    """
    if n>2*len(reactives)+2:
        raise ValueError('Superfluous resistor-only nodes: reduce via Kron elimination first')
    pair=node_pairs(n)
    condvars=[sp.Symbol('g_%s_%s'%(u,v),real=True,nonnegative=True) for u,v in pair]
    edges=[(u,v,g) for (u,v),g in zip(pair,condvars)]
    positive=[]
    for index,(kind,u,v) in enumerate(reactives):
        if (u,v) not in pair and (v,u) not in pair:
            raise ValueError('Bad endpoint for reactive element')
        if kind=='C':
            c=sp.Symbol('c_'+str(index),real=True,positive=True)
            edges.append((u,v,c*s))
            positive.append(c)
        elif kind=='L':
            h=sp.Symbol('h_'+str(index),real=True,positive=True)
            edges.append((u,v,h/s))
            positive.append(h)
        else:raise ValueError('Reactive kind must be C or L')
    num,den=impedance_cofactors(n,edges)
    poly=sp.cancel(sp.expand(target_num*den-target_den*num))
    pnum,pden=sp.fraction(sp.together(poly))
    coeffs=sp.Poly(pnum,s).all_coeffs()
    return {'nodes':n,'reactives':reactives,'conductances':condvars,
            'positive_parameters':positive,
            'connected_at_s1':sp.factor(den.subs(s,1)),
            'constraints':[sp.factor(v) for v in coeffs],
            'numerator':num,'denominator':den}


def run_exact_checks():
    q=sp.Rational
    report=[]
    # Degree 0: ordinary resistor.
    report.append(check_witness('constant resistor 5/2',q(5,2),2,
                                [(0,1,q(2,5))],0))
    # Degree 1: pure inductor.
    report.append(check_witness('inductor 2s',2*s,2,
                                [(0,1,1/(2*s))],1))
    # Degree 1: filtered reflection of F(t)=t, exact RL physical circuit.
    b=q(1,2)
    z_rl=((1+b)*s+(1-b))/((1-b)*s+1+b)
    report.append(check_witness('Fejer filtered F=t: RL impedance',z_rl,3,
                        [(1,2,q(3,1)),(2,0,q(3,8)),(2,0,q(9,8)/s)],1))
    # Degree 2: series LC.
    z_lc=q(6,5)*s+1/(5*s)
    report.append(check_witness('series LC',z_lc,3,
                                [(1,2,q(5,6)/s),(2,0,5*s)],2))
    # Degree 3: three reactives in a completely rational RLC network.
    z3=s+s/(s*s+s+1)
    report.append(check_witness('rational three-reactive ladder',z3,3,
                      [(1,2,1/s),(2,0,sp.Integer(1)),(2,0,s),(2,0,1/s)],3))
    # Kron elimination: node 3 has no reactive elements.
    # Original conductances: g13=2, g23=3, g03=5. Eliminate node 3:
    # g12=6/10; g10=10/10; g20=15/10.
    external=[(1,3,sp.Integer(2)),(2,3,sp.Integer(3)),(0,3,sp.Integer(5)),
              (2,0,2*s),(1,0,3/s)]
    reduced=[(1,2,q(3,5)),(1,0,sp.Integer(1)),(2,0,q(3,2)),
             (2,0,2*s),(1,0,3/s)]
    assert sp.cancel(impedance(4,external)-impedance(3,reduced))==0
    report.append({'name':'exact Kron elimination of resistor-only internal node',
                   'passed':True,'original_nodes':4,'reduced_nodes':3})
    # Fixed-graph CAD equations: target Z=2s with q=1 and n=2.
    temp=symbolic_template(2*s,sp.Integer(1),2,[('L',0,1)])
    g=temp['conductances'][0];h=temp['positive_parameters'][0]
    sol=sp.solve(temp['constraints'],(g,h),dict=True)
    assert sol==[{g:0,h:sp.Rational(1,2)}] or all(sp.simplify(expr.subs(sol[0]))==0 for expr in temp['constraints'])
    assert all(sp.simplify(expr.subs({g:0,h:q(1,2)}))==0 for expr in temp['constraints'])
    report.append({'name':'exact certificate for q=1 inductance by polynomial equations',
                   'constraints':[str(v) for v in temp['constraints']],
                   'solution':{'g': '0','h':'1/2'}})
    # Check no-go sensitivity inequality on a passive resistor-only one-copy combiner.
    a,b=sp.symbols('a b',positive=True)
    mix=(2*a*b+a+b)/(a+b+2)
    sens=sp.factor(sp.diff(mix,a))
    assert sens==2*(b+1)**2/(a+b+2)**2
    assert sens.subs({a:1,b:10})==q(242,169)>1
    report.append({'name':'one-copy resistive combiner violates derivative upper bound',
                   'sensitivity':'2(b+1)^2/(a+b+2)^2',
                   'counterexample':'a=1,b=10 gives 242/169 > 1'})
    # Exact rational positive-real minimum-function geometry (not a component-count proof).
    zstar=(s**2+q(1,2)*s+q(2,3))/(s**2+q(1,3)*s+q(3,2))
    w=sp.Symbol('w',real=True)
    re=sp.factor(sp.re(zstar.subs(s,sp.I*w)))
    den=(q(3,2)-w*w)**2+w*w/9
    assert sp.cancel(re-(w*w-1)**2/den)==0
    assert sp.cancel(sp.together(zstar)).as_numer_denom()[1]!=1
    report.append({'name':'biquadratic minimum-function exact boundary power gap',
                   'real_part_numerator':'(w^2 - 1)^2',
                   'global_reactive_minimum':'Not inferred from this test'})
    # Finite-difference sensitivity witness, independent of numerical differentiation.
    assert sp.simplify(mix.subs({a:2,b:10})-mix.subs({a:1,b:10}))==q(121,91)
    report.append({'name':'finite one-copy resistive sensitivity witness',
                   'difference':'121/91 > 1'})
    # Degree-six certificate carried from prior version, without assuming a q=6 RLC witness.
    p6=450*s**6+1385*s**5+2477*s**4+2200*s**3+1142*s*s+335*s+75
    d6=5*(30*s**6+159*s**5+275*s**4+344*s**3+250*s*s+89*s+5)
    assert sp.gcd(p6,d6)==1
    assert max(sp.degree(p6,s),sp.degree(d6,s))==6
    report.append({'name':'degree-six target establishes only lower bound q>=6',
                   'gcd':'1','degree':6,'q6_transformerfree_feasible':'UNDETERMINED'})
    return report


if __name__=='__main__':
    checks=run_exact_checks()
    output={'author':'Komorebi P.','scope':'Exact circuit cofactors and semialgebraic feasibility encoding',
            'not_claimed':'No CAD search of six-reactive transformer-free circuits has been completed.',
            'tests':checks,'passed':len(checks)}
    p=Path(__file__).with_name('smith_transformerfree_decision_checks.json')
    p.write_text(json.dumps(output,indent=2),encoding='utf-8')
    print(f'{len(checks)} exact tests passed; six-reactive transformer-free status: UNDETERMINED')
    for v in checks:print(' *',v['name'])
