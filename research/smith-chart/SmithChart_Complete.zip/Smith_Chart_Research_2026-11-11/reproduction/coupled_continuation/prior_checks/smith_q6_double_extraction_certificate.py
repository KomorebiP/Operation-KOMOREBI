#!/usr/bin/env python3
"""A second exact, positive 1L+1C pole-pair extraction and a nonregularity certificate.
Author: Komorebi P.
Algebraically exact circuit identities; outward-rounded pole enclosures for signs.
Does not certify a six-reactive transformer-free realization.
"""
import json
from pathlib import Path
import sympy as sp
from mpmath import iv,mp
iv.dps=80
s=sp.symbols('s')
P=450*s**6+1385*s**5+2477*s**4+2200*s**3+1142*s**2+335*s+75
D=5*(30*s**6+159*s**5+275*s**4+344*s**3+250*s**2+89*s+5)
complex_roots = sp.intervals(D/5,eps=sp.Rational(1,10**20),all=True)[1]
uppers=sorted([pair for pair,m in complex_roots if sp.im(pair[0])>0],key=lambda pair:float(sp.im(pair[0])))
assert len(uppers)==2

def rat(x):
 x=sp.Rational(x); return iv.mpf(str(x.p))/iv.mpf(str(x.q))
def hull(a,b):
 return iv.mpf([rat(a).a,rat(b).b])
def civ(box):
 return iv.mpc(hull(sp.re(box[0]),sp.re(box[1])),hull(sp.im(box[0]),sp.im(box[1])))
def evep(w):return 450*w**6+1385*w**5+2477*w**4+2200*w**3+1142*w**2+335*w+75
def evedp(w):return 5*(180*w**5+795*w**4+1100*w**3+1032*w**2+500*w+89)
def bound(w):return [str(w.a),str(w.b)]
def pos(w):return bool(w.a>0)
def neg(w):return bool(w.b<0)
def sec(pair):
 pole=civ(pair);res=evep(pole)/evedp(pole);x,y=pole.real,pole.imag;u,v=res.real,res.imag
 return dict(p=-2*x,q=x*x+y*y,a=2*u,b=-2*(u*x+v*y))
mid=sec(uppers[0]);high=sec(uppers[1]);rmax=sp.Rational(11,5);rmin=sp.Rational(213,100)
result={'author':'Komorebi P.','scope':'Two exact, independent 1L1C sections in series; third section nonregular and unsynthesized','checks':[]}
def ck(name,boolvalue):
 assert boolvalue,name
 result['checks'].append(name)
for z in (mid,high):ck('Algebraic pole sections have stable quadratics '+str(len(result['checks'])),pos(z['p']) and pos(z['q']))
# Second circuit: nodes port1, interior2, ground0;
# G resistor (port--ground) // c capacitor (port--ground),
# A resistor (port--internal), B resistor (internal--ground) // L (internal--ground).
p,q,a,b=[mid[k] for k in 'pqab'];G=rat(1)
A=q/b-G;X=(p-a*G-b/a)/a;B=X*A/(A-X);c=1/a;ell=(b/a)*(A+B)
for name, quantity in [('a',a),('b',b),('ap-b',a*p-b),('q/b-1',A),('X',X),('A-X',A-X),('B',B),('c',c),('ell',ell)]:
 ck('Mid-pole circuit strict positivity '+name,pos(quantity))
# Exact symbolic substitution, independent of numerical poles.
ps,qs,aa,bb,gg,z=sp.symbols('p q a b g s',nonzero=True,real=True)
As=qs/bb-gg
Xs=(ps-aa*gg-bb/aa)/aa
Bs=sp.factor(Xs*As/(As-Xs))
cs=1/aa
ells=bb/aa*(As+Bs)
Zcirc=((As+Bs)*z+ells)/(cs*(As+Bs)*z*z+(gg*(As+Bs)+cs*ells+As*Bs)*z+ells*(gg+As))
Zwanted=(aa*z+bb)/(z*z+ps*z+qs)
ck('Symbolic nodal circuit exactly equals middle-pole section for formal p,q,a,b',sp.cancel(Zcirc-Zwanted)==0)
ck('Symbolic middle section degree 2 for nondegenerate poles',pos(mid['a']*mid['p']-mid['b']))
# 0 feedthrough is allowed; prove PR by Re Z(iω)=((a p-b)ω²+b q)/positive denominator.
ck('Middle-pole section is positive-real including zero high-frequency constant',pos(a*p-b) and pos(b*q))
# Spectral split with zero constant assigned to middle group:
# r_real + 0 + (3-r_real)=3 identically. For r_real∈[2.13,2.2], high r∈[.8,.87].
ck('Constant allocations exactly add to 3',sp.simplify(sp.Rational(11,5)+0+(3-sp.Rational(11,5))-3)==0)
R=iv.mpf([rat(sp.Rational(4,5)).a,rat(sp.Rational(87,100)).b])
ph,qh,ah,bh=[high[k] for k in 'pqab']
M=R*(ph*ph-2*qh)+ah*ph-bh
C=qh*(R*qh+bh)

for j in range(7):
    Rj=iv.mpf([rat(sp.Rational(4,5)+sp.Rational(j,100)).a,rat(sp.Rational(4,5)+sp.Rational(j+1,100)).b])
    Mj=Rj*(ph*ph-2*qh)+ah*ph-bh; Cj=qh*(Rj*qh+bh)
    ck(f'High-pole strict PR on subinterval {j+1}',pos(Rj) and pos(Cj) and (pos(Mj) or pos(4*Rj*Cj-Mj*Mj)))
# Lemma 5 Jiang/Smith (2009/2011) biquadratic regularity.
# Z(s)=(A s² + B s + C)/(D s²+E s+F); here A=r, B=r*p+a, C=r*q+b, D=1,E=p,F=q.
AA=R;BB=R*ph+ah;CC=R*qh+bh;DD=iv.mpf(1);EE=ph;FF=qh
Delta=AA*FF-CC*DD
lambda1=EE*(BB*FF-CC*EE)-FF*Delta
lambda2=BB*(AA*EE-BB*DD)-AA*Delta
ck('High-pole: AF-CD strictly positive for all r',pos(-bh))
ck('High-pole: lambda1 strictly negative for all r in interval',neg(lambda1))
ck('High-pole: lambda2 strictly negative for all r in interval',neg(lambda2))
ck('High-pole: lambda1 independent of r and negative by simplified formula', neg(ph*(ah*qh-bh*ph)+qh*bh))
ck('High-pole: b-a*p is negative, forcing lambda2<0 for all r>=0',neg(bh-ah*ph))
# independent symbolic check lambda1 and lambda2 simplified (no interval cancellation)
rr,pp,qq,alpha,beta=sp.symbols('r p q a b')
LL1=sp.expand(pp*((rr*pp+alpha)*qq-(rr*qq+beta)*pp)-qq*(-beta))
LL2=sp.expand((rr*pp+alpha)*(rr*pp-(rr*pp+alpha))-rr*(-beta))
ck('lambda1 independent of r, exact',sp.simplify(sp.diff(LL1,rr))==0)
ck('lambda2=r*(b-a*p)-a², exact',sp.simplify(LL2-(rr*(beta-alpha*pp)-alpha**2))==0)
# Full classical exceptional-bridge exclusion for every nonnegative constant r_h<=3.
# If the last pole pair is realized with 2 reactive elements and arbitrarily many
# resistors, Reichert's theorem reduces it to <=3 resistors (the Ladenheim catalogue).
# Jiang/Smith/Morelli classify the only nonregular 3R+1L+1C bridge family V_H.
# Their necessary conditions for Delta>0 are mu1>=0 and signs of lambda1,lambda2,rho1
# not all the same (or the all-zero degeneracy, impossible here).
# For r in [0,13/10], rho1<0. For r in [13/10,3], mu1<0 by convexity.
# This excludes the pole-pair series construction at the degree-matching 2-reactive count.
K=bh*bh+ah*(ah*qh-bh*ph)
ck('Classical biquadratic resultant K is strictly positive',pos(K))
def rho1_of(r):return -K-2*bh*(r*qh+bh)
def mu1_of(r):return K+4*(r*qh+bh)*(2*bh+ah*ph+r*ph*ph)
rrat=rat(sp.Rational(13,10));rtop=rat(3)
ck('rho1 is strictly increasing in nonnegative r',pos(-2*bh*qh))
ck('rho1(13/10)<0, hence rho1<0 on [0,13/10]',neg(rho1_of(rrat)))
ck('mu1(13/10)<0',neg(mu1_of(rrat)))
ck('mu1(3)<0',neg(mu1_of(rtop)))
ck('mu1 is strictly convex in r, coefficient of r² positive',pos(4*qh*ph*ph))
# If high-section numerator constant C=r*q+b <=0, Z(0)=C/q <=0;
# at the zero boundary C=0, its real part is negative for small positive omega.
rcritical=-bh/qh
Mcritical=rcritical*(ph*ph-2*qh)+ah*ph-bh
ck('Critical constant r0=-b/q between 0 and 13/10',pos(rcritical) and pos(rrat-rcritical))
ck('At zero numerator constant, real part is negative for small nonzero frequency',neg(Mcritical))
result['bridge_exclusion']={
 'theorem':'For all r_h∈[0,3], the upper-frequency conjugate-pole pair impedance cannot be realized by any transformer-free RLC one-port with only two reactive elements.',
 'rho1_at_13_over_10':bound(rho1_of(rrat)),
 'mu1_at_13_over_10':bound(mu1_of(rrat)),
 'mu1_at_3':bound(mu1_of(rtop)),
 'positive_quadratic_coefficient_mu':bound(4*qh*ph*ph),
 'critical_r0':bound(rcritical),
 'M_at_critical_r0':bound(Mcritical),
 'proof':'r<=r0: not PR. r>r0 up to 1.3: lambda1,lambda2,rho1 are all strictly negative, excluding V_H bridge necessary conditions. r>=1.3 up to 3: mu1<0 by convexity with negative endpoint values, excluding V_H. Regularity fails for all positive r, and Reichert theorem reduces all 2-reactive networks with arbitrarily many resistors to the 3-resistor catalogue.',
 'scope':'Excludes all additive, independently passive three-pole-pair series realizations using exactly 2 reactive elements per pair (total 6). Does not exclude other transformer-free six-reactive networks with mixed poles.'
}
result['middle']={key:bound(mid[key]) for key in 'pqab'}
result['circuit']={key:bound(x) for key,x in [('G',G),('A',A),('B',B),('capacitor_C',c),('inverse_inductance_ell',ell),('inductance_L',1/ell),('X',X),('A_minus_X',A-X)]}
result['high']={key:bound(high[key]) for key in 'pqab'}
result['high'].update({'r_interval':['4/5','87/100'],'Delta':bound(Delta),'lambda1':bound(lambda1),'lambda2':bound(lambda2), 'limitation':'Nonregularity alone excludes series-parallel circuits. A separate positive-real/bridge-criterion certificate now additionally excludes 2-reactive exceptional bridges for every r_h in [0,3].'})
result['claims']=[
  'The two lower-frequency pole pairs individually possess exact, positive transformer-free 1L1C circuits; place them in series for a 4-reactive impedance.',
  'The high-frequency pole-pair residual is positive-real and nonregular over a certified continuum of feedthrough allocations.',
  'Exceptional two-reactive bridge realization is excluded for the final pole pair whenever feedthrough r_h is in [0,3], using Reichert and the classical VH bridge criterion. The general six-reactive target remains unresolved.'
]
result['check_count']=len(result['checks'])
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2))
print('PASSED',len(result['checks']),'exact symbolic + interval assertions.')
print('Middle section (p,q,a,b):',*(bound(mid[z]) for z in 'pqab'))
for k,v in result['circuit'].items():print('  ',k,v)
print('High nonregular lambda1,lambda2:',bound(lambda1),bound(lambda2))
print('Bridge obstruction rho1@1.3, mu1@1.3, mu1@3:',bound(rho1_of(rrat)),bound(mu1_of(rrat)),bound(mu1_of(rtop)))
