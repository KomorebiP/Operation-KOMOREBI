# Smith chart: four-anchor continuation and coupled-synthesis audit

**Author:** Komorebi P.  
**Date:** 2026-11-09  
**Status:** Unpublished. The public GitHub/.io reader is unchanged.

## Exact results (verified in this pass)

1. The existing degree-six normalized impedance is a reduced rational positive-real function with exact reflections `G(1)=G(-1)=1/2`, `G(i)=(1+i)/2`, `G(-i)=(1-i)/2`.
2. Among real-rational positive-real responses matching `Z(0)=Z(infty)=3`, `Z(i)=1+2i`, degree two and below are impossible. A degree-three Schur polynomial provides an explicit passive equality case. This is a **rational-degree** minimum, not a physical reactive-element-count theorem.
3. `H_3(t)=1/2+(t-t^3)/4` has exact `H∞` norm `sqrt(13)/4`. Its normalized impedance is `(3s^3+11s^2+7s+3)/(s^3+s^2+5s+1)`.
4. The original degree-six response has exact boundary magnitude square equal to the specified rational function `R(cos θ)`. The global maximum occurs at the unique isolated middle root of a displayed degree-nine critical polynomial and equals approximately `0.7648753772695961` in magnitude. A strict rational certificate gives `||G||∞ < 7649/10000`, hence `Re Z_6(iω) > 2351/17649` for all real ω. The earlier `4/5` reflection upper bound and `1/9` real-part lower bound were valid but loose.
5. The exact reflection-error residual between degree six and three factors by `t^4-1`. At `s=i/3`, the squared reflection error is exactly `4406821/8177000`. An exact Sturm certificate gives the two-sided global inequality `73/100 < ||G-H_3||∞ < 92/125`.
6. These constructions provide a quantified finite-measurement ambiguity example. The general phenomenon is classical Schur/Nevanlinna–Pick interpolation; instance-specific formulas do **not** establish a new general theorem or publication priority.

## Executed checks

- `smith_q6_four_anchor_certificates.py`: **32/32 exact** symbolic, Sturm root-count, rational root-isolation and rational interval assertions passed.
- `smith_q6_anchor_figures.py`: generated 3 new figures in both Matplotlib SVG and PNG. No generated or AI-assisted image model was used.
- `browser_audit.py`: passed at widths 320, 390, 768, 1440 pixels. Each run identified **1,319 rendered math containers**, 36 embedded and loaded figures, 17 tables, no MathJax errors, no JavaScript page errors, no broken section anchors, and no horizontal page overflow.
- Build program appended the new chapter to the recovered 33-figure offline edition without publishing or modifying existing library/repository files.

### Corrections and diagnostic failures encountered

- The first run of the new exact checker rejected a polynomial factorization because the assertion used **syntactic expression equality** rather than expanded polynomial equality. After replacing that assertion by `expand(lhs-rhs)==0`, the identity was independently verified and all 32 checks passed. This was an assertion-design error, not a discovered counterexample.
- Chromium rejected direct `file://` navigation with `ERR_BLOCKED_BY_ADMINISTRATOR`. Browser QA was rerun by loading the **same complete local HTML bytes** using `page.set_content`; those checks passed at all four widths. This does not constitute a remote hosting or server deployment test.
- Exploratory positive-component optimizers did not produce an exact 3L+3C circuit. The best previously saved seven-node fit was marginally reduced from approximately `6.0074×10^-5` to `5.9797×10^-5` on sampled scaled residuals, which is not an equality certificate. The three-reactive trial on a difficult biquadratic pole pair likewise did not produce an exact identity. No topology's infeasibility follows from these numerical results.

## The precise unresolved synthesis problem

For

`Z_6(s) = (450s^6+1385s^5+2477s^4+2200s^3+1142s^2+335s+75) / [5(30s^6+159s^5+275s^4+344s^3+250s^2+89s+5)]`,

there is neither a certified transformer-free RLC realization with exactly six reactive elements nor a complete impossibility certificate. The previously derived `3L+3C` allocation, four-node obstruction, and 168 five-node reactive symmetry classes remain **necessary constraints**, not full feasibility classifications. The fully pole-separated series architecture was excluded at six reactives in the preceding manuscript, subject to its original classical bridge-criterion assumptions. No new claim about its novelty is made here.

## Prior art positioning

- Schur-class and Nevanlinna–Pick interpolation, including nonunique finite-data passive completions, is a long-established field.
- Bultheel and Lasarow, 2008, multiple Nevanlinna–Pick interpolation for Schur functions; DOI 10.1524/anly.2008.0904.
- Jiang and Smith, 2011, minimum-complexity positive-real biquadratic synthesis; DOI 10.1109/TAC.2010.2077810.
- Morelli, 2019, transformer-free network synthesis classification, Cambridge thesis: https://www.repository.cam.ac.uk/items/c41b15a3-f6b3-4650-b7b9-65f14425f0e1

**Next work:** form and solve exact coupled nodal determinant identities with positive algebraic component values, or obtain complete signed-polynomial infeasibility certificates. Hardware performance, computational optimality, and originality remain unverified.
