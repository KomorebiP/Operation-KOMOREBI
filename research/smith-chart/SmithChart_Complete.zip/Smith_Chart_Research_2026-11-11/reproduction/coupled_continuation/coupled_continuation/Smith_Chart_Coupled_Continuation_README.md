# Smith chart: exact four-anchor continuation (unpublished)

**Author:** Komorebi P.

This package continues the prior Smith chart research edition. It adds a minimal rational-degree Schur interpolant at three normalized frequency anchors, a sharp algebraic reflection-norm characterization for the degree-six target, and a quantified demonstration that strictly passive models can agree at the selected frequencies while differing elsewhere.

Open `Smith_Chart_Extended_Four_Anchor_Continuation.html` locally in a web browser for the full offline reading edition, including embedded MathJax and 36 Python-generated figures. The Markdown version is the complete mathematical text.

For independent checking, with Python, SymPy, NumPy, and Matplotlib installed:

```text
python coupled_continuation/smith_q6_four_anchor_certificates.py
python coupled_continuation/smith_q6_anchor_figures.py
```

The first command should report `PASS 32 symbolic/Sturm/interval assertions`. The second regenerates the SVG and PNG plots. If using an extracted archive, the scripts resolve their own paths. The browser audit additionally needs Playwright and system Chromium; its command is `python coupled_continuation/browser_audit.py` and it attempts to load the full HTML from the sibling path, so users may need to adapt that QA script to their local browser executable.

The six-reactive-element transformer-free synthesis question is **unresolved**. The degree-three Schur interpolant is *not* a proof of a three-reactive-element transformer-free physical circuit. See `Smith_Chart_Coupled_Continuation_Audit.md` for exact claims and their limitations.

No contents of this package were published to GitHub or GitHub Pages.
