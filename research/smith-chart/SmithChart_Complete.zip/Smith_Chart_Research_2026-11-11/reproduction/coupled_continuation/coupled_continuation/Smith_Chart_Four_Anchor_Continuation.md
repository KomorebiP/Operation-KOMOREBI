# Smith chart continuation: exact passive interpolation and the coupled-mode boundary

**Author:** Komorebi P.  
**Date:** 9 November 2026  
**Status:** Unpublished mathematical continuation; no change to the public reader site.  
**Claim scope:** Theorems for one explicit rational impedance and its Schur reflection. These are mathematical results, not demonstrations of priority, hardware performance, or a minimum six-reactive-element transformer-free circuit.

## The unchanged synthesis target

Work in dimensionless Laplace frequency \(s\), normalized reference impedance \(Z_0=1\), and the standard disk coordinate

\[
t=\frac{s-1}{s+1},\qquad \Gamma(t)=\frac{Z(s)-1}{Z(s)+1}.
\]

The degree-six target from the preceding chapters remains

\[
Z_6(s)=\frac{450s^6+1385s^5+2477s^4+2200s^3+1142s^2+335s+75}{5(30s^6+159s^5+275s^4+344s^3+250s^2+89s+5)}.
\]

Its reflection response is exactly the safe four-phase Fejér average of the original two-reactive lossless reflection \(F(t)=(2t+1)(3t+1)/[(t+2)(t+3)]\):

\[
G(t)=\tfrac12F(t)+\tfrac14F(it)+\tfrac14F(-it)=\frac{12t^6+35t^5+103t^4+5t^3+163t^2+210t+72}{2t^6+10t^5+38t^4+130t^3+228t^2+360t+432}.
\]

The numerator and denominator are coprime. Consequently, the McMillan degree is six. The degree lower bound is **not** a general six-reactive transformer-free existence theorem.

## Theorem 1. Exact minimal rational degree at three frequency anchors

Direct substitution gives

\[
\boxed{Z_6(0)=3,\quad Z_6(\infty)=3,\quad Z_6(i)=1+2i.}
\]

Because the coefficients are real, the conjugate data at \(-i\) follow automatically. The corresponding reflection data are \(G(1)=G(-1)=1/2\) and \(G(i)=(1+i)/2\), \(G(-i)=(1-i)/2\). These are four boundary points of the disk.

**Theorem.** Among real-rational positive-real impedances satisfying the displayed three conditions, the least possible rational degree is exactly **three**.

**Lower bound.** A degree-one rational response with identical values at zero and infinity is constant. Any nonconstant degree-two candidate, after normalizing the denominator, is

\[
Z(s)=\frac{3as^2+bs+3c}{as^2+es+c}.
\]

The interpolation condition \(Z(i)=1+2i\) forces \(e=a-c\) and \(b=c-a=-e\). With a stable real quadratic denominator, \(a,c>0\) and \(e\ge0\). If \(e>0\), the numerator has a negative linear coefficient and thus a right-half-plane zero, contradicting positive realness. If \(e=0\), then \(a=c\), \(b=0\), and cancellation leaves the constant response \(Z=3\), also contradicting \(Z(i)=1+2i\). Therefore degree two is impossible, including the boundary-degenerate case.

**Construction.** Define the degree-three Schur polynomial

\[
H_3(t)=\frac12+\frac14(t-t^3).
\]

It takes the same four reflection values as \(G\) and has exact Cayley impedance

\[
\boxed{Z_3(s)=\frac{3s^3+11s^2+7s+3}{s^3+s^2+5s+1}.}
\]

This fraction is coprime. Since \(|H_3(t)|\le1/2+(|t|+|t|^3)/4\le1\) on the unit disk, \(Z_3\) is positive-real. In fact, the exact boundary norm is strictly smaller than one:

\[
\boxed{\|H_3\|_{H^\infty}=\sqrt{13}/4\approx0.901388.}
\]

To verify sharpness, put \(x=\cos\theta\). Then

\[
|H_3(e^{i\theta})|^2=\frac12+x-\frac14x^2-x^3.
\]

The derivative vanishes at \(x=1/2\) and \(x=-2/3\); comparison with the endpoints gives the maximum \(13/16\). This establishes the degree-three upper bound and completes the theorem. **It does not assert that three physical reactive elements suffice without transformers.**

![Python-generated Smith disk with exact anchors](figures/34_exact_anchor_ambiguity_smith.png)

## Theorem 2. A sharper global passivity margin for the degree-six target

On \(t=e^{i\theta}\), set \(x=\cos\theta\). Exact Fourier/Chebyshev reduction of \(|G(t)|^2\) gives

\[
\boxed{R(x)=\frac{6912x^6+20160x^5+23076x^4+2555x^3-14063x^2-840x+7200}{4(3x+5)(4x+5)(9x^2+16)(16x^2+9)}.}
\]

The denominator is strictly positive for \(-1\le x\le1\). The stationary points of \(R\) in this interval are the three roots of

\[
43200x^9+448560x^8+1379556x^7+2101295x^6+1969310x^5+1235710x^4+262862x^3-482545x^2-412428x-65520=0
\]

lying in \((-1,1)\). Exact rational root isolation selects the middle critical point
\(\xi\approx-0.214257162267435\) as the global maximum. Its squared peak is \(R(\xi)\approx0.585034342753307\), so

\[
\boxed{\|G\|_{H^\infty}=\sqrt{R(\xi)}\approx0.764875377269596.}
\]

A simpler fully rational certificate is

\[
\boxed{\|G\|_{H^\infty}<\frac{7649}{10000}=0.7649.}
\]

The checker forms \((7649/10000)^2|D(e^{i\theta})|^2-|N(e^{i\theta})|^2\), expresses it as a degree-six rational-coefficient polynomial in \(x\), and uses exact Sturm root counts to verify that it has **no zero** in \([-1,1]\) and is strictly positive at \(x=0\). There is no frequency-grid approximation in this statement.

Consequently, every point of the normalized six-state impedance obeys the global real-part bound

\[
\boxed{\operatorname{Re}Z_6(i\omega)>\frac{2351}{17649}\approx0.13321\quad\text{for all real }\omega.}
\]

This strengthens the earlier \(1/9\) passivity margin. It is a conservative lower bound on real impedance, not the separately optimized sharp minimum of \(\operatorname{Re}Z_6\).

![Python-generated exact boundary reflection norms](figures/35_certified_reflection_norm.png)

## Theorem 3. Finite-data ambiguity is quantitatively large

The degree-three and degree-six impedances are both strictly passive and agree at \(s=0\), \(s=i\), and \(s=\infty\). Nevertheless, their global responses differ markedly.

The reflection discrepancy admits the **exact factorization**

\[
\boxed{G(t)-H_3(t)=\frac{(t^4-1)(t^5+5t^4+18t^3+82t^2+156t+288)}{2(2t^6+10t^5+38t^4+130t^3+228t^2+360t+432)}.}
\]

The factor \(t^4-1\) explains the four matching disk-boundary points, but does not force small error between them. At normalized \(s=i/3\), equivalently \(t=(-4+3i)/5\), the difference is exactly

\[
G(t)-H_3(t)=\frac{-3000137-88441i}{4088500},
\qquad |G(t)-H_3(t)|^2=\frac{4406821}{8177000}.
\]

Thus \(|G-H_3|>73/100\) at that exact frequency. The same Chebyshev/Sturm procedure used above proves the full-boundary upper bound \(\|G-H_3\|_{H^\infty}<92/125\). The maximum-modulus principle extends this upper bound to the entire disk. Together:

\[
\boxed{\frac{73}{100}<\|G-H_3\|_{H^\infty}<\frac{92}{125}.}
\]

At \(s=i/3\), the two impedances are respectively

\[
Z_6(i/3)=\frac{1875}{6089}-\frac{2764}{30445}i,\qquad Z_3(i/3)=\frac{237}{157}-\frac{42}{157}i.
\]

The rigorous conclusion is a **concrete nonidentifiability example**: matching a finite set of Smith-chart measurements, even exactly and with strict passivity, does not identify the intervening response or its rational degree. The general principle is classical Nevanlinna–Pick/Schur interpolation theory. The particular rational witness and constants are specific calculations and are **not a verified priority claim**.

![Python-generated all-frequency reflection error](figures/36_interpolation_error_frequency.png)

## Relation to the original six-reactive-element synthesis problem

Nothing in these three theorems produces a six-reactive-element transformer-free network for \(Z_6\), nor a proof that such a circuit is impossible. They establish:

1. A rigorous passive interpolation baseline for selected normalized frequencies, with minimum rational degree three.
2. An exact algebraic measure of how much the degree-six target can differ from that baseline despite exact agreement on all prescribed data.
3. A stronger, independently verified all-frequency passivity margin for the degree-six target, useful when certifying future candidates and measurement tolerances.

The previous **three-inductor/three-capacitor allocation** and five-node topology constraints remain necessary conditions. The earlier series-of-independent-pole-pairs obstruction is unaffected. New numerical coupled-circuit fits did not yield a zero-residual algebraic identity; such fits are *not* feasibility or infeasibility certificates.

A next constructive route is to work with the exact nodal cofactor polynomial identities of one fixed coupled 3L+3C topology and search for a certified positive algebraic solution. To establish minimum order, a matching complete nonexistence certificate for all smaller permitted reactive budgets would also be required.

## Reproducibility, prior literature and boundaries

Run `python smith_q6_four_anchor_certificates.py` for the exact SymPy symbolic, Sturm, and rational-interval certificates. Run `python smith_q6_anchor_figures.py` to recreate the three Matplotlib figures. The exact checker includes no fitted component values or numerical root tests in place of a proof. Decimal approximations only display the isolated algebraic constants.

Relevant prior work includes the classical Schur–Nevanlinna interpolation theory, the multi-point Schur interpolation treatment of Bultheel and Lasarow (2008), and transformer-free RLC synthesis/realizability classifications by Jiang and Smith (2011) and Morelli (2019). The present four-anchor theorem should not be described as a newly discovered general interpolation theorem.

- Bultheel and Lasarow, *Solution of a multiple Nevanlinna–Pick problem for Schur functions via orthogonal rational functions*, *Analysis* 28(1), 95–123 (2008). DOI 10.1524/anly.2008.0904.
- Jiang and Smith, *Regular positive-real functions and five-element network synthesis*, *IEEE Transactions on Automatic Control* 56(6), 1275–1290 (2011). DOI 10.1109/TAC.2010.2077810.
- Morelli, *Synthesis of electrical and mechanical networks of restricted complexity*, Cambridge doctoral thesis (2019). https://www.repository.cam.ac.uk/items/c41b15a3-f6b3-4650-b7b9-65f14425f0e1

**Open synthesis gap:** exact transformer-free realization with six energy-storage elements of \(Z_6\), or a valid impossibility proof. **No change has been made to the public GitHub/.io reading site.**
