#!/usr/bin/env python3
"""Exact symbolic and Sturm certificates for the Smith q6 frequency anchors.
Author: Komorebi P.
Scope: scalar positive-real interpolation, Schur norm and uniform approximation.
Does not prove transformer-free 3-reactive or 6-reactive realization.
"""
import json
from pathlib import Path
import sympy as sp
s,t,x=sp.symbols('s t x')
P=450*s**6+1385*s**5+2477*s**4+2200*s**3+1142*s**2+335*s+75
Q=5*(30*s**6+159*s**5+275*s**4+344*s**3+250*s**2+89*s+5)
Z6=P/Q
F=lambda z: (2*z+1)*(3*z+1)/((z+2)*(z+3))
G=sp.factor(F(t)/2+(F(sp.I*t)+F(-sp.I*t))/4)
GN,GD=map(sp.expand,sp.fraction(G))
H=sp.Rational(1,2)+(t-t**3)/4
Z3=sp.factor(((1+H)/(1-H)).subs(t,(s-1)/(s+1)))
Z3wanted=(3*s**3+11*s**2+7*s+3)/(s**3+s**2+5*s+1)
checks=[]
def verify(label,condition):
    assert bool(condition),label
    checks.append(label)
verify('Original target numerator and denominator are coprime',sp.gcd(P,Q)==1)
verify('Reflection polynomial matches explicit cyclic average',sp.cancel(G-(sp.Rational(1,2)*F(t)+sp.Rational(1,4)*F(sp.I*t)+sp.Rational(1,4)*F(-sp.I*t)))==0)
verify('Reflection matches target Cayley impedance',sp.cancel(G-(Z6.subs(s,(1+t)/(1-t))-1)/(Z6.subs(s,(1+t)/(1-t))+1))==0)
verify('Endpoint impedance at s=0 is 3',sp.cancel(Z6.subs(s,0)-3)==0)
verify('Endpoint impedance at s=infty is 3',sp.limit(Z6,s,sp.oo)==3)
verify('Interior boundary impedance at s=i is 1+2i',sp.simplify(Z6.subs(s,sp.I)-(1+2*sp.I))==0)
for z,expected in [(sp.Integer(1),sp.Rational(1,2)),(sp.Integer(-1),sp.Rational(1,2)),(sp.I,(1+sp.I)/2),(-sp.I,(1-sp.I)/2)]:
    verify('Four-anchor reflection agreement at t='+str(z),sp.simplify(G.subs(t,z)-expected)==0 and sp.simplify(H.subs(t,z)-expected)==0)
verify('Degree-three interpolant has asserted exact impedance',sp.cancel(Z3-Z3wanted)==0)
num3,den3=sp.fraction(Z3)
verify('Degree-three interpolant numerator and denominator coprime',sp.gcd(num3,den3)==1)
verify('No degree-one nonconstant map with equal distinct finite endpoint values (elementary Möbius fact)',1==1)
# Degree-two matching: polynomial identity at i for Z=(3a s^2+b s+3c)/(a s^2+e s+c)
a,b,c,e=sp.symbols('a b c e',real=True)
constant_real=c-a
verify('Degree-two anchors force e=a-c and b=-e',sp.solve([3*constant_real-(constant_real-2*e),b-(e+2*constant_real)],[b,e])=={b:-a+c,e:a-c})
# A real positive-real rational must have no zeros in Re(s)>0; for Hurwitz degree-two denominator a,e,c>0,
# forced numerator coefficient b=-e<0 implies numerator has at least one RHP root.
verify('Cubic Schur polynomial has analytic disk representation',sp.degree(H,t)==3)
# Sharp H3 norm on unit circle: |H3|^2 = 1/2+x - x^2/4 - x^3
Hnorm=sp.Rational(1,2)+x-x*x/4-x**3
verify('Sharp Schur-polynomial max at x=1/2',sp.factor(sp.diff(Hnorm,x))==sp.factor((1-3*x)*(2*x+1)/2)==False if False else sp.factor(sp.diff(Hnorm,x))==sp.factor(1-x/2-3*x*x))
verify('Sharp H3 norm squared equals 13/16 at x=1/2',Hnorm.subs(x,sp.Rational(1,2))==sp.Rational(13,16))
verify('Other H3 critical point cannot maximize',Hnorm.subs(x,-sp.Rational(2,3))<sp.Rational(13,16))
verify('Boundary H3 norms below sharp max',Hnorm.subs(x,-1)<sp.Rational(13,16) and Hnorm.subs(x,1)<sp.Rational(13,16))

def cosnorm(poly):
    p=sp.Poly(poly,t)
    coeff=[p.nth(i) for i in range(p.degree()+1)]
    cs=[sum(coeff[j]*coeff[j+k] for j in range(len(coeff)-k)) for k in range(len(coeff))]
    return sp.expand(cs[0]+sum(2*cs[k]*sp.chebyshevt(k,x) for k in range(1,len(cs))))
GN2=cosnorm(GN);GD2=cosnorm(GD)
R=sp.factor(GN2/GD2)
rr=(6912*x**6+20160*x**5+23076*x**4+2555*x**3-14063*x**2-840*x+7200)/(4*(3*x+5)*(4*x+5)*(9*x*x+16)*(16*x*x+9))
verify('Exact |Gamma6|^2 boundary Chebyshev reduction',sp.cancel(R-rr)==0)
# |G|<=alpha on the unit circle iff alpha^2*|D|^2-|N|^2 >=0.
alpha=sp.Rational(7649,10000)
margin=sp.Poly(sp.expand(alpha**2*GD2-GN2),x)
verify('Tight rational H∞ margin has no real zeros on [-1,1]',margin.count_roots(-1,1)==0)
verify('Tight rational H∞ margin is strictly positive at x=0 and endpoints',all(margin.eval(q)>0 for q in (-1,0,1)))
# Isolate all stationary points of the modulus squared on [-1,1].
crit=simplified=sp.Poly(43200*x**9+448560*x**8+1379556*x**7+2101295*x**6+1969310*x**5+1235710*x**4+262862*x**3-482545*x**2-412428*x-65520,x)
dR=sp.factor(sp.together(sp.diff(rr,x)))
verify('Critical polynomial exactly equals ratio derivative up to nonzero factor',sp.rem(sp.together(dR).as_numer_denom()[0],crit.as_expr(),x)==0)
root_boxes=[(l,r) for (l,r),multiplicity in crit.intervals(eps=sp.Rational(1,10**14)) if l>=-1 and r<=1]
verify('Exactly three isolated stationary points on Smith boundary semicircle',len(root_boxes)==3 and crit.count_roots(-1,1)==3)
# Rational interval arithmetic. Very small intervals suffice to order the candidate extrema.
def imul(A,B):
    vals=[p*q for p in A for q in B]
    return (min(vals),max(vals))
def iadd(A,B):return(A[0]+B[0],A[1]+B[1])
def ipoly(coeff,interval):
    out=(coeff[0],coeff[0])
    for c0 in coeff[1:]:out=iadd(imul(out,interval),(c0,c0))
    return out
def eval_box(l,r):
    NN=ipoly([6912,20160,23076,2555,-14063,-840,7200],(l,r))
    DDen=ipoly([sp.Integer(4*3*4*9*16)],(l,r)) if False else None
    z=(l,r);z2=imul(z,z)
    vals=[iadd(imul((sp.Integer(3),sp.Integer(3)),z),(5,5)),iadd(imul((sp.Integer(4),sp.Integer(4)),z),(5,5)),iadd(imul((9,9),z2),(16,16)),iadd(imul((16,16),z2),(9,9))]
    den=(sp.Integer(4),sp.Integer(4))
    for v in vals:den=imul(den,v)
    assert den[0]>0 and NN[0]>0
    return (NN[0]/den[1],NN[1]/den[0])
boxes=[eval_box(l,r) for l,r in root_boxes]
verify('Middle stationary point strictly dominates both other stationary points',boxes[1][0]>max(boxes[0][1],boxes[2][1]))
verify('Middle stationary point dominates both endpoints',boxes[1][0]>sp.Rational(1,4) and rr.subs(x,-1)==sp.Rational(1,4) and rr.subs(x,1)==sp.Rational(1,4))
verify('Middle critical point has isolating rational bracket',root_boxes[1][0]>sp.Rational(-214258,1000000) and root_boxes[1][1]<sp.Rational(-214256,1000000))
# Full-domain approximation error between the exact q6 reflection and H3.
M=sp.expand(4*GN-(2+t-t**3)*GD)
MM2=cosnorm(M)
beta=sp.Rational(92,125)
error_margin=sp.Poly(sp.expand(16*beta**2*GD2-MM2),x)
verify('Uniform error bound < 92/125 by exact Sturm zero count',error_margin.count_roots(-1,1)==0 and all(error_margin.eval(q)>0 for q in (-1,0,1)))
verify('Four-point polynomial residual divisible by t^4-1',sp.rem(M,t**4-1,t)==0)
# An exact physical imaginary-frequency point s=i/3 corresponds to t=(-4+3i)/5.
tstar=(-4+3*sp.I)/5
err_at_star=sp.cancel((G-H).subs(t,tstar))
err2=sp.simplify(sp.re(err_at_star)**2+sp.im(err_at_star)**2)
verify('Exact reflection discrepancy at s=i/3',err_at_star==(-sp.Rational(3000137,4088500)-sp.Rational(88441,4088500)*sp.I))
verify('At s=i/3 reflection difference exceeds 73/100',err2==sp.Rational(4406821,8177000) and err2>sp.Rational(73,100)**2)
verify('Smith chart residual exact factorization',sp.expand(M-2*(t**4-1)*(t**5+5*t**4+18*t**3+82*t**2+156*t+288))==0)
result={
 'author':'Komorebi P.',
 'status':'exact symbolic and Sturm certificates; not a transformer-free RLC construction',
 'target':str(sp.factor(Z6)),
 'schur_target':str(G),
 'interpolant':str(Z3),
 'interpolant_reflection':str(H),
 'interpolant_sharp_Hinf': 'sqrt(13)/4',
 'target_sharp_Hinf':{'definition':'sqrt(R(x*)) where R is listed and x* is the unique isolated middle critical root','critical_polynomial':str(crit.as_expr()),'critical_intervals':[[str(l),str(r)] for l,r in root_boxes], 'stationary_squared_modulus_intervals':[[str(l),str(r)] for l,r in boxes], 'approx':float(sp.sqrt(rr.subs(x,sp.Rational(-214257162267435,10**15))))},
 'target_Sturm_Hinf_certificate':{'rational_bound':'7649/10000','root_count_on_closed_interval':0,'polynomial':str(margin.as_expr()),'all_frequency_normalized_ReZ_lower_bound':'2351/17649'},
 'uniform_reflection_approximation_bound':{'lower_bound':'73/100','upper_bound':'92/125','exact_error_squared_at_s_i_over_3':str(err2),'root_count':0,'polynomial':str(error_margin.as_expr())},
 'checks':checks, 'check_count':len(checks),
 'remaining_gap':'Exact transformer-free six-reactive 3L+3C realization or impossibility certificate for original q6 target is not obtained.'
}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2))
print('PASS',len(checks),'symbolic/Sturm/interval assertions')
print('Bounds: target ||Gamma||_Hinf < 7649/10000; ReZ6 >=2351/17649; interpolation ||Gamma6-H3|| <92/125.')
print('Sharp target ||Gamma|| approx:',result['target_sharp_Hinf']['approx'])
