#!/usr/bin/env python3
"""Recreate exactly calculated visuals for the unpublished Smith-chart addendum.
Author: Komorebi P. Python / NumPy / Matplotlib only.
"""
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
R=Path(__file__).parent/'figures';R.mkdir(parents=True,exist_ok=True)

def F(t):return (2*t+1)*(3*t+1)/((t+2)*(t+3))
def G(t):return .5*F(t)+.25*F(1j*t)+.25*F(-1j*t)
def H(t):return .5+.25*(t-t**3)
def t_from_w(w):return (1j*w-1)/(1j*w+1)
def style(ax):
    ax.spines[['top','right']].set_visible(False)
    ax.grid(alpha=.17,linewidth=.65)
    ax.tick_params(labelsize=10)
    ax.set_axisbelow(True)
blue='#2E617C';green='#3F725A';rust='#AF654B';ink='#243C35';gray='#707E7A'
w=np.geomspace(1e-4,1e4,2600);t=t_from_w(w)
# 34 Smith disk comparison
fig,ax=plt.subplots(figsize=(9.8,6.6),layout='constrained');ax.set_aspect('equal')
ph=np.linspace(0,2*np.pi,500);ax.plot(np.cos(ph),np.sin(ph),linewidth=1.8,color='#AAB6AE',label='Unit circle |Γ| = 1')
for rad in (.25,.5,.75):ax.plot(rad*np.cos(ph),rad*np.sin(ph),linewidth=.65,color='#D5DDD6')
ax.axhline(0,color='#D4DED7',linewidth=.7);ax.axvline(0,color='#D4DED7',linewidth=.7)
ax.plot(G(t).real,G(t).imag,color=blue,linewidth=2.3,label='Exact degree-six response')
ax.plot(H(t).real,H(t).imag,color=green,linewidth=2,linestyle='--',label='Degree-three passive interpolant')
for label,ww in [('ω = 1',1.),('ω = 1/3',1/3)]:
    tt=t_from_w(ww); zz=G(tt);hh=H(tt)
    ax.scatter([zz.real],[zz.imag],s=52,color=blue,zorder=4,edgecolor='white',linewidth=.9)
    if label=='ω = 1/3':
        ax.scatter([hh.real],[hh.imag],s=56,marker='D',color=green,zorder=4,edgecolor='white',linewidth=.7)
        ax.plot([hh.real,zz.real],[hh.imag,zz.imag],linestyle=':',color=rust,linewidth=1.3)
        ax.annotate('ω = 1/3: distinct passive responses',(zz.real,zz.imag),xytext=(-.91,-.80),textcoords='data',fontsize=9,color=ink,arrowprops=dict(arrowstyle='-',lw=.8,color=gray))
    else:
        ax.annotate('ω = 1: exact agreement',(zz.real,zz.imag),xytext=(-.88,.77),textcoords='data',fontsize=9,color=ink,arrowprops=dict(arrowstyle='-',lw=.8,color=gray))
ax.scatter([.5],[0],s=65,marker='s',color=rust,zorder=6,edgecolor='white',linewidth=.7)
ax.annotate('DC and high frequency: Γ = 1/2',(.5,0),xytext=(.43,-.92),textcoords='data',fontsize=9,arrowprops=dict(arrowstyle='-',lw=.8,color=gray),color=ink)
ax.set(xlabel='Re Γ',ylabel='Im Γ',xlim=(-1.04,1.04),ylim=(-1.04,1.04))
ax.set_title('Smith disk | Identical anchors, distinct frequency responses',loc='left',fontsize=14,fontweight='semibold',color=ink)
ax.legend(loc='upper right',frameon=False,fontsize=9)
fig.savefig(R/'34_exact_anchor_ambiguity_smith.png',dpi=200);fig.savefig(R/'34_exact_anchor_ambiguity_smith.svg');plt.close(fig)
# 35 sharp boundary modulus
x=np.linspace(-1,1,2400)
q=(6912*x**6+20160*x**5+23076*x**4+2555*x**3-14063*x**2-840*x+7200)/(4*(3*x+5)*(4*x+5)*(9*x*x+16)*(16*x*x+9))
q3=.5+x-x*x/4-x**3
fig,ax=plt.subplots(figsize=(9.6,4.9),layout='constrained');style(ax)
ax.plot(x,np.sqrt(q),color=blue,lw=2.4,label='Exact |Γ₆| on the unit circle')
ax.plot(x,np.sqrt(q3),color=green,lw=2,ls='--',label='Interpolant |Γ₃|')
ax.axhline(7649/10000,color=rust,linestyle=':',lw=1.6,label='Certified bound 0.7649 for Γ₆')
xi=-.214257162267435;mx=float(np.sqrt((6912*xi**6+20160*xi**5+23076*xi**4+2555*xi**3-14063*xi**2-840*xi+7200)/(4*(3*xi+5)*(4*xi+5)*(9*xi*xi+16)*(16*xi*xi+9))))
ax.scatter([xi],[mx],s=55,color=blue,edgecolor='white',linewidth=.7,zorder=3)
ax.annotate('Sharp peak ≈ 0.76487538',(xi,mx),xytext=(-.91,.94),fontsize=10,arrowprops=dict(arrowstyle='-',lw=.8,color=gray),color=ink)
ax.set(xlabel='x = cos θ on reflection-circle boundary',ylabel='Reflection magnitude',xlim=(-1,1),ylim=(0,1.02))
ax.set_title('Uniform passivity | Exact boundary norm certificates',loc='left',fontsize=14,fontweight='semibold',color=ink)
ax.legend(loc='lower left',frameon=False,fontsize=9)
fig.savefig(R/'35_certified_reflection_norm.png',dpi=200);fig.savefig(R/'35_certified_reflection_norm.svg');plt.close(fig)
# 36 rigorous ambiguity band
w=np.geomspace(1e-3,1e3,4000);v=np.abs(G(t_from_w(w))-H(t_from_w(w)))
fig,ax=plt.subplots(figsize=(9.6,4.8),layout='constrained');style(ax)
ax.semilogx(w,v,lw=2.35,color=rust,label='|Γ₆(iω) − Γ₃(iω)|')
ax.axhline(92/125,color=blue,ls=':',lw=1.5,label='Proven uniform upper bound 92/125')
ax.scatter([1/3,1],[float(abs(G(t_from_w(1/3))-H(t_from_w(1/3)))),0],color=[rust,green],s=50,zorder=4,edgecolor='white',linewidth=.8)
ax.axvline(1/3,linestyle='--',color='#A9B7A9',lw=1)
ax.axvline(1,linestyle='--',color='#A9B7A9',lw=1)
ax.annotate('ω = 1/3\nerror > 0.73',(1/3,float(abs(G(t_from_w(1/3))-H(t_from_w(1/3))))),xytext=(.005,.42),fontsize=10,arrowprops=dict(arrowstyle='-',lw=.8,color=gray),color=ink)
ax.annotate('ω = 1\nexact match',(1,0),xytext=(3,.20),fontsize=10,arrowprops=dict(arrowstyle='-',lw=.8,color=gray),color=ink)
ax.set(xlabel='Normalized angular frequency ω (logarithmic)',ylabel='Absolute reflection difference',xlim=(.001,1000),ylim=(0,.87))
ax.set_title('Finite-frequency ambiguity | Two strictly passive models',loc='left',fontsize=14,fontweight='semibold',color=ink)
ax.legend(loc='upper right',frameon=False,fontsize=9)
fig.savefig(R/'36_interpolation_error_frequency.png',dpi=200);fig.savefig(R/'36_interpolation_error_frequency.svg');plt.close(fig)
print('Saved 3 Matplotlib figures in SVG and PNG.')
