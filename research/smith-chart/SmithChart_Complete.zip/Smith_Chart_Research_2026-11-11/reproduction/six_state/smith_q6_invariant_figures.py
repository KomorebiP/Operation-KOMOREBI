#!/usr/bin/env python3
"""Create exact-invariant and graph-pruning figures entirely with Python.
Author: Komorebi P.
"""
from pathlib import Path
import json, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch
import networkx as nx
from sympy import symbols, lambdify

BASE=Path(__file__).parent; OUT=BASE/'figures';OUT.mkdir(exist_ok=True)
INK='#233d32'; EMERALD='#2c6952'; DEEP='#203a4c'; BLUE='#4a6e8f'; GOLD='#b18236'; RED='#a34c4b'; MUTED='#5d6b61'; PARCHMENT='#faf9f5'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.titlesize':13,'axes.labelsize':11,'axes.edgecolor':'#cbd4c8','axes.labelcolor':INK,'axes.titlecolor':INK,'xtick.color':MUTED,'ytick.color':MUTED,'figure.facecolor':'white','axes.facecolor':PARCHMENT,'savefig.facecolor':'white','svg.fonttype':'none'})

def finish(fig,name):
 fig.savefig(OUT/name,bbox_inches='tight',pad_inches=.2)
 plt.close(fig);print(name)

# Exact Sylvester signature
sg=[1,-1,-1,1,1,1,-1]
fig,ax=plt.subplots(figsize=(10.3,3.35));ks=np.arange(7)
ax.axhline(0,color='#aabbb2',lw=1)
for k,v in enumerate(sg):
 ax.plot(k,v,'o',markersize=11,color=EMERALD if v>0 else GOLD,zorder=3)
 if k: ax.plot([k-1,k],[sg[k-1],v],lw=2,color=RED if v!=sg[k-1] else BLUE)
 ax.text(k,v+(.13 if v>0 else -.2),'+' if v>0 else '−',color=INK,ha='center',va='center',fontsize=15,fontweight='bold')
ax.set_xticks(ks,[r'$S_0$',r'$S_2$',r'$S_4$',r'$S_6$',r'$S_8$',r'$S_{10}$',r'$S_{12}$'])
ax.set_yticks([-1,1],['Negative','Positive']);ax.set_ylim(-1.65,1.6);ax.set_xlim(-.4,6.4)
ax.set_title('Exact Sylvester signature: three changes, three permanences',loc='left',fontweight='bold',pad=15)
ax.text(.04,.05,'3 inductors  •  3 capacitors  •  conditional on exactly six reactive elements',transform=ax.transAxes,color=MUTED,fontsize=10)
ax.spines[['top','right']].set_visible(False);fig.tight_layout();finish(fig,'23_sylvester_reactive_signature.svg')

# Laplace real-axis reactance balance: derivative sign flip
ss=np.logspace(-3,2.6,1100)
P=lambda s:450*s**6+1385*s**5+2477*s**4+2200*s**3+1142*s**2+335*s+75
D=lambda s:5*(30*s**6+159*s**5+275*s**4+344*s**3+250*s**2+89*s+5)
poly=lambda s:3750*s**10+12360*s**9+31679*s**8+70780*s**7+111388*s**6+111300*s**5+64642*s**4+16020*s**3-3314*s**2-3260*s-625
z=P(ss)/D(ss);dz=40*poly(ss)/D(ss)**2
sstar=0.33531046044782
fig,(ax,bx)=plt.subplots(1,2,figsize=(11.4,3.9),gridspec_kw={'width_ratios':[1.1,1.0]})
ax.plot(ss,z,color=EMERALD,lw=2.5)
ax.scatter([sstar],[P(sstar)/D(sstar)],color=GOLD,zorder=4)
ax.axvline(sstar,ls='--',color=GOLD,lw=1.4)
ax.axhline(3,ls=':',color=MUTED,lw=1.3)
ax.set_xscale('log');ax.set_title('Input impedance on real $s>0$',loc='left',fontweight='bold');ax.set_xlabel('Dimensionless Laplace variable  $s>0$');ax.set_ylabel('$Z(s)$, normalized')
ax.set_ylim(0.8,3.1);ax.text(.035,2.72,r'$Z(0)=Z(\infty)=3$',color=MUTED,fontsize=10)
bx.plot(ss,dz,color=BLUE,lw=2.2)
bx.fill_between(ss,dz,0,where=dz<0,color=RED,alpha=.16)
bx.fill_between(ss,dz,0,where=dz>0,color=EMERALD,alpha=.16)
bx.axhline(0,color='#80998a',lw=1)
bx.axvline(sstar,ls='--',color=GOLD,lw=1.4)
bx.set_xscale('log');bx.set_ylim(-45,12)
bx.set_title('Exact capacitor–inductor slope balance',loc='left',fontweight='bold')
bx.set_xlabel('Dimensionless Laplace variable  $s>0$');bx.set_ylabel('$Z\'(s)$')
bx.annotate(r'$s_*\approx 0.33531046$',xy=(sstar,0),xytext=(1.2,-19),fontsize=10,color=INK,arrowprops={'arrowstyle':'->','color':MUTED})
for a in (ax,bx):a.grid(True,alpha=.13);a.spines[['top','right']].set_visible(False)
fig.tight_layout();finish(fig,'24_unique_reactive_sensitivity_crossover.svg')

# Exact counts, all L/C 3-subsets may overlap each other
fig,ax=plt.subplots(figsize=(10.2,4.7))
levels=[('All labeled placements',14400),('No endpoint shorts',3249),('No same-type cycles',2500),('Both slope signs possible',1934),('Terminal-preserving orbits',168)]
Y=np.arange(len(levels))[::-1]
ax.barh(Y,[j[1] for j in levels],color=[BLUE,'#72968a','#668b7a',EMERALD,GOLD],height=.56)
ax.set_yticks(Y,[v[0] for v in levels]);ax.set_xlim(0,15400)
for y,(_,v) in zip(Y,levels):ax.text(v+180,y,f'{v:,}',va='center',fontsize=10.5,weight='bold',color=INK)
ax.set_title('Five-node topology reduction before component fitting',loc='left',fontweight='bold',pad=14)
ax.set_xlabel('Number of labeled placements (last row: symmetry classes)')
fig.text(.57,.02,'Exact enumeration. Passing a filter does not imply realizability.',ha='center',color=MUTED,fontsize=10)
ax.spines[['top','right','left']].set_visible(False);ax.tick_params(axis='y',length=0);ax.grid(axis='x',alpha=.12)
fig.tight_layout(rect=[0,.10,1,1]);finish(fig,'25_five_node_exact_topology_pruning.svg')

# Diagram of node-edge necessary visibility condition
pos={0:(0,0),1:(3.1,0),2:(-.12,1.65),3:(1.55,1.85),4:(3.2,1.65)}
examples=[('Rejected: every C is L-shorted at DC',[(0,2),(0,3),(0,4)],[(0,2),(0,3),(0,4)]),('Not rejected: C voltage can survive',[(0,2),(0,3),(0,4)],[(0,2),(0,3),(1,4)])]
fig,axes=plt.subplots(1,2,figsize=(11.3,4.2))
for ax,(ttl,ls,cs) in zip(axes,examples):
 ax.set_xlim(-.8,3.8);ax.set_ylim(-.48,2.15);ax.set_aspect('equal');ax.set_title(ttl,loc='left',fontweight='bold',fontsize=11)
 for e in ls:
  u,v=e;path=FancyArrowPatch(pos[u],pos[v],connectionstyle='arc3,rad=.16',arrowstyle='-',lw=2.5,color=BLUE,zorder=1);ax.add_patch(path)
 for e in cs:
  u,v=e;path=FancyArrowPatch(pos[u],pos[v],connectionstyle='arc3,rad=-.16',arrowstyle='-',lw=2.5,color=GOLD,zorder=1);ax.add_patch(path)
 for node,p in pos.items():
  ax.scatter(*p,s=450,color=PARCHMENT,edgecolor=EMERALD,lw=1.7,zorder=3)
  ax.text(*p,str(node),ha='center',va='center',weight='bold',color=INK,zorder=4)
 ax.text(0,-.36,'ground (0)',fontsize=8,color=MUTED,ha='center')
 ax.text(3.1,-.36,'port (1)',fontsize=8,color=MUTED,ha='center')
 ax.axis('off')
fig.text(.52,.015,'Inductor: blue   ·   Capacitor: amber   ·   Resistors can occupy any node pair',ha='center',color=MUTED,fontsize=10)
fig.tight_layout(rect=[0,.05,1,1]);finish(fig,'26_reactive_endpoint_graph_examples.svg')
