## Exactly six reactive elements with an ideal reciprocal combiner

The filtered degree-six LC response from (O15) admits a fully specified passive realization with exactly six reactive elements, **provided an ideal static transformer and isolation resistor are allowed**. This result does not imply six-reactive-element realizability with an RLC-only network. The ideal transformer carries no independent energy-storage state, but is an additional, excluded device for the transformer-free problem.

Write the original two-reactive-element series-LC reflection and its conjugate rotation average as

\[
F(t)=\frac{(2t+1)(3t+1)}{(t+2)(t+3)},\qquad
H(t)=\frac{F(it)+F(-it)}{2}
=\frac{6(1-t^2)^2}{(t^2+4)(t^2+9)}.
\tag{C1}
\]

The safe fourth-order Fejér response is \(G(t)=(F(t)+H(t))/2\). Under \(t=(s-1)/(s+1)\), the normalized impedance of \(H\) is

\[
z_H(s)=1+\frac{48s}{35(s^2+1)}
-\frac{48s}{7(5s^2+14s+5)}.
\tag{C2}
\]

It has an exact series decomposition into a parallel LC tank and the parallel connection of a resistor with a series RLC branch:

\[
\boxed{
 z_H(s)=
 \underbrace{\left(\frac{1}{(48/35)s}+(35/48)s\right)^{-1}}_{\text{parallel LC}}
 +\underbrace{\left(1+\frac1{25/24+(35/48)s+1/((48/35)s)}\right)^{-1}}_{\text{resistor parallel to series RLC}}.
}\tag{C3}
\]

The first part uses one inductor and one capacitor, and the second uses one inductor, one capacitor, and two resistors. All coefficients are positive. The reduced denominator of \(z_H\) has degree four, so this **four-reactive-element** circuit attains its degree lower bound. The \(F\) circuit is the original series LC with \(L=6/5,C=5\).

![Exact Python-generated ideal three-port and the two passive LC/RLC subnetworks.](figures/17_six_state_ideal_combiner.png)

*Figure 17. Exact 2+4 reactive-state construction in the broader class allowing an ideal static modal transformer.*

![Four-element passive RLC realization of the conjugate rotation subnetwork.](figures/18_four_state_rlc_topology.png)

*Figure 18. Exact normalized values, no fitted elements.*

Connect the two subnetworks to the output terminals of a reciprocal, static, three-port with scattering matrix

\[
S=\begin{pmatrix}
0 & 1/\sqrt2 & 1/\sqrt2\\
1/\sqrt2 & 0 & 0\\
1/\sqrt2 & 0 & 0
\end{pmatrix}.
\tag{C4}
\]

Its passivity matrix is

\[
I-S^{\mathsf T}S=
\begin{pmatrix}
0&0&0\\
0&1/2&-1/2\\
0&-1/2&1/2
\end{pmatrix}\succeq0.
\tag{C5}
\]

Because the outputs have zero mutual scattering and zero direct output reflection, the terminated input reflection is exactly

\[
\boxed{\Gamma_{\mathrm{in}}(t)=\tfrac12F(t)+\tfrac12H(t)=G(t).}
\tag{C6}
\]

Equivalently, if \(a=z_F(s)\) and \(b=z_H(s)\), the input impedance is

\[
\boxed{z_G(s)=\frac{2ab+a+b}{a+b+2}.}
\tag{C7}
\]

The circuit therefore uses exactly **six** energy-storage elements (two in \(F\), four in \(H\)), plus an ideal static three-port coupling device. This achieves the rational-degree lower bound **only in that wider component class**. A separate exact polynomial certificate also proves \(\lvert G(t)\rvert\le 4/5\) for all \(\lvert t\rvert\le1\), hence normalized \(\Re z_G(s)\ge1/9\) on the right half-plane.

![Boundary locus and the exact global reflection bound from the Python-generated verification figure.](figures/19_six_state_smith_passivity.png)

*Figure 19. The bound is established algebraically in the companion checker, not inferred from the plotted samples.*

![Bernstein-polynomial positivity certificate for the global Smith-disk bound.](figures/20_six_state_passivity_certificate.png)

*Figure 20. Exact certificate for \(\lvert G\rvert\le4/5\); plotting is supporting illustration only.*

The code `smith_six_state_checks.py` records the exact identities, passive element values, nonnegative scattering dissipation, and rational boundary certificate. It does not establish a transformer-free RLC-only synthesis.
