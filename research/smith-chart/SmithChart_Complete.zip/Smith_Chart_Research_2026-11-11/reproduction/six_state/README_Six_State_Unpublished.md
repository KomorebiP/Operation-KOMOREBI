# Six-state Smith chart research package

**Author:** Komorebi P.  
**Status:** Unpublished research, 8 November 2026.

This archive includes the offline self-contained HTML reading edition, the full Markdown manuscript, a standalone chapter of exact necessary conditions for six-reactive-element transformer-free synthesis, Python source for exact computations and graphs, selected numerical experiments, and Python-generated vector figures.

## Key result and limitation

The target degree-six rational impedance has an exact passive realization using ideal transformers, but **a six-reactive-element transformer-free RLC realization is neither constructed nor disproved**. The necessary conditions established here are a 3L+3C allocation, at least five graph nodes, an exact sensitivity crossover, and a five-node enumeration reduced to 168 symmetry classes. These are *necessary* conditions, not an exhaustive nonrealizability certificate.

## Reproduce

Run in the extracted package directory using Python 3 and SymPy:

```bash
python smith_q6_invariant_certificates.py
python smith_mask_checks.py
python smith_realization_checks.py
python smith_order_growth_checks.py
python smith_six_state_checks.py
python smith_transformerfree_decision.py
```

Optional, requires NumPy, SciPy and Matplotlib: run `smith_q6_invariant_figures.py` to regenerate diagrams. Optional browser validation requires Playwright and a local Chromium installation; the HTML is self-contained and opens offline without Python.

The six suites contain 255 exact and structural checks in total. Passing the tests is not an external peer review or a proof of the unresolved existence claim. The numerical fittings are **approximations only** and use nonidentical sample grids.

No changes have been made to the public GitHub or .io sites.
