#!/usr/bin/env python3
"""Improved numerical RLC topology search with exact analytic sensitivities.
Author: Komorebi P.
All results are numerical hypotheses, NOT exact existence or nonexistence certificates.
"""
import numpy as np, itertools, json, argparse, time
from scipy.optimize import least_squares
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--n',type=int,default=5);p.add_argument('--trials',type=int,default=100);p.add_argument('--seed',type=int,default=981771);p.add_argument('--steps',type=int,default=260);a=p.parse_args()
rng=np.random.default_rng(a.seed);n=a.n;edges=list(itertools.combinations(range(n),2));m=len(edges)
P=np.array([450,1385,2477,2200,1142,335,75.]);Q=np.array([150,795,1375,1720,1250,445,25.])
ss=np.r_[1j*np.geomspace(.006,120,34),np.geomspace(.02,30,10)]
target=np.polyval(P,ss)/np.polyval(Q,ss); weights=1/(1+abs(target))
B=np.zeros((m,n-1));
for ei,(i,j) in enumerate(edges):
 if i>0:B[ei,i-1]+=1
 if j>0:B[ei,j-1]-=1
Bcols=B.T

def valid_react(react):
 for subset in [[ei for k,ei in react if k==kind] for kind in ('L','C')]:
  graph={v:set() for v in range(n)}
  # no cycles if possible
  for ei in subset:
   u,v=edges[ei];graph[u].add(v);graph[v].add(u)
  seen={0};todo=[0]
  while todo:
   x=todo.pop()
   for y in graph[x]:
    if y not in seen:seen.add(y);todo.append(y)
  if 1 in seen:return False
 return True

def run(react,x0):
 def calc(x,jac=False):
  g=np.exp(np.clip(x[:m],-18,18));h=np.exp(np.clip(x[m:],-18,18))
  Y=np.broadcast_to(g,(len(ss),m)).astype(complex).copy()
  for hj,(kind,ei) in zip(h,react):Y[:,ei]+=hj*ss if kind=='C' else hj/ss
  mats=np.einsum('ei,fe,ej->fij',B,Y,B,optimize=True)
  try: V=np.linalg.solve(mats,np.broadcast_to(np.eye(n-1)[:,:1],(len(ss),n-1,1)))[:,:,0]
  except np.linalg.LinAlgError:
   return np.full(2*len(ss),1e5),np.zeros((2*len(ss),len(x)))
  err=(V[:,0]-target)*weights
  resid=np.r_[err.real,err.imag]
  if not jac:return resid
  vd=V@B.T
  factors=np.broadcast_to(g,(len(ss),m)).astype(complex).copy()
  reacs=np.zeros((len(ss),len(react)),complex)
  for i,(hj,(kind,ei)) in enumerate(zip(h,react)):
   reacs[:,i]= -vd[:,ei]**2 * (hj*ss if kind=='C' else hj/ss)
  deriv=np.c_[-(vd**2)*factors,reacs]*weights[:,None]
  return resid,np.r_[deriv.real,deriv.imag]
 def fun(x):return calc(x)
 def jac(x):return calc(x,True)[1]
 return least_squares(fun,x0,jac=jac,max_nfev=a.steps,method='trf',ftol=1e-12,xtol=1e-12,gtol=1e-12)

best=1e5;start=time.monotonic(); data=[]
for trial in range(a.trials):
 nr=int(rng.choice([2,3,4]));kinds=['L']*nr+['C']*(6-nr)
 react=None
 for k in range(300):
  locations=rng.choice(m,6,replace=False)
  test=list(zip(kinds,map(int,locations)))
  if valid_react(test):react=test;break
 if react is None:continue
 x0=np.log(rng.lognormal(0,1.5,m+6))
 try:opt=run(react,x0)
 except (ValueError, OverflowError):continue
 resid=opt.fun;err=float(np.max(np.hypot(resid[:len(ss)],resid[len(ss):])))
 if err<best:
  best=err
  record={'trial':trial,'nodes':n,'edges':edges,'reactives':react,'component_conductances':list(np.exp(opt.x[:m])),'reactance_parameters':list(np.exp(opt.x[m:])),'best_max_scaled_error':err,'steps':opt.nfev,'type':'NUMERICAL ONLY; not an exact circuit'}
  Path(f'/mnt/data/smith_revision/q6_gradient_best_{n}.json').write_text(json.dumps(record,indent=2))
  print('BEST',trial,err,'types',kinds,'duration',round(time.monotonic()-start,1),flush=True)
 if trial%30==29:print('TRIALS',trial+1,'elapsed',round(time.monotonic()-start,1),'best',best,flush=True)
 if err<1e-10:break
print('FINAL',best,'trials',trial+1,'elapsed',round(time.monotonic()-start,1))
