#!/usr/bin/env python3
"""Numerical fitting over exact five-node topological orbit representatives.
Author: Komorebi P.
WARNING: A numerical fit NEVER certifies equality or infeasibility.
"""
import numpy as np, json, itertools, time, argparse
from scipy.optimize import least_squares
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--begin',type=int,default=0);p.add_argument('--end',type=int,default=168);p.add_argument('--steps',type=int,default=650);p.add_argument('--seed',type=int,default=170031);a=p.parse_args()
root=Path(__file__).parent
cases=json.loads((root/'q6_5node_canonical_topologies.json').read_text());N=5;edges=list(itertools.combinations(range(N),2));m=len(edges)
S=np.r_[1j*np.geomspace(.002,150,36),np.geomspace(.01,40,12)]
P=np.array([450,1385,2477,2200,1142,335,75.]);D=np.array([150,795,1375,1720,1250,445,25.]);tar=np.polyval(P,S)/np.polyval(D,S);weights=1/(1+abs(tar))
B=np.zeros((m,N-1))
for ei,(i,j) in enumerate(edges):
 if i>0:B[ei,i-1]+=1
 if j>0:B[ei,j-1]-=1
I=np.broadcast_to(np.eye(N-1)[:,:1],(len(S),N-1,1))

def fit(react,seed):
 rng=np.random.default_rng(seed)
 startvec=np.log(rng.lognormal(0,1.35,m+6))
 def eval_(x,jac=False):
  g=np.exp(np.clip(x[:m],-25,25));h=np.exp(np.clip(x[m:],-25,25))
  Y=np.broadcast_to(g,(len(S),m)).astype(complex).copy()
  for v,(kind,ei) in zip(h,react):Y[:,ei]+=v*S if kind=='C' else v/S
  M=np.einsum('ei,fe,ej->fij',B,Y,B,optimize=True)
  try: V=np.linalg.solve(M,I)[:,:,0]
  except np.linalg.LinAlgError:return np.full(2*len(S),1e5) if not jac else np.zeros((2*len(S),m+6))
  E=(V[:,0]-tar)*weights
  if not jac:return np.r_[E.real,E.imag]
  vd=V@B.T
  J=np.c_[-vd**2*g,np.column_stack([-vd[:,ei]**2*v*(S if kind=='C' else 1/S) for v,(kind,ei) in zip(h,react)])]*weights[:,None]
  return np.r_[J.real,J.imag]
 opt=least_squares(lambda x:eval_(x),startvec,jac=lambda x:eval_(x,True),max_nfev=a.steps,ftol=1e-11,gtol=1e-11,xtol=1e-11)
 err=np.max(np.hypot(opt.fun[:len(S)],opt.fun[len(S):]))
 return float(err),list(np.exp(opt.x)),int(opt.nfev)

best=100;results=[];start=time.monotonic()
for idx in range(a.begin,min(a.end,len(cases))):
 rec=cases[idx];react=[('L',j) for j in rec['L_edges']]+[('C',j) for j in rec['C_edges']]
 err,values,steps=fit(react,a.seed+idx*71)
 results.append({'id':idx,'error':err,'conductances':values[:m],'reactance':values[m:],'steps':steps,'reactives':react,'orbit_size':rec['orbit_size']})
 if err<best:
  best=err
  print('BEST',idx,'error',err,'elapsed',round(time.monotonic()-start,1),flush=True)
 if (idx-a.begin)%30==29:
  print('COMPLETED',idx+1,'elapsed',round(time.monotonic()-start,1),'best',best,flush=True)
 if err<1e-10:break
result={'author':'Komorebi P.','status':'numerical topologies, not exact proof', 'labelled_graphs_considered':sum(v['orbit_size'] for v in cases[a.begin:a.end]),'cases':results}
(root/f'q6_canonical_fits_{a.begin}_{a.end}.json').write_text(json.dumps(result,indent=2))
print('FINAL',len(results),'best',best,'elapsed',round(time.monotonic()-start,1),flush=True)
