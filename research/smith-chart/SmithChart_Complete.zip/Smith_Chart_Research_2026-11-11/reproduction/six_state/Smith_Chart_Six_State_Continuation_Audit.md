# Smith chart: six-state continuation audit

**Author:** Komorebi P.  
**Date:** 8 November 2026.  
**Publication:** Unpublished; no GitHub/.io updates.

## Mathematical result status

- **Verified exact algebra:** degree-six polynomial target; exact Sylvester signature (+,−,−,+,+,+,−); necessary 3L+3C allocation for six-reactive realizations; impossibility of four-node, six-reactive ordinary RLC realization; exact target boundary values; derivative and unique positive real-Laplace sensitivity crossover; conditional exposed-resistor bounds.
- **Verified finite enumeration:** five-node 3L+3C reactive-edge placements start at 14,400, reduce to 1,934 surviving the stated graph restrictions, and form 168 symmetry classes. Resistor conductances have not been algebraically solved for these classes. The six-node census is also generated.
- **Previously constructed witness:** an exact six-reactive realization allowing ideal transformers. This is not an ordinary transformer-free RLC solution.
- **Not verified:** a transformer-free six-reactive network for the target, or a certificate that none exists. Numerical searches are not constructive proofs or impossibility proofs. Arbitrary five- or higher-node resistor topologies have not been subjected to complete quantifier elimination.
- **Originality:** the Sylvester sign theorem, network-sensitivity identity and graph-theory tools are classical. No priority claim is made for the resulting instance-specific calculations.

## Executed exact check suites

All six source suites were executed in this build context and finished without exception. Their respective check counts are 65, 40, 63, 37, 11 and 39, totaling **255 assertions**. The assertions audit finite algebraic fixtures, graph counts and numerical regressions, not the missing existential theorem.

## Browser audit

The final self-contained HTML was checked with headless system Chromium at **320, 390, 768 and 1440 px** widths after the last figure regeneration. At every width, all **1,058 MathJax expressions** and **26 embedded Python-generated vector figures** rendered, all **11 semantic tables** were accessible, no page-wide overflow or MathJax/browser errors occurred, and no broken internal anchors were detected. Five source downloads from the new section were decoded and verified byte-for-byte against their local source files.

## Numerical exploratory results

The one-start fit over 168 canonical five-node reactive placements attained best sampled discrepancy approximately **0.00113538**. A separate unrestricted seven-node gradient exploration attained approximately **0.00006007** on its own grid. Neither is a certificate of exact equality. A longer constrained search terminated at the execution limit; no definitive statement is based on it.

## Outstanding deliverable

Resolve the finite semialgebraic conditions for all six-reactive transformer-free topologies, or produce a single exact positive-parameter circuit and verify its rational cofactor identity. The present work provides restrictions and reproducible data, **not** a yes-or-no resolution.
