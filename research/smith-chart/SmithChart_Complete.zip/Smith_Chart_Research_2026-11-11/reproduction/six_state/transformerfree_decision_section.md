## Transformer-free synthesis: a precise decision theorem and a topology obstruction

**Scope and status.** This section strengthens the preceding realization discussion but does not claim that the six-state filtered LC example has a six-reactive-element, transformer-free circuit. It proves a general **finite decision criterion at any prescribed reactive-element count**, derives a strict obstruction to the most direct resistive composition strategy, and identifies the computational obstacle to using the criterion at order six. It is an exact algebraic reduction, not an efficient completed computer-algebra synthesis for every input. Author: Komorebi P.

### Why exact McMillan degree is not always the realizable reactive-element count

The rational degree \(d=\max(\deg P,\deg Q)\) of a reduced impedance \(Z(s)=P(s)/Q(s)\) is a lower bound on the number \(q\) of physical inductors and capacitors in an ordinary transformer-free RLC network. **Equality is not universal.** Classical research on biquadratic minimum functions gives degree-two positive-real functions whose transformer-free realizations require more than two reactive elements. A safe cyclic filter guarantees positive-realness when its reflection output is also real-rational, not a minimum-order circuit. [1–3]

For an example of the relevant boundary geometry, let

\[
Z_*(s)=\frac{s^2+\tfrac12s+\tfrac23}{s^2+\tfrac13s+\tfrac32}.
\]

It is reduced and positive-real. Its poles lie strictly in the open left half-plane and

\[
\Re Z_*(i\omega)=
\frac{(\omega^2-1)^2}{(\tfrac32-\omega^2)^2+\omega^2/9}\ge 0.
\]

It is a *biquadratic minimum function* because the real part vanishes at finite nonzero frequencies. We do not infer an exact minimal count for this specific example from its degree or this boundary calculation alone. The classical results establish the obstruction for the class. Consequently, the unrestricted hypothesis that **every** safe cyclic filter has a transformer-free realization using exactly its rational degree is false: it already includes the identity filter acting on degree-two positive-real impedances.

### Universal finite test for any fixed reactive-element budget

**Theorem (finite transformer-free synthesis decision).** Let \(Z(s)=P(s)/Q(s)\) be a nonzero, finite, real-rational positive-real driving-point impedance with coefficients in the real algebraic numbers, and reduced degree \(d\). Fix an integer \(q\ge d\). There is an explicitly constructible **finite collection of polynomial systems over the real algebraic numbers** such that:

1. At least one system has a real solution if and only if \(Z\) is the driving-point impedance of a finite **transformer-free** network with exactly \(q\) ideal positive inductors and capacitors, together with any finite number of positive resistors and ideal wires.
2. Every solution returns an exact circuit topology and positive element values. If the input data are real algebraic, the values can be selected to be real algebraic.
3. If every system is infeasible, no such \(q\)-reactive-element RLC realization exists. The answer can be decided exactly in principle using quantifier elimination over real closed fields.

By searching \(q=d,d+1,\ldots\), this yields a terminating, in-principle constructive method for the **globally minimum number of reactive elements**, because the Bott–Duffin positive-real synthesis theorem guarantees at least one finite transformer-free RLC realization. This is a decidability and certificate theorem. The amount of computation can be enormous, and it is **not** a practical uniform minimum-order synthesis formula.

**Proof, reduction of resistor-only internal nodes.** Choose the grounded port terminal as node \(0\), the excited port terminal as node \(1\), and let \(B\) contain both terminals and every endpoint of the \(q\) reactive edges. Then

\[
2\le |B|\le 2q+2.\tag{S1}
\]

All remaining nodes touch resistors only. Remove any disconnected components invisible at the port. The nodal conductance matrix of the remaining resistor network is a weighted graph Laplacian. Its Schur complement onto \(B\) is again a symmetric Laplacian with nonpositive off-diagonal entries. Thus elimination of every resistor-only internal node produces **only ordinary nonnegative conductances between pairs of nodes in \(B\)**. It changes no port impedance and does not require a transformer, negative resistance, or additional reactive edge. Multiple resistors between the same two boundary nodes combine into one conductance. Therefore at most

\[
\boxed{\binom{2q+2}{2}}
\tag{S2}
\]

resistor edges suffice in this finite normal form. The bound is for an existence search, not a sharp minimal resistor count.

**Proof, exact algebraic characterization.** Enumerate integers \(m=2,\ldots,2q+2\), the placements of \(q\) labeled reactive edges (inductors or capacitors, including parallel placements) on \(m\) nodes, and allow a nonnegative resistor conductance \(g_{uv}\ge0\) for each node pair. Use positive capacitor values \(c_j>0\) and positive reciprocal inductor values \(h_j=1/\ell_j>0\). For each oriented edge \(e\), let \(b_e\) be its incidence column after grounding node \(0\), and form

\[
Y(s)=\sum_{u<v}g_{uv}b_{uv}b_{uv}^{\mathsf T}
+s\sum_{e\in\mathcal C}c_e b_e b_e^{\mathsf T}
+\frac1s\sum_{e\in\mathcal L}h_e b_e b_e^{\mathsf T}.\tag{S3}
\]

Let \(D(s)=\det Y(s)\) and \(N(s)=\det Y_{\widehat{1}\widehat{1}}(s)\), where the latter removes the row and column of terminal \(1\), and a zero-dimensional determinant is defined as \(1\). The connectedness condition is simply \(D(1)>0\): every present edge has positive admittance at \(s=1\), and Kirchhoff's matrix–tree theorem detects whether the graph is connected to ground. For a connected network, Cramer's rule gives

\[
\boxed{Z_{\rm circuit}(s)=\frac{N(s)}{D(s)}.}\tag{S4}
\]

Equality to the target is equivalent to the vanishing of all coefficients in the polynomial obtained by clearing powers of \(s\) from

\[
\boxed{P(s)D(s)-Q(s)N(s)=0.}\tag{S5}
\]

Because at most \(q\) inductive admittances contribute factors \(1/s\), multiplication by \(s^q\) clears all these denominators. Hence each topology gives finitely many **polynomial equalities and strict or weak polynomial inequalities** in the real element parameters. Quantifier elimination decides whether such a set is nonempty. Positivity and graph connectedness make \(Y\) invertible in \(\Re s>0\), because every active edge admittance has strictly positive real part there. The resulting impedance is positive-real. This proves both necessity and sufficiency.

![Exact resistor-node elimination and its equivalent complete boundary conductances.](figures/21_kron_node_elimination.png)

*Figure 21. A reproducible rational example of Kron reduction, showing that pure resistor-only interior nodes can be eliminated without changing the impedance.*

There are finitely many placements for each \(q\), so the test is finite. A nonempty semialgebraic set defined over real algebraic numbers contains an algebraic point, giving exact algebraic element values. The outer search terminates by the classical transformer-free realization theorem. \(\square\)

**Important qualification.** Ordinary arbitrary real-valued coefficients cannot be treated as exact finite input unless an appropriate coefficient oracle is supplied. The finite algorithm is stated for real algebraic data. For nonrational analytic Schur functions, a finite ideal lumped RLC network generally cannot reproduce the response exactly. The isolated zero-impedance and infinite-impedance limits are handled separately as ideal shorts and opens.

### A sharp no-go for the obvious two-network resistive combiner

The previous exact six-state construction used an ideal three-port passive combiner, with a transformer-based bright mode and resistor-based dark-mode termination. For arbitrary normalized positive input impedances \(a,b\), its driving-point impedance is

\[
\boxed{M(a,b)=\frac{2ab+a+b}{a+b+2}.}\tag{S6}
\]

Suppose a *fixed resistor-only interconnection* were to implement \(M(a,b)\) by placing a **single copy** of a variable two-terminal impedance \(a\) and a single copy of \(b\) in the circuit. Specialize them to ordinary positive resistors. For any passive resistive network carrying a unit input current, Thomson's minimum-dissipation principle gives

\[
\frac{\partial R_{\rm eff}}{\partial a}=I_a^2.\tag{S7}
\]

All resistor voltage drops follow the monotone potential ordering. Choose a threshold between the endpoint potentials of edge \(a\). The directed cut separating those potentials carries total input current exactly one, with nonnegative current along every cut edge, so \(0\le I_a\le1\). Consequently

\[
\boxed{0\le\frac{\partial R_{\rm eff}}{\partial a}\le1.}\tag{S8}
\]

On the other hand,

\[
\frac{\partial M}{\partial a}
=\frac{2(b+1)^2}{(a+b+2)^2},\qquad
\left.\frac{\partial M}{\partial a}\right|_{a=1,b=10}
=\frac{242}{169}>1.\tag{S9}
\]

This contradicts (S8). An equivalent purely finite witness is

\[
M(2,10)-M(1,10)=\frac{121}{91}>1=2-1.\tag{S10}
\]

**Theorem.** No fixed network made solely of positive resistors, ideal wires, and one occurrence of each variable one-port \(a,b\), can reproduce (S6) for **all** positive \(a,b\). This explains why the previous sum-mode ideal transformer cannot simply be replaced by an arbitrary resistor-only mixer that leaves both subcircuits untouched. It does **not** exclude a special transformer-free six-reactive realization of our particular frequency-dependent target, with its energy-storage edges redistributed.

![The Python-generated region where the exact impedance-combination sensitivity exceeds the maximum permitted by any one-copy resistor-only realization.](figures/22_resistive_mixer_obstruction.png)

*Figure 22. The region above the threshold shows a genuine obstruction to a universal resistor-only two-network combiner. It is not a no-go for every possible six-reactive RLC circuit.*

### What the decision theorem says about the outstanding degree-six example

For the previously established filtered LC response,

\[
Z_6(s)=\frac{450s^6+1385s^5+2477s^4+2200s^3+1142s^2+335s+75}
{5(30s^6+159s^5+275s^4+344s^3+250s^2+89s+5)},\tag{S11}
\]

the numerator and denominator are coprime, so **every** transformer-free circuit realizing it requires \(q\ge6\) reactive elements. For the equality case \(q=6\), the theorem reduces the entire search to circuits on at most \(14\) retained nodes, with at most \(\binom{14}{2}=91\) resistor conductances, plus the six positive reactive parameters. Every graph placement has a finite algebraic feasibility test, but the number of placements and quantifier-elimination complexity are formidable.

The earlier transformer-and-resistor three-port construction establishes a passive **six-reactive realization in a broader ideal-network class**. It does not settle whether the semialgebraic transformer-free \(q=6\) family is feasible. A heuristic search of simple five-node topologies made numerical approximations only, with no exact polynomial identity; a low numerical residual cannot establish feasibility, and numerical failure cannot establish impossibility. Therefore the q=6 transformer-free question is **not yet closed for this particular impedance**.

### Independent tests and precise outstanding claims

The companion Python code `smith_transformerfree_decision.py` constructs the grounded nodal cofactors, tests the coefficient identities, validates exact witnesses for 0-, 1-, 2-, and 3-reactive circuits, verifies an explicit resistor-only node elimination, and checks the rational sensitivity contradiction. The executable demonstration does not include a complete implementation of real quantifier elimination, and its successful tests do **not** count as a completed q=6 decision.

**What is settled:** finite semialgebraic reducibility and exact decidability at fixed storage budget (for algebraic input), global termination in principle under the classical RLC existence theorem, and impossibility of the most direct universal transformer-free mixing scaffold. **What remains:** efficiently solve the q=6 semialgebraic case or give a different explicit six-reactive transformer-free circuit, and determine the minimal extra reactive order if q=6 is genuinely impossible. No originality or priority claim is made for the decidability approach without a separate literature review.

**Historical sources (context, not premises of the algebraic proofs).** [1] Timothy H. Hughes, *On the Synthesis of Passive Networks without Transformers* (University of Cambridge, 2014), https://doi.org/10.17863/CAM.12341. [2] T. H. Hughes, *Why RLC Realizations of Certain Impedances Need Many More Energy Storage Elements Than Expected*, *IEEE Transactions on Automatic Control* (2017), https://doi.org/10.1109/TAC.2017.2667585. [3] T. H. Hughes, A. Morelli, and M. C. Smith, *On a Concept of Genericity for RLC Networks*, *Systems & Control Letters* 134 (2020), https://doi.org/10.1016/j.sysconle.2019.104562.
