#!/usr/bin/env python3
"""Refine a prior numerical candidate. NOT exact proof. Author: Komorebi P."""
import numpy as np, json, argparse, time
from scipy.optimize import least_squares
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--n',type=int,default=7);p.add_argument('--steps',type=int,default=4000);a=p.parse_args()
fp=Path(f'/mnt/data/smith_revision/q6_gradient_best_{a.n}.json');record=json.loads(fp.read_text())
edges=record['edges'];react=record['reactives'];m=len(edges);n=a.n
ss=np.r_[1j*np.geomspace(.006,120,34),np.geomspace(.02,30,10)]
P=np.array([450,1385,2477,2200,1142,335,75.]);Q=np.array([150,795,1375,1720,1250,445,25.])
target=np.polyval(P,ss)/np.polyval(Q,ss); weights=1/(1+abs(target))
B=np.zeros((m,n-1));
for ei,(i,j) in enumerate(edges):
 if i>0:B[ei,i-1]+=1
 if j>0:B[ei,j-1]-=1
I=np.broadcast_to(np.eye(n-1)[:,:1],(len(ss),n-1,1))
x0=np.log(np.r_[record['component_conductances'],record['reactance_parameters']])
def calc(x,jac=False):
 g=np.exp(np.clip(x[:m],-35,35));h=np.exp(np.clip(x[m:],-35,35))
 ad=np.broadcast_to(g,(len(ss),m)).astype(complex).copy()
 for hj,(kind,ei) in zip(h,react):ad[:,ei]+=hj*ss if kind=='C' else hj/ss
 mats=np.einsum('ei,fe,ej->fij',B,ad,B,optimize=True)
 v=np.linalg.solve(mats,I)[:,:,0]
 err=(v[:,0]-target)*weights
 if not jac:return np.r_[err.real,err.imag]
 vd=v@B.T
 dr=np.c_[-vd**2*g[None,:],np.column_stack([-vd[:,ei]**2*hj*(ss if kind=='C' else 1/ss) for hj,(kind,ei) in zip(h,react)])]*weights[:,None]
 return np.r_[dr.real,dr.imag]
start=time.monotonic()
opt=least_squares(lambda x:calc(x),x0,jac=lambda x:calc(x,True),max_nfev=a.steps,method='trf',ftol=1e-13,xtol=1e-13,gtol=1e-13)
rr=opt.fun; maxerr=float(np.max(np.hypot(rr[:len(ss)],rr[len(ss):])))
new=dict(record);new['component_conductances']=list(np.exp(opt.x[:m]));new['reactance_parameters']=list(np.exp(opt.x[m:]));new['best_max_scaled_error']=maxerr;new['status']=opt.status;new['steps']=opt.nfev;new['seconds']=time.monotonic()-start;new['type']='NUMERICAL ONLY; not an exact circuit'
print('prior:',record['best_max_scaled_error'],'new',maxerr,'nfev',opt.nfev,'elapsed',new['seconds'])
Path(f'/mnt/data/smith_revision/q6_refined_{n}.json').write_text(json.dumps(new,indent=2))
