## Exact order proliferation under cyclic filtering

The preceding seven-component circuit proves that one particular safe packet filter of a single inductor needs exactly three independent reactive elements. The underlying order growth is more general. Here the relevant complexity is the **reduced rational-map degree** of a driving-point impedance, which supplies a lower bound on the number of independent ideal lumped inductors and capacitors. A degree lower bound does **not** by itself supply a circuit attaining it.

### Rotated-pole theorem: when the upper bound is attained

Let \(F(t)\) be a nonconstant rational Schur function with exactly \(d\) distinct simple finite poles \(p_1,\ldots,p_d\). Suppose the poles do not collide under the used cyclic rotations: all \(p_i/\omega_N^k\), for \(1\le i\le d\) and \(k\in S\), are pairwise distinct. Define

\[
G(t)=\sum_{k\in S}w_kF(\omega_N^kt),\qquad w_k\ne0,\qquad |S|=K.
\tag{O1}
\]

**Exact-order theorem.** The reduced rational degree of \(G\) is exactly \(Kd\). Indeed, \(F(\omega_N^kt)\) has a simple pole at each \(p_i/\omega_N^k\), with nonzero residue. By hypothesis no other summand has a pole there. Thus no pole cancels, so the rational sum has exactly \(Kd\) simple poles. Both the independent-variable map \(t=(s-1)/(s+1)\) and the value map \(G\mapsto (1+G)/(1-G)\) are invertible Möbius transformations and do not change rational-map degree.

If the weights are in addition a real-symmetric probability distribution, \(w_k\ge0\), \(\sum w_k=1\), \(w_k=w_{N-k}\), and \(F\) has real coefficients, then \(G\) is real-rational Schur. Its Cayley impedance is rational positive-real in the right half-plane. Every exact ideal lumped RLC realization consequently requires **at least \(Kd\) independent reactive elements**. This is a lower bound, not a universal minimal-element synthesis algorithm. The pole-disjointness condition is essential: rotational symmetries and repeated pole orbits can reduce the degree.

### Every noncentral inductance in the automorphism family has order three

For \(-1<a<1\), take

\[
F_a(t)=\frac{a+t}{1+at},\qquad
z_a^{\mathrm{input}}(s)=\frac{1+a}{1-a}s.
\tag{O2}
\]

The input is a pure inductor with physical value \(L_a=Z_0\tau(1+a)/(1-a)\). For \(a\ne0\), its reflection function has the simple pole \(t=-1/a\). The order-four Fejér mask from the preceding section uses three rotations, at \(1,i,-i\), with positive weights \(1/2,1/4,1/4\). They yield three different poles and therefore degree exactly three **for every \(a\in(-1,0)\cup(0,1)\)**.

For completeness, put

\[
\begin{aligned}
N_a(s)&=(3a^2+2a+3)s^3+7(1-a^2)s^2+(5a^2-2a+5)s+(1-a^2),\\
D_a(s)&=(1-a^2)s^3+(5a^2+2a+5)s^2+7(1-a^2)s+(3a^2-2a+3).
\end{aligned}
\tag{O3}
\]

Then the entire filtered family has the exact closed form

\[
\boxed{z_a^{\mathrm{Fej}}(s)=\frac{1+a}{1-a}\frac{N_a(s)}{D_a(s)},\qquad
\operatorname{Res}_s(N_a,D_a)=131072a^6.}
\tag{O4}
\]

The nonzero resultant verifies the degree calculation algebraically. At \(a=0\), two common factors \((s+1)^2\) cancel and the impedance reduces to \((3s+1)/(s+3)\), a one-reactive-element resistor–inductor circuit. This is a **singular exact-order transition**. For arbitrarily small nonzero \(a\), degree three remains necessary for exact equality, even though the response approaches the first-order circuit continuously.

The denominator also has a useful universal pole classification. Its discriminant is

\[
\begin{aligned}
\operatorname{Disc}_sD_a
&=-64a^2\bigl(7a^4+44a^3+330a^2+44a+7\bigr),\\
7a^4+44a^3+330a^2+44a+7
&=7\left(a^2+\frac{22}{7}a+1\right)^2+\frac{1728}{7}a^2>0.
\end{aligned}
\tag{O5}
\]

For every \(a\ne0\), the cubic has one real pole and one nonreal conjugate pair. Its coefficients and cubic Routh–Hurwitz determinant are positive:

\[
(5a^2+2a+5)\,7(1-a^2)-(1-a^2)(3a^2-2a+3)
=16(1-a^2)(2a^2+a+2)>0.
\tag{O6}
\]

Thus all poles lie in the left half-plane, while the nonreal pair rules out pure resistor–inductor and pure resistor–capacitor realizations. **Both inductive and capacitive storage are required** for the noncentral family. The existing seven-component realization at \(a=1/3\) attains the three-reactive-element lower bound. Attainment for every parameter is not claimed.

![Python figure comparing exact rational degrees and displaying the nonreal pole trajectories of filtered inductors.](figures/13_order_growth_and_poles.png)

*Figure 13. A safe filter can multiply the exact reactive-order lower bound. As the automorphism parameter \(a\) approaches zero, the conjugate pole pair approaches the canceling double factor at \(s=-1\); the effective approximation order can be smaller than the exact order.*

### Uniform dissipation bound, and a sharp bound in the synthesized case

The filter is not merely contractive. An explicit weighted-variance identity gives a strict boundary margin. For the real automorphism \(F_a\), and any nonnegative rotation weights summing to one, write \(\nu=\sum_k w_k\omega_N^k\). On the unit circle \(|t|=1\), all rotated values of \(F_a\) have unit modulus and hence

\[
\begin{aligned}
1-|G(t)|^2
&=\sum_{k<\ell}w_kw_\ell
\bigl|F_a(\omega_N^kt)-F_a(\omega_N^\ell t)\bigr|^2,\\
&\ge\left(\frac{1-|a|}{1+|a|}\right)^2
\underbrace{\sum_{k<\ell}w_kw_\ell|\omega_N^k-\omega_N^\ell|^2}_{1-|\nu|^2}.
\end{aligned}
\tag{O7}
\]

The inequality uses the exact difference formula

\[
F_a(u)-F_a(v)=\frac{(1-a^2)(u-v)}{(1+au)(1+av)}.
\]

For a probability filter involving two or more distinct rotations, \(|\nu|<1\), giving an explicit positive margin at *every* boundary frequency. For our Fejér filter, \(\nu=1/2\), so

\[
\boxed{1-|G(t)|^2\ge\frac34\left(\frac{1-|a|}{1+|a|}\right)^2 \quad (|t|=1).}
\tag{O8}
\]

The universal bound is conservative. At \(a=1/3\) a stronger **sharp** result follows from elementary polynomial factorization. Put \(x=t+t^{-1}=2\cos\theta\in[-2,2]\) for \(|t|=1\). Then

\[
|G(t)|^2=\frac{27x^3+90x^2+144x+160}{(3x+10)(9x^2+64)},
\tag{O9}
\]

and its difference from \(16/25\), after multiplying by the positive denominator, is

\[
\frac{16}{25}(3x+10)(9x^2+64)-(27x^3+90x^2+144x+160)
=\frac3{25}(2-x)\bigl[(9x+24)^2+464\bigr]\ge0.
\tag{O10}
\]

Equality holds at \(t=1\). The maximum-modulus principle therefore gives the *exact* closed-disk norm

\[
\boxed{\lVert G\rVert_{H^\infty(\mathbb D)}=\frac45.}
\tag{O11}
\]

For the ideal \(50\,\Omega\) one-port, this gives \(|\Gamma(j\omega)|\le4/5\) at every frequency, a worst-case VSWR of at most \(9\) and return loss of at least \(20\log_{10}(5/4)\approx1.94\,\mathrm{dB}\). An independent, sharper **resistance** bound follows from the exact expression (R11): setting \(x=\omega^2\) and \(B(x)=(3-7x)^2+x(7-x)^2\),

\[
\boxed{\Re z_{1/3}^{\mathrm{Fej}}(i\omega)-\frac23
=\frac{x(25x^2+2x+49)}{3B(x)}\ge0.}
\tag{O12}
\]

Equality holds at zero frequency, so the exact minimum of normalized input resistance is \(2/3\), or \(33\frac13\,\Omega\) at \(Z_0=50\,\Omega\). The underlying model remains ideal lumped RLC, without parasitics or material losses beyond its positive resistors.

![Python figure comparing the proved frequency-uniform dissipation margin with an explicitly labeled numerical boundary sweep.](figures/14_uniform_dissipation_margin.png)

*Figure 14. The solid lower envelope is proved for the entire automorphism family. The other curve is a numerical boundary search, shown for context only; the \(a=1/3\) maximum reflection has a separate exact certificate in (O9)–(O11).*

### A two-reactive-element lossless network becomes degree six

Order proliferation is not restricted to first-order loads. Take the product of two disk automorphisms,

\[
F_{\rm LC}(t)=\frac{(2t+1)(3t+1)}{(t+2)(t+3)}.
\tag{O13}
\]

Its normalized frequency-domain impedance is

\[
\boxed{z_{\rm LC}(s)=\frac{6s^2+1}{5s}=\frac65s+\frac1{5s}.}
\tag{O14}
\]

This is an ideal **series inductor and capacitor**, with dimensionless inductance \(6/5\) and capacitance \(5\). At \(Z_0=50\,\Omega\), \(\tau=1\,\mathrm{ns}\), the values are \(L=60\,\mathrm{nH}\), \(C=100\,\mathrm{pF}\). The input has rational degree two and zero resistance on the imaginary-frequency axis at every finite, nonzero frequency.

The two poles of \(F_{\rm LC}\), at \(t=-2,-3\), have disjoint orbits under the rotations \(1,i,-i\). The theorem predicts filtered degree \(2\cdot3=6\), and direct symbolic simplification gives

\[
\boxed{z_{\rm LC}^{\rm Fej}(s)=\frac{P_6(s)}{5D_6(s)},}
\quad\begin{aligned}
P_6(s)&=450s^6+1385s^5+2477s^4+2200s^3+1142s^2+335s+75,\\
D_6(s)&=30s^6+159s^5+275s^4+344s^3+250s^2+89s+5.
\end{aligned}
\tag{O15}
\]

The polynomials are coprime. Thus **any exact ideal lumped RLC realization uses at least six independent reactive elements**. Existence of some passive RLC realization follows from the classical rational positive-real synthesis theorem; a six-reactive-element topology realizing this particular polynomial has **not** been explicitly constructed or verified here.

Its boundary dissipation has an independent algebraic certificate. For \(x=\omega^2\ge0\), let

\[
H(x)=900x^4-323x^3-141x^2+307x+25.
\tag{O16}
\]

Then

\[
\boxed{\Re z_{\rm LC}^{\rm Fej}(i\omega)
=\frac{3(1+\omega^2)^2H(\omega^2)}{|D_6(i\omega)|^2}.}
\tag{O17}
\]

Although \(H\) contains negative coefficients, it is strictly positive for all \(x\ge0\). On \([0,1]\), its *degree-four Bernstein coefficients* are
\(25,407/4,155,104,768\), all positive. On \([1,\infty)\), write \(x=1+y\), \(y\ge0\), to obtain

\[
H(1+y)=900y^4+3277y^3+4290y^2+2656y+768>0.
\tag{O18}
\]

These two certificates establish strict positive-real boundary resistance and rule out any imaginary-axis zero of \(D_6\). They independently corroborate the Schur convexity proof, not a physical fabrication test.

![Python figure of the original lossless series LC reflection locus and its degree-six passive filtered counterpart, including the exact positive-real response.](figures/15_filtered_series_lc.png)

*Figure 15. A two-state lossless series LC network becomes a strictly dissipative sixth-degree positive-real impedance after the same Fejér packet filter. Six reactive elements are necessary for an exact circuit, but a circuit meeting that bound remains to be synthesized.*

### Interpretation and exact-versus-approximate complexity

| Input and mask | Exact input degree | Exact filtered degree | What is proved about a circuit |
|---|---:|---:|---|
| \(F_0(t)=t\), three-rotation Fejér | 1 | 1 | Explicit one-reactive RL realization |
| \(F_{1/3}(t)\), three-rotation Fejér | 1 | 3 | Explicit seven-component RLC with exactly 3 reactive elements, meeting the lower bound |
| \(F_a(t)\), \(0<|a|<1\), same Fejér | 1 | 3 | At least 3 reactive elements; explicit minimum-state topology not shown for every \(a\) |
| \(F_{\rm LC}(t)\), same Fejér | 2 | 6 | At least 6 reactive elements; explicit minimum-state topology remains open |

A safe filter is therefore **not complexity-neutral**. It can turn a lossless response into a strictly dissipative one while increasing exact reactive order by a factor equal to the number of independently rotated pole families. Nevertheless, exact order is sensitive to pole coincidences and may be much larger than the order needed for a finite-error approximation. In particular, \(F_a\to t\) uniformly on the unit disk as \(a\to0\), because

\[
\lvert F_a(t)-t\rvert=\left\lvert\frac{a(1-t^2)}{1+at}\right\rvert
\le\frac{2|a|}{1-|a|},\qquad |t|\le1.
\tag{O19}
\]

The same bound holds after a probability-weighted rotation average. Hence the new modes disappear continuously in amplitude as \(a\to0\) even though the exact reduced degree jumps at \(a=0\). An error-tolerant circuit synthesis question must therefore specify a frequency band, reflection or impedance error norm, and component constraints before claiming a practical minimum state count.

### A universal one-inductor approximation with an exact reflection-error certificate

The singular degree transition at \(a=0\) has a constructive resolution when an approximation is acceptable. Keep the constant and first Taylor coefficients of the filtered reflection, set \(b_a=(1-a^2)/2\), and define

\[
\boxed{H_a(t)=a+b_at.}
\tag{O20}
\]

Since \(|a|+b_a=1-\frac12(1-|a|)^2<1\), this is a real-rational **strictly Schur** function for every such parameter. Its Cayley impedance is positive-real, with reduced rational degree one. In fact, it has an explicit passive series-resistor and parallel resistor–inductor realization:

\[
\begin{aligned}
z_{H_a}(s)
&=\frac{(1+a+b_a)s+(1+a-b_a)}{(1-a-b_a)s+(1-a+b_a)}\\
&=r_s+\frac{r_p\ell s}{r_p+\ell s},
\end{aligned}
\tag{O21}
\]

where

\[
\boxed{
 r_s=\frac{(1+a)^2}{(1-a)(a+3)},\qquad
 r_p=\frac{8(1+a)}{(1-a)^2(a+3)},\qquad
 \ell=\frac{8(1+a)}{(1-a)(a+3)^2}.}
\tag{O22}
\]

All three values are strictly positive for \(-1<a<1\). As before, \(R=Z_0r\) and \(L=Z_0\tau\ell\). This is a physical one-reactive approximation to the filtered response, not a truncated Taylor polynomial interpreted as a standalone load.

The error is analytically controlled over the **entire unit disk**. The Fejér mask has monomial multipliers

\[
 m_n=\frac12+\frac12\cos\left(\frac{\pi n}{2}\right),
 \qquad(m_1,m_2,m_3,m_4)=(1/2,0,1/2,1).
\tag{O23}
\]

Using the Taylor expansion \(F_a(t)=a+(1-a^2)\sum_{n\ge1}(-a)^{n-1}t^n\), the retained terms are precisely \(H_a(t)\). The omitted terms start at degree three. Since all \(m_n\ge0\), their absolute coefficient sum gives a global bound, and the coefficients align at \(t=-1\) for \(a>0\) and at \(t=1\) for \(a<0\). Hence the bound is **attained**:

\[
\boxed{\|G_a-H_a\|_{H^\infty(\mathbb D)}
=(1-a^2)\frac{\frac12|a|^2+|a|^3+\frac12|a|^4}{1-|a|^4}
=\frac{a^2(1+|a|)^2}{2(1+a^2)}.}
\tag{O24}
\]

This is a sharp **all-frequency absolute reflection-error certificate**, not an assertion that \(H_a\) is the best possible degree-one approximant. In particular, the error is of order \(a^2\), improving the preceding first-order continuity bound. At \(a=1/10\) it is \(121/20200\approx0.0059901\), despite exact filtered degree three.

At \(a=1/3\), where the full three-state circuit is already known, the simpler circuit is

\[
\boxed{z_H(s)=\frac{8s+4}{s+5}
=\frac45+\frac{\frac{36}{5}\cdot\frac{36}{25}s}{\frac{36}{5}+\frac{36}{25}s},
\qquad\|G_{1/3}-H_{1/3}\|_\infty=\frac4{45}.}
\tag{O25}
\]

At \(Z_0=50\,\Omega\) and \(\tau=1\,\mathrm{ns}\), this uses a \(40\,\Omega\) series resistor and a parallel \(360\,\Omega\) resistor–\(72\,\mathrm{nH}\) inductor branch. It replaces the previous seven-component exact circuit with **three positive components** at a controlled approximation error.

An important Smith-chart qualification is that absolute reflection and absolute impedance errors are different metrics. For the same example,

\[
 z_{\rm Fej}(s)-z_H(s)=
 \frac{(s-1)^3(s+2)}{(s+5)(s^3+7s^2+7s+3)}.
\tag{O26}
\]

Writing \(x=\omega^2\ge0\), the difference between squared denominator and numerator magnitudes on the imaginary-frequency axis is exactly

\[
53x^3+867x^2+171x+221>0.
\tag{O27}
\]

The normalized impedance error is strictly smaller than one at every finite boundary frequency and tends to one as \(\omega\to\infty\). By the maximum-modulus principle for the stable bounded rational difference,

\[
\boxed{\|z_{\rm Fej}-z_H\|_{H^\infty(\Re s>0)}=1.}
\tag{O28}
\]

Thus the same passive approximation has **sharp reflection error \(4/45\)** and **sharp normalized impedance error \(1\)**, corresponding to \(50\,\Omega\) in the stated example. Both are correct: a small difference on the reflection disk need not be small in ohms near the Cayley map's high-impedance region. Practical specifications should state which metric matters.

![Python-generated schematic of the simple one-inductor approximant and its sharp reflection and impedance error curves.](figures/16_passive_one_state_approximation.png)

*Figure 16. The first-order passive RL replacement meets a global, sharp reflection-error guarantee while its normalized impedance error has a different sharp maximum. All plotted curves are generated from exact rational formulas, not measured RF data.*

The results in this section are proved by the displayed algebra, pole isolation, standard positive-real and degree principles, and the supplemental Python checker. No priority claim or blanket minimal-circuit theorem is made.
