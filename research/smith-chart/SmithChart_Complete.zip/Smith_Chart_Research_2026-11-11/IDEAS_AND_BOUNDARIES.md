# Smith chart: ideas, theorems, and boundaries

Author: Komorebi P.  
11 November 2026 · Unpublished research status ledger

The categories here distinguish mathematics proved in the accompanying text, finite empirical checks, and genuinely open research questions. They do not constitute a novelty certificate.

## A. Established constructions or mathematical results in this collection

### A1. Exact reflection and cyclic packet reconstruction

Start with normalized impedance \(z=Z/Z_0\) and reflection \(\Gamma=(z-1)/(z+1)\). Roots-of-unity projectors isolate the exponent classes of analytic functions and reconstruct the original response when every packet is included. Dropping packets can break the Schur bound \(|\Gamma|\le1\), so packet truncation and physical passivity are not interchangeable.

**Research boundary:** coordinatewise passivity or pointwise disk geometry does not alone establish causal frequency-dependent, reciprocal, or prescribed-topology network synthesis.

### A2. Convex cyclic masks and exact order growth

Positive normalized cyclic weights preserve Schur contractivity. When a proper rational response has distinct simple poles with disjoint rotated orbits, a noncancelling sum of \(K\) rotations of a degree-\(d\) function has reduced rational degree \(Kd\). The **properness hypothesis** is necessary; the source gives a counterexample with a pole at infinity.

### A3. Minimal three-reactive-element example

The recorded fourth-order Fejér filtering of a single inductor produces a degree-three positive-real driving point impedance. The reading supplies a physical positive component RLC construction with two inductors, one capacitor, and four resistors. The degree-three lower bound proves minimality of its **reactive count** for this specific target, not minimal resistor or total-element count.

### A4. Filtered series LC and its six-state alternatives

A two-reactive-element series LC input produces a degree-six positive-real impedance after a three-rotation Fejér mask. The reading gives a six-reactive exact realization in a broader class using an ideal static reciprocal transformer/combiner. The use of that device does **not** settle the transformer-free, resistor-inductor-capacitor-only problem.

### A5. Exact seven-reactive transformer-free circuit

For the explicitly stated rational target \(Z_6(s)\), a certified passive series split \(Z_6=Z_A+Z_B\) is realized by two positive RLC sections:

- \(Z_A\): 2 inductors + 1 capacitor + 4 resistors, reduced degree three.
- \(Z_B\): 2 inductors + 2 capacitors + 10 resistors, reduced degree three after one exact port-dark cancellation.

Together: **4 inductors, 3 capacitors, 14 resistors**, input degree six, giving the certified interval

\[
6\le q_{\min}\le7.
\]

The exact circuit is defined by polynomial systems and certified rational boxes, not by rounding the displayed component values. The independent nodal sweep is supporting evidence rather than the exact existence certificate.

### A6. Port-dark desingularization of the coefficient system

For the certified complementary four-reactive section, the grounded nodal matrix \(Y(s)\) has a vector \(w=(0,v)\) at a nonzero frequency \(s_0\) with \(Y(s_0)w=0\). The port sees a common factor in numerator and denominator. This makes direct coefficient matching singular: at the exact solution the coefficient Jacobian \(J_F\) has a nonzero left annihilator

\[
(1,s_0,s_0^2,\ldots,s_0^7)J_F=0.
\]

Adding nodal dark-mode equations removes the degeneracy from the particular certificate system and yields the exact root. **Generalizing this method** to a systematic synthesis theorem for hidden modes is a proposed next step, not already proved for all graphs.

### A7. Arbitrarily large exact degree with exponentially accurate one-state approximation

For \(N\ge4\), \(a=1/3\), \(\rho=1/4\), and positive mask

\[
w_k=\frac{1+\frac12\cos(2\pi k/N)}{N},\quad
G_N(t)=\sum_{k=0}^{N-1}w_k\frac{1/3+\omega^kt}{1+\omega^kt/3},\quad\omega=e^{2\pi i/N},
\]

the exact reduced degree is \(N\) while the fixed one-reactive RL impedance

\[
z_*(s)=\frac{7s+5}{2s+4}
\]

has reflection difference with **sharp** \(H^\infty\) norm

\[
E_N=\frac{44}{81}\frac{3^{-(N-2)}}{1-3^{-N}}.
\]

Uniform bounds additionally imply \(\Re z_N(s)\ge23/97\) throughout the open right half-plane and \(\Re p\le-1/5\) for all finite impedance poles \(p\) (normalized units). Thus exact physical reactive-order lower bounds grow with \(N\), whereas a fixed single-reactive *approximation* becomes exponentially accurate. Full proof and finite checks are separate in the package.

**Boundary:** this explicit example does not establish historical novelty, and it does not determine whether the degree-six target admits a transformer-free six-reactive circuit.

## B. Verified necessary conditions / finite enumerations, not a global solution

For the **particular degree-six target**, a six-reactive transformer-free realization would require a 3L+3C allocation and at least five nodes. Earlier restricted graph enumeration has 168 symmetry classes among five-node reactive placements after its specified pruning. No exact positive-resistor feasibility or exhaustive nonexistence certificate is provided for all remaining classes, and larger-node networks have not been excluded. See reproduction/six_state/README_Six_State_Unpublished.md and its audit.

Finite Pick-matrix feasibility, cross-frequency compatibility, and the joint load/frequency discussion in the reading produce additional explicit obstructions for their stated data and response classes. They are not a universal prescribed-topology synthesis theorem.

## C. Highest-value open questions

1. **Close 6 versus 7:** exhibit a positive transformer-free 3L+3C circuit with exact rational target or rigorously rule out every such topology, including unrestricted node counts.
2. **Generalize dark-mode lifting:** identify graph-theoretic and algebraic hypotheses under which introducing explicit hidden eigenvectors restores regularity of a singular coefficient system. Prove a bound on the number of additional variables/equations needed.
3. **Quantify exact versus practical complexity:** for prescribed \(\epsilon\), passive approximation, frequency band, pole gap, resistor range, and allowed topology, determine minimum reactive count. The arbitrary-order family gives a sharp test case and a warning that exact rational degree can be misleading.
4. **Prove or refute minimum total and resistor counts** for specific realized impedances. Reactive count alone does not settle hardware complexity.
5. **Multiport / matrix extensions:** carry scalar cyclic completion and realizability analysis into reciprocal and nonreciprocal multivariable matrix settings without assuming scalar formulas commute.
6. **Independent novelty audit:** compare the explicit constructions and claimed special-case theorems with classical network synthesis, positive-real realization, McMillan-degree discontinuities, and passive model reduction before external priority claims.
7. **Physical sensitivity and robustness:** bound component perturbations, detect hidden-mode splitting, and evaluate behavior with losses and parasitics. The exact cancellation certificate is not a manufacturing tolerance guarantee.

## D. Reproducibility and publishing boundaries

- Current exact circuit replay and rational bounds were recorded on 11 November 2026; the new arbitrary-order checker was rerun for this consolidation.
- The full reading includes older experiments with different statuses. Read their local audit files before interpreting them as proved global results.
- No new Lean proof, hardware/actual SPICE run, public publication, or claim of historical novelty is made here.
- The local browser preview was blocked by the runtime environment; syntax, assets and static structure have been inspected previously, but a fresh full visual/browser audit is pending.
