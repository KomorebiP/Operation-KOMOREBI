# Smith chart extended reading

Author: Komorebi P.  
Revised 11 November 2026. Unpublished draft.

Open `Smith_Chart_Extended_Seven_Reactive_Exact.html` in a browser. The reading embeds its mathematical figures, math renderer, styles, manuscript download, and current certificate archive. Public reference links require an internet connection, but the reading's assets are contained in the file.

## Current result

The displayed degree-six impedance has an exact passive RLC realization without transformers using four inductors, three capacitors, and fourteen positive resistors. Its minimum reactive element count satisfies **6 ≤ q_min ≤ 7**. The six-element question remains open.

The two section-local circuits are connected in series by identifying node 0_A with node 1_B. The combined input is between 1_A and 0_B.

## This revision

- Reconciles the current exact theorem with the earlier numerical stage.
- Corrects the rotated-pole theorem by requiring no pole at infinity, and supplies a counterexample explaining the hypothesis.
- Proves that the complementary circuit has exactly one canceled factor and derives the coefficient Jacobian's nonzero left-null row.
- Adds exact rational margins for the reduced target at the canceled pole.
- Distinguishes physical components, independent dynamic variables, and observable rational degree.
- Reorganizes the reading into one hierarchy with six navigation groups.
- Preserves the earlier forty mathematical figures and adds a Python construction map.
- Embeds the current proof sources and manuscript download in the HTML.

## Reproduce the current certificate

Go to `reproduction/exact_seven` and follow its README. The graph systems are regenerated before the rational acceptance tests. Use ordinary Python with assertions enabled. The numerical nodal check is separate from the existence proof.

`SOURCE_INDEX.md` identifies the current certificate and the recovered historical source groups. Historical programs and records retain their original scope. This revision does not claim to have replayed every earlier checker, and the unrecovered historical 171-check suite is not supplied.

## Rebuild the reading

With Pandoc, Python, lxml, and Pillow installed:

```text
python build_reading.py
```

With Matplotlib installed, the new construction map can be regenerated using:

```text
python reproduction/make_reading_map.py
```

The mathematical narrative and proofs are in the Markdown source. The HTML build checks internal links, heading identity, table structure, figure availability, and embedded resources.

## Validation and limits

The exact circuit certificate, internal rank test, new interval margins, and independent 165-point nodal diagnostic passed replay. The revised proof sections received a focused mathematical audit and proofreading. See `audit/` for the scope and records.

The local Chromium runner failed because the environment denied a browser socket. The available browser interface also refused local-file preview under its URL policy. Consequently, this revision has **not** completed a fresh browser layout or interaction test. Static structure and script syntax were checked, and the new Python figure was visually inspected. Do not read the earlier editions' browser records as validation of this revised layout.

No changes were made to the public GitHub or reading site. No hardware validation, resistor-count minimality, six-element impossibility, or historical novelty claim is made.

## New continuation: 11 November 2026 (unpublished)

The extended reading now includes the original general theorem "A new exact-versus-approximate boundary for passive cyclic synthesis". It proves a family of strictly passive one-ports whose exact McMillan degrees are N for every N >= 4, yet whose H-infinity reflection distance to one fixed passive RL circuit is an explicitly sharp O(3^{-N}) value. The family also has independent-of-N passivity and pole-gap bounds. This does not change the open six-versus-seven reactive-element synthesis interval for the earlier degree-six target.

Read `Smith_Order_Separation_Theorem_Unpublished.md` for a standalone proof. Reproduce the finite diagnostic checks with `python reproduction/new_order_separation/check_order_gap.py`. Regenerate Figure 42 with `python reproduction/new_order_separation/plot_order_gap.py`. Figure 42 and all other figures are Python-generated. The HTML is a self-contained reading edition but fresh browser rendering has not been checked in this continuation.

The historical novelty of the new theorem is unverified. The public GitHub/.io site was not modified.
