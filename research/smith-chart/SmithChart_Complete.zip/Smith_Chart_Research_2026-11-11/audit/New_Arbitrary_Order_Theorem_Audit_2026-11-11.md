# New theorem audit | Smith chart order separation

**Author:** Komorebi P.  
**Date:** 2026-11-11  
**Status:** Unpublished. Not a publication-priority claim.

## New result

For every N >= 4, cyclic masks w_k = (1 + (1/2) cos(2 pi k/N))/N applied to F(t)=(1/3+t)/(1+t/3) produce a strictly passive real-rational impedance of degree N. Thus its exact reactive-state lower bound is N. A fixed one-inductor RL impedance z_*(s)=(7s+5)/(2s+4) approximates the entire family with exact reflection H-infinity error E_N = (44/81) 3^{-(N-2)}/(1-3^{-N}).

The proved uniform bounds are Re z_N(s) >= 23/97 for Re s > 0, and Re(p) <= -1/5 for every finite impedance pole p, in normalized Laplace units. The normalized impedance H-infinity error is <= (270/23) E_N.

## Proof mechanics

1. The mask weights are strictly positive, sum to one, and are invariant under conjugation.
2. Their Fourier moments are 1 on multiples of N, rho on residues +-1, and 0 otherwise.
3. Summing the three geometric series produces the closed rational form in the reading.
4. Distinct non-canceling simple poles give exact degree N for all N >= 4.
5. A boundary point t = -1 attains the full-disk error upper bound, hence sharpness.
6. On |t| <= 3/2, |G_N| <= 43/45; the Cayley relation implies the common pole gap.
7. Standard positive-real and rational-degree principles give the physical consequences.

## Reproduction performed in this revision

`python reproduction/new_order_separation/check_order_gap.py` passed. The check includes exact Fraction values E_4, E_5, E_6, E_10, E_20; strict rational passivity and stability margins; pointwise comparisons of the independent cyclic sums with the closed form for N=4..30; and sharp boundary diagnostics. The figure source `plot_order_gap.py` was run and the PNG output inspected. The finite checks are not the mathematical proof for all N.

The full extended HTML was regenerated from the updated Markdown with embedded vector figure and an integrity check for unique IDs, internal links, all 42 illustrations, and absence of external script/style URLs. Visual browser layout testing has not been repeated for this revision.

## Boundary and novelty

This result does not imply that the original degree-six Z_6 has a six-reactive transformer-free realization; its minimum remains between six and seven. Rational approximation, McMillan degree, positive-real synthesis, and loss of observable order have classical precedents. The exact special cyclic family, sharp bound, and joint stability/passivity properties have not been checked exhaustively against the literature. No novelty, world-first, Lean proof, SPICE test, or hardware claim is made.
