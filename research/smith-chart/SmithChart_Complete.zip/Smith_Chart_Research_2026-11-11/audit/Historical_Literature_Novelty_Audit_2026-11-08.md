# Smith chart research: literature-based novelty audit

**Author of project under review:** Komorebi P.  
**Audit date:** 8 November 2026  
**Scope:** unpublished `Smith_Chart_Extended_Six_State_Invariants.md` and its earlier research sections, checked against public sources available through web search.  
**Publication status:** research assessment only; does not modify the public GitHub or website.

## Executive finding

The mathematical work contains reproducible calculations, particular circuit constructions and a coherent research workflow. **The literature check does not support describing the general cyclic-passivity, matrix-interpolation, reactive-minimality, or decision-procedure ideas as novel theorems.** Key components are direct applications of classical mathematics or published results in circuit synthesis. Certain exact instances—the particular filtered inductor/LC rational functions, the fully specified circuit for one parameter, the specific exact approximation bound and the 168-topology count for the degree-six target—may be independently derived and perhaps not previously published in this exact form. This is *not* evidence of priority, mathematical depth beyond the examples, engineering utility, or publication readiness.

## Claim-by-claim comparison

| Claim in draft | Closest verified literature | Assessment |
|---|---|---|
| Roots-of-unity packet projections preserve sup-norm contractivity in allowed coset cases | Brevig–Ortega-Cerdà–Seip (2021), *Idempotent Fourier multipliers acting contractively on H^p spaces*; classical multirate/polyphase theory | Existing underlying theory; specialization to Smith disk not new by itself |
| Universal norm of finite rotation averaging and constant-preserving nonnegative-weight criterion | Standard total-variation norm of finite discrete measures / convexity; related Fourier multiplier theory above | Elementary specialized criterion, not established as a new theorem |
| Sharp safe-mask repair amount `sum |w_k| − 1` for real weights summing to 1 | Distance in ℓ¹ from a signed unit-mass vector to the probability simplex; convolution-operator norm interpretation | Standard convex optimization with a useful tailored engineering interpretation |
| Matrix-valued finite passive completion via positive Pick matrix | Delsarte–Genin–Kamp (1979) and Chen–Koç (1994) | Classical matrix Nevanlinna–Pick interpolation; example computations may be original |
| Joint bidisk frequency/load interpolation criteria | Agler–McCarthy (1999), multivariable Schur–Agler interpolation | Established theorem family; translating to this network setting may be expository or a new application only |
| `d → Kd` rational degree under noncolliding pole rotations | Elementary rational pole counting plus Möbius invariance; system-theoretic McMillan-degree standard | Valid under hypotheses, but originality of theorem unsupported |
| Exact three-reactive-element RLC for one filtered inductor, exact four-reactive branch, ideal six-reactive combiner | Brune (1931), Bott–Duffin (1949), Hughes–Smith (2014), Zhang et al. (2017), RF power-combiner theory | Particular component values/circuit identity may be original instances; construction *principles* established; ideal-transformer construction is not transformer-free |
| Three-inductor/three-capacitor necessary signature, four-node obstruction, 168 five-node surviving symmetry classes | Hughes (2014 thesis), extended Cauchy index/Sylvester bounds; SIAM monograph (2018) classification/enumerative approach; elementary graph theory | Instance-specific derivation and enumeration; cannot claim new general count theorem or exact q=6 resolution |
| Decidable fixed-q transformer-free RLC synthesis for algebraic input via topology enumeration, Kron reduction and real QE | Real-algebraic quantifier elimination, circuit enumeration, Bott–Duffin existence theorem; SIAM monograph (2018) | Routine decidability consequence of known methods, not demonstrably a newly discovered general algorithm; practical complexity high |
| Exact passive order-one approximation to degree-three target with stated error | Classical rational positive-real approximation and passivity-constrained model reduction (Gustavsen, 2005–2026) | Exact error formula and component values are project-specific; no blanket novelty claim |

## Primary comparisons (with public links)

1. O. F. Brevig, J. Ortega-Cerdà, and K. Seip, *Idempotent Fourier multipliers acting contractively on H^p spaces*, **Geometric and Functional Analysis** 31 (2021), 1377–1413. Published 27 December 2021. https://link.springer.com/article/10.1007/s00039-021-00586-0 . Their Theorem 1.1 characterizes contractive idempotent multipliers onto cosets for Lp, including p=∞; their discussion includes Hardy spaces.
2. Ph. Delsarte, Y. Genin, and Y. Kamp, *The Nevanlinna–Pick Problem for Matrix-Valued Functions*, **SIAM Journal on Applied Mathematics** 36(1) (1979), 47–61. https://doi.org/10.1137/0136005 . Matrix Pick feasibility and interpolation.
3. G. Chen and Ç. K. Koç, *Computing matrix-valued Nevanlinna–Pick interpolation*, **Linear Algebra and its Applications** 203–204 (1994), 253–263. https://www.sciencedirect.com/science/article/pii/0024379594902054 . Computational implementation of matrix Pick interpolation.
4. J. Agler and J. E. McCarthy, *Nevanlinna–Pick interpolation on the bidisk*, **Journal für die reine und angewandte Mathematik** 506 (1999), 191–204. https://doi.org/10.1515/crll.1999.506.191 . Matrix-valued bidisk interpolation.
5. T. H. Hughes and M. C. Smith, *On the Minimality and Uniqueness of the Bott–Duffin Realization Procedure*, **IEEE Transactions on Automatic Control** 59(7) (2014), 1858–1873. https://ieeexplore.ieee.org/document/6775281/ . Particular passive impedances need unexpectedly many reactive elements; classification/minimality results.
6. T. H. Hughes, *On the Synthesis of Passive Networks without Transformers* (2014 thesis), University of Cambridge. https://www.repository.cam.ac.uk/items/0db868a3-5c51-4e0f-98ac-ae821db31fdc . Extended Cauchy-index and Sylvester/Bézoutian reactive bounds; synthesis of transformer-free networks.
7. T. H. Hughes, A. Morelli, and M. C. Smith, *Electrical Network Synthesis: A Survey of Recent Work*. https://api.repository.cam.ac.uk/server/api/core/bitstreams/4a496c9a-9083-419e-8c0a-94cebf184864/content . Explicitly records the general minimum reactive-element synthesis problem and existing enumerative methods.
8. *Passive Network Synthesis: An Approach to Classification*, SIAM, 2018. https://epubs.siam.org/doi/book/10.1137/1.9781611975826 . Focus on exact RLC topology enumeration and equivalences, including classical Ladenheim catalogue.
9. S. Y. Zhang et al., *Synthesis of essential-regular bicubic impedances*, **International Journal of Circuit Theory and Applications** 45(11) (2017), 1482–1496. https://doi.org/10.1002/cta.2342 . Exact minimal-reactive realizations in a specialized rational class.
10. B. Gustavsen and A. Semlyen, *Rational approximation of frequency domain responses by vector fitting*, **IEEE Transactions on Power Delivery** 14(3) (1999). Source/software overview: https://www.sintef.no/en/software/vector-fitting/ . Related passivity enforcement and model reduction already established.
11. B. Gustavsen, *Computer code for passivity enforcement of rational macromodels by residue perturbation*, **IEEE Transactions on Advanced Packaging** 30(2) (2007), 209–215. https://www.sintef.no/en/publications/publication/1274134/ .
12. S. Basu, *Synthesis of passive multidimensional scattering matrices: a survey* (June 2026). https://arxiv.org/abs/2607.02557 . Multivariable passive realization challenges and classical machinery.

## What no exact match was identified for in this targeted search

- The exact filtered rational function `Z(s) = (9s^3+14s^2+11s+2)/(s^3+7s^2+7s+3)` with its particular RLC realization.
- The filtered degree-six LC polynomial in this manuscript and the explicitly constructed two-/four-state ideal-combiner decomposition.
- The specific count 168 of symmetry classes after the manuscript's stated five-node restrictions.
- The exact order-one passive approximation with reflection-error `4/45` for the selected parameter.

These negative search findings are **not** proof of novelty. Numerous papers are paywalled, mathematical identities may be indexed under different notation, and authors may have established more general results covering these instances.

## Substantive unclosed problem

The draft has not proved or ruled out transformer-free realization of its degree-six impedance with exactly six reactive elements. This is the most concrete open result in the present program. A completed topology-specific semialgebraic certificate or a verified positive-parameter witness would materially strengthen the paper. Even then, novelty would require a targeted comparison with contemporary higher-order network synthesis results.

## Recommended research framing

Present the work as a **constructive computational study of cyclic Schur-function filtering and passive RLC realization**, with exact examples and rigorous limits on their scope. Cite the classical tools beside the first appearance of each theorem. Place possible contributions in three categories: (i) distinctive modeling pipeline; (ii) certified new **examples**, pending external priority check; (iii) open transformer-free synthesis and possible computational value, with no claim of verified advancement yet. Avoid stating that passivity preservation, Pick interpolation, rational degree counting, or general RLC existence have been discovered here.

## Review limitations

This was a targeted literature comparison, not a systematic novelty search across all patents, dissertations, engineering proceedings and database-indexed full texts. This audit did not rerun all mathematical checkers or physically validate circuitry; mathematical validity and novelty are separate questions. The user should not infer that the absence of an exact formula in web search establishes publication priority. No institutional peer review or professional patent novelty assessment was performed.
