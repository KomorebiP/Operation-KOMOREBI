"""Build the self-contained Smith chart reading from its Markdown source.
Author: Komorebi P.
Requires pandoc, lxml, and Pillow. No network access is used.
"""
from pathlib import Path
from lxml import html, etree
from html import escape
from PIL import Image
import base64, copy, json, re, subprocess, zipfile

ROOT=Path(__file__).resolve().parent
NAME='Smith_Chart_Extended_Seven_Reactive_Exact'
SOURCE=ROOT/(NAME+'.md')

def data_url(path, mime=None):
    if mime is None:
        mime={'.png':'image/png','.svg':'image/svg+xml','.jpg':'image/jpeg','.md':'text/markdown','.zip':'application/zip'}[path.suffix]
    return 'data:'+mime+';base64,'+base64.b64encode(path.read_bytes()).decode()

def serialize(element):
    return html.tostring(element,encoding='unicode',method='html')

raw=subprocess.run(['pandoc',str(SOURCE),'-f','markdown+tex_math_single_backslash+pipe_tables+header_attributes','-t','html5','--mathjax','--wrap=none','--no-highlight'],check=True,capture_output=True,text=True).stdout
article=html.fragment_fromstring(raw,create_parent='article')
article.set('class','manuscript');article.set('id','manuscript')
title=article.find('h1');assert title is not None
title_id=title.get('id');title_text=title.text_content()
article.remove(title)
metadata=article.find('p');article.remove(metadata)
intro=article.find('p');article.remove(intro)
intro.set('class','dek')

# Every figure remains embedded and gets a native full-size viewing control.
image_count=0
for img in list(article.xpath('.//img')):
    path=ROOT/img.get('src')
    assert path.is_file(),path
    image_count+=1
    img.set('src',data_url(path))
    if path.suffix=='.png':
        with Image.open(path) as im:width,height=im.size
        img.set('width',str(width));img.set('height',str(height))
    img.set('decoding','async')
    parent=img.getparent()
    if parent.tag=='figure':
        figure=parent
    elif parent.tag=='p' and len(parent)==1:
        figure=html.Element('figure');parent.addprevious(figure);parent.remove(img);figure.append(img)
        parent.getparent().remove(parent)
    else:
        figure=html.Element('figure');parent.replace(img,figure);figure.append(img)
    figure.set('class','research-figure');figure.set('id',f'figure-{image_count}')
    caption=figure.find('figcaption')
    next_el=figure.getnext()
    if next_el is not None and next_el.tag=='p' and (next_el.text_content().startswith('Figure ') or next_el.text_content().startswith('Construction map.')):
        if caption is None:caption=etree.SubElement(figure,'figcaption')
        caption.clear();caption.text=next_el.text
        for child in list(next_el):caption.append(child)
        next_el.getparent().remove(next_el)
    if caption is None:
        caption=etree.SubElement(figure,'figcaption');caption.text=img.get('alt','Mathematical figure')
    actions=etree.SubElement(figure,'div',{'class':'figure-actions'})
    b=etree.SubElement(actions,'button',{'type':'button','class':'figure-open','aria-label':f'Open figure {image_count} at full size'})
    b.text='Open figure at full size'

# Keep real tables. Mobile labels contain the same markup as their headers.
table_count=0
for table in list(article.xpath('.//table')):
    table_count+=1
    table.set('aria-label',f'Reference table {table_count}')
    heads=table.xpath('./thead/tr/th')
    for head in heads:head.set('scope','col')
    wrapper=html.Element('div',{'class':'table-wrap stack-table'})
    words=' '.join(h.text_content() for h in heads)
    if len(heads)>=5 and any(x in words for x in ['Constant','Quadratic','Cubic']):
        wrapper.set('class','table-wrap numeric-table')
        wrapper.set('tabindex','0');wrapper.set('aria-label','Polynomial coefficient table; scroll horizontally on narrow screens')
    parent=table.getparent();parent.replace(table,wrapper);wrapper.append(table)
    table.attrib.pop('style',None)
    for row in table.xpath('./tbody/tr'):
        for j,cell in enumerate(row):
            value=html.Element('div',{'class':'cell-value'})
            value.text=cell.text;cell.text=None
            for child in list(cell):value.append(child)
            if j<len(heads):
                label=html.Element('span',{'class':'mobile-label','aria-hidden':'true'})
                label.text=heads[j].text
                for child in list(heads[j]):label.append(copy.deepcopy(child))
                cell.append(label)
            cell.append(value)
    if 'numeric-table' in wrapper.get('class'):
        note=html.Element('p',{'class':'table-scroll-note'});note.text='Scroll this coefficient table sideways to read every column.';wrapper.addnext(note)

heading_nodes=article.xpath('.//h2')
heading_map={h.get('id'):h.text_content() for h in heading_nodes}
groups=[
('Read the chart',['the-calculation-in-view','how-to-read-the-calculation','conventions-and-two-distinct-complex-variables','one-load-through-a-transmission-line','rotations-as-rational-impedance-transformations']),
('Reconstruct with packets',['split-an-analytic-response-into-cyclic-packets','a-complete-exact-impedance-and-admittance-calculation','from-the-chart-to-a-passive-two-port','incomplete-packets-can-hide-two-different-passive-networks']),
('Complete passive data',['passive-completion-from-incomplete-packets','reconstruct-a-fixed-reciprocal-two-port','matrix-packets-without-commuting-the-network-blocks','frequencies-must-agree-with-one-physical-network','one-last-compatibility-layer-frequency-and-load-simultaneously','reciprocity-imposes-an-obstruction-beyond-passivity','boundary-adapted-sampling-useful-and-limited','a-compact-method-for-reading-each-proof']),
('From response to circuit',['from-a-safe-packet-mask-to-an-explicit-minimal-state-passive-rlc-circuit','exact-order-proliferation-under-cyclic-filtering','exactly-six-reactive-elements-with-an-ideal-reciprocal-combiner','transformer-free-synthesis-a-precise-decision-theorem-and-a-topology-obstruction']),
('The degree-six investigation',['six-state-invariants','pole-pair-extraction','second-pole-pair-extraction','four-anchor-continuation','certified-cubic-extraction','seven-reactive-exact']),
('Verification and scope',['arbitrary-order-separation','verification-register-and-reproducible-records','what-has-been-settled-and-what-remains-open','sources-and-provenance','suggested-reading-routes'])]
toc=[]
for i,(label,ids) in enumerate(groups,1):
    for ident in ids:assert ident in heading_map,(ident,list(heading_map))
    links=''.join(f'<a href="#{ident}">{escape(heading_map[ident])}</a>' for ident in ids)
    toc.append(f'<details class="toc-group"'+(' open' if i in [1,5] else '')+f'><summary><span class="toc-number">{i:02}</span>{escape(label)}</summary><div class="toc-links">{links}</div></details>')

proof_zip=ROOT/'downloads/Smith_Chart_Exact_Certificate.zip'
with zipfile.ZipFile(proof_zip,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for f in sorted((ROOT/'reproduction/exact_seven').rglob('*')):
        if f.is_file() and f.suffix not in ['.pkl','.pyc'] and '__pycache__' not in f.parts:
            z.write(f,f.relative_to(ROOT/'reproduction/exact_seven'))
proof_data=data_url(proof_zip)
md_data=data_url(SOURCE)
downloads=html.fragment_fromstring(f'<div class="download-panel"><p><strong>Read and reproduce.</strong> The certificate archive contains the current graph definitions, exact rational centers, verified bounds, and replay instructions.</p><div class="download-list"><a download="Smith_Chart_Exact_Certificate.zip" href="{proof_data}">Download exact certificate files</a><a download="{NAME}.md" href="{md_data}">Download manuscript source</a></div></div>')
anchor=article.get_element_by_id('verification-register-and-reproducible-records')
anchor.addnext(downloads)

css=(ROOT/'assets/reading.css').read_text()
js=(ROOT/'assets/reading.js').read_text()
mathjax=(ROOT/'assets/mathjax-tex-svg.js').read_text()
config=r'window.MathJax={tex:{inlineMath:[["\\(","\\)"]],displayMath:[["\\[","\\]"]],tags:"ams"},svg:{fontCache:"global"},options:{enableMenu:false},startup:{typeset:true}};'
top_downloads=f'<a download="Smith_Chart_Exact_Certificate.zip" href="{proof_data}">Proof files</a><a download="{NAME}.md" href="{md_data}">Source</a>'
doc=f'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="author" content="Komorebi P."><meta name="description" content="An unpublished reading edition connecting Smith chart geometry, cyclic packets, passive completion, and exact circuit synthesis."><title>{escape(title_text)} · Komorebi P.</title><style>{css}</style><script>{config}</script></head>
<body><a class="skip-link" href="#manuscript">Skip to reading</a><div class="draft-notice">UNPUBLISHED READING EDITION · REVISED 11 NOVEMBER 2026</div>
<header class="topbar"><a class="wordmark" href="#{title_id}">KOMOREBI<small>MATHEMATICS · SIGNALS · REALIZATION</small></a><nav class="top-actions" aria-label="Reading actions"><a href="#current-result">Current result</a>{top_downloads}<button type="button" class="text-button" id="print-reading">Print</button></nav></header>
<main class="page"><section class="cover"><p class="kicker">Extended worked example · exact mathematics</p>{serialize(title)}<p class="author-line">Author: Komorebi P. · Revised 11 November 2026</p>{serialize(intro)}<nav class="quick-nav" aria-label="Choose a reading route"><a href="#current-result">Current result</a><a href="#one-load-through-a-transmission-line">Start with the chart</a><a href="#seven-reactive-exact">Exact circuit proof</a><a href="#arbitrary-order-separation">Order boundary</a><a href="#verification-register-and-reproducible-records">Verify the calculation</a></nav></section>
<div class="reading-layout"><details class="contents" id="contents" open><summary>Contents · six reading routes</summary><div class="contents-title">In this reading</div><a class="toc-current" href="#current-result">Current result: six or seven?</a>{''.join(toc)}<div class="toc-progress">Reading progress<progress id="reading-progress" max="100" value="0" aria-label="Reading progress"></progress></div></details>{serialize(article)}</div>
<footer class="end-note"><strong>Komorebi P.</strong> · Unpublished reading draft. {image_count} Python-generated mathematical figures. Exact ideal-circuit existence is distinguished from numerical regression, hardware validation, and historical novelty.</footer></main>
<a class="back-top" href="#{title_id}" aria-label="Return to the top of the reading">↑ Top</a>
<dialog id="figure-dialog" aria-label="Expanded mathematical figure"><div class="dialog-toolbar"><button class="text-button" type="button" id="figure-fit" aria-pressed="false">View at full resolution</button><button class="dialog-close" type="button" id="figure-close">Close</button></div><div id="dialog-image-wrap" class="dialog-image-wrap dialog-fit"><img id="dialog-image" alt=""></div><p id="dialog-caption"></p></dialog>
<script>{mathjax}</script><script>{js}</script></body></html>'''
dest=ROOT/(NAME+'.html');dest.write_text(doc)

# Static integrity checks fail the build if a reader link or structural ID is broken.
tree=html.fromstring(doc)
ids=tree.xpath('//*[@id]/@id')
assert len(ids)==len(set(ids)), 'Duplicate IDs'
missing=[a.get('href') for a in tree.xpath('//a[starts-with(@href,"#")]') if a.get('href')[1:] not in set(ids)]
assert not missing,missing
assert len(tree.xpath('//h1'))==1
assert len(tree.xpath('//article//img'))==42
assert len(tree.xpath('//article//table'))==table_count
assert not tree.xpath('//script[@src] | //link[@rel="stylesheet"]'), 'External render dependency'
summary={'html':dest.name,'bytes':dest.stat().st_size,'figures':image_count,'tables':table_count,'headings':len(tree.xpath('//h1|//h2|//h3|//h4|//h5')),'h1_count':1,'broken_fragment_links':missing,'external_render_dependencies':0,'proof_archive_bytes':proof_zip.stat().st_size}
(ROOT/'audit/build_integrity.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
