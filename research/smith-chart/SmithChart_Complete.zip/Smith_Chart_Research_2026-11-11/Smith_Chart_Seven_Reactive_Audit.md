# Smith chart reading revision and verification

Author: Komorebi P.  
11 November 2026. Unpublished.

## Outcome

The current exact construction survives focused proof audit and rational certificate replay. It realizes the specified degree-six impedance with four inductors, three capacitors, and fourteen positive resistors, without transformers. The justified minimum-count interval remains 6 ≤ q_min ≤ 7.

## Mathematical changes

**Corrected hypothesis.** The rotated-pole theorem now assumes a proper rational function of the disk variable, excluding a pole at infinity. Without that condition, the finite-pole count does not determine rational-map degree. The inserted Schur counterexample has one finite pole and degree two. The applications to the noncentral automorphism and filtered LC examples satisfy the corrected hypothesis.

**Expanded cancellation proof.** Coprimality of the reduced cubic numerator and denominator forces the two quartic nodal polynomials to share exactly one linear factor. The new derivation proves a nonzero left-null row for the eight-coefficient Jacobian. Its rank is at most seven at the certified solution, explaining why the direct square solve is singular.

**New exact interval checks.** The supplied rational boxes imply:

\[
-169/1000 < B(s_0) < -165/1000,\qquad
246/1000 < T(s_0) < 252/1000.
\]

These bounds justify the nonzero derivatives and ranks used in the new Jacobian explanation. They were checked with exact Fraction interval arithmetic.

**Corrected minimality logic.** An exact six-reactive construction would already meet the established degree-six lower bound. It would not require a new exclusion of all smaller counts. Conversely, proving that no six-reactive circuit exists would combine with the seven-reactive construction to establish minimum seven.

**Assembly and terminology.** The reading now specifies the series wiring of the two local circuits. It distinguishes the earlier seven-total-component example from the current seven-reactive, twenty-one-total-component construction. The final circuit is not described as a proved minimum-seven circuit.

## Computational evidence

The symbolic systems were regenerated from reviewed graph definitions. The current acceptance tests passed using exact rational comparisons. Approximate values below describe those checked quantities:

| Check | Replayed result |
|---|---|
| First-stage contraction | approximately 1.45618 × 10^-69 |
| Uniform second-stage contraction | approximately 3.75486 × 10^-47 |
| Second-stage displacement divided by radius | approximately 8.59049 × 10^-16 |
| Internal rank witness | exact interval strictly below -42 |
| Degree-six target resultant | 48289705700056104960000000000 |
| Independent nodal diagnostic | 165 points; maximum normalized discrepancy about 1.45356 × 10^-83 |

The nodal error is consistently abs(computed − target) / max(1, abs(target)). It is a numerical regression metric, separate from the exact existence certificate. Explicit positivity, coordinate-partition, and interval-envelope guards were added to the verifier copies.

Observed environment: Python 3.12.14, SymPy 1.14.0, mpmath 1.3.0, NumPy 2.3.5. The separate replay report gives the input/output provenance and detailed scope.

## Reading and source package

The document has one page title, six grouped navigation routes, a current-result overview, properly structured reference tables, and 41 Python-generated mathematical figures. The forty previous figures are preserved, including their original vector data where available. The new map shows the two-section series assembly and the distinction between seven reactive elements and input degree six.

The current certificate sources and exact rational centers are embedded as a downloadable archive. The manuscript source is also downloadable from the HTML. The complete package includes the recovered historical sources listed in SOURCE_INDEX.md. Claims that unavailable older notes or the historical 171-check suite were supplied have been removed or qualified.

## Verification boundary

The focused audit covers the seven-reactive theorem, the newly expanded cancellation/Jacobian explanation, and the corrected degree statement. It is not a claim that every theorem in the full reading received a new independent audit.

The local browser runner failed: its default browser binary was unavailable, and the installed Chromium was unable to create a required socket under the environment's restrictions. The available browser interface then blocked local-file preview under its URL policy. No workaround was attempted after that policy block. Fresh browser layout, scrolling, figure-dialog, and download-interaction checks therefore remain uncompleted. The package records those checks as blocked, not passed.

Static checks verified the single H1, unique IDs, existing internal anchor targets, real table markup, all image assets, and the absence of external script/style URLs. JavaScript syntax checks passed. The new Python map was visually inspected. The earlier browser records belong to their earlier editions.

## Still open

Six-reactive transformer-free realizability or impossibility for this exact target, minimal resistor count, practical tolerance bounds, and historical novelty remain unsettled. The work remains unpublished.
