# Prior art and dependencies

**Author: Komorebi P.**

The core impedance H(s)=(6s^2+3s+4)/(6s^2+2s+9), its five-reactive realization, and the fact that its global minimum reactive count is five are due to Timothy H. Hughes, *Why RLC realizations of certain impedances need many more energy storage elements than expected*, IEEE Transactions on Automatic Control 62(9), 4333–4346 (2017), arXiv:1611.06258v2. The application uses Lemma 3 and Theorems 4–6 with K=omega_0=F=1 and W=2/3. The five-reactive netlist was recovered from the project's retained November 11 implementation and replayed independently.

The six-reactive bound mentioned in an earlier brainstorm concerns the series-parallel restriction. It must not be substituted for the unrestricted five-reactive bound for this core.

Resistor Kron reduction, weighted tree/forest impedance formulas, endpoint open/short analysis, compactness of finite-dimensional boxes, real-algebraic feasibility, and interval exclusion are established mathematical tools. The project already had an unbounded exact all-topology formulation and proof-carrying positive constructions. The present note's contribution within the project is the explicit bounded formulation, the forced-degeneration preservation argument, and the reactive allocation argument across scales, with their carefully scoped corollaries.

Sources consulted:

- https://arxiv.org/pdf/1611.06258v2
- https://api.repository.cam.ac.uk/server/api/core/bitstreams/728a4eec-47b0-425a-833c-4e87fd37a8a0/content
- https://doi.org/10.1137/1.9781611975826 (Passive Network Synthesis: An Approach to Classification)
- Previous project file: Smith_RLC_Coupled_Core_Lifting_Theorem_2026-11-11.md
- Previous project file: Smith_RLC_Composition_Report_2026-11-11.md

The arXiv PDF text was retrieved. Its screenshot endpoint initially failed with a cache-miss error; a Cambridge repository PDF screenshot succeeded. The decisive Hughes theorem conditions were cross-checked in the text and the repository page image.

Targeted searches did not establish historical novelty of the new arguments. They are not a comprehensive priority audit. No claim of first discovery should be attached to this checkpoint.
