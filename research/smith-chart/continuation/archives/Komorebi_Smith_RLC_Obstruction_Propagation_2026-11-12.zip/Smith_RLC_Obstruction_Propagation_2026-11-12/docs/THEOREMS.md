# Obstruction propagation and separated-scale RLC synthesis

**Author: Komorebi P.**  
**Date: 12 November 2026**  
**Status:** Unpublished research derivations with complete arguments below and supplementary exact implementation checks. Self-reviewed in this checkpoint. No independent review, Lean verification, or historical-priority claim. The quantitative smallness thresholds have not been computed.

## 0. The question answered

Earlier work constructed full-dimensional families with reactive count equal to rational degree. It did not establish whether a core's *excess* reactive complexity survives a passive attachment or survives composition with other cores.

This note proves an asymptotic preservation statement, not an unrestricted preservation statement for arbitrary attachment values. It also proves additivity under sufficiently large separation of frequency scales. Together, the arguments give families at unbounded degree with exact reactive minima strictly above rational degree.

Let r(Z) be the least number of physical inductors plus capacitors among finite ordinary positive, uncoupled, transformer-free RLC one-ports realizing Z. Arbitrarily many resistors are permitted. Wires may be contracted. Ideal open/short branches appear only in compact intermediate descriptions. They are removed or contracted before counting the final physical realization. No mutual inductance, ideal transformer, controlled source, distributed element, or negative component is admitted.

The degree d(Z) is max(deg P,deg Q) for coprime real polynomials Z=P/Q. All nonzero finite passive targets considered here satisfy 0<Z(s)<infinity for s>0. Endpoint statements concern limits along positive real s, not an assumption about a particular internal sinusoidal solution.

## 1. Finite graph bound despite unrestricted resistor count

**Lemma 1.** A network with at most q reactive branches can be replaced, without changing its impedance or increasing its reactive count, by a network with at most N=2q+2 vertices and at most N(N-1)/2 resistor branches.

**Proof.** Retain the two terminals and every endpoint of every reactive branch. There are at most 2q+2 retained vertices. All other vertices are incident only with resistors. Eliminate these resistor-only vertices by the Schur complement of their conductance Laplacian. A resistor component with no retained vertex is disconnected from the active network and is discarded.

For each remaining eliminated component, the grounded Dirichlet matrix is positive definite and has a nonnegative inverse. The Schur complement is again a graph Laplacian: off-diagonal entries are nonpositive and row sums are zero. It is therefore realized by nonnegative conductances on pairs of retained vertices. Omit zero conductances and combine parallel resistors. The eliminated matrices have no s dependence, so this is an identity of rational impedances, not a sample-wise approximation. Every reactive branch is retained. QED.

For a fixed q, pad to N vertices. Include one optional resistor on every vertex pair and q optional reactive slots. Each slot chooses a pair and the type L or C. There are finitely many labeled skeletons. Repeated slots on one pair are harmless. Zero slot values omit branches and cover smaller budgets.

**Lemma 2.** Every such finite network has rational degree at most its reactive count.

**Proof.** Write its edge admittances as g, c s, and h/s, where h=1/L. The weighted spanning-tree and terminal-separating spanning-two-forest formulas give its impedance as a ratio of sums of edge products. If the network contains ell inductors and c capacitors, multiply both sums by s^ell. Each monomial exponent is ell+c_T-ell_T, between 0 and ell+c=q. Cancellation can only lower the resulting rational degree. Disconnected/open and identically short cases are handled separately. QED.

## 2. A bounded real-Laplace network representation

For each branch set

    t = kappa/(1+kappa),   0 <= t <= 1,

where kappa=g for R, kappa=c for C, and kappa=h=1/L for L. At a positive real Laplace argument s, let

    phi_R(s)=1,   phi_C(s)=s,   phi_L(s)=1/s.

The branch law is

    (1-t) i = t phi(s) (v_u-v_v).                       (2.1)

At t=0 it requires i=0, so the branch is open. At t=1 it requires equal endpoint voltages, so the branch is a wire. For 0<t<1 it is the ordinary positive finite element.

Drive the one-port through a unit series resistance from a unit source. With ground potential zero, impose

    V_port + I_port = 1.

This is a mathematical normalization. It does not add a counted element to the synthesized network. For impedance Z(s)>0 it gives

    V_port = Z(s)/(1+Z(s)),
    I_port = 1/(1+Z(s)),
    gamma(s) = (Z(s)-1)/(Z(s)+1) = 2 V_port-1.

**Lemma 3.** Every finite network has a witness at each s>0 with every node voltage in [0,1] and every oriented branch current in [-1,1].

**Proof.** At s>0 all edge admittances are positive real numbers. The discrete maximum principle places every node in a source-connected component between the ground and terminal potentials, and 0<=V_port<=1. Set potentials in irrelevant floating components to zero.

For an edge with v_u>v_v, choose a level theta strictly between them. All currents crossing the cut {v>theta} point outwards. If that cut carries any nonzero current, it contains the driven terminal but not ground. Summing KCL shows that its total outward current is I_port<=1. The selected edge current is one nonnegative summand. Equal-potential edges carry zero current. The opposite orientation changes only the sign. QED.

For a fixed finite set of sample arguments, all t variables, all node voltages, and all branch currents consequently belong to a compact box. KCL, the port equation, and (2.1) are closed polynomial equations over the rationals for rational sample arguments.

**Lemma 4: boundary semantics.** Any solution of those closed equations is a genuine sample response of the graph obtained by contracting every t=1 branch and deleting every t=0 branch. Every surviving branch has a positive finite ordinary R/L/C value, and the number of surviving reactive branches does not increase.

**Proof.** Sum KCL over each contracted vertex class. Internal wire currents cancel. The surviving equations are exactly KCL and the finite positive branch laws on the quotient graph. If the terminals contract together, the port is the identically short case. If they disconnect, it is the open case. Otherwise the positive-real-Laplace equations have a unique terminal response. Self-loops and components not affecting the terminals can be discarded. QED.

This is important: zero/infinite component limits have not been replaced by ideal transformers or by an unproved effective model.

## 3. Compactness and finite-sample separation

**Theorem 1: bounded-reactive compactness.** Fix q and finitely many positive real sample arguments. The set of sample vectors gamma obtainable with at most q reactive elements, including the ideal open/short limits, is compact.

**Proof.** For each of the finitely many skeletons from Lemma 1, use the box and closed equations of Section 2, allowing gamma coordinates in [-1,1]. Its solution set is compact. Projection onto the gamma coordinates is compact. Lemma 4 proves that every projected boundary solution still describes an ordinary reduced circuit, or a terminal open/short. The finite union over skeletons is compact. QED.

**Finite identity lemma.** If a rational target Z has degree n and a candidate has degree at most q, agreement at n+q+1 distinct positive real arguments implies rational identity. Indeed, the cross-multiplied difference polynomial has degree at most n+q. Passive finite candidates have no poles at these arguments.

**Corollary 1: persistence of lower bounds.** Suppose r(Z)>q. At any chosen n+q+1 distinct positive real sample arguments, there is a positive separation between the target's gamma vector and the compact q-budget response set. Consequently, sufficiently small perturbations of that finite sample vector cannot be realized with q or fewer reactive elements.

This does not give the numerical separation without additional work. It does establish that allowing arbitrary component values to tend to zero/infinity cannot erase a genuine fixed-budget obstruction.

**Limit form used below.** Suppose Z_j -> Z pointwise on positive real arguments and r(Z_j)<=q. Choose reduced bounded graphs as in Lemma 1 and a subsequence with fixed skeleton and fixed present/absent support. Pass to a common subsequence of compact parameters and normalized witnesses at n+q+1 arguments. By Lemma 4 and the finite identity lemma, the resulting contracted/deleted graph realizes Z with at most q reactive elements.

If an identified reactive branch must have t=0 or t=1 in that limit, it is absent from the counted limit circuit. If a distinct second reactive branch must also degenerate, the limit uses at most q-2 elements. These stronger count statements drive the next results.

**Corollary 1b: weak resistor addition preserves the minimum.** For every realizable nonzero finite Z with r=r(Z), there is rho_0>0 such that r(Z+rho)=r for 0<rho<rho_0. Adding a series resistor gives the upper bound without adding storage. A sequence of smaller-budget realizations converging to Z would contradict Theorem 1. The corresponding small positive shunt-conductance statement follows in the same way. This is a lower-budget stability assertion, not a claim that arbitrary large resistance additions preserve complexity.

## 4. Endpoint properties are path and cut properties

For a finite positive RLC network with distinct connected terminals:

| Port property | Equivalent graph condition |
|---|---|
| Z(0)=0 | An inductor-only path joins the terminals |
| Z(0)=infinity | No path joins the terminals using R and L branches only |
| Z(infinity)=0 | A capacitor-only path joins the terminals |
| Z(infinity)=infinity | No path joins the terminals using R and C branches only |

**Justification.** At s down to zero, inductors short and capacitors open. The finite remaining resistor network has zero effective resistance precisely when the terminals have already been joined by the inductive shorts, and infinite effective resistance precisely when no R/L path exists. The high-frequency assertions follow with C and L exchanged. These conclusions also follow directly from positive-real conductance variational bounds, so there is no complex cancellation argument at an endpoint.

**Lemma 5: forced loss of a reactive branch.** In a bounded-graph limit whose port remains a nonzero finite rational function:

* If an original zero at zero disappears, some original inductor on an inductive terminal path has h->0 and is deleted.
* If an original zero at infinity disappears, some original capacitor on a capacitive terminal path has c->0 and is deleted.
* If an original pole at zero disappears, some original capacitor has c->infinity and is contracted.
* If an original pole at infinity disappears, some original inductor has h->infinity and is contracted.

**Proof.** For a zero at zero, take a fixed inductive terminal path along a subsequence. If none of its branches is deleted, its finite inductors and contracted wires still give an inductive terminal path in the quotient. The limiting port would still be zero at zero, or identically short. This is contrary to the hypothesis. The capacitor path argument is identical at infinity.

For a pole at infinity, the R/C subgraph initially has no terminal path. Contracting an R or C edge cannot join distinct components of this subgraph, and deleting edges cannot create a path. If no inductor is contracted, the quotient still has no R/C terminal path. Its port would retain the pole at infinity, or become identically open. Thus an inductor must be contracted. Exchanging L and C gives the zero-frequency pole statement. QED.

This lemma is about all competing topologies after bounded-graph reduction, not only a visibly attached outer element in the construction.

## 5. Weak lossless attachments preserve the exact minimum

**Theorem 2: weak endpoint lifting.** Let Z be a realizable nonzero finite rational impedance and r=r(Z). Each line below has a threshold epsilon_0>0, depending on Z and the selected operation, such that for every 0<epsilon<epsilon_0 the transformed impedance has minimum reactive count r+1.

| Operation | Formula | Endpoint hypothesis on Z |
|---|---|---|
| Series inductor | Z+epsilon s | No pole at infinity |
| Series capacitor | Z+epsilon/s | No pole at zero |
| Shunt capacitor | (Z^{-1}+epsilon s)^{-1} | No zero at infinity |
| Shunt inductor | (Z^{-1}+epsilon/s)^{-1} | No zero at zero |

The physical element values are L=epsilon, C=1/epsilon, C=epsilon, and L=1/epsilon respectively. "Weak" refers to their port contribution, not to every physical value tending to zero.

**Proof for a series inductor.** A minimum r-element realization of Z plus the stated inductor gives an upper bound r+1. The transformed impedance has a pole at infinity and tends to Z at every positive real argument as epsilon tends to zero.

If arbitrarily small positive epsilon admitted an r-or-fewer realization, select a sequence and apply the limit form of Theorem 1. Since Z has no pole at infinity, Lemma 5 forces at least one inductor to contract. The resulting limit circuit realizes Z with at most r-1 reactive elements, contradicting the definition of r. Thus there is a punctured neighborhood in which the lower bound is r+1. The upper bound matches.

The other three proofs use the other three forced-degeneration statements. QED.

**Degree statement.** Under the indicated endpoint hypotheses each operation raises reduced rational degree by exactly one. For series L and shunt C this follows from the polynomial pairs (P+epsilon sQ,Q) and (P,Q+epsilon sP) and their unchanged gcd. The zero-frequency operations have pairs (sP+epsilon Q,sQ) and (sP,sQ+epsilon P). The endpoint hypotheses exclude an extra factor s, and leading coefficients of a positive-real function have the required sign. No extra cancellation occurs.

**Scope.** This theorem does not assert preservation for every positive epsilon. It gives a complete asymptotic statement. The threshold is not evaluated in this checkpoint.

## 6. Localization adds exactly two reactive elements

**Theorem 3: weak shunt-LC localization.** Suppose Z has finite strictly positive limits at both zero and infinity, degree d, and minimum reactive count r. Define

    B_delta(Z)(s) = [ Z(s)^(-1) + delta(s+s^(-1)) ]^(-1).

There is a delta_0>0 such that for all 0<delta<delta_0,

    d(B_delta(Z)) = d+2,
    r(B_delta(Z)) = r+2,
    B_delta(Z)(0) = B_delta(Z)(infinity) = 0.

**Proof.** Add one shunt capacitor C=delta and one shunt inductor L=1/delta to a minimum circuit for Z. This uses r+2 reactive elements. The target has both endpoint zeros and tends pointwise to Z on s>0 as delta goes to zero.

If arbitrarily small delta admitted at most r+1 reactive elements, bounded-graph compactness would produce a limit realizing Z. Disappearance of the zero at zero forces deletion of an inductor. Disappearance of the zero at infinity forces deletion of a capacitor. These are distinct branches. At most r-1 reactive elements remain, a contradiction.

For Z=P/Q with deg P=deg Q=d and P(0)Q(0) nonzero, the transformed pair is

    N=sP,
    D=sQ+delta(s^2+1)P.

It is coprime: D(0)=delta P(0) is nonzero, and any common root of P and D would be a common root of P and sQ. Its denominator has degree d+2 and numerator degree d+1. QED.

The common delta in this result is not obtained by assuming that two separate one-parameter thresholds are uniform in each other. The two-forced-deletions proof handles the simultaneous limit directly.

## 7. Additivity at widely separated frequency scales

**Theorem 4: scale-separated lower bounds.** Let a_1,...,a_k be distinct fixed integers. Suppose a family T_epsilon of realizable rational impedances satisfies

    T_epsilon(epsilon^(a_j) s) -> F_j(s),  for every s>0,

where each F_j is a nonzero finite realizable rational impedance with r_j=r(F_j). Then for all sufficiently small positive epsilon,

    r(T_epsilon) >= r_1+...+r_k.                         (7.1)

**Proof.** Suppose instead that a sequence epsilon_l down to zero has realizations with q<=sum r_j-1. Apply Lemma 1 to obtain a common bounded skeleton along a subsequence. Use compact normalized sample witnesses at each scale, with at least d(F_j)+q+1 distinct arguments s>0 in each band.

An original capacitor with coefficient c_l is seen in band j with coefficient

    c_l epsilon_l^(a_j).

An original inductor with inverse-inductance coefficient h_l is seen in that band with coefficient

    h_l epsilon_l^(-a_j).

Pass to a simultaneous extended limit in [0,infinity] of all those finitely many scaled coefficients. A given capacitor cannot have a finite strictly positive limit in two different bands: the ratio of its coefficients in two bands is epsilon_l raised to a nonzero power. The same is true for an inductor. Thus every reactive branch survives as a finite physical branch in at most one limiting band circuit.

By the compact sample equations and the finite identity lemma, the j-th quotient graph realizes F_j. If q_j counts its surviving reactive branches, then q_j>=r_j. But the disjoint survival property gives sum q_j<=q. This contradicts q<=sum r_j-1. QED.

Resistor values may tend to zero, infinity, or finite positive values and can be shared between band limits. They are not counted, and this does not weaken the reactive allocation argument. No assumption of an initially series-parallel competitor is made.

**Corollary 2: exact series additivity for localized cores.** Suppose each F_j vanishes at both zero and infinity. Put

    T_epsilon(s) = sum_{j=0}^{k-1} F_j(s/epsilon^j).

At the j-th scale all other summands tend to zero. Theorem 4 gives the sum of the minima as a lower bound for sufficiently small epsilon. The displayed series connection gives the matching upper bound, hence

    r(T_epsilon) = sum_j r(F_j)

for sufficiently small epsilon.

For copies of one degree-D profile with no zero-frequency pole, the pole sets of the scaled summands are disjoint for sufficiently small epsilon. If all poles have moduli in [a,b], 0<a<=b<infinity, it suffices that epsilon<a/b. No pole can cancel against other summands, which are analytic at that pole. Therefore the degree is exactly kD.

For a polynomial denominator sum_{i=0}^D d_i s^i with nonzero d_0,d_D, explicit coarse rational bounds are

    b = 1 + max_{i<D} |d_i/d_D|,
    a = 1 / (1 + max_{i>0} |d_i/d_0|).

These certify pole separation. They do NOT by themselves certify the stronger reactive-minimality threshold.

## 8. Application to the Hughes biquadratic core

Use the published core

    H(s) = (6s^2+3s+4)/(6s^2+2s+9).

It has H(0)=4/9, H(infinity)=1, H(i)=i, and

    Re[P(i omega)Q(-i omega)] = 36(omega^2-1)^2.

The denominator is Hurwitz and the function is positive real. Its minimum reactive count is five by Hughes, arXiv:1611.06258v2, Theorems 4–6, with K=omega_0=F=1 and W=2/3. In Theorem 5 the two potentially relevant exceptional squared conditions give F^2=4/3 or 4/27, neither equal to one. This five-element lower bound is PRIOR ART, not a new claim here.

A retained exact five-reactive physical realization is supplied in results/Hughes_base_witness.json. The new Fraction nodal evaluator replays it independently at ten positive real arguments, exceeding the degree-two/physical-five identity threshold of eight.

Its localized profile is

    B_delta(s) = (6s^3+3s^2+4s) /
      [6delta s^4+(6+3delta)s^3+(2+10delta)s^2+(9+3delta)s+4delta].

For every positive delta this formula has degree four, vanishes at both endpoints, is positive real, and satisfies B_delta(i)=i. Its dissipation polynomial in x=omega^2 is 36x(x-1)^2 before any common scalar normalization.

**Consequences of the new arguments.** There exists delta_0>0 such that every 0<delta<delta_0 has

    d(B_delta)=4,  r(B_delta)=7.

Fix any such delta. For every positive integer k there exists epsilon_0(k,delta)>0 such that

    T_{k,delta,epsilon}(s) = sum_{j=0}^{k-1} B_delta(s/epsilon^j)

has, for 0<epsilon<epsilon_0,

    d(T)=4k,  r(T)=7k.                                  (8.1)

The epsilon threshold is also restricted to enforce disjoint poles as above. Thus the excess count is 3k and is unbounded with degree. The quantifiers are delta first, then fixed k, then epsilon. No single epsilon has been shown to work for all k.

For k>=2 and distinct scales, the sum has strictly positive dissipation at every finite nonzero imaginary-axis frequency: each summand's only positive lossless-contact frequency is its own scale, so they cannot all vanish at the same frequency.

An even stronger interior version follows from Corollary 1b. For sufficiently small rho>0, define

    Z_hat(s) = rho + T_{k,delta,epsilon}(s).

Then d(Z_hat)=4k and r(Z_hat)=7k, while Re Z_hat(i omega)>=rho>0 at every real frequency and Z_hat(0)=Z_hat(infinity)=rho. Thus a finite-frequency dissipation-zero invariant alone cannot capture all of the excess reactive complexity. The hard seed is on the lossless-contact boundary, but the transported obstruction survives inside strictly dissipative target families. The numerator/denominator gcd is unchanged by adding rho Q to P.

Every sufficiently small positive rational delta and epsilon in the stated nested ranges produces rational target coefficients and a fully rational forward circuit. This statement does not identify a numerical pair until the thresholds are separately certified.

**Every-degree version.** Starting from (8.1), append t=0,1,2,3 weak endpoint attachments at infinity, alternating series L then shunt C then series L. Each satisfies Theorem 2 and raises both degree and minimum count by one. For every n=4k+t, k>=1, there consequently exist positive-real rational impedances with

    d(Z)=n,  r(Z)=7k+t = n+3 floor(n/4).

Separately, alternating weak endpoint lifts starting from H gives an impedance of every degree n>=2 with r(Z)=n+3. These are different targets from the earlier degree-six example whose certified minimum remains six.

## 9. Finite exact lower-budget certificates in principle

For rational target coefficients and rational positive sample arguments, the compact equations from Section 2 form a finite collection of bounded polynomial systems. Choose at least n+q+1 arguments. Feasibility of their union is equivalent to q-budget realizability, because boundary solutions reduce to ordinary networks and finite agreement implies rational identity.

If one such boxed system is infeasible, its defining polynomial residuals cannot vanish simultaneously anywhere in its compact box. The continuous function max_i |f_i(x)| has a positive minimum. Natural rational interval evaluation has uniformly vanishing overestimation as a bounded box mesh tends to zero. Therefore a sufficiently fine finite dyadic partition excludes every leaf by at least one residual interval not containing zero.

A portable certificate can be just that partition tree with the index of an excluding equation at each leaf. A checker regenerates the equations from the declared graph and target, verifies exact bisection coverage, and checks every rational interval exclusion. No solver UNSAT status need be trusted. All skeletons must be covered for a global budget conclusion.

This proves finite negative-certificate existence, not good complexity. A capped implementation may return UNKNOWN. Feasible singular systems need a positive algebraic-witness route rather than interpreting failure of interval exclusion as success.

### Computing the weak-attachment thresholds in principle

For a series-L lift, enumerate the skeleton supports with an R/C terminal cut. For shunt-C lifting, enumerate a capacitor-only terminal path, and use the analogous endpoint conditions for the other operations. In each endpoint-constrained compact system, feasibility at epsilon=0 would give either an impossible endpoint for the core or a core realization with one fewer reactive element. It is therefore impossible when the supplied core minimum is correct.

The closed feasible parameter set has positive distance from epsilon=0. Consequently there exists a rational eta>0 for which the complete constrained systems are infeasible on 0<=epsilon<=eta. Dyadic cover certificates can certify this. Fairly interleaving searches over decreasing eta and increasing proof budgets eventually finds one; naively running a feasible candidate forever would not suffice.

For localization, constrain both the inductive and capacitive paths. At delta=0 at least two distinct reactive branches must disappear. The same compact argument applies.

For separated bands, introduce one compact coefficient t_ej per branch per band. For a capacitor and a_j>a_i impose

    t_ej(1-t_ei) = epsilon^(a_j-a_i) t_ei(1-t_ej),

and reverse i,j for an inductor. At epsilon=0 these equations forbid the same branch from lying strictly between zero and one in two bands. The impossible sum-of-budgets condition therefore persists at the compact boundary. Target sample functions extend to epsilon=0 because the localized profiles vanish at both endpoints. Again a finite rational threshold and finite cover certificates exist.

None of those high-dimensional threshold searches has been executed here. The included cover checker demonstrates the format on two complete q=0 exclusions only. This limitation is explicit in CHECKED_AND_UNCHECKED.md and results/CHECKS.json.

## 10. Relationship to the previous gap and remaining work

The dissipation polynomial remains useful for finding hard cores and excluding resistor-connected topologies. The present closure uses a complementary global mechanism: endpoint connectivity forces reactive loss in a degeneration, and scale separation prevents one surviving physical element from paying for two limiting cores.

What the argument closes is the asymptotic obstruction-preservation and scale-additivity gap for the stated families. What it does not close is practical arbitrary-target minimum synthesis, explicit useful threshold values, lower bounds for every mixed-RLC target, global minimum resistor count, or physical engineering tolerance questions.

The proof should next receive an independent mathematical review, particularly of Lemma 1, boundary semantics, and the multiscale survival argument. Historical novelty remains unestablished. The universal statements in this note follow from their proofs, not from the finite checks.
