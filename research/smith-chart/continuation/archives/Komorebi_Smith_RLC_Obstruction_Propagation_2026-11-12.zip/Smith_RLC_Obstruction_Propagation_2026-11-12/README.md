# Smith / RLC obstruction propagation

**Author: Komorebi P.**  
**Date: 12 November 2026**  
**Publication status: unpublished.**

This is a focused research supplement to the November 11 composition checkpoint, not a replacement archive for all previous Smith chart work.

## Main mathematical result

The included arguments establish, within ordinary positive uncoupled transformer-free RLC networks:

1. Compactness of fixed-reactive-budget response sets after resistor-only node elimination and exact open/short compactification.
2. Preservation of the exact minimum under sufficiently weak lossless endpoint attachments.
3. An exact two-element increase under weak shunt-LC localization.
4. Additivity of reactive minima under sufficiently separated frequency scales.

Starting from the published Hughes degree-two, five-reactive core, the construction gives degree 4k families with minimum reactive count 7k for every positive integer k. Additional weak endpoint attachments give every-degree families. A sufficiently small added series resistor moves the examples into strictly dissipative families without changing reactive count or degree.

**Qualification:** The smallness thresholds are proved to exist and a complete exact certificate scheme is described, but their numerical values were not computed. Concrete numerical files here are forward realizations and upper bounds, not newly certified point minima. The proofs are self-reviewed, not independently reviewed or Lean formalized. Historical novelty is not established.

Read `docs/THEOREMS.md` for all hypotheses, quantifiers, proofs, and dependencies. Read `CHECKED_AND_UNCHECKED.md` before using any experimental numbers.

## Reproduction

No external Python packages are required:

```bash
python -S tests/run_checks.py
```

This replays the retained five-reactive Hughes circuit using a new Fraction nodal evaluator, checks compact open/short semantics, exercises endpoint degeneration rules, verifies rational target/circuit identities through degree 16, checks scale-allocation identities, and verifies two complete q=0 negative box-cover certificates.

Files:

- `src/compact_rlc.py`: exact bounded-port nodal evaluation and skeleton generator.
- `src/rational_functions.py`: independent Fraction polynomial operations.
- `src/interval_refutation.py`: small exact box-cover producer and checker.
- `tests/run_checks.py`: reproducible finite checks.
- `results/CHECKS.json`: exact scope and accepted results.
- `results/two_band_forward_witness.json`: rational degree-eight circuit with fourteen reactive elements. Its new lower bound at these particular numeric parameter values is NOT established.
- `docs/THEOREMS.md`: universal mathematical arguments.
- `docs/PRIOR_ART_AND_DEPENDENCIES.md`: what is borrowed and what is newly derived here.
- `CONTINUITY_HANDOFF.md`: next steps and pitfalls.

The previous original degree-six result remains q_min=6. The previous all-degree q_min=n construction is a different family and remains intact. This supplement addresses excess complexity, not a contradiction to those results.
