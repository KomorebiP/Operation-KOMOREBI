# Checked and unchecked

**Author: Komorebi P.**

## Mathematical arguments supplied

Complete self-contained arguments are included for the finite graph reduction, compact sample semantics, fixed-budget compactness, weak endpoint lifting, simultaneous localization, and separated-scale additivity. They use a published Hughes core lower bound for the numerical ratio application. The new proofs have not received independent review and are not Lean verified. Finite tests are not substitutes for these arguments.

## Executed exact checks

- 180 compact networks, 1,080 positive-real-Laplace sample checks, including 213 short-edge and 206 open-edge occurrences.
- The retained Hughes five-reactive circuit replayed at ten exact sample arguments. Degree bounds make these sufficient for its rational identity. Its lower bound is Hughes's published theorem.
- 11,000 decorated endpoint-degeneration graphs, including all 1,000 three-node decorations in the specified enumeration. There were 4,636 nondegenerate port limits and 1,551 endpoint changes checked.
- Three localized rational forward circuits, each with degree four and seven reactive elements, checked at twelve exact arguments.
- Four multiband forward circuits of degrees 4, 8, 12, 16 with 7, 14, 21, 28 reactive elements, checked at 12, 23, 34, 45 exact arguments respectively. These meet n+q+1 identity thresholds.
- 180 exact positive-scale allocation equalities and 32 admissible compact-boundary patterns in the declared finite alphabet.
- Two complete q=0 box covers, with 68 and 55 leaves. These certify only the q=0 examples, not Hughes's q<=4 lower bound or any higher-budget exclusion.
- Eight corrupted certificates rejected.
- A one-node proof-search budget deliberately returned UNKNOWN. Exhaustion is not an infeasibility result.

## Not completed

No numeric delta_0, epsilon_0, or endpoint-lift threshold has been computed. Consequently delta=1/10, 1/100, 1/1000 and epsilon=1/1000 in the finite checks must not be called certified parameter regimes for the new minima.

No all-topology q=4, q=6, or larger interval-cover run was completed. The exhaustive skeleton generator and cover checker are prototypes. Their theoretical completeness applies to an unlimited search schedule, not to a capped invocation.

No new concrete degree-eight point has a checked fourteen-reactive lower-bound certificate in this package. It has an exact fourteen-reactive upper-bound witness and lies in the formula family whose sufficiently-separated regime is addressed by the theorem.

The entire earlier composition release was not recompiled or replayed. Only the explicitly identified Hughes witness was recovered and checked for this supplement.

No SPICE, component tolerances, physical hardware tests, independent mathematical review, Lean formalization, or exhaustive novelty audit was performed. Nothing was published to GitHub or the reading site.
