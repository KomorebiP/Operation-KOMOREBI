"""Reproducible checks, not a finite proof of universal theorems.
Author: Komorebi P. Run with python -S tests/run_checks.py.
"""
import sys, json, random, itertools, copy, time
from pathlib import Path
from fractions import Fraction as F
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from compact_rlc import Edge,DSU,sample,verify_sample,skeletons
import rational_functions as rf
from interval_refutation import search,check

report={'author':'Komorebi P.','date':'2026-11-12','scope':'Finite exact implementation checks; universal proofs are separate.'}
rng=random.Random(20261112)
counts={'networks':0,'sample_checks':0,'short_edge_occurrences':0,'open_edge_occurrences':0}
for k in range(180):
    n=rng.randrange(2,8); edges=[]
    for j in range(rng.randrange(1,15)):
        u,v=rng.sample(range(n),2)
        t=rng.choice([F(0),F(1),F(1,2),F(2,3),F(1,5),F(5,6)])
        edges.append(Edge(rng.choice('RLC'),u,v,t))
        counts['short_edge_occurrences']+=t==1;counts['open_edge_occurrences']+=t==0
    for s in [F(1,8),F(1,2),F(1),F(2),F(7),F(16)]:
        sample(n,edges,s);counts['sample_checks']+=1
    counts['networks']+=1
report['compact_network_semantics']=counts

# The old Hughes witness is replayed using the new independent Fraction nodal evaluator.
old=json.loads((ROOT/'results'/'Hughes_base_witness.json').read_text())
physical=[(k,u,v,F(x)) for k,u,v,x in old['edges']]
def from_physical(physical):
    out=[]
    for kind,u,v,value in physical:
        kappa=value if kind=='C' else 1/value
        out.append(Edge(kind,u,v,kappa/(1+kappa)))
    return out
H=rf.reduce_rational([4,3,6],[9,2,6])
base=from_physical(physical)
for s in map(F,range(1,11)):
    w=sample(5,base,s);assert w['V']/w['I']==rf.rational_value(H,s)
report['Hughes_base']={'exact_positive_samples':10,'reactive_count':5,
 'degree':rf.degree(H),'identity_sample_threshold':8,
 'lower_bound_dependency':'Hughes arXiv:1611.06258v2, Theorems 4–6; not independently reproved here.'}
assert rf.dissipation([F(4),F(3),F(6)],[F(9),F(2),F(6)])==[36,-72,36]

# Port endpoint signatures, tested through all 10^3 three-node decorated cases.
def connected(n,edges,allowed):
    d=DSU(n)
    for kind,u,v in edges:
        if kind in allowed: d.union(u,v)
    return d.find(0)==d.find(1)
def signs(n,edges):
    return {'zero0':connected(n,edges,'L'),'zeroInf':connected(n,edges,'C'),
            'pole0':not connected(n,edges,'RL'),'poleInf':not connected(n,edges,'RC')}
def degeneration_case(n,decorated):
    orig=[(k,u,v) for k,u,v,status in decorated]
    if not connected(n,orig,'RLC'): return None
    d=DSU(n)
    for k,u,v,status in decorated:
        if status=='short': d.union(u,v)
    if d.find(0)==d.find(1): return None
    remaining=[(k,d.find(u),d.find(v)) for k,u,v,status in decorated if status=='finite' and d.find(u)!=d.find(v)]
    # Relabel quotient to keep ground/port at 0/1.
    roots=[d.find(0),d.find(1)]+sorted(set(d.find(i) for i in range(n))-{d.find(0),d.find(1)})
    ix={v:i for i,v in enumerate(roots)}
    remaining=[(k,ix[u],ix[v]) for k,u,v in remaining]
    if not connected(len(roots),remaining,'RLC'): return None
    before,after=signs(n,orig),signs(len(roots),remaining)
    implications=[('zero0','L','open'),('zeroInf','C','open'),('pole0','C','short'),('poleInf','L','short')]
    changed=0
    for sig,kind,status in implications:
        if before[sig] and not after[sig]:
            assert any(k==kind and st==status for k,u,v,st in decorated)
            changed+=1
    return changed
choices=[None]+[(k,st) for k in 'RLC' for st in ['open','finite','short']]
cases=valid=changes=0
for assignment in itertools.product(choices,repeat=3):
    dec=[(kind,*pair,st) for pair,a in zip([(0,1),(0,2),(1,2)],assignment) if a is not None for kind,st in [a]]
    cases+=1;out=degeneration_case(3,dec)
    if out is not None: valid+=1;changes+=out
for _ in range(10000):
    dec=[]
    for u,v in itertools.combinations(range(4),2):
        a=rng.choice(choices)
        if a is not None: dec.append((a[0],u,v,a[1]))
    cases+=1;out=degeneration_case(4,dec)
    if out is not None:valid+=1;changes+=out
report['endpoint_degenerations']={'decorated_graphs':cases,'nondegenerate_port_limits':valid,'endpoint_changes_checked':changes}

# Exact forward witnesses for localizers and multiband sums. The constants below
# are algebraic test constants, NOT certified small enough for the new lower bounds.
forward=[]
for delta in [F(1,10),F(1,100),F(1,1000)]:
    B=rf.localize(H,delta)
    assert rf.degree(B)==4
    capsule=physical+[('C',1,0,delta),('L',1,0,1/delta)]
    es=from_physical(capsule)
    for s in map(F,range(1,13)):
        w=sample(5,es,s);assert w['V']/w['I']==rf.rational_value(B,s)
    forward.append({'delta':str(delta),'degree':4,'reactive_upper_bound':7,'exact_samples':12,
                    'minimum_at_this_numeric_delta':'NOT ESTABLISHED'})
report['localized_forward_examples']=forward

# Multiband target arithmetic and graph identity at k=1,2,3,4.
multiband=[]
delta=F(1,100);B=rf.localize(H,delta);capsule=physical+[('C',1,0,delta),('L',1,0,1/delta)]
for k in range(1,5):
    eps=F(1,1000); total=([F(0)],[F(1)]); assembled=[]; nxt=2
    # Series connection from node 1 to node 0; internal port junctions are fresh.
    a=1
    for j in range(k):
        b=0 if j==k-1 else nxt
        if j<k-1:nxt+=1
        mapping={1:a,0:b}
        for internal in [2,3,4]:mapping[internal]=nxt;nxt+=1
        factor=eps**(-j)
        for kind,u,v,x in capsule:
            value=x*factor if kind in 'LC' else x
            assembled.append((kind,mapping[u],mapping[v],value))
        total=rf.series(total,rf.argument_scale(B,factor));a=b
    assert rf.degree(total)==4*k
    es=from_physical(assembled);ns=nxt
    points=list(map(F,range(1,11*k+2))) # n+q+1 = 11k+1
    for s in points:
        w=sample(ns,es,s);assert w['V']/w['I']==rf.rational_value(total,s)
    entry={'bands':k,'delta':str(delta),'epsilon':str(eps),'degree':4*k,
           'reactive_upper_bound':7*k,'exact_identity_samples':len(points),
           'lower_bound_for_these_numeric_parameters':'NOT ESTABLISHED'}
    multiband.append(entry)
    if k==2:
        (ROOT/'results'/'two_band_forward_witness.json').write_text(json.dumps({**entry,
          'P':list(map(str,total[0])),'Q':list(map(str,total[1])),
          'edges':[[kind,u,v,str(x)] for kind,u,v,x in assembled]},indent=2))
report['multiband_forward_examples']=multiband

# Exact scaling constraints, including the epsilon=0 compact boundary.
scale_checks=0
for kind in 'LC':
    for eps in [F(1,2),F(1,3),F(1,10)]:
        for kappa in [F(1,5),F(2),F(7,3)]:
            t=[]
            for a in range(5):
                c=kappa*eps**(a if kind=='C' else -a);t.append(c/(1+c))
            for i,j in itertools.combinations(range(5),2):
                if kind=='C':assert t[j]*(1-t[i])==eps**(j-i)*t[i]*(1-t[j])
                else:assert t[i]*(1-t[j])==eps**(j-i)*t[j]*(1-t[i])
                scale_checks+=1
boundary_admissible=0
for kind in 'LC':
    for t in itertools.product([F(0),F(1,3),F(2,3),F(1)],repeat=5):
        ok=all((t[j]*(1-t[i]) if kind=='C' else t[i]*(1-t[j]))==0 for i,j in itertools.combinations(range(5),2))
        if ok:
            assert sum(0<x<1 for x in t)<=1;boundary_admissible+=1
report['scale_allocation']={'exact_positive_scale_equalities':scale_checks,'admissible_boundary_patterns':boundary_admissible}

# Proof-carrying q=0 exclusions: after resistor Kron reduction N=2, one R.
cover_reports=[];certs=[]
for name,P,Q in [('inductor',[0,1],[1]),('Hughes',[4,3,6],[9,2,6])]:
    model={'nodes':2,'edges':[['R',0,1]],'P':list(map(str,P)),'Q':list(map(str,Q)),'samples':['1','2','3']}
    result=search(model,15000);assert result['status']=='CERTIFIED_INFEASIBLE'
    cert=result.pop('certificate');assert check(cert)['verified'];certs.append(cert)
    (ROOT/'results'/f'{name}_q0_cover.json').write_text(json.dumps(cert,indent=2))
    cover_reports.append({'target':name,**result,'scope':'All q=0 networks only'})
report['exact_negative_covers']=cover_reports
# Genuine budget exhaustion must not be reported as a proof.
unknown=search(certs[0]['model'],1);assert unknown['status']=='UNKNOWN'
report['budget_control']=unknown
rejections=0
for cert in certs:
    bad=copy.deepcopy(cert);bad['model']['P'][0]='999'
    try:check(bad)
    except (ValueError,KeyError):rejections+=1
    else:raise AssertionError('Hash corruption accepted')
    bad=copy.deepcopy(cert);bad['tree']={'equation':-1}
    try:check(bad)
    except (ValueError,KeyError):rejections+=1
    else:raise AssertionError('Invalid leaf accepted')
    bad=copy.deepcopy(cert);bad['tree']={'split':0,'left':{'equation':0}}
    try:check(bad)
    except (ValueError,KeyError):rejections+=1
    else:raise AssertionError('Incomplete cover accepted')
    bad=copy.deepcopy(cert);bad['tree']={'equation':0}
    try:check(bad)
    except (ValueError,KeyError):rejections+=1
    else:raise AssertionError('Nonexcluding root accepted')
report['corrupt_certificate_rejections']=rejections
report['verdict']='PASS'
report['not_computed']=['Quantitative weak-attachment thresholds','Quantitative frequency-separation thresholds',
 'All-topology high-budget interval-cover searches','A new explicit high-degree point minimum certificate',
 'Lean formalization','Independent external review','Historical novelty']
(ROOT/'results'/'CHECKS.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
