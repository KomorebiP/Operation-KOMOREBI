"""Small exact box-cover refuter and checker. Author: Komorebi P.

The complete mathematical scheme is described in docs/THEOREMS.md. This
prototype does NOT execute the global high-budget searches in that theorem.
"""
from fractions import Fraction as F
import hashlib, json

# Sparse polynomial: tuple of variable indices (repetition allowed) -> Fraction.
def add(p,q):
    out=dict(p)
    for m,c in q.items():
        out[m]=out.get(m,F(0))+c
        if not out[m]: del out[m]
    return out

def scale(p,c): return {m:v*F(c) for m,v in p.items() if v*c}
def mul(p,q):
    out={}
    for a,c in p.items():
        for b,d in q.items():
            m=tuple(sorted(a+b)); out[m]=out.get(m,F(0))+c*d
    return {m:c for m,c in out.items() if c}
def constant(c): return {():F(c)} if c else {}
def var(i): return {(i,):F(1)}
def polyval(p,s):
    z=F(0)
    for c in reversed(p): z=z*s+F(c)
    return z

def build_system(model):
    n=int(model['nodes']); edges=model['edges']; P=list(map(F,model['P'])); Q=list(map(F,model['Q']))
    ss=list(map(F,model['samples']))
    if n<2 or not ss or len(set(ss))!=len(ss) or min(ss)<=0: raise ValueError('Invalid model')
    bounds=[(F(0),F(1)) for _ in edges]; names=[f't_{j}' for j in range(len(edges))]; eq=[]
    for z,s in enumerate(ss):
        p,q=polyval(P,s),polyval(Q,s)
        if not q or p/q<=0: raise ValueError('Target not strictly positive at sample')
        vp=p/(p+q); ip=q/(p+q)
        vs=[constant(0),constant(vp)]
        for u in range(2,n):
            vs.append(var(len(bounds))); bounds.append((F(0),F(1))); names.append(f'v_{z}_{u}')
        ins=[]
        for j in range(len(edges)):
            ins.append(var(len(bounds))); bounds.append((F(-1),F(1))); names.append(f'i_{z}_{j}')
        bal=[{} for _ in range(n)]
        for j,(kind,u,v) in enumerate(edges):
            if kind not in ('R','L','C') or not 0<=u<n or not 0<=v<n or u==v: raise ValueError('Bad edge')
            t=var(j); dv=add(vs[u],scale(vs[v],-1))
            f=F(1) if kind=='R' else (s if kind=='C' else 1/s)
            eq.append(add(mul(add(constant(1),scale(t,-1)),ins[j]),scale(mul(t,dv),-f)))
            bal[u]=add(bal[u],ins[j]); bal[v]=add(bal[v],scale(ins[j],-1))
        for u in range(1,n): eq.append(add(bal[u],constant(-ip if u==1 else 0)))
    return {'bounds':bounds,'names':names,'equations':eq}

def interval(p,box):
    lo=hi=F(0)
    for mon,c in p.items():
        a=b=c
        for j in mon:
            x,y=box[j]; choices=(a*x,a*y,b*x,b*y); a,b=min(choices),max(choices)
        lo+=a; hi+=b
    return lo,hi

def fingerprint(model):
    return hashlib.sha256(json.dumps(model,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def exclusion(equations,box):
    for i,p in enumerate(equations):
        a,b=interval(p,box)
        if a>0 or b<0: return i
    return None

def search(model,max_nodes=20000):
    system=build_system(model); count=0; leaves=0; maxdepth=0
    class Budget(Exception): pass
    def rec(box,depth):
        nonlocal count,leaves,maxdepth
        count+=1; maxdepth=max(maxdepth,depth)
        if count>max_nodes: raise Budget()
        e=exclusion(system['equations'],box)
        if e is not None: leaves+=1; return {'equation':e}
        j=max(range(len(box)),key=lambda i:box[i][1]-box[i][0])
        a,b=box[j]; mid=(a+b)/2
        if a==b: raise Budget()
        left=list(box); right=list(box); left[j]=(a,mid); right[j]=(mid,b)
        return {'split':j,'left':rec(left,depth+1),'right':rec(right,depth+1)}
    try:
        tree=rec(system['bounds'],0)
    except (Budget,RecursionError):
        return {'status':'UNKNOWN','nodes':count,'completed_leaves':leaves,'max_depth':maxdepth}
    cert={'schema':'komorebi-compact-cover-v1','model':model,'model_sha256':fingerprint(model),'tree':tree}
    check(cert)
    return {'status':'CERTIFIED_INFEASIBLE','nodes':count,'leaves':leaves,'max_depth':maxdepth,'certificate':cert}

def check(cert):
    if cert.get('schema')!='komorebi-compact-cover-v1': raise ValueError('Wrong schema')
    model=cert['model']
    if cert.get('model_sha256')!=fingerprint(model): raise ValueError('Model hash mismatch')
    system=build_system(model); nodes=leaves=0
    def rec(t,box,depth):
        nonlocal nodes,leaves
        nodes+=1
        if depth>1000 or nodes>2000000: raise ValueError('Checker resource cap')
        if set(t)=={'equation'}:
            i=t['equation']
            if type(i) is not int or not 0<=i<len(system['equations']): raise ValueError('Bad equation')
            a,b=interval(system['equations'][i],box)
            if a<=0<=b: raise ValueError('Leaf does not exclude zero')
            leaves+=1; return
        if set(t)!={'split','left','right'}: raise ValueError('Incomplete cover')
        j=t['split']
        if type(j) is not int or not 0<=j<len(box): raise ValueError('Bad split')
        a,b=box[j]
        if a==b: raise ValueError('Degenerate split')
        mid=(a+b)/2; left=list(box); right=list(box)
        left[j]=(a,mid); right[j]=(mid,b)
        rec(t['left'],left,depth+1); rec(t['right'],right,depth+1)
    rec(cert['tree'],system['bounds'],0)
    return {'nodes':nodes,'leaves':leaves,'verified':True}
