# Continuity handoff

**Author: Komorebi P.**  
**Checkpoint: smith-rlc-obstruction-propagation-2026-11-12**

## Preserve these distinctions

The original degree-six project target has q_min=6. The all-degree coupled-cubic lifting family has q_min=n. Neither is replaced by the new hard families, which are different targets.

The new results are asymptotic minimum-count theorems with explicit formulas and uncomputed smallness thresholds. Do not promote forward examples with delta=1/100 and epsilon=1/1000 into certified minima. Their JSON records deliberately say the lower bounds at those numeric parameters are not established.

The Hughes degree-two/five-reactive base is prior art. New arithmetic replay is not a new lower-bound discovery.

## Mathematical restart point

Read docs/THEOREMS.md in this order: Lemmas 1–4; endpoint path/cut table; Lemma 5; Theorems 2–4; application in Section 8. The critical proof mechanisms are:

1. Arbitrary resistor counts can be eliminated to at most 2q+2 vertices without touching reactive endpoints.
2. At positive real Laplace samples, the Robin normalization V+I=1 bounds every potential and branch current.
3. Compact coefficient endpoints are literal open/short branches, not transformers.
4. A disappearing endpoint pole/zero forces an actual reactive branch to contract/delete.
5. The same physical reactive branch can survive with finite positive value at only one separated frequency scale.

## Next mathematical and engineering work

The highest-value next step is an independent audit of these universal arguments. In particular, challenge the common fixed-skeleton extraction, the endpoint graph implications after resistor Kron reduction, and the treatment of unused/self-loop reactive slots after contraction.

Then implement endpoint-constrained compact systems and seek an actual rational smallness threshold for the Hughes shunt-LC localization against budget six. Use symmetry, cut/path restrictions, exact linear elimination, and sparse equations. Do not start by treating the full dense all-topology problem as a routine numerical optimizer task.

The next deliverable should be a named rational delta with a complete six-budget exclusion certificate, plus its seven-reactive forward circuit. That would turn the new degree-four family theorem into a concrete new point-minimality certificate. Until it is done, keep the theorem/point distinction explicit.

After a certified profile is fixed, repeat at two scales against budget thirteen to get a concrete degree-eight, fourteen-reactive exact minimum. The separation theorem proves that a threshold exists, not that a practical search is already available.

The current interval kernel returns UNKNOWN on budget exhaustion. Its only completed global covers here are q=0 unit tests. Never relabel them as nontrivial Hughes or general lower-budget certificates.

## Reproduce

Run `python -S tests/run_checks.py`. Read results/CHECKS.json. No external Python packages are needed. All acceptance calculations use Fraction arithmetic. No files in the earlier release are overwritten.
