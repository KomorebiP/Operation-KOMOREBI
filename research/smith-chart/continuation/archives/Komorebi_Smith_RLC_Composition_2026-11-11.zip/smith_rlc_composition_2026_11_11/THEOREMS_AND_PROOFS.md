# Mathematical statements and proof map

**Author: Komorebi P.**  
**Date:** November 11, 2026.

## T1. Exact interval circuit certification

For a finite connected positive uncoupled RLC graph, construct all coefficients of `Q*N-P*D` from its tree and separating-forest polynomials. Append any explicitly fixed component constraints. If the square full system admits a positive rational box and invertible rational preconditioner satisfying strict self-mapping and weighted contraction, there is exactly one exact real root of the declared system in the box. It realizes the complete target impedance.

Proof: `reports/INTERVAL_CHECKER_NOTES.md`. Independent audit: `reports/INTERVAL_INDEPENDENT_AUDIT.md`. Exact acceptance code: `src/interval_certificate.py`. The core and audit source hashes are recorded in those files.

## T2. Degree equality proves global reactive minimality

For any competing graph with q reactive elements, multiplying every tree and forest admittance term by `s^(number of inductors)` gives polynomial degrees between zero and q. Reduction cannot increase degree. A reduced degree-n target therefore needs at least n reactive elements. A certified realization with q=n is minimum reactive within the stated physical class, independently of how restricted the search that found it was.

The conclusion is about reactive count. It does not claim minimum total elements, a universal n-reactive synthesis theorem, or uniqueness across topologies. The proof is included in both T1 records.

## T3. Explicit seven-dimensional cubic neighborhood

For every real normalized coefficient vector in the exact box of `certificates/local_family_case_1.json`, the specified seven-branch graph has a unique positive component root inside the common component box and minimum reactive count three. The proof uses the joint fourteen-variable coefficient equations and a uniform Sylvester nonsingularity bound, preserving exact degree throughout the box.

Full statement, exact center/radii, uniform inequalities and independent derivation: `reports/FAMILY_INDEPENDENT_AUDIT.md`. Checker: `src/interval_family.py`. This theorem concerns one explicit local family.

## T4. Exact origin-pole sufficient family

For positive rational A, B, C, D, E, kappa, assume

\[
F=D-CB/A>0,\qquad \Delta=AE-BF>0.
\]

Then

\[
Z(s)=\kappa/s+s(A+Bs)/(C+Ds+Es^2)
\]

has a positive five-element realization with three reactive elements, using

\[
C_0=1/\kappa,\ L=A/C,\ R_s=B/E,\ R_p=\Delta/(EF),\ C_1=E^2/\Delta.
\]

The proof establishes the identity and absence of cancellation, so the degree is three and reactive count three is globally minimum. The concrete repaired target uses `(C0,L,Rs,Rp,C1)=(4/5,7,10/7,6/35,147/16)`.

Proof: `reports/BOUNDARY_ROUTE.md`. Independent audit: `reports/BOUNDARY_INDEPENDENT_AUDIT.md`. Symbolic and independent nodal evidence: `experiments/prior_boundary_audit.json`.

## T5. Proof-carrying composition across independent parameter contexts

A finite expression built from independently verified algebraic or interval circuit leaves, strictly positive rational R/L/C elements, series composition, parallel composition and frequency inversion realizes the rational impedance rebuilt from its expression. Every leaf occurrence has separate internal node labels and its own algebraic field or interval-root context. Series gluing identifies only successive terminals; parallel gluing identifies only the two external terminals. Frequency inversion exchanges inductive and capacitive admittance types on the same graph and reverses both target polynomials after padding to a common degree.

The exact checker verifies each leaf, reconstructs the complete graph, reduces every scalar impedance identity, binds the result to the requested target, and counts every physical reactive branch occurrence. A successful certificate establishes a positive realization. It establishes global minimum reactive count only when the actual count equals the final reduced target degree, by T2. A cancellation or duplicate physical branch cannot silently produce a minimum claim.

Proof and wire-format scope: `reports/COMPOSITION_THEOREM.md`. Independent mathematical and graph-nodal audit: `reports/COMPOSITION_INDEPENDENT_AUDIT.md`. Acceptance kernel: `src/composition_certificate.py`. Unsupported reciprocal graph operations are absent. The constructor enforces the reader's resource limits on its output; an independently detected large-coefficient portability failure and its narrow correction are retained in the frozen history.

## T6. Full-dimensional coupled-core families at every degree

For coprime real P,Q of degree n, with Q monic and positive leading numerator coefficient, and for positive real g,L, set

\[
N=P+sLQ,\qquad D=Q+gN.
\]

Then N,D are coprime of degree n+1. The physical transformation is a series inductor L followed by a shunt resistor 1/g. In monic-denominator target coordinates U,V, define

\[
g=1/U_{n+1},\quad H=V-gU,\quad h=H_n>0,
\quad L=U_{n+1}/h,\quad K=U-sLH.
\]

The additional strict condition K_n>0 gives the open image chart, and the inverse is P=K/h, Q=H/h. These exact forward and inverse formulas give a rational diffeomorphism, including n=0.

Iterating from the interior of T3's certified real coefficient box produces, for every n>=3, a nonempty open family of full normalized coefficient dimension 2n+1. Each target has a positive realization with n-1 inductors, one capacitor and n+1 resistors. Its global minimum reactive count is n. This universal family statement is proved by exact algebra and induction, not inferred from the finite tests.

Full proof and parameter-domain conditions: `reports/COUPLED_CORE_LIFT_THEOREM.md`. Separate independent review: `reports/COMPOSITION_INDEPENDENT_AUDIT.md`. Exact finite implementation controls: `experiments/coupled_core_lift_audit.json`. The all-real theorem is distinct from the bounded point-certificate API, which currently serializes rational wrapper values and existing exact point leaves.

## Preserved prior results

The image cubic and its exact endpoint/Cauer decomposition are retained in `certificates/image_baseline_cubic.json`. The original degree-six six-reactive certificate is retained in `experiments/prior_seed/`, with fresh replay and status reconciliation in `reports/PRIOR_STATE_AUDIT.md`.

Earlier proofs remain unchanged in `history/previous_checkpoint_docs/THEOREMS_AND_PROOFS.md` and the original checkpoint ZIP. They are history, not substitutes for the current statement map.

## Proof and novelty status

T1 through T6 have explicit derivations and independent mathematical/code reviews in their stated scope. Finite tests support implementation correctness in their recorded ranges. The uniform conclusions rely on the proofs and exact inequalities. Historical originality was not investigated in this continuation, and no publication-priority claim is attached to classical extraction, interval contraction, composition or graph-determinant methods.
