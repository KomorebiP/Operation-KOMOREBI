# Historical snapshot map

The full immediate parent is present both as its original ZIP and as `interval_checkpoint/`. Its original package inventory and release manifest are interpreted relative to that snapshot root. Older archives and the previous cubic frozen experiment remain inside it unchanged.

`frozen_composition_validation/` preserves the first fourteen-case target-only discovery run at composition checker hash `1aa31c10cead9b2da925b2637a84fe9dde4240aad313a72024c4333f25f39ba9`. Its `computations/composition_validation_001/manifest.json` is a valid v2 evidence record when checked against that frozen root. It includes all declared execution inputs, the independently generated target data and the source-core files needed by the retained generator.

The initial independent audit JSON in that frozen directory is a **historical failed audit record**, SHA256 `e52916364cc719de5517f29bfde21521342177b6e20c389117253ed83980f260`. It records the constructor portability failure. Although it declares schema_version2, it also has original provenance-schema limitations (unavailable Git dirty value and no hashed report output), so it is not a validator-valid v2 manifest. Its original bytes and complete pinned input closure are retained; do not repair history in place.

The final corrected audit at the project root is a validator-valid v2 record and passes its mathematical/implementation checks. Current release evidence is under the project root's `computations/composition_release_001/`. Frozen validation and current replay are distinct records.

At the project root, `BASE_COMPOSITION_CHECKPOINT.json` identifies this continuation's immediate parent. `BASE_CHECKPOINT.json` is retained inherited ancestry for the preceding interval stage; it does not identify the current checkpoint. `CONTINUITY.json` gives the current state.
