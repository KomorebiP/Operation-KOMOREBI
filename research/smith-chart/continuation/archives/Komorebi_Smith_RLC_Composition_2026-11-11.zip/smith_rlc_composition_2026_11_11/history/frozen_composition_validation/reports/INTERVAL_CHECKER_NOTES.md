# Exact component boxes for the RLC solver

**Author: Komorebi P.**  
**Research date:** November 11, 2026.  
**Status:** An internal proof and a standard-library exact checker, with finite implementation controls. The proof does not depend on numerical optimizer accuracy. No claim of a new general interval theorem or publication priority is made.

## 1. Target contract

The admissible circuit is a finite connected graph of strictly positive, uncoupled, lumped resistors, inductors and capacitors. It has no transformer, dependent source, mutual inductance or other component type. Node 0 is ground and node 1 is the input. Other node labels need not be consecutive. Different component types may be parallel. Duplicate branches of the same type and endpoints are rejected and must be merged before certification.

In the supplied branch order, the real unknowns are

\[
x_j=g_j=1/R_j,\qquad x_j=h_j=1/L_j,\qquad x_j=c_j=C_j.
\]

Each branch has its own variable. The target is a nonzero rational impedance \(P(s)/Q(s)\). Its coefficients are exact rational numbers in ascending powers. The checker cancels the rational polynomial gcd and makes \(Q\) monic before constructing equations. Thus scaled and unreduced descriptions of the same rational target are accepted, while a different impedance fails external target binding.

Let \(q\) be the number of listed inductors and capacitors, and let

\[
n=\max(\deg P,\deg Q)
\]

after reduction. The certificate must prove an exact positive component vector that realizes this entire rational function. An optimizer residual, a rounded component vector or a finite frequency fit is insufficient.

The present format requires a square system. It retains **every** one of the \(n+q+1\) impedance coefficient equations. If there are additional branch variables, the certificate may supply exact fixed-parameter constraints. These constraints are appended and never replace impedance equations. A seven-branch cubic chart uses seven coefficient equations. An eight-branch cubic chart can use those seven equations and one explicit fixed component parameter.

## 2. Graph identity reconstructed by the checker

Write \(v\) for the number of vertices. Choose an arbitrary orientation of each branch and let \(B\) be its vertex-edge incidence matrix. For a positive real Laplace argument \(s\), the branch admittances are

\[
y_j(s)=x_j s^{e_j},\qquad
e_j=0\text{ for }g,\quad e_j=-1\text{ for }h,\quad e_j=1\text{ for }c.
\]

Delete the ground row of \(B\), giving \(B_0\). The grounded nodal matrix is

\[
M(s)=B_0\operatorname{diag}(y_j(s))B_0^{\mathsf T}.
\]

For every nonzero grounded potential vector \(u\),

\[
u^{\mathsf T}M(s)u=\sum_j y_j(s)(u_{a_j}-u_{b_j})^2>0.
\]

Here the ground potential is zero. Equality would make the potential constant on every edge, and connectivity would force every potential to zero. Consequently \(M(s)\) is invertible for every positive \(s\). Under a unit input current, elementary cofactor inversion gives

\[
Z(s)=\frac{\det M_{\widehat{1},\widehat{1}}(s)}{\det M(s)}.
\]

### Exact tree and forest expansions

For completeness, the combinatorial formulas used in the code follow directly from determinant expansion. If \(U\) is a set of retained incidence rows, expanding the determinant of \(B_U\operatorname{diag}(y)B_U^{\mathsf T}\), and grouping terms by the selected columns, gives

\[
\det(B_U\operatorname{diag}(y)B_U^{\mathsf T})
=\sum_{|S|=|U|}\det(B_{U,S})^2\prod_{j\in S}y_j.
\]

The squared minor is zero if the selected edges contain a cycle, since the oriented cycle gives dependent columns. It is also zero if a connected component contains no deleted row: the sum of its retained incidence rows vanishes. When the selected edges form a forest and every component has exactly one deleted row, orienting each tree away from that root and deleting leaves successively shows that the minor is \(+1\) or \(-1\). The empty minor is 1.

With only row 0 deleted, the surviving subsets are exactly spanning trees. With rows 0 and 1 deleted, the surviving subsets are exactly spanning forests with two components, separating 0 and 1. This proves the formulas without treating a solver-supplied polynomial as evidence.

Let \(\ell\) be the number of inductors. The checker enumerates these edge subsets and constructs

\[
D(s,x)=s^{\ell}\sum_{T\text{ spanning tree}}\prod_{j\in T}x_js^{e_j},
\]

\[
N(s,x)=s^{\ell}\sum_{F\text{ two-root forest}}\prod_{j\in F}x_js^{e_j}.
\]

The power of \(s\) in any term is

\[
\ell-\#\{\text{selected inductors}\}
 +\#\{\text{selected capacitors}\},
\]

which lies between 0 and \(q\). Thus \(N,D\) are ordinary polynomials of degree at most \(q\). On every positive component box, \(D(s,x)>0\) for \(s>0\), and the exact circuit impedance is \(N/D\).

The checker constructs the full list

\[
F_k(x)=[s^k]\bigl(Q(s)N(s,x)-P(s)D(s,x)\bigr),
\qquad 0\le k\le n+q.
\]

The graph compiler retains structurally zero equations too. It cannot quietly choose a convenient subset. At a common zero, the full polynomial identity holds. Since \(D\) is not the zero polynomial, that identity proves \(Z=P/Q\) as rational functions. No pole-factorization assumption is used.

## 3. Exact root existence inside a rational box

This section applies to the full square system, including any declared constraints \(x_i-a_i=0\). Let its number of variables and equations be \(m\). The certificate supplies rational data

\[
c\in\mathbb Q^m,\qquad r_i>0,\qquad
X=\prod_i[c_i-r_i,c_i+r_i],\qquad
Y\in\mathbb Q^{m\times m}.
\]

The checker requires \(c_i-r_i>0\) and proves that \(Y\) is nonsingular by exact rational elimination. It rebuilds \(F\) and its symbolic derivative from the graph. Define

\[
T(x)=x-YF(x),\qquad
d_i=|(YF(c))_i|.
\]

For every derivative entry, it constructs the polynomial

\[
H_{ij}(x)=\delta_{ij}-\sum_kY_{ik}\partial_jF_k(x)
\]

**before** interval evaluation, preserving exact algebraic cancellation. Natural interval arithmetic with rational endpoints then supplies

\[
b_{ij}\ge\sup_{x\in X}|H_{ij}(x)|.
\]

Products, integer powers, signed coefficients and sums are enclosed using exact fractions. There is no floating-point rounding in the acceptance calculation.

The two acceptance inequalities are

\[
\lambda=\max_i\frac{\sum_jb_{ij}r_j}{r_i}<1,
\]

\[
d_i+\sum_jb_{ij}r_j<r_i\qquad\text{for every }i.
\]

### Proof of the accepted conclusion

The box is convex. Integrating the derivative along the segment between two points gives, in the weighted norm \(\|u\|_r=\max_i|u_i|/r_i\),

\[
\|T(x)-T(z)\|_r\le\lambda\|x-z\|_r.
\]

Applying the same bound from \(c\), together with the second inequality, shows that \(T(X)\) lies strictly inside \(X\). Start the iteration at \(x_0=c\). Every iterate remains in \(X\), and successive differences are bounded by a geometric sequence with ratio \(\lambda<1\). Therefore the iterates are Cauchy. The closed box is complete, so they converge to a point \(x_*\in X\). Continuity gives \(T(x_*)=x_*\). Nonsingularity of \(Y\) implies \(F(x_*)=0\).

Two such roots in \(X\) would be fixed points whose distance is at most \(\lambda\) times itself, so their distance must be zero. The root is unique in the box for the **entire declared system**, including any fixed-parameter equations. There may be other circuit roots outside the box, or other roots in the box when fixed-parameter constraints are omitted.

All branch values at \(x_*\) are strictly positive. The preceding graph identity proves that this exact circuit realizes the target. The root generally differs from \(c\). The rational endpoints and the fixed-point construction specify exact real component values through unique isolation, without requiring a minimal polynomial for a primitive algebraic element.

The checker reports exact rational contraction bounds, center corrections, self-mapping margins and intervals for \(g,h,c\). Resistance and inductance intervals are obtained by reversing and reciprocating their positive endpoints. The certificate directly encloses conductance and inverse inductance, not resistance and inductance themselves.

## 4. Global reactive minimum when q equals n

The same tree and forest argument applies to every finite connected positive network in the stated physical class, with any number of resistors or internal vertices. If it has \(q'\) reactive branches, its impedance has numerator and denominator degree at most \(q'\) before cancellation. Cancellation cannot increase the degree. Hence every realization of a reduced degree-\(n\) target has \(q'\ge n\).

An accepted circuit with exactly \(q=n\) therefore attains this lower bound. Its reactive count is globally minimum within the physical class, even though the solver searched only a few topologies. This argument does **not** claim minimum resistor count, minimum total component count, uniqueness across topologies or efficient universal synthesis.

If \(q>n\), the certificate proves a positive realization and a local isolated root, but does not prove global reactive minimality. The checker sets `global_minimum_proved_by_degree` only when the actual branch count equals the reduced target degree.

## 5. Implementation interface

`src/interval_certificate.py` imports only standard-library modules plus the package's standard-library exact polynomial routines. Its acceptance path does not import NumPy, SciPy, SymPy, an SMT solver or the numerical proposal code.

| Function | Contract |
|---|---|
| `graph_polynomials(branches)` | Rebuild tree and rooted-forest coefficients from the physical graph. |
| `build_coefficient_system(branches,P,Q,fixed_parameters=None)` | Rebuild all cross-product coefficient equations, then append declared fixed-parameter equations. |
| `evaluate_polynomial(poly,values)` | Exact evaluation of an exponent-tuple sparse polynomial. |
| `evaluate_system(system,values)` | Exact vector evaluation. |
| `evaluate_jacobian(system,values)` | Exact derivative matrix evaluation. |
| `interval_evaluate_polynomial(poly,intervals)` | Rational interval enclosure. |
| `invert_matrix(matrix)` | Exact rational inversion, rejecting singularity. |
| `verify_interval_circuit(cert,expected_target=None,expected_budget=None)` | Rebuild and verify the certificate and optional external bindings. |

The `variables` system field is the integer dimension \(m\). Polynomials map length-\(m\) tuples of nonnegative exponents to `Fraction` coefficients. The numerator and denominator fields are ascending lists of these polynomials. The `coefficient_equation_count` excludes fixed constraints, while the `equations` list includes them.

The certificate format is `komorebi-rlc-interval-v1`. It contains `target`, `storage_budget`, ordered `branches`, `center`, `radii`, and the square `preconditioner`. Each branch has exactly `type` and `nodes`. Optional `fixed_parameters` is a list of distinct `{index,value}` records. Indices refer to the branch order, and values must be strictly positive exact rationals. Other top-level metadata is not trusted as mathematical evidence. A supplied `equations` field cannot change the compiler's equations.

For application acceptance, callers should bind the certificate to the requested target and budget explicitly. A standalone replay can certify the target stated inside the certificate, which does not by itself establish that a separate user request named that same target.

The current exact compiler limits the branch count to 20 and the total candidate tree/forest subsets to 200,000. Exceeding these implementation limits is a failure to check with this implementation, never an impossibility result.

## 6. Observed implementation checks

Command:

```bash
python3 src/test_interval_core.py
```

The completed run passed **41 test groups**, comprising eight positive groups and 33 malformed or corrupted evidence controls. The positive groups include:

* An off-center one-resistor example with exact correction \(1/100\), radius \(1/50\), contraction zero and positive self-mapping margin \(1/100\).
* A four-branch degree-one RC chart with all three impedance coefficient equations and one fixed shunt conductance. It certifies an actual one-reactive minimum.
* Sixteen connected mixed graphs on two to five vertices, including nonconsecutive labels and parallel types. Tree/forest impedance equals an independently implemented direct KCL solve at four exact positive samples per graph, for 64 exact comparisons.
* All 49 entries of a seven-variable cubic Jacobian, compared with an exact finite-difference identity valid for its polynomial degree.
* Replay of the parent's `historical_case_1.json` interval certificate.
* Signed interval-power enclosure checks across zero, including even and odd powers.
* Exact target binding under scaling and removable common factors.
* Confirmation that a supplied alleged equation payload cannot alter the rebuilt system.

The 33 controls reject wrong targets, insufficient or mismatched budgets, singular or wrongly signed preconditioners, nonpositive boxes, zero/negative radii, floating-point and boolean rational inputs, malformed nodes, duplicate branches, disconnected material, overlarge boxes, non-square systems and invalid or incompatible fixed constraints. Strict self-mapping equality at the boundary is rejected.

These are finite implementation checks. They do not constitute exhaustive topology testing and are not substituted for the proofs above. Review provenance is self-review of this new kernel plus the orthogonal nodal and derivative calculations. A later independent review should be recorded separately.

### Pinned inputs for this run

Base archive: `Komorebi_RLC_General_Solver_Continuation_2026-11-11.zip`  
Base SHA256: `a7062b55396452139b017d361e690fec70ce21da580150893ce1ea817a38d4f9`

| Input | SHA256 |
|---|---|
| `src/interval_certificate.py` | `538da6d3c897554c2468b3c8c10508d2505374c4e9a007dcf110aa408c711de1` |
| `src/test_interval_core.py` | `76d58a218ddf7658b581a884526767e5f49b60e427de6b17f63089c673a74af7` |
| `src/real_algebraic.py` | `7a32375fc115c63bebc505c2b93eaa817b72dc9a093c49da9c664c40b0bb7c57` |
| `src/exact_polynomials.py` | `d94e61424ecc82cb2489c358de45de460c76b3529926c01036ba5ea66918e2a6` |
| `certificates/historical_case_1.json` | `a750210a7d1d4781c45eaaa7b9b539f6b443db38ff77956008a3f58a454bc4f3` |

The test command prints its current input hashes and detailed pass/rejection names, so replay after an edit distinguishes new evidence from this recorded snapshot.

## 7. Continuation boundary

This checker removes the requirement that every proposed component value reconstruct to a small rational. It can certify an isolated positive real solution whenever a rational box and preconditioner pass the exact inequalities. It does not guarantee that the numerical proposal process finds such a box, nor that a chosen topology contains the target.

Further useful work includes better topology selection, parameter scaling, wider boxes with sharper polynomial interval bounds, and uniform target neighborhoods. Any such extension must preserve all coefficient equations, external target binding and exact acceptance. A failure of the interval inequalities leaves the circuit search unresolved.

## Current checkpoint cross-references

Independent review is now recorded in `reports/INTERVAL_INDEPENDENT_AUDIT.md`. The uniform target-neighborhood extension mentioned above is implemented and certified for the explicit seven-dimensional family in `reports/FAMILY_INDEPENDENT_AUDIT.md`. These later records preserve the kernel and proof scopes stated here.
