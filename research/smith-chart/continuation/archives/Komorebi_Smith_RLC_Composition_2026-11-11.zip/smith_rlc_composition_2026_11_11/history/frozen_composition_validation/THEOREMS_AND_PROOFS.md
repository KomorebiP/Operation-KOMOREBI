# Mathematical statements and proof map

**Author: Komorebi P.**  
**Date:** November 11, 2026.

## T1. Exact interval circuit certification

For a finite connected positive uncoupled RLC graph, construct all coefficients of `Q*N-P*D` from its tree and separating-forest polynomials. Append any explicitly fixed component constraints. If the square full system admits a positive rational box and invertible rational preconditioner satisfying strict self-mapping and weighted contraction, there is exactly one exact real root of the declared system in the box. It realizes the complete target impedance.

Proof: `reports/INTERVAL_CHECKER_NOTES.md`. Independent audit: `reports/INTERVAL_INDEPENDENT_AUDIT.md`. Exact acceptance code: `src/interval_certificate.py`. The core and audit source hashes are recorded in those files.

## T2. Degree equality proves global reactive minimality

For any competing graph with q reactive elements, multiplying every tree and forest admittance term by `s^(number of inductors)` gives polynomial degrees between zero and q. Reduction cannot increase degree. A reduced degree-n target therefore needs at least n reactive elements. A certified realization with q=n is minimum reactive within the stated physical class, independently of how restricted the search that found it was.

The conclusion is about reactive count. It does not claim minimum total elements, a universal n-reactive synthesis theorem, or uniqueness across topologies. The proof is included in both T1 records.

## T3. Explicit seven-dimensional cubic neighborhood

For every real normalized coefficient vector in the exact box of `certificates/local_family_case_1.json`, the specified seven-branch graph has a unique positive component root inside the common component box and minimum reactive count three. The proof uses the joint fourteen-variable coefficient equations and a uniform Sylvester nonsingularity bound, preserving exact degree throughout the box.

Full statement, exact center/radii, uniform inequalities and independent derivation: `reports/FAMILY_INDEPENDENT_AUDIT.md`. Checker: `src/interval_family.py`. This theorem concerns one explicit local family.

## T4. Exact origin-pole sufficient family

For positive rational A, B, C, D, E, kappa, assume

\[
F=D-CB/A>0,\qquad \Delta=AE-BF>0.
\]

Then

\[
Z(s)=\kappa/s+s(A+Bs)/(C+Ds+Es^2)
\]

has a positive five-element realization with three reactive elements, using

\[
C_0=1/\kappa,\ L=A/C,\ R_s=B/E,\ R_p=\Delta/(EF),\ C_1=E^2/\Delta.
\]

The proof establishes the identity and absence of cancellation, so the degree is three and reactive count three is globally minimum. The concrete repaired target uses `(C0,L,Rs,Rp,C1)=(4/5,7,10/7,6/35,147/16)`.

Proof: `reports/BOUNDARY_ROUTE.md`. Independent audit: `reports/BOUNDARY_INDEPENDENT_AUDIT.md`. Symbolic and independent nodal evidence: `experiments/prior_boundary_audit.json`.

## Preserved prior results

The image cubic and its exact endpoint/Cauer decomposition are retained in `certificates/image_baseline_cubic.json`. The original degree-six six-reactive certificate is retained in `experiments/prior_seed/`, with fresh replay and status reconciliation in `reports/PRIOR_STATE_AUDIT.md`.

Earlier proofs remain unchanged in `history/previous_checkpoint_docs/THEOREMS_AND_PROOFS.md` and the original checkpoint ZIP. They are history, not substitutes for the current statement map.

## Proof and novelty status

T1 through T4 have explicit derivations and independent mathematical/code reviews. Finite tests support implementation correctness in their recorded ranges. The uniform conclusions rely on the proofs and exact inequalities. Historical originality was not investigated in this continuation, and no publication-priority claim is attached to classical extraction, interval contraction or graph-determinant methods.
