# Independent audit of the uniform cubic family certificate

**Author: Komorebi P.**  
**Review date:** November 11, 2026, America/Chicago  
**Review provenance:** Independent delegated derivation from raw source, the exact certificate and the physical graph definition.  
**Primary verdict:** Proved as written for the specified closed coefficient box and component box.

## Exact claim

Write a normalized cubic target as

\[
P_y(s)=y_0+y_1s+y_2s^2+y_3s^3,\qquad
Q_y(s)=y_4+y_5s+y_6s^2+s^3.
\]

For **every real vector** \(y\) in the certificate's seven-dimensional closed target box, the specified seven-branch graph has exactly one component vector in the specified positive component box whose impedance is \(P_y/Q_y\). Every one of these targets has reduced degree three, and its global minimum reactive count is three.

The graph has two inductors, one capacitor and four resistors. The uniqueness statement is restricted to its component box. It is not uniqueness over all graphs.

The target-box center is

\[
a=\left(
\frac{75}{868},\frac{45}{124},\frac{597}{434},\frac{60}{31},
\frac{25}{248},\frac{405}{868},\frac{913}{868}
\right).
\]

Its radii, in that order, are

\[
\rho=\left(
10^{-10},10^{-10},\frac{597}{4340000000000},
\frac{3}{15500000000},10^{-10},10^{-10},
\frac{913}{8680000000000}
\right).
\]

All seven radii are positive, so the box includes a nonempty open subset of the normalized coefficient space.

## Audited revision and evidence

Source `src/interval_family.py` SHA256:

```text
81772b2a1a25fc3651013ced311d984fbce1c0647833c9dcfb2beadbf9dca52e
```

Certificate `certificates/local_family_case_1.json` SHA256:

```text
28d096fa089bb550208f7dc7e5eede622d4cdf9704210088447c99e5f2899ffe
```

The graph compiler initially reviewed with this source had SHA256 `538da6d3c897554c2468b3c8c10508d2505374c4e9a007dcf110aa408c711de1`. Exact before/after hashes, raw rational results and the replay command are in `experiments/prior_independent_audit.json`.

The fresh replay passed with a uniform contraction bound approximately 0.243341 and minimum strict self-map margin above \(7.3\times10^{-6}\). The uniform center correction is below \(2.583\times10^{-7}\). These displayed decimal bounds are summaries only; the checker performs no floating-point acceptance decisions.

## Reconstructed uniform proof

The compiler constructs all seven coefficients of

\[
F(x,y)=Q_y(s)N(s,x)-P_y(s)D(s,x).
\]

They are polynomials in fourteen variables: the seven component parameters and seven target coefficients. The target coordinates are not treated as a finite sample set.

Fix any real \(y\) in its target box. On the common component box define

\[
T_y(x)=x-YF(x,y).
\]

The checker evaluates the entire interval for \(YF(c,y)\) with \(x=c\) and all target coordinates varying. It also bounds every component derivative of \(I-YD_xF(x,y)\) over the joint component and target box. Since these interval bounds contain every real choice in both boxes, the same strict self-map and contraction inequalities apply to this arbitrary fixed \(y\).

The fixed-point argument yields one and only one root \(x(y)\) in the common component box. Positivity and the rebuilt full graph identity then prove exact physical realization. As the argument begins with an arbitrary real \(y\), it proves the universal real-coefficient statement. Rational verification arithmetic does not restrict the quantifier to rational targets.

## Degree preservation and minimality

The code independently verifies that every target in the box has coprime cubic numerator and denominator. It constructs the six-by-six coefficient matrix of

\[
(U,V)\longmapsto UP_y+VQ_y,\qquad \deg U,\deg V\le2.
\]

This is the explicit Sylvester map in ascending coefficient order. Let its matrix be \(S(y)\), with \(S(a)\) at the target center. Since its dependence on \(y\) is linear, the checker computes a rational bound on

\[
\|I-S(a)^{-1}S(y)\|_\infty.
\]

The accepted bound is exactly

\[
\frac{211787599}{223125000000000}<10^{-6}.
\]

Therefore every \(S(y)\) is nonsingular. A common factor would give a nonzero kernel vector: divide both cubics by that common factor and use \((U,V)=(Q_y/d,-P_y/d)\), whose degrees are at most two. Hence a common factor is impossible. The positive lower bound on \(y_3\) and fixed denominator leading coefficient one retain both cubic degrees.

Each target thus has reduced rational degree three. The graph realizes it with three physical reactive elements. The universal graph degree bound, independent of the number of resistors or graph topology, excludes a realization with fewer than three reactive elements.

## Obligation matrix

| Obligation | Verdict | Evidence |
|---|---|---|
| Correct normalized coordinate order | Passed | Explicit convention string and independent convolution check |
| All coefficient equations included | Passed | Seven coefficients of the full cross-product |
| Uniform dependence on real target coefficients | Passed | Joint polynomial intervals over all fourteen variables |
| Positive component box | Passed | Strict rational lower bounds |
| Common invertible preconditioner | Passed | Exact rational inversion |
| Uniform contraction and self-map | Passed | Full joint-box derivative and center-correction bounds |
| Exact target realization for each vector | Passed | Fixed-point root plus graph identity |
| Uniform coprimality | Passed | Exact Sylvester norm bound below one |
| Reduced degree and global reactive minimum | Passed | Cubic degrees, coprimality, three-reactive witness |
| Global coverage of cubic positive-real functions | Out of scope | One explicit local family |

## Independent implementation controls

The audit script freshly replayed the family certificate. It compared the joint fourteen-variable polynomial evaluation with separately regenerated fixed-target coefficient equations at three positive rational component fixtures and four target vectors, for twelve comparisons. It also checked the Sylvester matrix against direct polynomial convolution at four target vectors.

A singular preconditioner, enlarged target box, incorrect coordinate convention, wrong storage signature and loss of the leading numerator coefficient were rejected. These finite controls help detect implementation errors. The all-real conclusion rests on the uniform proof above.

## Limits and review freshness

The box is a deliberately small explicit neighborhood. The result does not quantify broad practical coverage, physical component tolerance performance, global solver completeness or historical novelty. It proves existence and a local uniqueness statement, not that all nearby physical realizations must lie in this box.

Any change to the graph compiler, interval arithmetic, joint equation construction, target-coordinate convention or coprimality calculation requires review of the corresponding dependency. Changes confined to proposal generation do not change this proof kernel's mathematical acceptance contract.

