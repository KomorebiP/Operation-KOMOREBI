"""Author: Komorebi P. Independent composition/lift audit controls.

Contract: inspect the rebuilt graph, and solve its grounded nodal equations with
new Fraction or Q(sqrt(2),sqrt(3)) arithmetic. Check q+n+1 positive rational
arguments for each declared finite fixture, together with independent recursive
impedance evaluation and malformed-input controls. The independent arithmetic
does not import the production polynomial, algebraic-field, graph, or nodal
implementations. The production checker is the object under test.

Interval nodes with a provably rational root use that root, never their center.
The inherited cubic interval leaf is replayed and audited by the all-real proof;
it is not replaced by a rational sample of its component box.

The all-real, all-degree claims rest on reports/COMPOSITION_INDEPENDENT_AUDIT.md,
not on this finite test set. No search coverage or historical novelty is tested.

Run from project root: python3 -S experiments/composition_independent_audit.py
Only this script's JSON result is written.
"""
from __future__ import annotations

from copy import deepcopy
from datetime import datetime, timezone
from fractions import Fraction as F
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from composition_certificate import (
    FORMAT, element_node, certificate_node, series_node, parallel_node,
    frequency_invert_node, make_composition, verify_circuit,
)


def check(condition, message):
    if not condition:
        raise AssertionError(message)


def solve(matrix, rhs):
    """Independent exact Gauss-Jordan elimination for F or Quadratic entries."""
    m = [list(row) + [value] for row, value in zip(matrix, rhs)]
    n = len(m)
    check(all(len(row) == n + 1 for row in m), "bad audit matrix dimensions")
    for j in range(n):
        pivot = next((i for i in range(j, n) if m[i][j]), None)
        check(pivot is not None, "singular audit nodal matrix")
        m[j], m[pivot] = m[pivot], m[j]
        z = m[j][j]
        m[j] = [x / z for x in m[j]]
        for i in range(n):
            if i != j and m[i][j]:
                z = m[i][j]
                m[i] = [a - z * b for a, b in zip(m[i], m[j])]
    return [row[-1] for row in m]


class Quadratic:
    """Independent four-dimensional exact field with basis 1,sqrt2,sqrt3,sqrt6."""
    __slots__ = ("coefficients",)

    def __init__(self, value=0):
        if isinstance(value, Quadratic):
            self.coefficients = value.coefficients
        elif isinstance(value, (list, tuple)):
            check(len(value) == 4, "bad audit field vector")
            self.coefficients = tuple(map(F, value))
        else:
            self.coefficients = (F(value), F(0), F(0), F(0))

    def __add__(self, other):
        other = Quadratic(other)
        return Quadratic([a + b for a, b in zip(self.coefficients, other.coefficients)])
    __radd__ = __add__

    def __neg__(self):
        return Quadratic([-a for a in self.coefficients])

    def __sub__(self, other):
        return self + -Quadratic(other)

    def __rsub__(self, other):
        return Quadratic(other) + -self

    def __mul__(self, other):
        other = Quadratic(other)
        out = [F(0)] * 4
        for i, a in enumerate(self.coefficients):
            for j, b in enumerate(other.coefficients):
                shared = i & j
                out[i ^ j] += a * b * (2 if shared & 1 else 1) * (3 if shared & 2 else 1)
        return Quadratic(out)
    __rmul__ = __mul__

    def inverse(self):
        check(bool(self), "division by audit field zero")
        columns = []
        for j in range(4):
            unit = [F(0)] * 4
            unit[j] = F(1)
            columns.append((self * Quadratic(unit)).coefficients)
        return Quadratic(solve([[columns[j][i] for j in range(4)] for i in range(4)],
                               [F(1), F(0), F(0), F(0)]))

    def __truediv__(self, other):
        return self * Quadratic(other).inverse()

    def __rtruediv__(self, other):
        return Quadratic(other) * self.inverse()

    def __bool__(self):
        return any(self.coefficients)

    def __eq__(self, other):
        return self.coefficients == Quadratic(other).coefficients


def polynomial_value(poly, argument):
    result = F(0)
    for a in reversed(poly):
        result = result * argument + F(a)
    return result


def target_value(target, argument):
    return polynomial_value(target["P"], argument) / polynomial_value(target["Q"], argument)


def expression_value(expression, argument):
    op = expression["op"]
    if op == "element":
        a = F(expression["value"])
        return a if expression["type"] == "R" else a * argument if expression["type"] == "L" else 1 / (a * argument)
    if op == "certificate":
        return target_value(expression["certificate"]["target"], argument)
    if op == "frequency_invert":
        return expression_value(expression["child"], 1 / argument)
    terms = [expression_value(child, argument) for child in expression["children"]]
    return sum(terms, F(0)) if op == "series" else 1 / sum((1 / z for z in terms), F(0))


def expression_counts(expression):
    op = expression["op"]
    if op == "element":
        return 1, int(expression["type"] != "R"), 0
    if op == "certificate":
        branches = expression["certificate"]["branches"]
        return len(branches), sum(row["type"] != "g" for row in branches), 1
    if op == "frequency_invert":
        return expression_counts(expression["child"])
    rows = [expression_counts(child) for child in expression["children"]]
    return tuple(sum(row[j] for row in rows) for j in range(3))


def root_for_context(context):
    poly = list(map(F, context["field"]["polynomial"]))
    lo, hi = map(F, context["field"]["interval"])
    if poly == [F(0), F(1)]:
        return Quadratic(0)
    check(poly in ([F(-2), F(0), F(1)], [F(-3), F(0), F(1)]), "undeclared algebraic audit field")
    index = 1 if poly[0] == -2 else 2
    vector = [F(0)] * 4
    check(lo > 0 or hi < 0, "audit requires a signed isolating interval")
    vector[index] = F(1 if lo > 0 else -1)
    return Quadratic(vector)


def coefficient_value(row, contexts, extended):
    value = row["coefficient"]
    if value["kind"] == "rational":
        result = F(value["value"])
    elif value["kind"] == "algebraic":
        context = contexts[value["context"]]
        coefficients = list(map(F, value["polynomial"]))
        if len(coefficients) == 1:
            result = coefficients[0]
        else:
            result = polynomial_value(coefficients, root_for_context(context))
    else:
        context = contexts[value["context"]]
        definition = context["definition"]
        check(len(definition["branches"]) == 1 and definition["branches"][0]["type"] == "g",
              "only the proved rational resistor root is used in audit nodal arithmetic")
        check(value["index"] == 0, "wrong interval index")
        result = 1 / target_value(definition["target"], F(1))
        lo, hi = map(F, context["component_intervals"][0])
        check(lo < result < hi, "independent resistor root outside interval box")
        check(result != F(definition["center"][0]), "fixture must distinguish the exact root from its center")
    return Quadratic(result) if extended else F(result)


def nodal_value(verified, argument):
    graph = verified["rebuilt_graph"]
    contexts = {entry["id"]: entry for entry in verified["parameter_contexts"]}
    extended = any(row["coefficient"]["kind"] == "algebraic" and
                   len(row["coefficient"]["polynomial"]) > 1 for row in graph["branches"])
    convert = Quadratic if extended else F
    nodes = sorted(set(graph["nodes"]) - {0})
    ix = {node: i for i, node in enumerate(nodes)}
    matrix = [[convert(0) for _ in nodes] for _ in nodes]
    rhs = [convert(int(node == 1)) for node in nodes]
    for row in graph["branches"]:
        a, b = row["nodes"]
        admittance = coefficient_value(row, contexts, extended)
        if row["type"] == "h":
            admittance /= argument
        elif row["type"] == "c":
            admittance *= argument
        if a:
            matrix[ix[a]][ix[a]] += admittance
        if b:
            matrix[ix[b]][ix[b]] += admittance
        if a and b:
            matrix[ix[a]][ix[b]] -= admittance
            matrix[ix[b]][ix[a]] -= admittance
    return solve(matrix, rhs)[ix[1]], extended


def sqrt_resistor_leaf(d, negative=False):
    sign = -1 if negative else 1
    # At t=sign*sqrt(d), g1=sign*t, g2=(d+sign*t)/(d-1).
    # Their series resistance is exactly 1, with both conductances positive.
    return {"format": "komorebi-algebraic-circuit-v1", "target": {"P": ["1"], "Q": ["1"]},
            "storage_budget": 0,
            "field": {"polynomial": [str(-d), "0", "1"],
                      "interval": ["-2", "-1"] if negative else ["1", "2"]},
            "branches": [{"type": "g", "nodes": [0, 917], "coefficient": ["0", str(sign)]},
                         {"type": "g", "nodes": [1, 917],
                          "coefficient": [str(F(d, d - 1)), str(F(sign, d - 1))]}]}


def rational_interval_leaf():
    return {"format": "komorebi-rlc-interval-v1", "target": {"P": ["2"], "Q": ["1"]},
            "storage_budget": 0, "branches": [{"type": "g", "nodes": [1, 0]}],
            "center": ["51/100"], "radii": ["1/10"], "preconditioner": [["-1/2"]]}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run():
    started_at = datetime.now(timezone.utc).isoformat()
    start = time.monotonic()
    inputs = [
        "src/composition_certificate.py", "src/algebraic_witness.py", "src/interval_certificate.py",
        "src/real_algebraic.py", "src/exact_polynomials.py", "src/interval_family.py",
        "reports/COMPOSITION_THEOREM.md", "reports/COUPLED_CORE_LIFT_THEOREM.md",
        "reports/FAMILY_INDEPENDENT_AUDIT.md", "reports/INTERVAL_CHECKER_NOTES.md",
        "THEOREMS_AND_PROOFS.md", "certificates/image_baseline_cubic.json",
        "certificates/boundary_endpoint_cubic.json", "certificates/historical_case_1.json",
        "certificates/local_family_case_1.json", "experiments/coupled_core_lift_audit.py",
        "experiments/coupled_core_lift_audit.json", "experiments/composition_independent_audit.py",
    ]
    before = {path: sha(ROOT / path) for path in inputs}
    def load(name):
        return json.loads((ROOT / name).read_text())
    image_leaf = certificate_node(load("certificates/image_baseline_cubic.json"))
    boundary_leaf = certificate_node(load("certificates/boundary_endpoint_cubic.json"))
    interval = certificate_node(rational_interval_leaf())
    a2, a3, negative_a2 = [certificate_node(c) for c in
                          [sqrt_resistor_leaf(2), sqrt_resistor_leaf(3), sqrt_resistor_leaf(2, True)]]
    R = lambda v: element_node("R", v)
    L = lambda v: element_node("L", v)
    C = lambda v: element_node("C", v)
    fixtures = [
        ("pure_resistor", R("7/3")),
        ("unequal_degree_inverse_L", frequency_invert_node(L("5/7"))),
        ("unequal_degree_inverse_C", frequency_invert_node(C("11/13"))),
        ("series_RL_inverse", frequency_invert_node(series_node(R(2), L(3)))),
        ("nested_mixed", parallel_node(series_node(R(2), L(3)),
                                      frequency_invert_node(series_node(C("2/5"), R("7/3"))))),
        ("parallel_same_type_inductors", parallel_node(L(2), L(3))),
        ("series_same_type_capacitors", series_node(C(2), C(3))),
        ("reused_algebraic_leaf", series_node(image_leaf, image_leaf)),
        ("two_different_rational_leaves", parallel_node(image_leaf, boundary_leaf)),
        ("double_frequency_inverse", frequency_invert_node(frequency_invert_node(
            series_node(image_leaf, parallel_node(R(4), C("3/2")))))),
        ("rational_interval_root_not_center", parallel_node(interval, interval)),
        ("interval_algebraic_mix", series_node(interval, image_leaf, L("2/3"))),
        ("independent_sqrt2_sqrt3_fields", parallel_node(series_node(a2, L(2)),
                                                        series_node(a3, C(3)))),
        ("reused_field_and_opposite_root", parallel_node(series_node(a2, a3, R(3)),
                                                         series_node(a2, negative_a2, L(4)))),
    ]
    positive = []
    artifacts = {}
    for label, expression in fixtures:
        certificate = make_composition(expression)
        verified = verify_circuit(certificate, certificate["target"], certificate["storage_budget"])
        physical, storage, leaves = expression_counts(expression)
        graph = verified["rebuilt_graph"]
        check(verified["physical_branch_count"] == physical == len(graph["branches"]), label + " branch count")
        check(verified["actual_storage"] == storage, label + " storage count")
        check(verified["leaf_occurrence_count"] == leaves, label + " leaf occurrence count")
        check(len({x["id"] for x in verified["parameter_contexts"]}) == leaves, label + " unique contexts")
        check([x["instance"] for x in graph["branches"]] == list(range(physical)), label + " physical instances")
        check(len({tuple(x["nodes"]) for x in graph["branches"]}) <= physical, label + " graph shape")
        degree = max(len(certificate["target"]["P"]), len(certificate["target"]["Q"])) - 1
        check(verified["reduced_target_degree"] == degree, label + " reported degree")
        check(verified["global_minimum_proved_by_degree"] == (storage == degree), label + " minimum gate")
        check(verified["realization_only"] == (storage != degree), label + " realization-only flag")
        extended = False
        for k in range(1, storage + degree + 2):
            s = F(2 * k + 1, 7)
            got, extended = nodal_value(verified, s)
            wanted = expression_value(expression, s)
            check(got == wanted, label + " independent nodal mismatch")
            check(target_value(certificate["target"], s) == wanted, label + " target mismatch")
        if label == "parallel_same_type_inductors":
            check([row["nodes"] for row in graph["branches"]] == [[0, 1], [0, 1]], "duplicates were merged")
            check(storage == 2 and degree == 1 and verified["realization_only"], "duplicate minimum overclaim")
        if label == "reused_algebraic_leaf":
            context_nodes = []
            for context in verified["parameter_contexts"]:
                context_nodes.append({node for row in graph["branches"]
                                      if row["coefficient"].get("context") == context["id"] for node in row["nodes"]})
            check(len(context_nodes[0] & context_nodes[1]) == 1, "series leaves share material beyond chain junction")
        positive.append({"label": label, "physical_branches": physical, "actual_storage": storage,
                         "degree": degree, "leaf_occurrences": leaves,
                         "exact_nodal_arguments": storage + degree + 1,
                         "arithmetic": "Q(sqrt(2),sqrt(3))" if extended else "Q",
                         "minimum_proved": storage == degree, "status": "PASS"})
        artifacts[label] = (certificate, verified)

    # Algebraically equivalent target descriptions and inert forged metadata.
    certificate, verified = artifacts["series_RL_inverse"]
    scaled = deepcopy(certificate)
    for name in ("P", "Q"):
        old = list(map(F, scaled["target"][name]))
        out = [F(0)] * (len(old) + 1)
        for i, value in enumerate(old):
            out[i] -= 3 * value
            out[i + 1] -= 3 * value
        scaled["target"][name] = list(map(str, out))
    scaled["rebuilt_graph"] = {"branches": []}
    scaled["equations"] = ["untrusted"]
    scaled["global_minimum_proved_by_degree"] = False
    check(verify_circuit(scaled, certificate["target"], certificate["storage_budget"])["target"]
          == verified["target"], "unreduced target or forged metadata affected semantics")

    rejections = []
    def reject(label, action):
        try:
            action()
        except ValueError as exc:
            rejections.append({"label": label, "status": "REJECTED", "exception": "ValueError", "reason": str(exc)})
        except Exception as exc:
            raise AssertionError(label + " escaped with " + type(exc).__name__) from exc
        else:
            raise AssertionError(label + " was accepted")

    base = artifacts["nested_mixed"][0]
    def mutate(path, value):
        changed = deepcopy(base)
        obj = changed
        for key in path[:-1]:
            obj = obj[key]
        obj[path[-1]] = value
        return changed
    reject("external_target_binding", lambda: verify_circuit(base, {"P": [1], "Q": [1]}))
    reject("external_budget_binding", lambda: verify_circuit(base, expected_budget=0))
    reject("declared_target_binding", lambda: verify_circuit(mutate(["target"], {"P": [1], "Q": [1]})))
    reject("insufficient_budget", lambda: verify_circuit(mutate(["storage_budget"], 0)))
    for value, label in [(True, "boolean"), ("2", "string"), (-1, "negative"), (257, "excessive")]:
        reject(label + "_budget", lambda value=value: verify_circuit(mutate(["storage_budget"], value)))
    for value, label in [(0, "zero"), (-1, "negative"), (True, "boolean"), (1.0, "float"),
                         ("NaN", "nan"), ("1/0", "zero_denominator"), ("1e2", "scientific_text")]:
        expression = {"op": "element", "type": "R", "value": value}
        reject(label + "_element", lambda expression=expression: make_composition(expression))
    for expression, label in [
        ({"op": "element", "type": "X", "value": 1}, "unknown_element"),
        ({"op": "reciprocal", "child": R(1)}, "unproved_reciprocal"),
        ({"op": "parallel", "children": [R(1)]}, "unary_parallel"),
        ({"op": "series", "children": []}, "empty_series"),
        ({"op": "element", "type": "R", "value": 1, "target": {}}, "extra_node_field"),
        ({"op": "series", "children": [R(1)] * 65}, "child_limit"),
        ({"op": "certificate", "certificate": base}, "nested_composition_leaf"),
    ]:
        reject(label, lambda expression=expression: make_composition(expression))
    depth = R(1)
    for _ in range(34):
        depth = {"op": "frequency_invert", "child": depth}
    reject("expression_depth_limit", lambda: make_composition(depth))
    cyclic = deepcopy(base)
    cyclic["metadata"] = cyclic
    reject("cyclic_ignored_metadata", lambda: verify_circuit(cyclic))
    reject("oversize_ignored_text", lambda: verify_circuit(dict(base, metadata="x" * 16385)))
    reject("nonstring_metadata_key", lambda: verify_circuit(dict(base, metadata={1: "x"})))
    reject("floating_ignored_metadata", lambda: verify_circuit(dict(base, metadata=1.0)))
    for target, label in [({"P": [0], "Q": [1]}, "zero_target"),
                          ({"P": [1], "Q": [0]}, "infinite_target"),
                          ({"P": [1.0], "Q": [1]}, "floating_target"),
                          ({"P": [True], "Q": [1]}, "boolean_target"),
                          ({"P": [1] + [0] * 65, "Q": [1]}, "untrimmed_degree_limit")]:
        reject(label, lambda target=target: verify_circuit(mutate(["target"], target)))
    leaf = sqrt_resistor_leaf(2)
    for field, value, label in [("nodes", [0, 0], "self_loop"), ("nodes", [0, True], "boolean_node"),
                                ("nodes", [0, -1], "negative_node"), ("nodes", [0], "missing_node"),
                                ("coefficient", [-1], "negative_algebraic_branch")]:
        broken = deepcopy(leaf)
        broken["branches"][0][field] = value
        reject(label, lambda broken=broken: verify_circuit(broken))
    duplicate = deepcopy(leaf)
    duplicate["branches"].append(deepcopy(duplicate["branches"][0]))
    reject("duplicate_inside_legacy_leaf", lambda: verify_circuit(duplicate))
    nonisolated = deepcopy(leaf)
    nonisolated["field"]["interval"] = ["-2", "2"]
    reject("nonisolated_algebraic_root", lambda: verify_circuit(nonisolated))
    singular = rational_interval_leaf()
    singular["preconditioner"] = [["0"]]
    reject("singular_interval_preconditioner", lambda: verify_circuit(singular))
    invalidbox = rational_interval_leaf()
    invalidbox["radii"] = ["1"]
    reject("nonpositive_interval_box", lambda: verify_circuit(invalidbox))

    # This originally exposed a portable-builder defect, not false acceptance.
    large = 2 ** 2100 + 1
    expression = series_node(R(F(1, large)), R(F(1, large + 2)))
    try:
        result = make_composition(expression)
    except ValueError as exc:
        portability = {"status": "PASS", "behavior": "builder rejects an output outside its replay caps", "reason": str(exc)}
    else:
        try:
            verify_circuit(result)
        except ValueError as exc:
            portability = {"status": "FAIL", "behavior": "builder returned an unreplayable certificate", "reason": str(exc)}
        else:
            portability = {"status": "PASS", "behavior": "builder output replays"}
    portability.update({"input_denominator_bits": large.bit_length(),
                        "normalized_output_denominator_bits": (F(1, large) + F(1, large + 2)).denominator.bit_length(),
                        "first_affected_revision": "1aa31c10cead9b2da925b2637a84fe9dde4240aad313a72024c4333f25f39ba9"})

    # General interval leaf: replay exact proof and verify occurrence semantics.
    real_leaf = certificate_node(load("certificates/historical_case_1.json"))
    interval_composition = make_composition(series_node(real_leaf, frequency_invert_node(real_leaf)))
    real_verified = verify_circuit(interval_composition)
    check(real_verified["leaf_occurrence_count"] == 2, "real interval leaf occurrences merged")
    check(real_verified["actual_storage"] == 6, "real interval branch count changed")
    check(all(c["kind"] == "interval" for c in real_verified["parameter_contexts"]), "real root semantics lost")
    check(len({c["id"] for c in real_verified["parameter_contexts"]}) == 2, "real root contexts merged")

    # Reproduce the author's documented exact computation in memory; its file is
    # not overwritten, and this reproduction is separate from our nodal audit.
    spec = importlib.util.spec_from_file_location("lift_controls_under_audit", ROOT / "experiments/coupled_core_lift_audit.py")
    lift_module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(lift_module)
    lift_replay = lift_module.run()
    recorded_lift = load("experiments/coupled_core_lift_audit.json")
    check(lift_replay == recorded_lift, "recorded lift computation differs on reproduction")
    check(len(lift_replay["instances"]) == 72, "lift finite range count")
    check(lift_replay["finite_check_scope"]["single_step_roundtrips"] == 108, "lift roundtrip count")
    check(lift_replay["finite_check_scope"]["exact_scalar_identity_checks"] == 324, "lift scalar count")
    check(lift_replay["uniform_cubic_certificate_replay"]["coefficient_domain"]
          == "all real coefficients in the closed target box", "uniform real scope changed")
    after = {path: sha(ROOT / path) for path in inputs}
    unchanged = before == after
    status = "PASS" if unchanged and portability["status"] == "PASS" else "FAIL"
    try:
        commit = subprocess.run(["git", "rev-parse", "HEAD"], cwd=ROOT, capture_output=True, text=True, check=True).stdout.strip()
        dirty = bool(subprocess.run(["git", "status", "--porcelain"], cwd=ROOT, capture_output=True, text=True, check=True).stdout.strip())
    except subprocess.CalledProcessError:
        commit, dirty = "not a git checkout", None
    return {
        "schema_version": 2, "claim_id": "COMPOSITION_AND_COUPLED_CORE_INDEPENDENT_AUDIT",
        "status": status, "author": "Komorebi P.", "review_provenance": "independent delegated audit of raw source and proof",
        "repository": {"commit": commit, "dirty": dirty},
        "command": ["python3", "-S", "experiments/composition_independent_audit.py"],
        "environment": {"software": [{"name": "Python", "version": platform.python_version()}],
                        "hardware": platform.machine(), "platform": platform.platform()},
        "mathematics": {
            "assertion_tested": "Declared finite composition fixtures agree with independently rebuilt nodal equations; malformed inputs reject; the recorded lift computation reproduces exactly.",
            "coefficient_domain": "exact Q and Q(sqrt(2),sqrt(3)); inherited interval real roots replayed without center substitution",
            "conventions": "ascending polynomial arrays; conductance g, inverse inductance h, capacitance c; unit current at port1, ground0",
            "inputs": inputs, "bounds": {"declared_nodal_fixtures": len(positive), "exact_positive_arguments_per_fixture": "q+n+1", "maximum_storage_tested": max(x["actual_storage"] for x in positive)},
            "non_claims": ["No global target coverage", "No universal theorem from finite sampling", "No minimum total component count", "No novelty or external literature claim", "No running-time or memory upper bound"]},
        "randomness": {"used": False, "generator": "none; explicit deterministic fixtures", "seed": None},
        "run": {"started_at": started_at, "runtime_seconds": time.monotonic() - start,
                "exit_status": 0 if status == "PASS" else 1,
                "status": "completed" if status == "PASS" else "inputs-changed" if not unchanged else "failed",
                "resource_limits": {"memory_bytes": None, "cpu_seconds": None, "max_cores": None, "max_threads": None}},
        "input_artifacts": [{"path": path, "sha256": before[path], "sha256_after": after[path]} for path in inputs],
        "source_unchanged": unchanged,
        "positive_nodal_checks": positive,
        "exact_nodal_argument_count": sum(x["exact_nodal_arguments"] for x in positive),
        "equivalent_unreduced_target_and_ignored_metadata": "PASS",
        "rejection_controls": rejections,
        "portable_builder_regression": portability,
        "general_interval_occurrences": {"status": "PASS", "occurrences": 2, "actual_storage": 6,
                                         "semantics": "unique exact real leaf roots; no rational component approximation"},
        "lift_record_reproduction": {"status": "PASS", "identical_to_recorded_result": True,
                                      "selected_instances": 72, "single_step_roundtrips": 108,
                                      "exact_scalar_identity_checks": 324, "domain_rejection_controls": 11,
                                      "uniform_cubic_family_replay": "PASS"},
        "outputs": [], "declared_results": [],
        "checks": ["before/after source hashes", "independent exact nodal equations", "q+n+1 distinct positive rational arguments", "separate parameter contexts", "strict malformed rejection", "documented lift computation reproduction"],
        "result": "implementation and finite assertion verified in the stated range" if status == "PASS" else "portable-builder defect or changed inputs require follow-up",
        "residual_risks": ["Finite controls supplement the raw universal proof audit", "Existing exact leaf kernels remain dependencies; their raw source and relevant semantics were inspected", "The JSON is the result record itself; its file hash is recorded externally in the audit report, avoiding a self-hash"]}


if __name__ == "__main__":
    result = run()
    output = ROOT / "experiments/composition_independent_audit.json"
    output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"status": result["status"], "nodal_fixtures": len(result["positive_nodal_checks"]),
                      "exact_nodal_arguments": result["exact_nodal_argument_count"],
                      "rejection_controls": len(result["rejection_controls"]),
                      "portable_builder": result["portable_builder_regression"]["status"],
                      "source_unchanged": result["source_unchanged"], "output": str(output)}, indent=2))
    raise SystemExit(0 if result["status"] == "PASS" else 1)
