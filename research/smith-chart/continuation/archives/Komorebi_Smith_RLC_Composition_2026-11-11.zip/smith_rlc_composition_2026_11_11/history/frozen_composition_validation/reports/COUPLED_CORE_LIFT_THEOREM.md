# Lifting an interval-certified coupled cubic core to every degree

**Author: Komorebi P.**  
**Date:** November 11, 2026, America/Chicago.  
**Primary verdict:** Proved as written for the normalized domains below.  
**Review provenance:** Independent derivation of the proposed lifting claim, separate from the composition checker and search implementation. The new proof below is self-reviewed; it has not yet received a separate review of its own. The inherited uniform cubic input already has an independent audit in `reports/FAMILY_INDEPENDENT_AUDIT.md`.

## 1. Exact statement and conventions

All coefficients in the theorem are real. Store polynomial coefficients in increasing powers of the Laplace variable `s`. Define

\[
\mathcal C_n=\{(P,Q):\deg P=\deg Q=n,\ Q_n=1,\ P_n>0,\ \gcd(P,Q)=1\}.
\]

Here `gcd=1` means coprime up to a nonzero scalar. The coordinates of this set are the `n+1` numerator coefficients and the first `n` denominator coefficients. Thus \(\mathcal C_n\) is an open subset of \(\mathbb R^{2n+1}\). The domain includes rational functions that need not have passive realizations; passivity enters the physical corollary separately.

For \(g,L>0\), put

\[
W_{g,L}(Z)=\left[g+\frac1{Ls+Z}\right]^{-1}.
\]

**Lift theorem.** For every integer \(n\ge0\), this operation induces a rational diffeomorphism from \(\mathcal C_n\times(0,\infty)^2\) onto the open endpoint chart \(\mathcal E_{n+1}\subset\mathcal C_{n+1}\) defined in Section 3. Its inverse is explicit. No numerator/denominator cancellation occurs, and the reduced degree increases by exactly one.

**Physical corollary.** If a target in \(\mathcal C_n\) has a positive ordinary uncoupled RLC realization with exactly `n` reactive elements, the lifted target has such a realization with exactly `n+1` reactive elements: add one series inductor of value `L`, then a resistor of value `1/g` in parallel with the entire arm. Its global minimum reactive count is `n+1`.

**All-degree open-family corollary.** Let \(\mathcal U_3\) be the interior of the exact seven-dimensional coefficient box in `certificates/local_family_case_1.json`. For every \(m\ge0\), iterating `m` lifts gives a nonempty open family \(\mathcal U_{3+m}\) in the full \(2(3+m)+1\)-dimensional normalized coefficient space. Every target in this family has global minimum reactive count \(3+m\). The constructed graph has

\[
\#L=2+m,\qquad \#C=1,\qquad \#R=4+m,
\]

and therefore `2m+7` physical components in total. The component-count equality does not assert minimum resistor count or minimum total component count.

## 2. Exact identity, degree and coprimality

Write \(Z=P/Q\), with \((P,Q)\in\mathcal C_n\). Set

\[
N=P+sLQ,\qquad D=Q+gN.
\]

The ordinary series and parallel impedance identities give

\[
W_{g,L}(P/Q)=\frac{N}{D}.
\]

Because \(Q_n=1\) and \(L>0\), the leading coefficient of \(N\) is `L` and \(\deg N=n+1\). The leading coefficient of \(D\) is `gL`, so \(\deg D=n+1\) as well. Euclidean polynomial operations give

\[
\gcd(N,D)=\gcd(N,Q)=\gcd(P+sLQ,Q)=\gcd(P,Q)=1.
\]

Consequently these raw degrees are also the reduced degrees. There is no reliance on genericity, floating-point root separation or a finite test set.

The unique representation with monic denominator is

\[
U=\frac{P+sLQ}{gL},\qquad
V=\frac{Q+g(P+sLQ)}{gL}.
\]

Its leading numerator coefficient is \(U_{n+1}=1/g>0\), and its denominator is monic. This defines the forward coordinate map

\[
\Phi_n(P,Q,g,L)=(U,V).
\]

## 3. The inverse and the exact open image

Take \((U,V)\in\mathcal C_{n+1}\). Its denominator is already monic. Form

\[
g=\frac1{U_{n+1}},\qquad H=V-gU.
\]

The coefficient of \(s^{n+1}\) in `H` vanishes identically. Require

\[
h:=H_n>0.
\]

Then `H` has exact degree `n`. Next form

\[
L=\frac{U_{n+1}}h,\qquad K=U-sLH.
\]

The coefficient of \(s^{n+1}\) in `K` also vanishes identically. Require

\[
K_n>0.
\]

These conditions define \(\mathcal E_{n+1}\). The recovered normalized core is

\[
\boxed{P=K/h,\qquad Q=H/h.}
\]

Every recovered parameter is of the required sign: \(g>0\) follows from \(U_{n+1}>0\), \(L>0\) follows from `h>0`, and \(P_n=K_n/h>0\). Also \(Q_n=1\). Coprimality follows in the reverse direction:

\[
\gcd(K,H)=\gcd(U,H)=\gcd(U,V)=1.
\]

Thus the recovered core belongs to \(\mathcal C_n\). Its unnormalized forward polynomials are

\[
P+sLQ=U/h,\qquad Q+g(P+sLQ)=V/h.
\]

Normalizing the denominator recovers exactly `(U,V)`. Conversely, for any forward image one has

\[
H=\frac{Q}{gL},\quad h=\frac1{gL},\quad
K=\frac{P}{gL},
\]

so these inverse formulas recover the original `g`, `L`, `P` and `Q` exactly. They establish both directions of the bijection.

All formulas are rational functions of the coefficient coordinates. Their only divisors on the indicated domains are nonzero quantities, including \(U_{n+1}\), `g`, `L` and `h`. Hence both maps are smooth and continuous. The conditions `h>0` and \(K_n>0\) are strict inequalities of continuous functions, so \(\mathcal E_{n+1}\) is open in \(\mathcal C_{n+1}\), and therefore in the ambient normalized coefficient space. This proves the diffeomorphism and the openness claim without an uncomputed Jacobian assertion.

For \(n=0\), the same formulas hold with constant `H` and `K`. The term \(H_{-1}\), if the coefficients are written out explicitly, is taken as zero. There is no exceptional loss of the base case.

### Normalization matters

For an arbitrary common-scaled output `(N,D)`, the first inverse formula is \(g=D_{n+1}/N_{n+1}\). Setting \(H=D-gN\), \(L=N_{n+1}/H_n\) still recovers the physical values. To compare normalized coefficient vectors, divide the recovered core pair \((N-sLH,H)\) by `H_n`. Using `g=1/N[n+1]` before making the denominator monic would be incorrect.

## 4. Why the physical realization is minimum reactive

The added elements are finite and strictly positive. The inductor is placed in series with a copy of the core, and the new resistor is placed across the resulting two-terminal arm. The core's internal nodes remain separate from the new external node. Kirchhoff's laws then give exactly the impedance identity in Section 2. No mutual inductance, ideal transformer or negative element is introduced.

The construction adds one reactive branch and one resistor. The new target has reduced degree `n+1` by the preceding algebra. For any finite ordinary positive uncoupled RLC graph with `q` reactive branches, the tree/forest impedance polynomials, after clearing the inductive powers of `s`, have degrees at most `q`. Reduction can only decrease degree. Thus every realization of a reduced degree-`n+1` target has at least `n+1` reactive elements. The constructed circuit reaches that bound.

This lower bound is the already retained statement T2 in `THEOREMS_AND_PROOFS.md`. It applies to competing graph topologies too. The restriction of the search algorithm to a particular family therefore does not restrict this minimum-reactive conclusion for an accepted target.

## 5. Lifting the explicit certified cubic box

The inherited certificate uses

\[
P_y=y_0+y_1s+y_2s^2+y_3s^3,
\qquad Q_y=y_4+y_5s+y_6s^2+s^3.
\]

Its exact center is

\[
a=\left(\frac{75}{868},\frac{45}{124},\frac{597}{434},
\frac{60}{31},\frac{25}{248},\frac{405}{868},\frac{913}{868}\right),
\]

and its seven positive radii are

\[
\rho=\left(10^{-10},10^{-10},\frac{597}{4340000000000},
\frac3{15500000000},10^{-10},10^{-10},\frac{913}{8680000000000}\right).
\]

The family checker certifies **every real** coefficient vector in the closed box. It supplies a positive three-reactive realization, a strict uniform contraction bound below `1/4`, and a uniform Sylvester nonsingularity bound

\[
\frac{211787599}{223125000000000}<10^{-6}.
\]

The positive lower bound on \(y_3\) and the Sylvester result put the entire box in \(\mathcal C_3\). Its interior \(\mathcal U_3\) is nonempty and open. Using the interior is essential for the assertion of an open image; the boundary of the closed box is not itself an open set.

Inductively define

\[
\mathcal U_{n+1}=\Phi_n\bigl(\mathcal U_n\times(0,\infty)^2\bigr).
\]

A diffeomorphism onto an open set sends open subsets of its domain to open subsets of the ambient target space. Therefore every \(\mathcal U_n\), for \(n\ge3\), is nonempty and open. The parameter count is

\[
7+2(n-3)=2n+1,
\]

the full normalized coefficient dimension. Every parameter pair adds one positive inductor and one positive resistor, so the counts and minimum-reactive statement follow by induction.

The inverse gives unique wrapper parameters and a unique residual **coefficient vector within this endpoint chart**. The inherited certificate gives a unique core component root inside its declared component box. Neither statement asserts uniqueness among all circuit topologies or among component values outside that box.

## 6. Concrete degree-four development fixture

At the certified cubic center, an integer representation is

\[
Z_3(s)=\frac{150+630s+2388s^2+3360s^3}
{175+810s+1826s^2+1736s^3}.
\]

Choose `g=2/5` and `L=3/2`, so the added resistor is `R=5/2`. The lifted target is

\[
\boxed{
Z_4(s)=\frac{1500+8925s+36030s^2+60990s^3+26040s^4}
{2350+11670s+32672s^2+41756s^3+10416s^4}.
}
\]

Exact inversion recovers this cubic center and the two chosen physical values. The construction uses three inductors, one capacitor and five resistors, and the global minimum reactive count is four. This is a deliberately generated development fixture. It is not an untouched validation example, and it is separate from the image-pinned cubic retained in the previous checkpoint.

## 7. Computation, dependency map and audit obligations

The script `experiments/coupled_core_lift_audit.py` uses its own small Fraction polynomial implementation for the lift/inverse checks; it does not import endpoint extraction or the new composition solver. It separately calls the inherited family checker to replay the exact uniform input certificate.

Run from the project root:

```bash
python3 -S experiments/coupled_core_lift_audit.py
```

The recorded result in `experiments/coupled_core_lift_audit.json` is `PASS`. It contains 72 selected rational instances at degrees 3, 4, 5, 6, 8 and 12, 108 single-step exact inverse checks, 324 direct scalar series/parallel identity checks, a degree-zero to degree-one case, 11 rejection controls, and before/after input hashes. The arithmetic is integer/Fraction only. The finite instances are supplementary implementation controls; they do not prove the universal statement by sampling.

| Dependency | Evidence type | Role |
|---|---|---|
| Series/parallel impedance identities | Internal algebra and Kirchhoff laws | Physical wrapper realization |
| GCD invariance under polynomial row operations | Internal proof in Section 2 | Exact degree increase |
| Explicit normalized rational inverse | Internal proof in Section 3 | Bijection and open full-dimensional image |
| Uniform cubic coefficient box | Inherited exact certificate plus independent audit | Every-real-coefficient passive base family |
| Universal graph degree bound | Retained internal proof T2 | Global minimum reactive count |
| Declared finite exact fixtures | Reproducible computation | Normalization, edge-case and implementation checks |

| Obligation | Verdict | Decisive evidence |
|---|---|---|
| Correct coefficient domain and normalized dimension | Passed | Definitions of \(\mathcal C_n\) and \(\mathcal E_{n+1}\) |
| Exact forward identity | Passed | \(N=P+sLQ\), \(D=Q+gN\) |
| No hidden degree cancellation | Passed | Leading coefficients and gcd identity |
| Inverse is two-sided and normalized | Passed | Direct substitutions in Section 3 |
| Image is open, not merely parameter-counted | Passed | Strict continuous inequalities and rational inverse |
| Positive uncoupled physical components | Passed | Explicit series-L / shunt-R graph construction |
| All-real, all-degree quantifiers | Passed | Uniform real base certificate plus exact induction |
| Nullary iteration and smallest lift | Passed | `m=0` proof and degree-zero finite control |
| Minimum reactive count across competing topologies | Passed | Degree lower bound attained |
| Universal passive target coverage | Out of scope | Only the stated endpoint charts are covered |
| Priority or historical novelty | Not addressed | No literature search undertaken |

The exact inherited certificate hash is

```text
28d096fa089bb550208f7dc7e5eede622d4cdf9704210088447c99e5f2899ffe
```

The family-checker source hash is

```text
81772b2a1a25fc3651013ced311d984fbce1c0647833c9dcfb2beadbf9dca52e
```

All other source hashes, including the audit script itself, are retained in the JSON result. None changed during that run.

## 8. Scope, relation to earlier work and remaining software obligation

Earlier checkpoint documentation already proves endpoint extraction and gives full-dimensional local cubic charts, as well as classical arbitrary-degree ladder charts. The present result makes their combination with the **explicit interval-certified coupled cubic family** precise, including the normalized two-sided inverse and the all-degree open-family statement. It is not presented as a novel historical synthesis theorem.

The mathematical result permits arbitrary positive real wrapper values and all real coefficients in the base box. The point composition-certificate API being developed in this checkpoint accepts exact rational wrapper values and existing exact point leaf certificates. It does not, merely by this theorem, acquire a serialization format for arbitrary real wrapper values or a universal family certificate for every lifted open set. A rational point in the original coefficient box is covered mathematically by the uniform certificate; separately certifying that point through the current point API can still depend on discovery and supported certificate formats.

The theorem supplies exact forward realizations and exact inverse reductions on this chart. It does not prove that the general target-only numerical search always finds the cubic leaf, that every positive-real target belongs to these charts, or that a failed candidate is impossible. The remaining implementation obligation is an independently replayable composition certificate binding each accepted complete circuit to its full target. This report does not substitute for that code audit.
