# Independent audit of the origin-pole boundary continuation

**Author: Komorebi P.**  
**Review date:** November 11, 2026, America/Chicago  
**Review provenance:** Independent delegated derivation, exact symbolic checks, circuit-certificate replay and a traced dispatcher control.  
**Primary verdict:** Proved as written for the stated sufficient family and specified target. The recursion change preserves independent acceptance.

## Claim and admissible objects

Let \(A,B,C,D,E,\kappa\) be positive rational numbers. Put

\[
F=D-\frac{CB}{A},\qquad \Delta=AE-BF,
\]

and suppose \(F>0\) and \(\Delta>0\). The claim is that

\[
Z_\kappa(s)=\frac{\kappa}{s}
+\frac{s(A+Bs)}{C+Ds+Es^2}
\]

has a positive transformer-free realization with exactly three reactive elements and two resistors, and has reduced rational degree three. Consequently its global reactive minimum is three.

This is a sufficient family, not a classification of all origin-pole cubic targets. The minimized count is inductors plus capacitors, not total components.

## Independent algebraic derivation

Set

\[
L=\frac AC,\qquad R_s=\frac BE,\qquad
R_p=\frac{\Delta}{EF},\qquad C_1=\frac{E^2}{\Delta},
\qquad C_0=\frac1\kappa.
\]

All five values are strictly positive under the stated hypotheses. Since \(R_pC_1=E/F\), the resistor-capacitor arm is

\[
\begin{aligned}
W(s)
 &=R_s+\frac{R_p}{1+sR_pC_1}\\
 &=\frac BE+\frac{\Delta}{E(F+Es)}\\
 &=\frac{BF+BEs+\Delta}{E(F+Es)}\\
 &=\frac{A+Bs}{F+Es}.
\end{aligned}
\]

Putting the inductor in parallel with this arm gives

\[
\begin{aligned}
\frac1{sL}+\frac1{W(s)}
 &=\frac{C}{As}+\frac{F+Es}{A+Bs}\\
 &=\frac{C+(CB/A+F)s+Es^2}{s(A+Bs)}\\
 &=\frac{C+Ds+Es^2}{s(A+Bs)}.
\end{aligned}
\]

The series capacitor \(C_0\) supplies \(\kappa/s\), proving the full identity. This derivation is independent of the endpoint-extraction code and does not rely on optimizer output.

## Noncancellation and global reactive minimum

The complete numerator and denominator are

\[
P_\kappa(s)=\kappa C+\kappa Ds+(\kappa E+A)s^2+Bs^3,
\qquad
Q_\kappa(s)=s(C+Ds+Es^2).
\]

Their leading coefficients \(B,E\) are positive. The numerator does not vanish at zero because \(P_\kappa(0)=\kappa C>0\). Let \(H(s)=C+Ds+Es^2\). At a root of \(H\), the numerator is \(s^2(A+Bs)\). Such a root is nonzero because \(C>0\), so cancellation would require \(s=-A/B\). But

\[
H(-A/B)
 =\frac{CB^2-DAB+EA^2}{B^2}
 =\frac{A\Delta}{B^2}>0.
\]

There is therefore no common root, even if \(H\) has a repeated root. The reduced target degree is exactly three.

For any finite positive transformer-free RLC graph with \(q\) reactive branches, the tree and separating-forest formulas, multiplied by \(s^{n_L}\), have degrees at most \(q=n_L+n_C\). This bound applies to every topology and any number of resistors. The reduced degree-three target requires at least three reactive elements. The exhibited circuit attains the bound.

## Exact remaining-case circuit

For the retained missed target

\[
Z(s)=\frac{320+1850s+3997s^2+2520s^3}
{256s+1480s^2+1764s^3},
\]

the parameters are

\[
A=1792,\ B=2520,\ C=256,\ D=1480,\ E=1764,\ \kappa=\frac54,
\qquad F=1120,\ \Delta=338688.
\]

The circuit is

\[
\frac{1}{(4/5)s}
+
\left[
7s\;\parallel\;
\left(
\frac{10}{7}
+
\left(\frac{6}{35}\parallel\frac{1}{(147/16)s}\right)
\right)
\right].
\]

The physical components are \(C_0=4/5\), \(L=7\), \(R_s=10/7\), \(R_p=6/35\), and \(C_1=147/16\). Every component is strictly positive.

The fresh independent audit recovered the exact target identity by symbolic rational simplification, checked the numerator-denominator gcd is constant, and replayed the saved graph certificate with explicit target and budget binding. The standard-library nodal checker passed all seven required exact samples, reported three reactive elements and two resistors, and confirmed degree-based global reactive minimality.

## Recursion change and acceptance contract

The comparison against **history/frozen_validation/src/recursive_modules.py** shows only this functional change, plus its explanatory comment:

    if d <= 2: return None

became

    if d <= 1: return None

The older guard stopped a degree-two residual before a valid one-reactive endpoint extraction could reach a supported degree-one Cauer core. The changed guard permits that existing operation. It does not change a polynomial identity, component formula, graph compiler or certificate checker.

For the present target, the dispatcher now follows these exact stages:

1. Remove the series capacitor \(4/5\).
2. Remove the shunt inductor \(7\).
3. Synthesize the remaining degree-one RC arm.

Every accepted graft is checked against its corresponding residual target by the independent algebraic nodal verifier. The top-level CERTIFIED_MINIMUM path additionally calls that verifier against the full original input and requires both actual storage and reduced target degree to equal the claimed minimum.

A runtime-only control replaced the top-target verification with a deliberate rejection. The dispatcher returned UNKNOWN, not CERTIFIED_MINIMUM. No source files were changed by this control. A traced successful run confirmed that the final actual verifier call bound the full original target and budget three.

These controls substantiate this path's implementation. Source review establishes that the relaxed cutoff does not create a success return bypassing final independent verification.

## Evidence, commands and hashes

Run from the project root:

    python3 experiments/prior_boundary_audit.py

The result is **experiments/prior_boundary_audit.json**. It contains exact input hashes before and after, four symbolic identities, component values, witness replay, dispatcher trace, forced-checker-rejection result and observed Python/SymPy versions. Its overall status is **PASS**, and all recorded source hashes remained unchanged during the run.

| Input | SHA256 |
|---|---|
| Frozen recursive_modules.py | c672992e3dc95d44b97aaa1d29abbf380d017ccb6858e022bf86c3146ebe5d90 |
| Current src/recursive_modules.py | 7f29b03a53fcd0631f415cdc1a3fe8c0ebc90eb319c2b8cdbcd365555d94cff1 |
| src/algebraic_witness.py | 8490cf4b993774cdaec091df9f63e30ec5efed79c7136a6c03a7c4a6949fd883 |
| experiments/boundary_exact_reduction.py | a077e9c4e6e983fde4a262d01801cbdd913e6454f630797037dc050a87ee00c7 |

The hand derivation above supplies the general proof. SymPy is used only for an orthogonal exact symbolic check. The replayed circuit certificate is accepted by the standard-library exact checker.

## Validation scope and remaining boundary

The frozen new 24-case experiment remains **23/24**, compared with its baseline **21/24**. Its source snapshot and raw results remain under **history/frozen_validation/**. This audit concerns a later investigation of that experiment's remaining case and the subsequent code correction.

Any 24/24 result on those same now-inspected cases is a **post-fix regression result**, not a new untouched validation score. The archived frozen result has not been overwritten.

The generalized positive family is proved under \(F>0\) and \(\Delta>0\). Boundary targets outside those inequalities or without exposed positive endpoint extractions remain outside this sufficient argument. The relaxed recursion guard does not establish complete degree-two synthesis, complete cubic boundary classification or unrestricted RLC completeness. No historical novelty or minimum-total-component claim was audited.

