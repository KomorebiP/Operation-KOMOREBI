# Exact endpoint continuation at the origin-pole boundary

**Author: Komorebi P.**  
**Date:** November 11, 2026  
**Status:** Exact rational physical witness checked independently.  
**Base checkpoint SHA256:** `a7062b55396452139b017d361e690fec70ce21da580150893ce1ea817a38d4f9`

## Current release addendum

The later coordinator revision has now applied and independently reviewed the degree-two recursion repair described below. Current regression passes all 24 inspected targets. The original frozen validation remains 23/24 and its full snapshot is preserved. The discovery-stage discussion below is retained to show exactly why the change was needed.

## Result and validation boundary

The frozen fresh validation recovered 23 of 24 targets. Its remaining target was

\[
Z(s)=\frac{320+1850s+3997s^2+2520s^3}
{256s+1480s^2+1764s^3}.
\]

This separate post-freeze investigation constructs an exact circuit with
**three reactive elements and two resistors**. The inherited independent exact
nodal checker passes the completed circuit at all seven required positive
samples and confirms reduced target degree three. Thus the circuit is minimum
in reactive element count. Minimal total component count is not claimed.

The frozen validation result remains **23/24**. This later resolution of its
remaining case is reported separately and must not be relabeled as an untouched
24/24 validation. No frozen synthesis or checker source was modified. The
generating physical witness was not inspected or supplied to any algorithm in
this continuation. Only the target coefficient arrays were used.

## Exact circuit

The topology is a series capacitor followed by a parallel connection. One
parallel arm is an inductor. The other arm is a series resistor followed by a
parallel resistor and capacitor:

\[
\boxed{
Z(s)=\frac{1}{(4/5)s}
 +\left[
 7s\;\parallel\;
 \left(\frac{10}{7}
   +\left(\frac{6}{35}\;\parallel\;\frac{1}{(147/16)s}\right)
 \right)
 \right].
}
\]

Here `A || B` denotes the impedance of two branches in parallel.

| Element | Physical value | Connection |
|---|---:|---|
| Capacitor | `4/5` | Series with the rest of the circuit |
| Inductor | `7` | One arm of the remaining parallel connection |
| Resistor | `10/7` | Series inside the other parallel arm |
| Resistor | `6/35` | In parallel with the final capacitor |
| Capacitor | `147/16` | In parallel with the `6/35` resistor |

All values are strictly positive rationals. The certificate stores resistor
conductances and inverse inductances, so its branch values are respectively
`4/5`, `1/7`, `7/10`, `35/6`, and `147/16`.

## Derivation from the target coefficients

The pole at the origin has residue

\[
\lim_{s\to0}sZ(s)=\frac{320}{256}=\frac54.
\]

Remove the series capacitor `C0 = 4/5`. Exact subtraction leaves

\[
Z_1(s)=Z(s)-\frac{5}{4s}
 =\frac{s(1792+2520s)}{256+1480s+1764s^2}.
\]

This residual vanishes at the origin. Its admittance has the exposed inductor
term

\[
\frac{1}{Z_1(s)}
 =\frac{1}{7s}+
 \frac{1120+1764s}{1792+2520s}.
\]

Therefore the inductor `L = 7` is in parallel with a residual impedance

\[
W(s)=\frac{1792+2520s}{1120+1764s}.
\]

The remaining degree-one function has the exact RC decomposition

\[
W(s)=\frac{10}{7}+\frac{192}{1120+1764s}
 =\frac{10}{7}+
 \left(\frac{6}{35}\;\parallel\;\frac{1}{(147/16)s}\right).
\]

This uses existing endpoint identities and the existing degree-one Cauer
routine. It does not require a new numerical optimizer or an algebraic root
extension.

## Smallest software obstruction

The inherited recursive dispatcher attempts supported base templates and then
contains the guard

```python
if d <= 2:
    return None
```

The degree-three origin pole is extracted correctly. The resulting degree-two
function misses the limited base charts, so that guard ends the search before
trying its exposed shunt inductor. The same source file already implements the
correct shunt-inductor extraction in `one_reactive_endpoint_candidates`. The
degree-one residual is already handled by `find_cauer`.

Thus the case exposes a premature recursion cutoff. It does not expose a
missing physical synthesis theorem. A future separately validated source
revision can permit endpoint extraction at degree two and stop at degree one.
This continuation deliberately leaves the frozen dispatcher unchanged.

The full-rank cubic graph search also has a separate structural boundary here:
the target denominator has constant coefficient zero. A topology with a
strictly positive constant denominator coefficient cannot realize this target
at strictly positive parameters. Topologies whose constant coefficient
vanishes identically have a coefficient image of dimension at most six in the
seven-coordinate full cubic chart, and the frozen generic rank filter omits
them. That is a limitation of this chart search. The elementary endpoint route
avoids it entirely for the present target.

## A reusable exact sufficient family

The mechanism extends beyond this one case. Let positive rational numbers
`A, B, C, D, E` satisfy

\[
F=D-\frac{CB}{A}>0,
\qquad
\Delta=AE-BF>0.
\]

Then

\[
G(s)=\frac{s(A+Bs)}{C+Ds+Es^2}
\]

has the positive two-reactive realization

\[
G(s)=sL\parallel
\left[R_s+(R_p\parallel 1/(sC_1))\right],
\]

with exact values

\[
L=\frac AC,
\quad R_s=\frac BE,
\quad R_p=\frac{\Delta}{EF},
\quad C_1=\frac{E^2}{\Delta}.
\]

Indeed, the resistor-capacitor arm simplifies directly to

\[
R_s+(R_p\parallel 1/(sC_1))
 =\frac{A+Bs}{F+Es}.
\]

Adding the parallel inductor admittance gives

\[
\frac{C}{As}+\frac{F+Es}{A+Bs}
 =\frac{C+Ds+Es^2}{s(A+Bs)},
\]

because `F + CB/A = D`. This proves the rational identity and component
positivity under the stated strict inequalities.

For any positive rational `kappa`, placing a capacitor `C0 = 1/kappa` in series
constructs

\[
Z_{\kappa}(s)=\frac{\kappa}{s}+G(s)
 =\frac{\kappa C+\kappa Ds+(\kappa E+A)s^2+Bs^3}
 {Cs+Ds^2+Es^3}.
\]

This target has reduced degree three. To see that no cancellation occurs, its
numerator is nonzero at the origin because `kappa*C > 0`. At a root of
`C + Ds + Es^2`, cancellation would require `A + Bs = 0`, but

\[
\left(C+Ds+Es^2\right)\big|_{s=-A/B}
 =\frac{A\Delta}{B^2}>0.
\]

Thus the constructed three-reactive circuit attains the rational degree lower
bound throughout this sufficient family. This is an elementary constructive
family, not a claim of complete boundary classification or research novelty.

For the target above, the parameters are

```
A = 1792, B = 2520, C = 256, D = 1480, E = 1764,
F = 1120, Delta = 338688, kappa = 5/4.
```

## Reproduction and evidence

Run from the project root:

```bash
python3 experiments/boundary_exact_reduction.py
```

The script records the two exact endpoint reductions, the degree-one Cauer
check, every physical component value, the completed portable rational circuit
certificate, and the independent checker result in
`experiments/boundary_exact_result.json`.

Observed checker result: `PASS`, defining field degree one, three reactive
elements, two resistors, seven exact positive samples, reduced target degree
three, and degree-based global reactive minimum true. The observed total
experiment runtime was about 0.011 seconds in this environment. That is a
single-case timing, not a general speed claim.

The result embeds the experiment and checker SHA256 hashes. The frozen topology
source hash remains
`24b76549008080322a0baa1ed00ce84a76bf3203088fefab1cb1d61f22f5284c`.

## Remaining work

The specific boundary miss is resolved. The general boundary-search route
remains open for targets without exposed positive endpoint reductions and for
lower-dimensional graph images that need exact removal of identically zero
equations. No arbitrary equation subset was discarded, and no graph boundary
certificate checker was changed in this investigation.
