# Target-only topology discovery for the four retained cubic misses

**Author: Komorebi P.**  
**Date:** November 11, 2026  
**Base checkpoint:** `Komorebi_RLC_General_Solver_Continuation_2026-11-11.zip`  
**Base SHA256:** `a7062b55396452139b017d361e690fec70ce21da580150893ce1ea817a38d4f9`

## Target and result

The route asks whether the four retained degree-three targets can be recovered
without supplying their archived circuit parameters or topology to a solver.
The old two-chart solver returned `UNKNOWN` for each target. The present route
found strictly positive numerical candidates in seven-component graphs for all
four targets. Three appeared in the first topology sweep. The fourth required a
second numerical start for one graph. An additional eight-component candidate
for the fourth target was found after five graph attempts and rationally fixing
one resistor coefficient. These are proposal-stage outcomes. Exact acceptance
is performed by the separate interval certificate checker and reported in its
certificate records.

The four old holdout cases are now regression data. Neither their recovery nor
the selected search settings constitute a new untouched holdout result. No
claim is made that the computed parameter values are irrational merely because
small-denominator rational reconstruction failed.

## Inputs and independence boundary

The only per-case inputs to the optimizer are the exact ascending coefficient
lists `P` and `Q`. The archived `known_exact_witness` fields are not passed to the
optimizer or used to choose topologies. The numerical source `src/topology_search.py`
does not read a fixture file at all.

The historical source record is `results/holdout_q3.json`, SHA256
`f80da085ae1c2e1398ac70f33791b63f5262fadb62be965365f4a760ce0b445b`.
It supplies the target indices 1, 3, 4, and 21, using zero-based indexing.

## First discriminator: the existing two charts

`experiments/topology_fit_existing.py` tried both inherited seven-component
charts on each miss with 30 starts per chart, at most 1500 function evaluations
per start, seed 2026111219, and a numerical candidate threshold of `1e-10` in
scaled rational-response coefficient coordinates. None reached that threshold.

| Historical index | Best bridge A residual | Best bridge B residual |
|---|---:|---:|
| 1 | 0.0305672 | 0.00929986 |
| 3 | 0.0184360 | 0.0000151838 |
| 4 | 0.121539 | 0.113973 |
| 21 | 0.00886731 | 0.000516773 |

These observations justify changing the search route. They do not prove that a
positive solution is absent from either chart. Several fits approached the
numerical positivity bounds. The complete numerical proposals and settings
are retained in `experiments/topology_existing_candidates.json`.

## Topology catalog and its exact scope

The reusable source enumerates four labeled vertices with ground 0 and port 1.
It chooses three mixed reactive branches on three distinct unordered vertex
pairs and either four or five resistor branches on distinct unordered pairs.
A resistor and a reactive branch may occupy the same pair. Each catalog is
canonicalized under the two terminal swap `0 <-> 1` and the internal vertex
swap `2 <-> 3`.

This canonicalization preserves scalar driving-point impedance: the spanning
tree denominator is label invariant, and the numerator sums spanning forests
with exactly two components, one containing each terminal. Interchanging the
two roots leaves that forest collection unchanged. Parameter order is the
sorted branch tuple order of each canonical graph.

| Catalog | Canonical graph count | Passed numerical generic rank filter |
|---|---:|---:|
| Three mixed reactive branches and four resistors | 468 | 129 |
| Three mixed reactive branches and five resistors | 192 | 74 |

The catalog is not an all-topology enumeration. It excludes extra vertices,
six or more resistor branches, and an inductor and capacitor sharing a single
reactive pair. The numerical rank filter is a search heuristic evaluated at one
deterministic strictly positive parameter point. It is not an exact exclusion
certificate for rejected topologies. A failed bounded search remains `UNKNOWN`.

## Coefficient model

For each graph, enumerate spanning trees and terminal-separating spanning
two-forests. Every monomial is a product of two or three branch admittance
parameters. Multiplication by `s` to the number of inductors removes negative
powers. The resulting numerator and denominator coefficient arrays are
normalized by the leading numerator coefficient, producing seven coordinates.

The search optimizes logarithms of the branch admittance parameters. Thus all
proposals have positive parameters. Differentiation of a monomial in those
coordinates multiplies it by its exponent vector. The implementation has no
symbolic algebra dependency. Numerical fitting uses NumPy and SciPy only. Its
output remains untrusted until the separate exact checker rebuilds the graph.

## Successful proposals

The initial enumeration used one zero start per surviving graph, 220 function
evaluations per fit, and seed 2026111223 for graph ordering. It produced the
following candidates in about 6.95 seconds in this environment:

| Historical index | Catalog index | Scaled coefficient residual | Components |
|---|---:|---:|---:|
| 1 | 459 | `2.22e-16` | 3 reactive + 4 resistors |
| 4 | 376 | `1.91e-13` | 3 reactive + 4 resistors |
| 21 | 208 | `4.06e-13` | 3 reactive + 4 resistors |

Index 3 did not cross the candidate threshold in that first sweep. Its best
scaled residual was about `8.34e-6`. A new multistart run used the reusable
kernel with a cap of five starts and 600 function evaluations per fit. It
reached a candidate in the second start round, after 188 attempts, in about
11.03 seconds. Catalog graph 147 is

```
C(0,2), C(0,3), L(2,3), R(0,2), R(0,3), R(1,2), R(1,3).
```

Its scaled residual was `1.82e-13`. The returned admittance coefficients,
in that order, were approximately

```
0.56514614585, 24.01297885265, 0.05696798615,
0.05490011711, 0.60395404948, 0.01047757539, 0.90618909128.
```

Inductor coefficients here are `h = 1/L`, resistor coefficients are `g = 1/R`,
and capacitor coefficients are `c = C`. These printed decimals are proposals,
not exact physical circuit values. Exact boxes are supplied by the separate
certificate workflow.

The eight-component variant, graph 58 of the five-resistor catalog, found a
candidate after five attempts in about 0.42 seconds. The underdetermined
seven-coordinate solve was made square by fixing resistor coefficient index 6
to the exact rational `29/36`, then refining the other seven parameters. Its
scaled residual was `8.33e-17`. The rational value is chosen by bounded-denominator
rounding of an optimizer output, not by reading the historical witness.
The exact checker must append the equation `x[6] - 29/36 = 0` rather than drop
one of the original target equations.

The three originally eight-component witnesses at indices 1, 3, and 21 have
seven-component proposals here. If accepted by the exact checker, that improves
the available resistor count for those targets. It does not establish globally
minimal total component count. Reactive minimality requires the separate degree
argument and exact physical witness acceptance.

## Frozen reusable interface and validation

`src/topology_search.py` exposes

```
fit_target(P, Q, resistors=4, starts=1, max_nfev=220,
           seed=2026111223, threshold=1e-10, max_candidates=1)
```

Its behavior was frozen for the parent's fresh 24-case validation.
This route did not inspect that corpus. The frozen source SHA256 is
`24b76549008080322a0baa1ed00ce84a76bf3203088fefab1cb1d61f22f5284c`.
The planned fresh-corpus contract uses one start and 220 evaluations for each
topology, first the four-resistor catalog and then the five-resistor catalog.
That contract differs from the deeper historical fourth-case search above.

The tree/forest numerical coefficient model was compared to the independent
inherited SymPy nodal determinant model for both original charts at two positive
parameter vectors. Maximum differences were below `1.8e-15`. Canonicalization
was checked on both transpositions for all 468 seven-component catalog graphs
(936 checks). Those are finite kernel checks, not a new general theorem.

Environment: Python 3.12.14, NumPy 2.3.5, SciPy 1.17.0, SymPy 1.14.0.
`experiments/topology_kernel_validation.json` records hashes and observations.

## Reproduction and records

From the project root:

```bash
python3 experiments/topology_fit_existing.py
python3 experiments/topology_enumerate.py
python3 experiments/topology_replay_fourth.py
```

The first two scripts preserve the original probes. The reusable kernel is in
`src/topology_search.py`; the fourth-case replay script imports it directly.
Raw outputs are `topology_existing_candidates.json`,
`topology_enumeration_candidates.json`, `topology_fourth_multistart.json`, and
`topology_fourth_eight.json` in `experiments/`.

## Remaining scope

The target-specific discovery bottleneck was removed for these four regression
cases. The route remains open for larger graphs, overlapping reactive pairs,
singular coefficient maps, repeated/canceling modes, and an efficient complete
search. No all-topology impossibility certificate, unrestricted synthesis
theorem, or external novelty claim follows from this experiment.

## Exact acceptance reconciliation

All four historical seven-component proposals now have independently accepted exact interval certificates under `certificates/historical_case_1.json`, `historical_case_3.json`, `historical_case_4.json`, and `historical_case_21.json`. The eight-component alternative also passed. Final current-source replay is recorded in `computations/release_001/results.json`. This supplements the numerical discovery record without treating its residuals as certificates.
