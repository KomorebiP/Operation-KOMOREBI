# Independent audit of the RLC interval certificate

**Author: Komorebi P.**  
**Review date:** November 11, 2026, America/Chicago  
**Review provenance:** Independent delegated derivation from the graph definition and raw checker source.  
**Primary verdict:** Proved as written for an accepted certificate under the implemented square full-system restrictions.

## Claim card

An accepted `komorebi-rlc-interval-v1` certificate specifies a finite connected transformer-free graph, one parameter per branch, a rational target, a positive rational component box, and a nonsingular rational preconditioner. It may also declare positive exact values for selected component parameters. The checker certifies a unique exact real parameter vector in that box satisfying the full impedance identity and all declared fixed-parameter constraints. If the actual physical reactive count equals the target's reduced rational degree, it certifies the global minimum reactive count.

Branches use conductance \(g=1/R\), inverse inductance \(h=1/L\), and capacitance \(c=C\). Ground is node zero and the input is node one. Every listed component is strictly positive throughout the box. The checked root need not equal the rational center.

## Audited revision and replay

The final audited core source SHA256 is

```text
538da6d3c897554c2468b3c8c10508d2505374c4e9a007dcf110aa408c711de1
```

The input certificate `certificates/historical_case_1.json` has SHA256

```text
a750210a7d1d4781c45eaaa7b9b539f6b443db38ff77956008a3f58a454bc4f3
```

The target is

```text
P = [150, 630, 2388, 3360]
Q = [175, 810, 1826, 1736].
```

Fresh independent checks were run with

```bash
python3 -S experiments/prior_independent_audit.py
```

The run and exact before/after input hashes are recorded in `experiments/prior_independent_audit.json`. It replayed the certificate with explicit expected-target and expected-budget binding. Its exact contraction bound is approximately \(6.21688\times10^{-8}\), and every strict self-map margin is positive. The number shown here is only a readable approximation; acceptance uses the full rational values in the report.

## Dependency graph

Graph definition and strict positivity imply a positive definite grounded nodal matrix for every positive real Laplace argument. Exact determinant expansions give numerator and denominator polynomials of degree at most the actual reactive count. The rebuilt full coefficient equations imply the exact target identity. A rational-box contraction yields their unique root. The separate degree calculation then gives reactive minimality when the degrees match.

No optimizer status or floating-point residual lies on this implication chain.

## Independent derivation of graph equations

Let \(B\) be the grounded incidence matrix and let \(y_e(s)\) be each branch admittance. Then the grounded nodal matrix is

\[
A(s)=B\,\mathrm{diag}(y_e(s))\,B^T.
\]

Expansion of the determinant gives

\[
\det A(s)=\sum_{|S|=V-1}\det(B_S)^2\prod_{e\in S}y_e(s).
\]

A cycle makes the selected incidence columns dependent. An acyclic selection with \(V-1\) edges is a spanning tree, and repeated leaf elimination gives determinant magnitude one. This is exactly the code's denominator sum.

Deleting the input row from \(B\) gives the port cofactor expansion. A nonzero minor now requires a forest of two components, one containing each deleted root, zero and one. The same leaf argument gives coefficient one. This is exactly the code's numerator sum. Node labels need not be consecutive.

Multiplication by \(s^{n_L}\) clears every inverse power. Each term has exponent \(n_L-\ell+c\), where at most \(n_L\) inductors and \(n_C\) capacitors are selected. The exponent therefore lies in \([0,q]\), where \(q=n_L+n_C\). The code retains all coefficients of \(QN-PD\), including zero equations. It does not choose a favorable subset.

## Independent contraction derivation

Let the component box be \(X=\{x:|x_i-c_i|\le r_i\}\), with every \(r_i>0\), and define \(T(x)=x-YF(x)\). The checker recomputes the polynomial Jacobian and rational interval bounds \(B_{ij}\) for

\[
|\delta_{ij}-(YJ(x))_{ij}|\le B_{ij},\qquad x\in X.
\]

The weighted norm is \(\|v\|_r=\max_i |v_i|/r_i\). Thus

\[
\|T(x)-T(z)\|_r\le
\left(\max_i\frac{\sum_j B_{ij}r_j}{r_i}\right)\|x-z\|_r.
\]

The checked bound is strictly below one. The other exact inequality,

\[
|(YF(c))_i|+\sum_jB_{ij}r_j<r_i,
\]

places \(T(X)\) strictly inside \(X\). Iteration from any point in the complete closed box is Cauchy, has a limit in the box, and converges to a unique fixed point. Since \(Y\) is independently inverted exactly, the fixed-point equation implies \(F=0\).

At that root the positive connected graph has \(D(s)>0\) for \(s>0\). Therefore the coefficient identity gives the claimed rational impedance. The same degree bound applies to every competing topology, so equality of actual reactive count and reduced target degree proves global reactive minimality.

## Obligation matrix

| Obligation | Verdict | Evidence |
|---|---|---|
| Exact rational inputs | Passed | Floats and booleans rejected by rational parser |
| Physical graph and positivity | Passed | Types, nodes, duplicate branches, connectivity and whole-box signs checked |
| Full target equation construction | Passed | Exact tree and forest construction, all coefficients retained |
| Target and budget binding | Passed | Reduced rational cross-identity and independent actual storage count |
| Interval enclosures | Passed | Rational interval products and powers, polynomial derivatives rebuilt |
| Preconditioner nonsingularity | Passed | Exact Gauss-Jordan inversion |
| Existence and uniqueness | Passed | Strict self-map and weighted contraction |
| Exact impedance identity | Passed | All coefficient equations and positive denominator |
| Global minimality | Passed when actual storage equals reduced degree | General tree/forest degree bound |
| Exhaustive topology discovery | Out of scope | Checker validates submitted graph only |

## Independent finite checks

The audit script compared exact graph-polynomial values with independently constructed nodal determinants at three positive rational parameter fixtures and seven rational Laplace points, for 21 pairs. It also checks the shared family joint coefficient construction at twelve rational fixtures. These are implementation controls; the determinant proof supplies the uniform graph identity.

Deliberate changes to the point target, singular preconditioner and nonpositive component box were rejected. Additional family corruption checks are listed in the companion audit.

## Optional fixed-parameter extension

The final checker retains every impedance coefficient equation and appends one equation `x[index] - value = 0` for each fixed parameter. It checks positive exact values, distinct valid indices and equality between the number of all equations and all branch variables. The contraction proof then applies to this complete augmented system without alteration.

The eight-branch certificate `certificates/historical_case_3_eight_branch.json` was separately replayed. All seven impedance coefficient equations remain, with an eighth equation fixing conductance to `29/36`. Direct evaluation checked the additional equation against its independent scalar definition. Removing that equation, changing its value, duplicating it, making its value negative and assigning an out-of-range index were all rejected. Exact results and hashes are in `experiments/prior_fixed_parameter_audit.json`.

For such a certificate, uniqueness is within the box **subject to the fixed-component constraints**. It is not uniqueness among all impedance-matching vectors of the unconstrained eight-variable graph. Existence and the resulting reactive-minimum conclusion do not require that stronger uniqueness claim.

## Remaining boundaries

A rectangular chart is not silently made square by discarding equations. The final implementation requires the augmented system of every impedance coefficient plus declared fixed-parameter equations to be square. The proof establishes uniqueness in this declared domain inside the submitted box, not among all parameter vectors or all topologies.

Failure to certify a box is inconclusive. Singularity, a loose interval bound, a poorly located center or an unsupported chart can all cause rejection without implying physical impossibility. No novelty assertion was examined.

