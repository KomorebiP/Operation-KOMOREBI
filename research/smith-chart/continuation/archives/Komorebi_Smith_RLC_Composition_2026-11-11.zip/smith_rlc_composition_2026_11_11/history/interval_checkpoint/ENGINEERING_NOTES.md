# Engineering decisions and failure record

**Author: Komorebi P.**  
**Date:** November 11, 2026.

## Separation of proposal and acceptance

`topology_search.py` reads only target coefficients and returns numerical proposals. Its floating rank tests, bounds, seeds and optimizer tolerances affect discovery coverage, not mathematical acceptance. `interval_synthesis.py` refines a proposed root using exact rational Newton steps rounded to a fixed rational grid. The center and preconditioner remain untrusted proposals. `interval_certificate.py` rebuilds all graph equations and proves exact existence independently.

The certificate uses g=1/R, h=1/L and c=C. Reported physical R or L intervals require reciprocating and reversing the corresponding positive bounds. Neither a rounded center nor an optimizer vector should be exported as exact physical component values.

## Systematic graph catalog

The four-node catalogs use three mixed L/C branches on distinct pairs and four or five resistor branches on distinct pairs. Port exchange and internal-node exchange are genuine graph symmetries. Counts are 468 and 192. The numerical rank heuristic retains 129 and 74, but its rejections are not proof of absent realizations. The code does not claim to enumerate all minimum RLC topologies.

The old two charts were insufficient in the tested numerical searches. A broader canonical catalog found three old misses on its first sweep. One needed a second numerical start. All four then passed exact interval certification. An eight-branch alternative appends a fixed positive conductance equation and independently checks the whole augmented system.

## Uniform target family

The family checker constructs all coefficients of Q_y*N-P_y*D in fourteen variables, seven component parameters and seven normalized target coordinates. It bounds the contraction uniformly over both boxes. A separate six-by-six Sylvester map certifies coprimality for every target. Small target radii are deliberately explicit. Widening the box is a future optimization, not required for the current theorem.

## The fresh failure and its repair

The sole miss in frozen validation had Q(0)=0. The existing recursive path extracted its series capacitor but stopped at degree two because of `if d<=2:return None`. The degree-two residual has an exposed shunt inductor and a degree-one Cauer remainder. Changing that guard to `d<=1` permits the existing exact endpoint method to finish. Accepted subcircuits and the completed circuit still pass the independent KCL checker.

A deliberately rejected final certificate produced `UNKNOWN` in the independent audit. The repair therefore changes search reachability, not the acceptance standard. Current regression also checks the reciprocal and frequency-inverted orientations.

The generic full-rank cubic chart search has an additional boundary limitation: a graph whose denominator constant term is identically zero has a lower-dimensional coefficient image and fails the seven-dimensional generic-rank filter. This specific case is resolved by endpoint extraction. A general boundary-chart compiler remains future work.

## Frozen evidence and current code

All inputs and outputs of the independent 23/24 experiment were copied intact to `history/frozen_validation/` before the recursion edit. Its provenance manifest validates with that directory as project root. The final current-source 74-target record is under `computations/release_001/`. Their claims and source revisions must remain separate.

The original degree-six closure was recovered from the later proof-carrying package, not inferred from an earlier reading page. Its exact checker, certificate and replay are retained under `experiments/prior_seed/` and the prior-state audit.

## Known limits and next implementation boundary

The root-level dispatcher can fall back to the new interval search on a degree-three target. The inherited recursive module composer still expects its earlier rational/algebraic witness format. It does not yet automatically graft an interval-certified core through arbitrary outer endpoint or module stages. A proof-carrying composition format is a natural next extension and should preserve exact target identities, positivity, node gluing and reactive counts.

More general graph discovery, singular roots, rectangular coefficient systems, exact boundary charts and general lower-budget refutation discovery remain unresolved. Runtime caps and numerical misses must remain `UNKNOWN`.

No source code or proof was fetched from the internet for this continuation. Existing project files, the supplied images, exact derivations and local computations were the working evidence. This does not establish literature novelty.
