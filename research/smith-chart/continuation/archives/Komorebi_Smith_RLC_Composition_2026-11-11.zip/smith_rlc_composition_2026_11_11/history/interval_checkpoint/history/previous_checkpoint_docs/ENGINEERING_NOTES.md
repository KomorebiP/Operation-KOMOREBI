# Engineering notes, failure analysis, and next solver architecture

**Author: Komorebi P.**  
**Status:** Implementation notes and research continuity record, 11 November 2026.

## Current pipeline

1. Validate exact rational coefficient input and reduce by its rational polynomial gcd.
2. Attempt Cauer RC/RL ladders, including relevant reciprocal impedance orientations. These use exact rational long division and physically positive component calculations.
3. Attempt high-frequency two-element extractions whose residual is a Cauer ladder. The primary case identifies a shunt resistor and a series inductor from the first noncancelling coefficients.
4. For reduced degree three, attempt exact rational-root elimination of a four-node mixed bridge. This is a sufficient template, not a completeness result.
5. For reduced degree three, attempt two sparse seven-component bridge charts. SciPy is used only to propose numerical component conductances/capacitances. Reconstruct bounded-denominator rationals and require independent exact circuit verification before accepting.
6. If no base circuit is found, recurse over four one-reactive endpoint extractions, two composite endpoint extractions, exact rational-pole modules, and suitable mixed quadratic RLC modules. Admittance-parallel variants are also considered.
7. Every successful full circuit is checked by independent rational/real-algebraic KCL at `n+q+1` distinct positive real Laplace points. Physical element signs and storage count are checked. Degree equality `q=n` proves minimum reactive count.
8. Otherwise return `UNKNOWN`, optionally passing the same target to the previous all-topology solver if explicitly configured. Never promote raw solver UNSAT or a failed optimizer to a theorem.

The general solver, prior interval Newton machinery for the original six-state seed, and the previous portable infeasibility-certificate checker remain separate. This package extends the *constructive front-end*, not their completeness.

## Why the hard cubic was easy after identifying the right structure

An irreducible cubic denominator defeated rational-pole stripping. Its leading coefficients nevertheless expose `g = Q3/P3` at a positive shunt conductance and, after removing that shunt path algebraically, `L = P3/T2` at a positive series inductor. The residual is the exact RC function `(7+12s)/(1+25s+36s²)`. Cauer inversion synthesizes it without algebraic root extraction. The full original function is then an elementary shunt resistor / series inductor / RC network with no transformer. This is a classical extraction principle applied in an exact dispatcher.

## Numerical proposal versus proof

The two sparse bridge searches optimize strictly positive variables in log-admittance coordinates. Their numerical model uses seven dimensionless rational-response coefficients, not an arbitrary frequency sweep. This is **proposal generation only**. The candidate parameters are converted to bounded-denominator Fractions and passed to `algebraic_witness.py`, which rebinds the target and recomputes the network's exact rational behavior. If a rounded numerical value is not the exact solution, it is rejected. Algebraic irrational solutions outside these bounded rational charts can be missed.

The full-rank Jacobian tests prove local coefficient-chart existence near two known points, but they do **not** supply machine-certified component values for arbitrary nearby targets. Extending the contraction/interval certificate method from the six-state seed to these q=3 topologies is a valuable next step.

## What did not work

* Sending all 3-L/C placements and positive continuous branch values to one global SMT system produced `UNKNOWN` on a simple irreducible cubic at a 500 ms limit. The original model used 8 node slots and 84 continuous branch variables.
* Direct symbolic Gröbner elimination over five remaining parameters in a fixed q3 bridge was too expensive in a bounded attempt. Using endpoint ratios to remove three variables reduced the same problem to a two-variable resultant, and a rational exact solution was found.
* The new solver misses four physically realizable cases in the 50-target holdout. These are preserved with actual complete circuit witnesses. They are not weak positive-real targets, and they refute any blanket claim of coverage of all 4-node q3 networks.
* Rational reconstruction will not accept a correct nonrational solution without a separate exact algebraic or interval certificate.

## Recommended next steps in order

**A. Generalize exact sparse q3 witnesses to algebraic numbers.** Develop rational interval Newton/Krawczyk certificates around numerical seeds, with independent checking of the 7 coefficient equations and strict component positivity. This closes the rational-parameter bottleneck and gives constructive local inverses beyond special rational targets. Retain the prior six-state certificate machinery, which already implements exact fixed-point acceptance.

**B. Replace selected templates with symmetry-reduced sparse graph discovery.** Generate four- to six-node candidate graphs and classify by reactive count, degree visibility, source-containing biconnected core, Cauchy index, Foster minimum functions, and endpoint connectivity. Fit only the surviving sparse topology classes. Never infer global impossibility from bounded node searches.

**C. Polynomial feature design and elimination.** For each selected graph, derive nodal tree/forest polynomials symbolically, use exact DC/high-frequency ratios to eliminate parameters, and retain independent target coefficient equations. This is the central improvement suggested by the successful 2-variable bridge reduction.

**D. Fully independent global lower-bound certificates.** Bring the previous proof-carrying sparse polynomial refutation checker into the same solver and develop automatic sums-of-squares or other Positivstellensatz-style certificate search. A restricted-topology refutation must carry its scope; no restricted result may be labeled globally UNSAT.

**E. Benchmarks that prevent overfitting.** Preserve the fixed holdout seed as historical evidence. Add new holdouts with five-to-ten nodes, noninteger rational values, nonrational algebraic component values, minimum-function boundaries, exact degeneracies, repeated poles, near-cancellations, and noisy measured frequency samples. Separate exact synthesizability from model fitting.

**F. Practical engineering.** After mathematical witness acceptance, execute SPICE with nonideal component models, quantify sensitivity to ESR/ESL and temperature, optimize bandwidth, noise, voltage/current ratings and tolerance. Minimum reactive count is not synonymous with minimum cost or performance-optimal hardware.

## Key distinctions

* **Degree bound** establishes a global reactive minimum only when an exact degree-matching physical circuit is constructed.
* **Positive-realness** alone establishes some passive realization, not degree-matching or minimal total components.
* **A numerical candidate** is not an exact circuit until independent proof checks all component values and the full rational identity.
* **`UNKNOWN`** means a search method did not certify a result, not that the target is unrealisable.
* **Local full rank** establishes an open image, not a uniform global inverse algorithm.
* **The two 7-element charts** were selected using development failures; use the separate holdout figure when discussing empirical generalization.

## Prior literature and originality

Foster/Cauer and Brune/Bott-Duffin methods are classical. Hughes (arXiv:1611.06258; IEEE TAC 2017) establishes minimum-function obstructions and unavoidable excess storage. Hughes, Morelli and Smith (SCL 2020) establish genericity via coefficient-map Jacobians. Exact elimination of a particular topology is a reproducible calculation, but research publication priority of these formulas or chart choices has not been established.
