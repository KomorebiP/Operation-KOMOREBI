# Verified results and benchmark interpretation

**Author: Komorebi P.**  
**Date:** 11 November 2026

## Functional regression

`python src/test_next.py` completed with **67 passing test groups**:

| Group | Passing groups | Independent acceptance |
|---|---:|---|
| Exact rational Cauer RC/RL/reciprocal synthesis | 48 | Actual nodal impedance verified |
| Irreducible degree-three endpoint target | 1 | Original physical witness and recovered witness verified |
| Series passive rational modules | 4 | Exact combined circuit |
| Admittance-parallel passive modules | 3 | Exact combined circuit |
| Nested coupled endpoint extensions | 2 | Exact minimum reactive count |
| Two sparse coupled bridge witnesses | 2 | Exact rational certificates independent of optimization |
| Controls for corruption, Hughes counterexample, invalid PR, cutoff | 7 | Rejection or `UNKNOWN` |
| **Total** | **67** | **All passed** |

`python src/check_sparse_rank.py` independently passes two exact determinant evaluations:

* Bridge A: `801/134456`.
* Bridge B: `-2299/2097152000`.

The determinants are defined using the coefficient-coordinate ordering given in the proof note; they are not frequency-domain error scores.

## Development corpus: 60 known-positive four-node, degree-three graphs

All were generated as positive physical circuits with exactly three mixed reactive elements. Their exact rational target coefficients were calculated using independent nodal determinants, and then supplied to the inverse solver without passing the circuit topology.

The measured sequence during development was:

| Successive solver stage | Exactly certified | Total |
|---|---:|---:|
| Earlier factor-and-degree-two method | 36 | 60 |
| Add Cauer and one-reactive/endcap extraction | 57 | 60 |
| Add exact rational-root bridge elimination | 58 | 60 |
| Add two sparse positive-parameter bridge charts | **60** | **60** |

**Important:** The two sparse chart shapes were selected after inspecting failures in this same corpus. This final **60/60 is development coverage**, not a statistically independent validation of broader generalization. The stages were exercised during code development, and only the final full source/test state is archived here. For the final cases and exact physical baselines see `results/independent_graph_q3.json`.

## Distinct-seed holdout: 50 independently generated circuits

The new seeded run is in `src/holdout_q3.py` and `results/holdout_q3.json`. Its sampling differs from the development corpus: four vertices, three mixed reactive elements (1L+2C or 2L+1C), three to five resistors, and integer component values 1 to 7. Invalid/non-degree-three graphs were skipped before testing.

* **50** valid independently verified target circuits.
* **46** recovered and independently exact-certified by the synthesis dispatcher.
* **4** returned `UNKNOWN` despite separately verified physical three-reactive witnesses.
* Holdout success fraction for this finite sampling scheme: **46/50 = 92%**.

No confidence interval or universal coverage claim is inferred. The known-witness values in the results file are **ground truth for audit**, not provided as arguments to the solver. The four misses are retained without adjusting the solver or the holdout seed.

## Unrestricted SMT comparison (one explicit target)

Target: `P=[28,52,100,144]`, `Q=[11,113,169,36]`, degree three. The two cubic polynomials are irreducible over the rationals.

* Earlier unrestricted q=3 Z3/SMT call, full 8-node bound, 84 continuous branch variables, seven exact samples: `UNKNOWN` at 500 ms, about 0.584 seconds observed total. This **is not UNSAT**.
* New dispatcher endpoint/Cauer route: `CERTIFIED_MINIMUM`, about 0.020 seconds observed for one run, including exact independent checking. It uses three reactive elements.

These timings are one-environment observations for one problem, not representative speedups or asymptotic guarantees.

## Known negative findings and incomplete work

1. A direct five-variable Gröbner basis for one three-reactive bridge was attempted and did not complete within the bounded execution. A lower-dimensional symbolic reduction to two variables worked and its rational-root witness passed exact KCL verification.
2. The numeric sparse bridge methods may produce excellent near-fits but return `UNKNOWN` unless an exact rational candidate is independently verified. They do not issue approximate success certificates.
3. Four holdout cases have known exact physical realizations but have not been discovered by these sufficient inverse templates. They are retained as concrete targets for future search, not proof gaps in the accepted witnesses.
4. All-topology exact mixed-RLC UNSAT discovery, proof-carrying algebraic nonrational roots for the sparse charts, and scalable arbitrary-target minimum synthesis remain unresolved.
5. No physical SPICE run, electronics manufacturing study, tolerance/thermal/noise optimization, or research-priority audit was performed.

## Reproduction

```bash
python src/test_next.py
python src/check_sparse_rank.py
python src/dispatch.py examples/hard_coupled_q3.json
PYTHONPATH=src python -c 'from holdout_q3 import run; print({k:v for k,v in run(limit=50).items() if k != "cases"})'
```

To minimize confusion, **only exact independent checker acceptance** is counted as a synthesized circuit. Unknown and model-discovery failures are recorded separately.
