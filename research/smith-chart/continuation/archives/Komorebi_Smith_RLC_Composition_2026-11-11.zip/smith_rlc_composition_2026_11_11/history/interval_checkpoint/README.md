# Komorebi Smith chart and RLC continuation

**Author: Komorebi P.**  
**Checkpoint:** November 11, 2026  
**Status:** Exact interval synthesis, systematic sparse graph proposals, a certified local family, and a repaired endpoint recursion. The unrestricted minimum-RLC synthesis problem remains open.

## Start here

Read `REPORT.md` for the results and their limits, `THEOREMS_AND_PROOFS.md` for the mathematical map, and `HANDOFF.md` before continuing development. `CONTINUITY.json` records the checkpoint, ancestry, evidence and next work in machine-readable form.

The starting point is the exact cubic in the supplied images:

\[
Z_3(s)=\frac{144s^3+100s^2+52s+28}{36s^3+169s^2+113s+11}
=\left[\frac14+\frac1{s+(12s+7)/(36s^2+25s+1)}\right]^{-1}.
\]

The two expressions were checked identically. That established result is retained, not counted as a new result of this continuation.

## Current results

| Evidence | Result | Interpretation |
|---|---:|---|
| Historical 50-target corpus | 50/50 certified, previously 46/50 | Regression after using its four failures during development |
| Fresh 24-target run with frozen source | 23/24 certified, previous solver 21/24 | Independent finite validation at one start and 220 evaluations per graph |
| The same 24 after endpoint repair | 24/24 certified | Post-validation regression, not a replacement for the frozen 23/24 result |
| Inherited regression suite | 67 groups pass | Existing constructive routes and rejection controls |
| New interval kernel suite | 41 groups pass | Eight positive groups and 33 rejection controls |
| Portable current certificate index | 10/10 replay | Seven interval circuits, two rational circuits and one uniform family |
| Original degree-six seed | Exact six-reactive witness replays | Its old six-versus-seven question was already closed |

All accepted circuits have independently checked exact identities. For the cubic examples, three physical reactive elements equal the reduced degree and therefore attain the global reactive lower bound. Minimum resistor count and minimum total component count are separate questions.

## Use the solver

Python 3.11 or newer is recommended. The tested environment used Python 3.12.14, SymPy 1.14.0, NumPy 2.3.5 and SciPy 1.17.0. The acceptance kernels and certificate replay require only the Python standard library.

```bash
python3 -m pip install -r requirements.lock.txt
python3 src/dispatch.py examples/holdout_unknown_q3.json --output results/my_result.json
python3 src/dispatch.py examples/boundary_degree_two_recursion.json
```

Targets are JSON objects with exact rational `P` and `Q` coefficient arrays in **ascending** powers of `s`. Numeric search proposes component values. A successful response requires an exact checker acceptance, never a residual threshold alone.

The current graph-search defaults are two starts and 600 evaluations per topology, in four-node catalogs containing three mixed reactive branches and four or five resistors. Numerical rank filtering is heuristic. The frozen fresh benchmark deliberately used the smaller preregistered limit of one start and 220 evaluations. Use `--topology-starts`, `--topology-evaluations`, or `--skip-interval-search` to control that stage.

The older general solver remains optional through `--legacy-src`. It is not included as an installed dependency. Without it, unsupported inputs return `UNKNOWN`, with the restricted search scope recorded.

## Replay without numerical dependencies

```bash
python3 -S src/replay_new_certificates.py
python3 -S src/test_interval_core.py
cd experiments/prior_seed
python3 -S src/verify_exact_six.py
```

The certificate center is a rational approximation. The exact circuit is the unique root specified by its certified rational box. Interval acceptance does not itself establish that any component is irrational.

## Reproduce the current regression

```bash
python3 experiments/run_release_checks.py --output results/release_rerun.json
```

To reproduce the original fresh experiment with its exact frozen implementation, run from `history/frozen_validation/`:

```bash
python3 experiments/run_fresh_holdout.py --output results/fresh_rerun.json
```

The archived result and version-two provenance manifest remain under that snapshot's `computations/fresh_holdout_001/`. The current release record is `computations/release_001/`. Do not validate the old manifest against current source after the documented endpoint fix.

## Package map

* `src/`: current synthesis, exact checking and regression code.
* `certificates/`: ten indexed portable certificates with external target bindings.
* `reports/`: complete proofs, independent audits, source recovery, topology scope and boundary derivation.
* `experiments/`: target generation, discovery records, failed searches, independent audit code and the original six-reactive seed.
* `computations/release_001/`: final current-source regression and provenance.
* `history/frozen_validation/`: unchanged inputs and outputs for the independent 23/24 run.
* `history/Komorebi_RLC_General_Solver_Continuation_2026-11-11.zip`: exact prior checkpoint.
* `figures/`: the exact boundary-circuit schematic, generated only in Python.

The research and reading material remain unpublished in this checkpoint. The proof scope and empirical limitations are carried explicitly in the report.
