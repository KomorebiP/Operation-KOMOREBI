# Komorebi RLC synthesis: exact higher-order fast paths

**Author: Komorebi P.**  
**Date:** November 11, 2026  
**Status:** Tested proof-carrying engineering research prototype. **Not** a complete unrestricted minimum-RLC synthesis engine.

This package extends the previous exact degree-two inverse charts with:

1. A rational-arithmetic RC/RL Cauer ladder synthesizer at arbitrary degree, without factoring poles.
2. Four one-reactive endpoint extractions, plus shunt-resistor/series-inductor and series-resistor/shunt-capacitor pairs that can be applied recursively.
3. Exact positive two-reactive RLC modules for selected irreducible quadratic factors, in both impedance-series and admittance-parallel orientations.
4. An exact bivariate resultant inverse for one fully coupled, four-node, three-reactive bridge.
5. Two positive seven-component degree-three bridge charts with certified full-rank Jacobian points, numerical *proposal* search, rational reconstruction, and an independent **exact** KCL acceptance checker.
6. Recorded holdout failures, controlled UNKNOWN status, and an optional dispatcher path to the previous generic solver.

## Installation and replay

Python 3.11+ recommended. `cauer_ladders.py`, the exact algebraic witness checker, and the Cauer tests are standard-library only. All bridge and factor-search modules use `sympy`. The sparse q3 proposal stage additionally requires `numpy` and `scipy`.

```bash
python -m pip install -r requirements.txt
python src/dispatch.py examples/hard_coupled_q3.json --output results/my_hard_q3.json
python src/cauer_ladders.py examples/degree8_rc_ladder.json
python src/bridge_three_reactive.py examples/bridge_three_node.json
python src/test_next.py
python src/check_sparse_rank.py
PYTHONPATH=src python -c 'from holdout_q3 import run;print(run(limit=50)["certified"])'
```

To try the previous generic fallback on a target not covered here:

```bash
python src/dispatch.py examples/holdout_unknown_q3.json \
  --legacy-src /path/to/smith_proof_carrying_2026_11_11/src \
  --timeout-ms 1000 --max-budget 3
```

The legacy package is **not bundled** here: the flag requires the previously supplied proof-carrying release and its dependencies. If unavailable, the dispatcher returns `UNKNOWN`, without inventing an infeasibility certificate.

## Main demonstration

A physically positive but earlier unsupported degree-three target has

```
P (ascending) = [28, 52, 100, 144]
Q (ascending) = [11, 113, 169, 36]
```

Both cubic polynomials are irreducible over the rationals. The exact endpoint inverse identifies a 4-ohm shunt resistor (`g=1/4`), an inductor `L=1` in series with a two-reactive RC remainder, then generates and independently checks the completed circuit. No factored rational roots are required. Degree three supplies the *global lower bound* of three reactive components, so the checked circuit is minimum reactive for this target.

## Test interpretation

* `results/test_next.json`: 67 regression groups; *passing fixture tests*, not 63 new theorems.
* `results/independent_graph_q3.json`: 60/60 *development* graph cases resolved. The last two sparse templates were selected on failures in this very development corpus, so this is an **in-sample** result.
* `results/holdout_q3.json`: 46/50 separate random-seed four-node q3 inputs solved. The four remaining inputs contain known separately verified three-reactive witnesses, and our solver reports UNKNOWN on them.
* `results/sparse_rank.json`: two exact symbolic determinant checks, providing full-rank local chart points.

The input domain in these benchmarks is finite four-node positive networks with three mixed L/C branches and three to five resistor branches, values drawn from small integers. Results cannot be extrapolated to all positive-real degree-three functions, higher node counts, or physical manufacturing performance.

## Status semantics

`CERTIFIED_MINIMUM` requires a valid positive physical circuit, exact verification and reactive count equal to reduced target degree. `UNKNOWN` includes absent templates, numerical optimization misses, and timeouts; it **never** means impossibility. This release does not discover general mixed-RLC global UNSAT proofs. Hughes’s known biquadratic minimum-function counterexample correctly remains UNKNOWN in this fast-path-only package rather than receiving a false degree-two certificate.

All code and mathematical records have detailed comments and reproducibility metadata. See `THEOREMS_AND_PROOFS.md`, `ENGINEERING_NOTES.md`, `RESULTS.md`, and `HANDOFF.md`.
