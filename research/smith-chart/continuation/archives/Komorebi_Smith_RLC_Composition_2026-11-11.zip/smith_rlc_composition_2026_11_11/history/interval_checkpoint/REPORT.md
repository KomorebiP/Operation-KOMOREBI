# Smith chart continuation: exact circuit discovery beyond rational reconstruction

**Author: Komorebi P.**  
**Date:** November 11, 2026  
**Checkpoint:** `smith-rlc-interval-2026-11-11`

## 1. What this continuation achieves

The four previously unresolved circuits in the latest 50-case corpus now have exact, positive, three-reactive realizations. A new interval certificate removes the requirement that numerical proposals reconstruct to small rational component values. Systematic graph enumeration replaces reliance on just two selected bridge shapes. An explicit seven-dimensional neighborhood of cubic targets now has a uniform exact realization certificate.

Fresh validation also found and isolated a real software defect. The recursive solver stopped at degree two before trying an endpoint reduction that it already knew how to perform. Correcting that cutoff recovered the last new test target as a simple five-element circuit. The correction was independently reviewed and its acceptance path was deliberately forced to fail as a control. It then returned `UNKNOWN`, confirming that the exact verifier remains mandatory.

This is a completed solver and proof checkpoint. It does not complete unrestricted minimum-RLC synthesis, prove that every positive-real degree-n function has an n-reactive realization, or establish publication priority for these methods.

## 2. Starting from the latest chat result

The supplied images specify

\[
Z_3(s)=\frac{144s^3+100s^2+52s+28}{36s^3+169s^2+113s+11}
\]

and the decomposition

\[
Z_3(s)=\left[\frac14+
\frac1{s+\frac{12s+7}{36s^2+25s+1}}\right]^{-1}.
\]

Exact symbolic subtraction gives zero. The physical interpretation is the existing 4-ohm shunt resistor, series inductor of value one, and two-reactive RC remainder. The current dispatcher again certifies the complete target. The image hashes and identity check are in `reports/IMAGE_BASELINE_CHECK.json`, and the portable circuit is `certificates/image_baseline_cubic.json`.

The project history was also reconciled. The older reading archive's six-versus-seven bound was already superseded by the later degree-six certificate. Fresh replay confirms a circuit with three inductors, three capacitors and seven resistors, so its minimum reactive count is six. That original checker and certificate are retained in `experiments/prior_seed/`. This is preserved earlier work, not a new six-reactive discovery.

## 3. Exact acceptance of real component roots

The earlier sparse charts could locate a near-fit but would accept it only when all parameters reconstructed to exact bounded-denominator fractions. The new certificate specifies a positive rational box and a rational preconditioner. Its checker independently regenerates the network's numerator and denominator from its graph and requires every coefficient of

\[
Q(s)N(s,x)-P(s)D(s,x)=0.
\]

No equation or derivative supplied by the optimizer is trusted. For a square system F, the checker establishes that

\[
T(x)=x-YF(x)
\]

is a strict contraction mapping the entire rational box into itself. All acceptance bounds use integer and Fraction arithmetic. The resulting exact root determines positive conductances, inverse inductances and capacitances. The printed center is only an approximation to that root.

The certificate proves the complete rational impedance identity. A small numerical error or frequency-sample fit is never the acceptance criterion. For eight-branch charts, one component can be fixed to an exact positive rational. Its constraint is appended after all impedance coefficient equations, and uniqueness is asserted subject to that fixed constraint.

The full proof, including a direct derivation of the tree and forest identities and the reactive degree bound, is in `reports/INTERVAL_CHECKER_NOTES.md`. Independent review is in `reports/INTERVAL_INDEPENDENT_AUDIT.md`.

## 4. Systematic discovery and the four recovered cases

The new search constructs canonical four-node graphs with three mixed reactive branches and either four or five resistor branches. It identifies graphs under exchange of the two terminals and exchange of the two internal vertices. There are 468 and 192 canonical graph shapes in these declared catalogs. A numerical generic-rank heuristic retains 129 and 74 for fitting. Failure of that heuristic is not a topology exclusion theorem.

All four historical misses were recovered in seven-component graphs, each containing three reactive elements and four resistors. A separately certified eight-component alternative tests the fixed-parameter extension. Numerical discovery sees only the target coefficient arrays. Each proposed graph must then pass the independent interval checker.

The original two charts still failed to reach the proposal threshold for these four cases after 30 starts per chart and 1,500 evaluations per start. The first single-start catalog sweep also missed one case. A second start found it. These failures and the changed search mechanism are retained in `reports/TOPOLOGY_ROUTE.md` and the associated experiment records. None is interpreted as physical impossibility.

## 5. An explicit uniform local family

The interval result was extended from individual inputs to an entire coefficient box. Write

\[
P_y(s)=y_0+y_1s+y_2s^2+y_3s^3,
\qquad Q_y(s)=y_4+y_5s+y_6s^2+s^3.
\]

Around the recovered target

\[
\frac{3360s^3+2388s^2+630s+150}
{1736s^3+1826s^2+810s+175},
\]

the certificate gives a seven-dimensional rational target box and a common positive component box. For every real target vector in that box, the same graph has a unique component root inside the component box and exactly three reactive elements suffice.

The target center is the monic-denominator normalization. Each target radius is

\[
\rho_i=10^{-10}\max(1,|a_i|).
\]

Component radii use `10^-5 * max(1,|c_i|)`, where the exact rational component center is stored in the certificate. The common contraction bound is approximately 0.2433401354. A separate exact Sylvester-matrix bound

\[
\frac{211787599}{223125000000000}<10^{-6}
\]

proves numerator-denominator coprimality throughout the target box. Hence every target there retains reduced degree three, and the constructed three-reactive circuit is globally minimum in reactive count.

This is a uniform statement over all real coefficient choices in the box, not a claim inferred from finitely many sampled targets. It is local to this specified graph and neighborhood. Exact data are in `certificates/local_family_case_1.json`, with a complete independent proof review in `reports/FAMILY_INDEPENDENT_AUDIT.md`.

## 6. Fresh validation and the endpoint repair

The fixed new sampling scheme generated 24 independently checked positive circuits: twelve four-node and twelve five-node graphs, each with three reactive elements, four or five resistors, and fractional positive component values. The inverse solver received only their target coefficients. The source was frozen and hashed before the run.

| Stage | Four-node cases | Five-node cases | Total |
|---|---:|---:|---:|
| Previous solver on the fresh set | 11/12 | 10/12 | 21/24 |
| New graph and interval search, frozen run | 12/12 | 11/12 | 23/24 |
| Current source after inspecting and fixing the last failure | 12/12 | 12/12 | 24/24 |

The **23/24** result is the independent validation result. The **24/24** result is later regression. The exact frozen code, input data, output and provenance remain in `history/frozen_validation/`. The initial run used one start and 220 evaluations per topology, smaller than the current dispatcher's default search allowance.

The remaining fresh target was

\[
Z(s)=\frac{2520s^3+3997s^2+1850s+320}{1764s^3+1480s^2+256s}.
\]

Its origin pole exposes a series capacitor `C0=4/5`. The residual exposes a shunt inductor `L=7`, and the final degree-one function has an exact RC realization. The complete circuit is

\[
Z(s)=\frac{1}{(4/5)s}
+\left[7s\parallel
\left(\frac{10}{7}+\left(\frac{6}{35}\parallel\frac{1}{(147/16)s}\right)\right)\right],
\]

where `A || B` means parallel impedance. All five elements are positive: two capacitors, one inductor and two resistors. The degree-three target requires at least three reactive elements, so the construction attains that lower bound. Minimum total component count is not asserted.

The only functional recursion correction was changing the early stop from `d <= 2` to `d <= 1`. The complete independent KCL check remains required at every accepted graft and at the final return. The original circuit, its reciprocal, its frequency inverse and its combined reciprocal/frequency inverse all pass the final regression.

The derivation also supplies an infinite sufficient family. For positive rational A, B, C, D, E, kappa, let

\[
F=D-\frac{CB}{A}>0,\qquad \Delta=AE-BF>0.
\]

Then

\[
\frac{\kappa}{s}+\frac{s(A+Bs)}{C+Ds+Es^2}
\]

has the same positive three-reactive topology with

\[
C_0=1/\kappa,\quad L=A/C,\quad R_s=B/E,
\quad R_p=\Delta/(EF),\quad C_1=E^2/\Delta.
\]

The proof includes exact noncancellation, so the entire stated family has minimum reactive count three. See `reports/BOUNDARY_ROUTE.md` and `reports/BOUNDARY_INDEPENDENT_AUDIT.md`.

## 7. Final verification and current boundary

The current release freshly certifies all 50 historical targets and all 24 post-validation regression targets. It also passes 67 inherited assertion groups, 41 interval-kernel groups, four endpoint orientations and ten indexed portable certificate replays. The kernel controls include 64 exact tree/forest versus independent KCL comparisons, 49 exact Jacobian checks, and 33 rejection cases. Independent audit scripts additionally verify the uniform-family equations, coprimality matrix, fixed constraints and deliberate acceptance failures.

Both the frozen validation and final current-source run have completed version-two provenance records with input hashes before and after execution. Successful execution is interpreted together with exact acceptance, not as a theorem by itself. The circuit schematic was generated in Python from the exact five-element topology.

Remaining work is concrete: efficient discovery beyond the four-node sparse catalogs, singular and lower-dimensional coefficient images, composition of interval-certified cores through the existing outer module recursion, and automatic general lower-budget refutations. No general infeasibility result is inferred from `UNKNOWN`. This checkpoint establishes broader exact construction and a specific uniform family while preserving those open boundaries.
