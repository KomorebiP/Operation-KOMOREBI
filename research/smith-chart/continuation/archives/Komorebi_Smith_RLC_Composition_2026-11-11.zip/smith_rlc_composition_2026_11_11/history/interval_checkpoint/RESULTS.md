# Results and evidence status

**Author: Komorebi P.**  
**Date:** November 11, 2026.

| Record | Exact result | Status |
|---|---|---|
| `computations/release_001/results.json` | 50/50 historical and 24/24 post-validation targets certified | Current regression |
| `history/frozen_validation/computations/fresh_holdout_001/results.json` | 21/24 old baseline, 23/24 new solver | Independent frozen validation |
| Same frozen run, four-node subset | 11/12 to 12/12 | Independent finite validation |
| Same frozen run, five-node subset | 10/12 to 11/12 | Independent finite validation |
| `src/test_next.py` | 67 groups pass on current source | Inherited regression |
| `src/test_interval_core.py` | 41 groups pass, including 33 rejection controls | Exact kernel implementation controls |
| `certificates/INDEX.json` | 10 entries replay | Seven interval circuits, two rational circuits, one uniform family |
| `reports/FAMILY_INDEPENDENT_AUDIT.md` | Every real target in the specified seven-dimensional box has minimum q=3 | Uniform proof and exact certificate |
| `experiments/boundary_exact_result.json` | Five-element circuit, three reactives, exact identity | Post-validation construction |
| `reports/BOUNDARY_INDEPENDENT_AUDIT.md` | Full sufficient-family identity and degree proof | Independent audit |
| `experiments/prior_seed_replay.json` | Original degree-six target has minimum q=6 | Preserved prior result, freshly replayed |

The release run took approximately 59.5 seconds in the recorded environment, including all 74 target calls, the four boundary orientations, the inherited suite and portable certificate replay. The frozen 24-case experiment took approximately 15.0 seconds excluding runner setup. These are observations for these runs, not asymptotic or broad performance claims.

The final boundary repair follows inspection of a fresh-test failure. It must not be used to rewrite the independent 23/24 result. Both the original implementation and its output bytes remain available in the frozen snapshot. The current 24/24 count is explicitly regression.

Numerical topology ranks and optimization residuals are only discovery heuristics. Every accepted result requires exact independent checking. `UNKNOWN` remains inconclusive. No fresh data or failed graph search supplies a general impossibility theorem.
