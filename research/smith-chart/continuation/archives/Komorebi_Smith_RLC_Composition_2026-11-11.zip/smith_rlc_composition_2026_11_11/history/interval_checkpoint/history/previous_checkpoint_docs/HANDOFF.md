# Continuity and handoff

**Author: Komorebi P.**  
**Date:** November 11, 2026.

## Current checked status

The previous project had: an exact degree-six transformer-free circuit with six reactive elements, arbitrary-degree constructed families, a local inverse, proof-carrying rational/algebraic circuit witnesses, and two degree-two algebraic fast paths. The remaining general global RLC synthesis and independent UNSAT discovery problems are still open.

This continuation supplies a new **factorization-free RC/RL ladder synthesis**, endpoint reductions, conjugate-quadratic RLC module stripping, exact q3 bridge elimination, and two sparse q3 full-rank template charts. The new dispatcher returns independently verified exact minimum-reactive circuits when its physical storage count equals the input rational degree, otherwise `UNKNOWN`.

## Checkpoint results

* `src/test_next.py`: 67/67 regression groups PASS.
* `src/check_sparse_rank.py`: two exact nonzero q3 Jacobian determinants PASS.
* `results/independent_graph_q3.json`: development cases 60/60 synthesized and verified. **In-sample after template selection.**
* `results/holdout_q3.json`: distinct seed, 50 known physical q3 circuits: **46 solved, 4 UNKNOWN**; every underlying physical witness separately passed.
* Old unrestricted Z3 q3 on irreducible cubic: UNKNOWN after 500 ms, while new direct endpoint method certified the circuit.
* `examples/hard_coupled_q3.json` and `examples/holdout_unknown_q3.json` are useful regression inputs. The latter is a legitimate unsolved inverse case, **not an impossible circuit**.

## Reproduction

```bash
python -m pip install -r requirements.txt
python src/test_next.py
python src/check_sparse_rank.py
python src/dispatch.py examples/hard_coupled_q3.json
PYTHONPATH=src python -c 'from holdout_q3 import run; d=run(limit=50); print(d["certified"],d["unknown"])'
```

The `src/` directory contains all code needed for these tests. The optional older generic fallback is *not bundled* and requires the earlier proof-carrying release. No website or GitHub content was modified.

## Immediate next concrete assignment

Implement independent rational interval Newton certificates for full-rank seven-component q3 chart roots, then use canonical labeled 4/5-node reactive graph enumeration and established endpoint/sensitivity pruning to find appropriate charts without manually selecting them from previously failed examples. Use the retained four holdout misses as baseline cases; do not train against them and subsequently report them as untouched holdouts.

## Standards for future releases

Keep all source code, full proof scope, positive/candidate/UNKNOWN statuses, independent exact proof replay, deliberate corruption tests, test matrices, module interconnections and all negative results in the archive. Only certify a global minimum via degree equality or a separately checked *global* lower-budget refutation. Never treat a failed topology family as all-topology impossibility. Maintain author attribution “Komorebi P.” and do not publish until explicitly requested.
