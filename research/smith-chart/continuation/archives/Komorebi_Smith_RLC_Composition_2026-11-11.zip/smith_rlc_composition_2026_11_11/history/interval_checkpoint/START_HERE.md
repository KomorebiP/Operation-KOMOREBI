# Start here

**Author: Komorebi P.**

This is the continuation after the exact cubic shown in the user's images.

* Read `REPORT.md` for the substantive result.
* Run `python3 -S src/replay_new_certificates.py` for the ten portable certificates.
* Run `python3 -S src/test_interval_core.py` for the exact kernel controls.
* Read `HANDOFF.md` before further development.

The current regression counts are 50/50 historical targets and 24/24 inspected new targets. The original independent fresh result is preserved as 23/24, compared with its 21/24 baseline. The original degree-six six-reactive closure is also retained.

The exact five-element boundary circuit is shown in `figures/Exact_Boundary_Circuit.png`. The complete proofs and independent audits are in `reports/`.
