# Exact reductions for minimum-reactive RLC synthesis

**Author: Komorebi P.**  
**Research continuation: 11 November 2026**  
**Status:** Proven sufficient synthesis charts, exact witness verification, and empirical topology search. Not a complete arbitrary-target minimum-RLC synthesis algorithm.

## Scope and normalization

An RLC one-port has a reduced real rational driving-point impedance \(Z=P/Q\), with coefficients stored in increasing powers of \(s\). Only finite ordinary positive resistors, inductors, capacitors and wires are allowed. A resistor edge has admittance \(g\), an inductor edge \(h/s\) with \(h=1/L\), and a capacitor edge \(cs\). A circuit with \(q\) reactive branches has reduced rational McMillan degree at most \(q\). Consequently a fully independently verified \(q=n\) circuit for a reduced degree-\(n\) target proves its *minimum reactive count* is \(n\). It does not establish minimum resistor or total component count for a named target.

The general problem includes positive-real degree-\(n\) targets requiring more than \(n\) reactive elements (Hughes, 2017). `UNKNOWN` from a restricted chart is never a nonexistence proof.

## 1. An exact factorization-free Cauer chart at arbitrary degree

For a proper reduced \(Z=P/Q\), choose the high-frequency series resistance \(R=\lim_{s\to\infty}Z(s)\ge0\), and put \(V=P-RQ\). If \(\deg Q=\deg V+1\) and \(C=\operatorname{lc}(Q)/\operatorname{lc}(V)>0\), define

\[
D(s)=Q(s)-s C V(s),\qquad Z_{\mathrm{next}}(s)=\frac{V(s)}{D(s)}.
\]

Then the exact rational identity

\[
\boxed{Z(s)=R+\frac{1}{s C+1/Z_{\mathrm{next}}(s)}}
\]

holds. When \(D\equiv0\), the final branch is a capacitor. Iterate only while physical values stay positive and rational degree decreases by exactly one. These steps construct a resistor/capacitor ladder without factoring any denominator. Frequency inversion gives resistor/inductor ladders. Applying the reciprocal at the rational-function level and a series/parallel dual to the *constructed ladder* covers corresponding admittance forms.

The verifier independently computes the actual nodal impedance and checks the exact target. This is classical Cauer synthesis implemented in an exact certificate-first dispatcher, not a claim to have invented Cauer synthesis.

## 2. Four one-reactive endpoint rules

At degree \(n\), a candidate one-element extraction is admissible only if the residual target has degree \(n-1\):

* **Series L:** \(L=\lim_{s\to\infty}Z(s)/s>0\), \(Z_*=Z-sL\).
* **Shunt C:** \(C=\lim_{s\to\infty}Y(s)/s>0\), \(Y_*=Y-sC\), \(Z_*=1/Y_*\).
* **Series C:** the residue \(\rho=\lim_{s\to0}sZ(s)>0\), \(C=1/\rho\), \(Z_*=Z-\rho/s\).
* **Shunt L:** \(h=\lim_{s\to0}sY(s)>0\), \(L=1/h\), \(Y_*=Y-h/s\), \(Z_*=1/Y_*\).

All operations are exact rational polynomial division and recomposition, with explicit positive elements. A subsequent independently verified residual circuit implies a correct parent circuit. Extracting an element whose removal does **not** lower degree does not justify minimum-\(n\) claims and is not accepted by this chart.

## 3. An irreducible cubic solved by endpoint extraction

For a reduced equal-degree target, define

\[
g=\frac{Q_n}{P_n},\quad T=Q-gP,\quad L=\frac{P_n}{T_{n-1}},\quad
Z_*=\frac{P-sLT}{T}.
\]

If \(g,L>0\), \(\deg T=n-1\), and \(Z_*\) has a positive reduced \((n-1)\)-reactive realization, then

\[
\boxed{Z=\left(g+\frac1{sL+Z_*}\right)^{-1}}
\]

is a positive \(n\)-reactive realization. The special implementation first attempts an RC Cauer circuit for \(Z_*\), then permits further verified recursive extraction.

The explicitly tested target

\[
Z_3(s)=\frac{144s^3+100s^2+52s+28}{36s^3+169s^2+113s+11}
\]

has numerator and denominator irreducible over \(\mathbb Q\), hence the simple rational-pole peeling path cannot apply. Direct exact arithmetic gives \(g=1/4\), \(L=1\), and

\[
Z_*=\frac{12s+7}{36s^2+25s+1}.
\]

The RC Cauer inverse of \(Z_*\), composed with this shunt resistor and series inductor, is independently verified to have precisely three reactive elements and the exact target. The older unrestricted q=3 SMT model reported `UNKNOWN` under a 500 ms limit; that solver outcome is not an obstruction.

A second exact endpoint pattern is

\[
R=\lim_{s\to\infty}Z(s),\quad T=P-RQ,\quad C=\frac{Q_n}{T_{n-1}},\quad
Z_*=\frac{T}{Q-sCT},\quad Z=R+\frac1{sC+1/Z_*},
\]

with the corresponding positivity and order-reduction checks. Either pattern may be applied recursively, including frequency-inverted orientations where explicitly supported.

## 4. Complex-pole two-reactive passive modules

Suppose a denominator has a relatively prime rational quadratic factor \(D(s)=s^2+a s+b\), and exact partial-fraction division gives \((A s+B)/D\). With

\[
c=\frac BA,\qquad g=\frac{a-c}{A},\qquad k=\frac{b-ac+c^2}{A},
\]

we have the identity

\[
\frac{D(s)}{A s+B}=\frac{s}{A}+g+\frac{k}{s+c}.
\]

If \(A>0\), \(c,g\ge0\), \(k>0\), this is a passive one-port containing a shunt capacitor \(C=1/A\), an optional shunt resistor \(R=1/g\), and a series resistor-inductor branch with \(R=c/k,L=1/k\). Zero optional resistors are omitted. This module has two reactive elements. It works with a conjugate nonreal pole pair and can be attached either in series (impedance decomposition) or in parallel (admittance decomposition, after reciprocal module conversion). If the remaining target is not independently realizable with the remaining reactive budget, the candidate is rejected rather than relabeled nonpassive by inference.

## 5. Exact elimination for one fully coupled four-node bridge

For the topology with conductances \(a=g_{12},b=g_{23},c=g_{02}\), capacitors \(d=C_{03},e=C_{23}\), and reciprocal inductance \(h=1/L_{13}\), clearing one inductive denominator produces

\[
\begin{aligned}
N_0&=h(a+b+c),&N_1&=ab+bc+eh,\\
N_2&=d(a+b+c)+e(a+c),&N_3&=de,\\
D_0&=ch(a+b),&D_1&=abc+h[d(a+b+c)+ce],\\
D_2&=ad(b+c)+ace+deh,&D_3&=ade.
\end{aligned}
\]

For a degree-three target \(P/Q\), \(a=Q_3/P_3\) is determined immediately. Put \(r=Q_0/P_0\), \(p_j=P_j/P_3\), \(q_j=Q_j/P_3\), and \(v=a+b\). The DC identity gives

\[c=\frac{rv}{v-r},\quad v>r.\]

Setting \(X=1/d,Y=1/e\), we obtain

\[
W=a+b+c,\qquad X=\frac{p_2-WY}{a+c},\qquad h=\frac{p_0}{WXY}.
\]

The remaining exact equations are

\[
\begin{aligned}
b(a+c)XY+\frac{p_0}{WY}&=p_1,\\
a(b+c)Y+acX+h&=q_2,\\
abcXY+h(WY+cX)&=q_1.
\end{aligned}
\]

They are rational equations in only \((b,Y)\), rather than the original six component parameters. The implementation clears denominators, computes a two-variable resultant, proposes rational roots, checks positivity and all remaining equations, then gives the candidate to the separate exact nodal verifier. An independently specified example

\[
Z=\frac{11+34s+92s^2+40s^3}{6+25s+26s^2+8s^3}
\]

returns \((a,b,c,d,e,h)=(1/5,1,1,1,2,1/4)\), with independently verified minimum reactive count three. Failure of a rational root search cannot exclude algebraic solutions or other graph topologies.

## 6. Two sparse seven-component local charts

For a general proper cubic impedance, the normalized coefficient vector

\[
(P_0/P_3,P_1/P_3,P_2/P_3,Q_0/P_3,Q_1/P_3,Q_2/P_3,Q_3/P_3)
\]

has seven coordinates. Each of two selected four-node graph topologies uses three L/C elements and four resistors, hence seven positive parameters. `src/check_sparse_rank.py` independently regenerates both nodal polynomial maps, differentiates them symbolically and checks their Jacobian determinants at explicit positive rational points:

| Chart | Exact seven-dimensional Jacobian determinant |
|---|---:|
| `bridgeA_2L1C_4R` | \(801/134456\) |
| `bridgeB_1L2C_4R` | \(-2299/2097152000\) |

Both are nonzero, so the inverse-function theorem guarantees full-dimensional *local* families of degree-three targets realized with exactly three reactive elements. Genericity of RLC coefficient maps and resulting total-element dimension arguments are prior art (Hughes, Morelli, Smith, *Systems & Control Letters*, 2020). No universal degree-three synthesis theorem is asserted.

The implementation uses least squares **only to propose** positive rational parameters for these two topologies. It reconstructs candidate Fractions with bounded denominators and accepts a result only if the independent standard-library graph checker confirms every element sign, the reactive count, and exact agreement at \(n+q+1\) distinct positive Laplace samples. By the degree bound, those exact matches imply an all-frequency rational identity. A near-fit on its own is always rejected.

## 7. Audit and mathematical limitations

* 67 deterministic test groups pass, including rational RC/RL ladders, genuine irreducible cubic extraction, verified series/parallel recursive modules, nested mixed networks and rejection tests.
* The 60-case *development* graph corpus now has 60 accepted circuits, but the two sparse templates were selected after inspecting failures on this corpus. **60/60 is not an independent generalization estimate.**
* The separate 50-case distinct-seed holdout yields 46 independent verified synthesis certificates and four `UNKNOWN`s. Each of the four has a separately verified positive three-reactive circuit, so every one is a **coverage failure**, not an impossibility result.
* The original unrestricted SMT fallback still returns `UNKNOWN` on the irreducible cubic when given 500 ms. Prior global refutation discovery and arbitrary-target exact minimum synthesis remain unresolved.
* Direct five-variable Gröbner elimination of a bridge example exceeded its bounded execution. A smaller two-variable elimination succeeded. This is evidence for symbolic preprocessing, not a complexity lower-bound theorem.
* No Lean formalization, physical SPICE/hardware measurements, universal topology optimum, or research-priority claim is made here.

## References

Timothy H. Hughes, *Why RLC realizations of certain impedances need many more energy storage elements than expected*, IEEE Transactions on Automatic Control 62(9), 4333–4346 (2017), arXiv:1611.06258.  
Timothy H. Hughes, Alessandro Morelli, Malcolm C. Smith, *On a concept of genericity for RLC networks*, Systems & Control Letters 134, 104562 (2020).  
Classical Cauer/Foster and Brune/Bott–Duffin synthesis predate this continuation. See also specialized third-order synthesis literature; the constructions and inverse charts here have not undergone a priority audit.
