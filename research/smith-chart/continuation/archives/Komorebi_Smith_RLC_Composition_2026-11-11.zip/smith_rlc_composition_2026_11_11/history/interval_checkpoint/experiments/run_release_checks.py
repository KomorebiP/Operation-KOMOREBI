"""Author: Komorebi P. Current release regression, explicitly post-validation."""
from pathlib import Path
import argparse
import json
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from dispatch import dispatch
from algebraic_witness import verify_algebraic_circuit
from interval_certificate import verify_interval_circuit
from replay_new_certificates import replay
from test_next import main as inherited_tests


def check_result(answer,target):
    if answer['status']!='CERTIFIED_MINIMUM':return None
    certificate=answer['certificate']
    if certificate['format']=='komorebi-rlc-interval-v1':
        return verify_interval_circuit(certificate,target,3)
    return verify_algebraic_circuit(certificate,target,3)


def run(output):
    started=time.perf_counter();records=[]
    old=json.loads((ROOT/'results/holdout_q3.json').read_text())['cases']
    fresh=json.loads((ROOT/'experiments/fresh_holdout_inputs.json').read_text())['cases']
    targets=[('historical',i,{'P':r['P'],'Q':r['Q']}) for i,r in enumerate(old)]
    targets += [('post_validation_regression',r['index'],r['target']) for r in fresh]
    for group,index,target in targets:
        answer=dispatch(target['P'],target['Q'])
        check=check_result(answer,target)
        records.append({'group':group,'index':index,'target':target,'status':answer['status'],
                        'verification':check,'result':answer})
        print('RELEASE',group,index,answer['status'],flush=True)
    boundary=fresh[18]['target']
    transforms=[('original',boundary['P'],boundary['Q']),
                ('reciprocal',boundary['Q'],boundary['P']),
                ('frequency_inverse',list(reversed(boundary['P'])),list(reversed(boundary['Q']))),
                ('reciprocal_frequency_inverse',list(reversed(boundary['Q'])),list(reversed(boundary['P'])))]
    boundary_checks=[]
    for name,P,Q in transforms:
        target={'P':P,'Q':Q};answer=dispatch(P,Q);check=check_result(answer,target)
        if check is None:raise AssertionError(('Boundary dual/orientation failed',name,answer))
        boundary_checks.append({'orientation':name,'status':'PASS','actual_storage':check['actual_storage']})
    inherited=inherited_tests()
    certificates=replay()
    summaries=[]
    for group in ('historical','post_validation_regression'):
        rows=[r for r in records if r['group']==group]
        summaries.append({'group':group,'total':len(rows),
                          'certified':sum(r['status']=='CERTIFIED_MINIMUM' for r in rows),
                          'unknown':sum(r['status']=='UNKNOWN' for r in rows)})
    record={'status':'PASS' if all(r['status']=='CERTIFIED_MINIMUM' for r in records) else 'PARTIAL',
            'summary':summaries,'boundary_orientation_checks':boundary_checks,
            'inherited_suite':inherited,'portable_certificates':certificates,
            'seconds':time.perf_counter()-started,'cases':records,
            'interpretation':'Both target sets are now regression sets. Frozen fresh evidence remains at history/frozen_validation.'}
    output.parent.mkdir(parents=True,exist_ok=True);output.write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps({k:v for k,v in record.items() if k not in ('cases','portable_certificates')},indent=2),flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True)
    run(p.parse_args().output)
