"""Komorebi P. Current release gate; frozen validation remains separately pinned."""
from pathlib import Path
import argparse
from contextlib import redirect_stdout
import hashlib
import importlib.util
import io
import json
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from test_next import main as inherited_tests
from test_interval_core import run as interval_tests
from test_composition_core import run as composition_tests
from replay_composition_certificates import replay
from dispatch import dispatch
from composition_certificate import verify_circuit


def run(output):
    start=time.perf_counter()
    outputs={}
    for name,fn in [('inherited_suite',inherited_tests),('interval_core',interval_tests),
                    ('composition_core',composition_tests),('portable_certificates',replay)]:
        outputs[name]=fn()
        assert outputs[name]['status']=='PASS'
        print('RELEASE',name,'PASS',flush=True)
    prior=[]
    for name in ['historical_case_1.json','historical_case_3.json','historical_case_4.json',
                 'historical_case_21.json','image_baseline_cubic.json','boundary_endpoint_cubic.json']:
        saved=json.loads((ROOT/'certificates'/name).read_text());target=saved['target']
        answer=dispatch(target['P'],target['Q'])
        assert answer['status']=='CERTIFIED_MINIMUM',(name,answer)
        check=verify_circuit(answer['certificate'],target,3)
        assert check['actual_storage']==3 and check['global_minimum_proved_by_degree']
        prior.append({'target_source':name,'status':'PASS','certificate_format':answer['certificate']['format'],
                      'actual_storage':check['actual_storage']})
        print('RELEASE','prior_dispatch',name,'PASS',flush=True)
    outputs['prior_dispatch_regressions']=prior
    audit=json.loads((ROOT/'experiments/composition_independent_audit.json').read_text())
    assert audit['status']=='PASS',audit.get('verdict')
    # Pin the independent evidence to the actual current source revision.
    for artifact in audit['input_artifacts']:
        name=artifact['path'];expected=artifact['sha256']
        actual=hashlib.sha256((ROOT/name).read_bytes()).hexdigest()
        assert actual==expected==artifact['sha256_after'],('Independent audit input changed',name)
    outputs['independent_audit_pin']={'status':'PASS','source_inputs':len(audit['input_artifacts']),
                                     'audit_sha256':hashlib.sha256((ROOT/'experiments/composition_independent_audit.json').read_bytes()).hexdigest()}
    # Replay the original exact-six proof without changing its archived report.
    path=ROOT/'experiments/prior_seed/src/verify_exact_six.py'
    spec=importlib.util.spec_from_file_location('retained_exact_six',path)
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    cert=json.loads((ROOT/'experiments/prior_seed/results/six_reactive_certificate.json').read_text())
    mod.BASE=output.parent/'prior_seed';(mod.BASE/'results').mkdir(parents=True,exist_ok=True)
    with redirect_stdout(io.StringIO()):seed=mod.verify(cert)
    assert seed['status']=='PASS'
    outputs['original_six_reactive_replay']=seed
    print('RELEASE','original_six_reactive_replay','PASS',flush=True)
    record={'status':'PASS','author':'Komorebi P.','checkpoint':'smith-rlc-composition-2026-11-11',
            'seconds':time.perf_counter()-start,**outputs,
            'interpretation':'Current release regression and exact certificate replay. Frozen14 structural-validation discovery is preserved at its original revision under history/frozen_composition_validation. Prior cubic24case frozen number remains23/24; subsequent24/24is regression.'}
    output.parent.mkdir(parents=True,exist_ok=True)
    output.write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps({'status':'PASS','seconds':record['seconds'],
                      'inherited_groups':outputs['inherited_suite']['total_assertion_groups'],
                      'interval_groups':outputs['interval_core']['test_groups'],
                      'composition_groups':outputs['composition_core']['test_groups'],
                      'portable_entries':outputs['portable_certificates']['total_entries']},indent=2),flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True)
    run(p.parse_args().output)
