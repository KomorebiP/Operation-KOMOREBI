"""Komorebi P. Exact circuit structure and sampled Smith-chart illustration.

All plotting is performed in Python. Frequency samples illustrate the exact
target functions; sample locations never enter a certificate acceptance test.
"""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, FancyBboxPatch

ROOT = Path(__file__).resolve().parents[1]


def main():
    core = json.loads((ROOT/'certificates/historical_case_1.json').read_text())['target']
    case = json.loads((ROOT/'experiments/composition_validation_inputs.json').read_text())['cases'][0]
    target = case['target']
    from fractions import Fraction
    def impedance(coeffs, w):
        p = [float(Fraction(x)) for x in coeffs['P']]
        q = [float(Fraction(x)) for x in coeffs['Q']]
        return np.polynomial.polynomial.polyval(1j*w, p)/np.polynomial.polynomial.polyval(1j*w, q)
    w = np.r_[0., np.logspace(-4, 4, 1800)]
    colors = {'core':'#2664A8','full':'#C45C26','ink':'#17324A','grid':'#D8E1E8'}
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'mathtext.fontset':'dejavusans'})
    fig = plt.figure(figsize=(14, 7.6), facecolor='white')
    gs = fig.add_gridspec(1, 2, left=.04, right=.97, top=.83, bottom=.22, wspace=.16, width_ratios=[1.08,1])
    ax = fig.add_subplot(gs[0,0]); ax.set_xlim(0,7); ax.set_ylim(0,5); ax.axis('off')
    fig.text(.04,.955,'A coupled cubic core inside a larger exact circuit',fontsize=21,fontweight='bold',color=colors['ink'])
    fig.text(.04,.91,'One added inductor raises the reduced degree from 3 to 4; the composition certificate checks the full target.',fontsize=11.5,color='#42586B')
    ax.text(0,4.75,'CIRCUIT COMPOSITION',color=colors['ink'],fontsize=12,fontweight='bold')
    xleft, xr, xl0, xl1, xc = .45,1.6,2.75,4.0,5.5
    yt,yb=3.65,1.05
    def line(xs,ys,**kw):ax.plot(xs,ys,color=colors['ink'],lw=2,**kw)
    line([xleft,xl0],[yt,yt]);line([xl1,xc],[yt,yt]);line([xleft,xc],[yb,yb])
    for x,y in [(xleft,yt),(xleft,yb),(xr,yt),(xr,yb)]:ax.plot(x,y,'o',color=colors['ink'],ms=5)
    ax.text(xleft-.22,yt,'+',va='center',ha='right',fontsize=15)
    ax.text(xleft-.22,yb,'−',va='center',ha='right',fontsize=15)
    ax.text(.36,2.35,'Z₄',ha='right',color=colors['full'],fontsize=15,fontweight='bold')
    # Four smooth inductor loops, drawn as an exact topology symbol.
    t=np.linspace(0,1,180)
    line(xl0+(xl1-xl0)*t,yt+.23*np.sin(4*np.pi*t)**2)
    ax.text((xl0+xl1)/2,4.2,'L = 5/3',ha='center',color=colors['full'],fontsize=13)
    # Vertical resistor.
    line([xr,xr],[yt,3.15]);line([xr,xr],[1.55,yb])
    ry=np.linspace(3.15,1.55,9);rx=np.array([0,.16,-.16,.16,-.16,.16,-.16,.16,0])+xr
    line(rx,ry)
    ax.text(xr-.35,2.35,'R = 7/2',ha='right',va='center',rotation=90,color=colors['full'],fontsize=13)
    line([xc,xc],[yt,3.14]);line([xc,xc],[1.56,yb])
    box=FancyBboxPatch((4.45,1.56),2.1,1.58,boxstyle='round,pad=.08,rounding_size=.12',
                       facecolor='#EEF5FC',edgecolor=colors['core'],lw=1.7)
    ax.add_patch(box)
    ax.text(xc,2.75,'Certified core Zc',ha='center',color=colors['core'],fontweight='bold',fontsize=12)
    ax.text(xc,2.30,'2 inductors\n1 capacitor\n4 resistors',ha='center',va='center',fontsize=10.7,color=colors['ink'],linespacing=1.5)
    ax.text(3.5,.46,r'$Z_4(s)=\left[\frac{2}{7}+\frac{1}{(5/3)s+Z_c(s)}\right]^{-1}$',ha='center',fontsize=17,color=colors['ink'])
    ax.text(3.5,.04,'Full realization: 4 reactive elements and 5 resistors',ha='center',fontsize=11,color=colors['ink'])
    # Smith chart, with normalized reference impedance exactly 1.
    chart=fig.add_subplot(gs[0,1]);chart.set_aspect('equal');chart.set_xlim(-1.12,1.12);chart.set_ylim(-1.09,1.13)
    chart.axis('off')
    chart.text(-1.10,1.16,'SMITH CHART · REFERENCE Z₀ = 1',fontsize=12,fontweight='bold',color=colors['ink'])
    chart.add_patch(Circle((0,0),1,fill=False,color='#8DA1B1',lw=1.1))
    for r in (.2,.5,1,2,5):chart.add_patch(Circle((r/(1+r),0),1/(1+r),fill=False,color=colors['grid'],lw=.7))
    rs=np.r_[0,np.logspace(-4,5,600)]
    for x in (.2,.5,1,2,5):
        for sign in (-1,1):
            z=rs+1j*sign*x;gam=(z-1)/(z+1);chart.plot(gam.real,gam.imag,color=colors['grid'],lw=.7)
    chart.plot([-1,1],[0,0],color=colors['grid'],lw=.8)
    for data,label,col in [(core,'Cubic core',colors['core']),(target,'Quartic circuit',colors['full'])]:
        z=impedance(data,w);gamma=(z-1)/(z+1)
        zinf=float(Fraction(data['P'][-1])/Fraction(data['Q'][-1]));ginf=(zinf-1)/(zinf+1)
        chart.plot(np.r_[gamma.real,ginf],np.r_[gamma.imag,0],color=col,lw=2.5,label=label)
        chart.scatter([gamma.real[0]],[0],s=38,color=col,zorder=4)
        chart.scatter([ginf],[0],s=45,facecolors='white',edgecolors=col,lw=1.8,zorder=4)
        k=int(np.argmin(abs(w-.5)))
        chart.annotate('',xy=(gamma[k+16].real,gamma[k+16].imag),xytext=(gamma[k].real,gamma[k].imag),
                       arrowprops={'arrowstyle':'->','lw':1.6,'color':col})
    chart.annotate('DC: −1/13',(-1/13,0),xytext=(-.72,.28),fontsize=9.6,color=colors['core'],
                   arrowprops={'arrowstyle':'-','color':colors['core'],'lw':.7})
    chart.annotate('DC: −19/103',(-19/103,0),xytext=(-.86,-.22),fontsize=9.6,color=colors['full'],
                   arrowprops={'arrowstyle':'-','color':colors['full'],'lw':.7})
    chart.annotate('∞: 29/91',(29/91,0),xytext=(.03,-.4),fontsize=9.6,color=colors['core'],
                   arrowprops={'arrowstyle':'-','color':colors['core'],'lw':.7})
    chart.annotate('∞: 5/9',(5/9,0),xytext=(.55,-.25),fontsize=9.6,color=colors['full'],
                   arrowprops={'arrowstyle':'-','color':colors['full'],'lw':.7})
    chart.legend(loc='lower left',bbox_to_anchor=(.01,-.07),frameon=False,ncol=2,fontsize=10.5,handlelength=2)
    fig.text(.04,.145,r'$Z_4(s)=\dfrac{60760s^4+134470s^3+78498s^2+19355s+3150}{17360s^4+74876s^3+60774s^2+22540s+4575}$',fontsize=18,color=colors['ink'])
    fig.text(.04,.067,'Normalized component values. Curves use s = jω, ω ≥ 0; filled markers are DC and open markers are the high-frequency limit.',fontsize=10,color='#526778')
    fig.text(.04,.032,'Komorebi P.  •  Exact target and component-count claims are checked by certificates; the sampled curves are illustrative.',fontsize=9.7,color='#526778')
    folder=ROOT/'figures';folder.mkdir(exist_ok=True)
    for ext in ('png','svg'):fig.savefig(folder/f'Composed_Core_Smith_Chart.{ext}',dpi=180,facecolor='white')
    plt.close(fig)
    print(json.dumps({'files':[str(folder/f'Composed_Core_Smith_Chart.{ext}') for ext in ('png','svg')],
                      'illustration_only':True,'reference_impedance':1,'frequency_samples':len(w)}))


if __name__=='__main__':main()
