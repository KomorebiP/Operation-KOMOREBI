"""Komorebi P. Freeze inherited-solver performance before composition changes."""
from pathlib import Path
import argparse
import hashlib
import json
import sys
import time


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    sys.path.insert(0, str(args.source / 'src'))
    from dispatch import dispatch
    from algebraic_witness import verify_algebraic_circuit
    inputs = root / 'experiments/composition_validation_inputs.json'
    data = json.loads(inputs.read_text())
    freeze = json.loads((root / 'experiments/composition_validation_freeze.json').read_text())
    assert hashlib.sha256(inputs.read_bytes()).hexdigest() == freeze['files'][str(inputs.relative_to(root))]
    hashes = {str(p.relative_to(args.source)): hashlib.sha256(p.read_bytes()).hexdigest()
              for p in sorted((args.source / 'src').glob('*.py'))}
    rows = []
    begun = time.perf_counter()
    for case in data['cases']:
        t0 = time.perf_counter()
        target = case['target']
        answer = dispatch(target['P'], target['Q'], max_degree=12, max_states=80,
                          max_budget=case['expected_degree'], interval_search=False)
        check = None
        if answer['status'] == 'CERTIFIED_MINIMUM':
            check = verify_algebraic_circuit(answer['certificate'], target, case['expected_degree'])
        row = {'id': case['id'], 'status': answer['status'], 'seconds': time.perf_counter()-t0,
               'verification': check, 'result': answer}
        rows.append(row)
        print('BASELINE', case['id'], answer['status'], round(row['seconds'], 3), flush=True)
    assert hashes == {str(p.relative_to(args.source)): hashlib.sha256(p.read_bytes()).hexdigest()
                      for p in sorted((args.source / 'src').glob('*.py'))}
    report = {'status': 'COMPLETED', 'author': 'Komorebi P.',
              'source_checkpoint': 'smith-rlc-interval-2026-11-11',
              'source_hashes': hashes, 'input_sha256': hashlib.sha256(inputs.read_bytes()).hexdigest(),
              'total': len(rows), 'certified': sum(r['status']=='CERTIFIED_MINIMUM' for r in rows),
              'unknown': sum(r['status']=='UNKNOWN' for r in rows),
              'seconds': time.perf_counter()-begun, 'cases': rows,
              'interpretation': 'Structural validation around known cubic cores; baseline root targets all have degree above three, so disabling root-only interval fallback changes no eligible discovery route.'}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps({k: v for k,v in report.items() if k not in ('cases', 'source_hashes')}, indent=2))


if __name__ == '__main__':
    main()
