"""Author: Komorebi P. Freeze a new rational 4/5-node corpus before fitting.

Derives targets using symbolic nodal determinants, independent from the new
tree/forest certificate implementation, then checks the known physical graph
with the inherited exact nodal acceptance kernel. No synthesis is performed.
"""
from pathlib import Path
from fractions import Fraction as F
import hashlib
import itertools
import json
import random
import sys
import time
import sympy as S

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from algebraic_witness import verify_algebraic_circuit


def derive(edges,nodes):
    s=S.Symbol('s');A=S.zeros(nodes-1)
    for typ,a,b,value in edges:
        value=S.Rational(value.numerator,value.denominator)
        y=value*s if typ=='c' else value/s if typ=='h' else value
        if a:A[a-1,a-1]+=y
        if b:A[b-1,b-1]+=y
        if a and b:A[a-1,b-1]-=y;A[b-1,a-1]-=y
    determinant=S.expand(A.det(method='domain-ge'))
    if not determinant:raise ValueError('Disconnected nodal system')
    z=S.cancel(S.expand(A.minor_submatrix(0,0).det(method='domain-ge'))/determinant)
    num,den=map(lambda x:S.Poly(x,s),S.fraction(z))
    if max(num.degree(),den.degree())!=3:raise ValueError('Not exact degree3')
    return {'P':list(map(str,reversed(num.all_coeffs()))),
            'Q':list(map(str,reversed(den.all_coeffs())))}


def main():
    contract_path=ROOT/'experiments/fresh_holdout_contract.json'
    contract=json.loads(contract_path.read_text());rng=random.Random(contract['seed'])
    rows=[];attempts=0;started=time.perf_counter();counts={4:0,5:0}
    for nodes in (4,5):
        pairs=list(itertools.combinations(range(nodes),2))
        while counts[nodes]<12 and attempts<3000:
            attempts+=1
            react=rng.sample(pairs,3);resist=rng.sample(pairs,rng.choice((4,5)))
            types=rng.choice((['h','h','c'],['h','c','c'])).copy();rng.shuffle(types)
            edges=[]
            for typ,(a,b) in list(zip(types,react))+[('g',ab) for ab in resist]:
                physical=F(rng.randint(1,7),rng.randint(1,5))
                parameter=physical if typ=='c' else 1/physical
                edges.append((typ,a,b,parameter))
            try:
                target=derive(edges,nodes)
                witness={'format':'komorebi-algebraic-circuit-v1','target':target,
                         'storage_budget':3,'field':{'polynomial':['0','1'],'interval':['-1','1']},
                         'branches':[{'type':typ,'nodes':[a,b],'coefficient':[str(value)]}
                                     for typ,a,b,value in edges]}
                check=verify_algebraic_circuit(witness,target,3)
            except (ValueError,ZeroDivisionError):continue
            rows.append({'index':len(rows),'node_count':nodes,'target':target,
                         'known_witness':witness,'known_witness_verification':check})
            counts[nodes]+=1
            print('GENERATED',len(rows),'nodes',nodes,flush=True)
    if len(rows)!=24:raise RuntimeError('Fresh corpus generation cap reached')
    out={'status':'COMPLETE','contract_sha256':hashlib.sha256(contract_path.read_bytes()).hexdigest(),
         'seed':contract['seed'],'attempted_graphs':attempts,'valid_cases':len(rows),
         'node_counts':counts,'elapsed_seconds':time.perf_counter()-started,'cases':rows}
    path=ROOT/'experiments/fresh_holdout_inputs.json'
    path.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({'output':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
                      'attempts':attempts,'seconds':out['elapsed_seconds']}),flush=True)


if __name__=='__main__':main()
