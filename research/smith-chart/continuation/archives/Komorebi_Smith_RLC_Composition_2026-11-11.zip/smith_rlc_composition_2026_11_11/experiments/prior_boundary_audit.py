"""Author: Komorebi P. Independent exact audit of the origin-pole continuation."""
from pathlib import Path
from fractions import Fraction as F
import hashlib
import json
import platform
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
import sympy as S
import recursive_modules as rm
from algebraic_witness import verify_algebraic_circuit


def main():
    inputs = ['src/recursive_modules.py', 'src/algebraic_witness.py',
              'src/real_algebraic.py', 'src/exact_polynomials.py',
              'experiments/boundary_exact_reduction.py',
              'results/boundary_dispatch_fixed.json',
              'history/frozen_validation/src/recursive_modules.py']
    def hashes():
        return {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in inputs}
    before = hashes()
    started = time.perf_counter()
    s, a, b, c, d, e, kappa = S.symbols('s A B C D E kappa')
    f = d - c*b/a
    delta = a*e - b*f
    L, Rs, Rp, C1 = a/c, b/e, delta/(e*f), e*e/delta
    arm = Rs + 1/(1/Rp + s*C1)
    reconstructed_G = 1/(1/(s*L) + 1/arm)
    stated_G = s*(a + b*s)/(c + d*s + e*s*s)
    target_P = kappa*c + kappa*d*s + (kappa*e + a)*s*s + b*s**3
    target_Q = s*(c + d*s + e*s*s)
    assert S.cancel(arm - (a+b*s)/(f+e*s)) == 0
    assert S.cancel(reconstructed_G - stated_G) == 0
    assert S.cancel(kappa/s + reconstructed_G - target_P/target_Q) == 0
    assert S.cancel((c+d*s+e*s*s).subs(s, -a/b) - a*delta/b**2) == 0
    P = [320, 1850, 3997, 2520]
    Q = [0, 256, 1480, 1764]
    substitution = {a:1792, b:2520, c:256, d:1480, e:1764, kappa:S.Rational(5,4)}
    actual = S.cancel((kappa/s + reconstructed_G).subs(substitution))
    p = S.Poly(sum(value*s**i for i,value in enumerate(P)),s)
    q = S.Poly(sum(value*s**i for i,value in enumerate(Q)),s)
    assert S.cancel(actual - p.as_expr()/q.as_expr()) == 0
    assert S.gcd(p,q).degree() == 0
    components = {'C0': S.Rational(4,5), 'L': L.subs(substitution),
                  'Rs': Rs.subs(substitution), 'Rp': Rp.subs(substitution),
                  'C1': C1.subs(substitution)}
    assert all(value > 0 for value in components.values())
    expected = {'C0':S.Rational(4,5),'L':7,'Rs':S.Rational(10,7),
                'Rp':S.Rational(6,35),'C1':S.Rational(147,16)}
    assert components == expected
    saved = json.loads((ROOT/'results/boundary_dispatch_fixed.json').read_text())
    witness = verify_algebraic_circuit(saved['certificate'], {'P':P,'Q':Q}, 3)
    assert witness['actual_storage'] == 3
    assert witness['resistors'] == 2
    assert witness['global_minimum_proved_by_degree']
    calls = []
    original = rm.verify_algebraic_circuit
    def traced(cert, target=None, budget=None):
        report = original(cert, target, budget)
        calls.append({'target': {k:list(map(str,v)) for k,v in target.items()},
                      'budget':budget,'status':report['status']})
        return report
    try:
        rm.verify_algebraic_circuit = traced
        replay = rm.synthesize(P,Q)
    finally:
        rm.verify_algebraic_circuit = original
    assert replay['status'] == 'CERTIFIED_MINIMUM'
    assert calls[-1]['target'] == {'P':list(map(str,P)), 'Q':list(map(str,Q))}
    assert calls[-1]['budget'] == 3
    # Runtime-only rejection injection: no source file is changed.
    rejected = []
    def reject_original(cert, target=None, budget=None):
        if budget == 3:
            rejected.append('original target verification required')
            raise ValueError('Independent audit deliberately rejects the top target')
        return original(cert, target, budget)
    try:
        rm.verify_algebraic_circuit = reject_original
        try:
            denied = rm.synthesize(P,Q)
            denied_status = denied['status']
        except ValueError:
            denied_status = 'RAISED_REJECTION'
    finally:
        rm.verify_algebraic_circuit = original
    assert rejected and denied_status != 'CERTIFIED_MINIMUM'
    after = hashes()
    report = {'status':'PASS' if before==after else 'INPUTS_CHANGED',
              'assertion_tested':'Exact symbolic family identities, independently recomputed target identity/coprimality, physical signs, saved witness replay, dispatcher final-check trace and forced checker rejection.',
              'argv':[sys.executable,'experiments/prior_boundary_audit.py'],
              'python':platform.python_version(),'sympy':S.__version__,
              'inputs_before':before,'inputs_after':after,
              'family_identities':{'arm':True,'parallel_stage':True,'full_target':True,'noncancellation':True},
              'target':{'P':P,'Q':Q},'target_reduced_degree':3,
              'physical_components':{k:str(v) for k,v in components.items()},
              'independent_witness_replay':witness,
              'dispatcher_status':replay['status'],'dispatcher_modules':replay['modules'],
              'verifier_calls':calls,'forced_final_checker_rejection':denied_status,
              'forced_rejections_observed':len(rejected),
              'elapsed_seconds':time.perf_counter()-started,
              'scope':'Post-freeze regression and a sufficient symbolic family. Frozen fresh result remains 23/24; no global solver completeness claim.'}
    (ROOT/'experiments/prior_boundary_audit.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k not in ('inputs_before','inputs_after','verifier_calls')},indent=2))


if __name__ == '__main__':
    main()
