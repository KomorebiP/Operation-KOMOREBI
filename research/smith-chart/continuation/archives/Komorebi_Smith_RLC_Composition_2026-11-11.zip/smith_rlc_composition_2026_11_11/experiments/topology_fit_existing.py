"""Author: Komorebi P. Bounded target-only fit of historical q3 misses.

The archived physical witness is never read by the fitting procedure. The
historical holdout is regression data after this continuation begins.
"""
import sys,json,time,hashlib
from pathlib import Path
import numpy as np
from scipy.optimize import least_squares
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from sparse_q3_templates import TEMPLATES,model

def run(starts=30,nfev=1500):
    source=ROOT/'results/holdout_q3.json'
    original=json.loads(source.read_text())
    inputs=[(i,{'P':x['P'],'Q':x['Q']}) for i,x in enumerate(original['cases']) if x['result']=='UNKNOWN']
    out={'base_archive_sha256':'a7062b55396452139b017d361e690fec70ce21da580150893ce1ea817a38d4f9','input_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'seed':2026111219,'starts_per_chart':starts,'max_nfev':nfev,'candidate_threshold':1e-10,'scope':'Four historical holdout misses. Target coefficients only used for fitting. This is now a regression set, not a new holdout.','cases':[]}
    rng=np.random.default_rng(out['seed']);t0=time.perf_counter()
    for index,target in inputs:
        P=np.array(list(map(float,target['P'])));Q=np.array(list(map(float,target['Q'])))
        tgt=np.r_[P[:3]/P[3],Q/P[3]];scale=np.maximum(1,abs(tgt))
        row={'index':index,'target':target,'charts':[]}
        for name,spec in TEMPLATES.items():
            ff,jj=model(name)
            def f(z):return (np.ravel(ff(np.exp(z)))-tgt)/scale
            def jac(z):
                v=np.exp(z)
                return np.asarray(jj(v))*v[None,:]/scale[:,None]
            best=None
            for attempt in range(starts):
                z=np.zeros(7) if attempt==0 else rng.normal(0,1.5,7)
                try:
                    fit=least_squares(f,z,jac=jac,bounds=(-18,18),max_nfev=nfev,ftol=1e-13,xtol=1e-13,gtol=1e-13)
                    vals=np.exp(fit.x);err=float(max(abs(f(fit.x))))
                except (ValueError,OverflowError,ZeroDivisionError,FloatingPointError):continue
                if best is None or err<best['scaled_residual']:
                    best={'template':name,'spec':spec,'parameters':[format(v,'.17g') for v in vals],'scaled_residual':err,'attempt':attempt,'nfev':fit.nfev,'jacobian_rank':int(np.linalg.matrix_rank(jj(vals))),'jacobian_condition':float(np.linalg.cond(jj(vals)))}
                if err<out['candidate_threshold']:break
            row['charts'].append(best)
            print(index,name,best['scaled_residual'],best['attempt'],flush=True)
        out['cases'].append(row);out['elapsed_seconds']=time.perf_counter()-t0
        (ROOT/'experiments/topology_existing_candidates.json').write_text(json.dumps(out,indent=2)+'\n')
    return out

if __name__=='__main__':
    d=run();print(json.dumps({'elapsed':d['elapsed_seconds'],'cases':len(d['cases'])}))
