"""Komorebi P. Package, hash and freshly replay the completed checkpoint.

Creates a complete ZIP, standalone report/theorem/figure, and verification JSON.
Output and extraction directories must be outside the project tree. This helper
does not upload, publish or share anything.
"""
from pathlib import Path
import argparse
import hashlib
import json
import shutil
import subprocess
import sys
import zipfile

ROOT=Path(__file__).resolve().parents[1]
PREFIX='Komorebi_Smith_RLC_Composition_2026-11-11'


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--deliverables',type=Path,required=True)
    p.add_argument('--verify-dir',type=Path,required=True)
    args=p.parse_args();out=args.deliverables.resolve();verify=args.verify_dir.resolve()
    if out.is_relative_to(ROOT) or verify.is_relative_to(ROOT):
        raise ValueError('Outputs and fresh extraction must be outside the source project')
    if verify.exists():raise FileExistsError('Fresh verification directory already exists')
    out.mkdir(parents=True,exist_ok=True)
    excluded={'MANIFEST.sha256.json','SHA256SUMS.txt'}
    files=[]
    for path in sorted(ROOT.rglob('*')):
        if '__pycache__' in path.parts or path.suffix=='.pyc':continue
        if path.is_symlink():raise ValueError('Refusing a symlink in the complete checkpoint: '+str(path))
        if path.is_file() and str(path.relative_to(ROOT)) not in excluded:files.append(path)
    hashes={str(path.relative_to(ROOT)):sha(path) for path in files}
    manifest={'author':'Komorebi P.','checkpoint':'smith-rlc-composition-2026-11-11',
              'hash_algorithm':'SHA256','files_count':len(hashes),
              'excluded_root_files':sorted(excluded),'ignored_generated_files':['__pycache__/**','*.pyc'],
              'files':hashes}
    (ROOT/'MANIFEST.sha256.json').write_text(json.dumps(manifest,indent=2)+'\n')
    (ROOT/'SHA256SUMS.txt').write_text(''.join(digest+'  '+name+'\n' for name,digest in hashes.items()))
    archive=out/(PREFIX+'.zip')
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for path in files+[ROOT/'MANIFEST.sha256.json',ROOT/'SHA256SUMS.txt']:
            name=ROOT.name+'/'+str(path.relative_to(ROOT))
            info=zipfile.ZipInfo(name,date_time=(2026,11,11,0,0,0))
            info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=(0o100644<<16)
            z.writestr(info,path.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
    verify.mkdir()
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        entries=z.namelist();assert len(entries)==len(set(entries))
        assert all(name.startswith(ROOT.name+'/') and '..' not in Path(name).parts for name in entries)
        z.extractall(verify)
    extracted=verify/ROOT.name
    unpacked=json.loads((extracted/'MANIFEST.sha256.json').read_text())
    for name,digest in unpacked['files'].items():
        assert sha(extracted/name)==digest,('Fresh extraction hash mismatch',name)
    replay_out=verify/'portable_replay.json'
    command=[sys.executable,'-S','src/replay_composition_certificates.py','--output',str(replay_out)]
    ran=subprocess.run(command,cwd=extracted,capture_output=True,text=True,timeout=120)
    (verify/'portable_stdout.txt').write_text(ran.stdout)
    (verify/'portable_stderr.txt').write_text(ran.stderr)
    if ran.returncode:raise RuntimeError('Fresh portable replay failed: '+ran.stderr)
    replay=json.loads(replay_out.read_text())
    assert replay['status']=='PASS' and replay['total_entries']==26
    standalone={
      'REPORT.md':'Smith_RLC_Composition_Report_2026-11-11.md',
      'reports/COUPLED_CORE_LIFT_THEOREM.md':'Smith_RLC_Coupled_Core_Lifting_Theorem_2026-11-11.md',
      'figures/Composed_Core_Smith_Chart.png':'Smith_RLC_Composed_Core_Smith_Chart_2026-11-11.png',
    }
    for source,name in standalone.items():shutil.copy2(ROOT/source,out/name)
    summary=json.loads((ROOT/'VERIFICATION_SUMMARY.json').read_text())
    record={'author':'Komorebi P.','status':'PASS','checkpoint':manifest['checkpoint'],
            'archive':{'filename':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,
                       'entries':len(entries),'crc':'PASS','unique_safe_paths':'PASS'},
            'file_manifest':{'hash_algorithm':'SHA256','verified_files':len(unpacked['files']),
                             'sha256':sha(extracted/'MANIFEST.sha256.json'),'status':'PASS'},
            'fresh_extraction_replay':{'status':replay['status'],'python':sys.version.split()[0],
                'site_packages_disabled':True,'inherited_entries':replay['inherited_entries'],
                'new_checkpoint_entries':replay['new_checkpoint_entries'],'total_entries':replay['total_entries'],
                'exit_code':ran.returncode,'result_sha256':sha(replay_out)},
            'standalone_files':[{'filename':name,'sha256':sha(out/name),'bytes':(out/name).stat().st_size}
                                for name in standalone.values()],
            'release_verification':summary,
            'publication_status':'unpublished; no external deployment or sharing performed'}
    verification=out/'Smith_RLC_Composition_Package_Verification_2026-11-11.json'
    verification.write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps({'status':'PASS','archive':record['archive'],
                      'manifest_files':len(unpacked['files']),'fresh_replay_entries':replay['total_entries'],
                      'deliverables':[str(archive)]+[str(out/name) for name in standalone.values()]+[str(verification)]},indent=2))


if __name__=='__main__':main()
