"""Author: Komorebi P. Exact continuation for the frozen validation boundary miss.

This experiment does not modify the frozen synthesis source or read the
generating circuit witness. It starts only from target polynomial coefficients.
"""
from fractions import Fraction as F
from pathlib import Path
import hashlib,json,sys,time
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from exact_biquadratic_templates import R,L,C,series,parallel,circuit_certificate
from algebraic_witness import verify_algebraic_circuit
from recursive_modules import one_reactive_endpoint_candidates
from cauer_ladders import find_cauer

TARGET={'P':['320','1850','3997','2520'],'Q':['0','256','1480','1764']}

def construct():
    P=list(map(F,TARGET['P']));Q=list(map(F,TARGET['Q']))
    stages=[]
    cap_options=list(one_reactive_endpoint_candidates(P,Q))
    cap=[row for row in cap_options if row[0]=='series-C'][0]
    _,c0,rp,rq=cap
    stages.append({'operation':'series-C','physical_value':str(c0),
                   'residual':{'P':list(map(str,rp)),'Q':list(map(str,rq))}})
    inductor_options=list(one_reactive_endpoint_candidates(rp,rq))
    shunt=[row for row in inductor_options if row[0]=='shunt-L'][0]
    _,l0,cp,cq=shunt
    stages.append({'operation':'shunt-L','physical_value':str(l0),
                   'residual':{'P':list(map(str,cp)),'Q':list(map(str,cq))}})
    core=find_cauer(cp,cq)
    if core['status']!='CERTIFIED_MINIMUM':raise AssertionError(core)
    a,b=cp;f,e=cq
    delta=a*e-b*f
    if min(a,b,f,e,delta)<=0:raise AssertionError('Outside the exact positive RC regime')
    rs=b/e;rp0=delta/(e*f);c1=e*e/delta
    tree=series(C(c0),parallel(L(l0),series(R(rs),parallel(R(rp0),C(c1)))))
    cert=circuit_certificate(P,Q,tree)
    verified=verify_algebraic_circuit(cert,TARGET,3)
    if not verified['global_minimum_proved_by_degree']:raise AssertionError(verified)
    return {'status':'CERTIFIED_MINIMUM','target':TARGET,'minimum_reactive_count':3,
        'scope':'Post-freeze continuation of one missed boundary target. Frozen fresh23/24 score unchanged.',
        'known_generating_witness_used':False,'stages':stages,
        'components':{'series_capacitor':str(c0),'shunt_inductor':str(l0),
            'core_series_resistor':str(rs),'core_parallel_resistor':str(rp0),
            'core_parallel_capacitor':str(c1)},'core_check':core['verification'],
        'certificate':cert,'verification':verified}

if __name__=='__main__':
    started=time.perf_counter();result=construct()
    result['elapsed_seconds']=time.perf_counter()-started
    result['base_archive_sha256']='a7062b55396452139b017d361e690fec70ce21da580150893ce1ea817a38d4f9'
    result['source_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    result['checker_sha256']=hashlib.sha256((ROOT/'src/algebraic_witness.py').read_bytes()).hexdigest()
    (ROOT/'experiments/boundary_exact_result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
