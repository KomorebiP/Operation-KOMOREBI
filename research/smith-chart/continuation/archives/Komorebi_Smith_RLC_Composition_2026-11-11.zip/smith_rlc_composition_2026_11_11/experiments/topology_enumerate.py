"""Author: Komorebi P. Bounded target-only four-node q3 topology proposals.

Enumeration includes three mixed reactive edges on distinct vertex pairs and
four resistor edges on distinct pairs. Quotient only the exact two-terminal
symmetries 0<->1 and 2<->3. Numerical ranks are search heuristics, not exclusions.
The graph model uses spanning trees/forests, independent from symbolic nodal
determinants used in the inherited template implementation.
"""
import sys,itertools,json,time,hashlib
from pathlib import Path
import numpy as np
from scipy.optimize import least_squares
ROOT=Path(__file__).resolve().parents[1]

def canonical(spec):
    keys=[]
    for port_swap in (False,True):
        for interior_swap in (False,True):
            perm=[int(port_swap),int(not port_swap),3 if interior_swap else 2,2 if interior_swap else 3]
            keys.append(tuple(sorted((t,*sorted((perm[a],perm[b]))) for t,a,b in spec)))
    return min(keys)

def catalog():
    pairs=list(itertools.combinations(range(4),2));specs=set()
    for react in itertools.combinations(pairs,3):
        for one_type in ('L','C'):
            other='C' if one_type=='L' else 'L'
            for one in range(3):
                re=[(one_type if i==one else other,*p) for i,p in enumerate(react)]
                for resist in itertools.combinations(pairs,4):
                    specs.add(canonical(re+[('R',*p) for p in resist]))
    return sorted(specs)

def components(spec,ids):
    parent=list(range(4))
    def find(a):
        while parent[a]!=a:a=parent[a]
        return a
    for j in ids:
        _,a,b=spec[j];a=find(a);b=find(b)
        if a==b:return None
        parent[a]=b
    return tuple(find(i) for i in range(4))

def forest_terms(spec):
    nl=sum(t=='L' for t,a,b in spec);terms=[[],[]]
    for side,size in ((0,2),(1,3)):
        for ids in itertools.combinations(range(7),size):
            co=components(spec,ids)
            if co is None:continue
            if side==0 and (len(set(co))!=2 or co[0]==co[1]):continue
            if side==1 and len(set(co))!=1:continue
            power=nl+sum({'L':-1,'C':1,'R':0}[spec[j][0]] for j in ids)
            terms[side].append((power,ids))
    return terms

def model(spec):
    terms=forest_terms(spec)
    if any(not v or max(p for p,_ in v)!=3 for v in terms):return None
    exponents=np.zeros((sum(map(len,terms)),7),dtype=int)
    out_matrix=np.zeros((8,len(exponents)))
    row=0
    for side,side_terms in enumerate(terms):
        for power,ids in side_terms:
            exponents[row,list(ids)]=1
            out_matrix[4*side+power,row]=1;row+=1
    # All monomials are square-free. In log coordinates differentiation is
    # multiplication by the exponent matrix, with no divisions by variables.
    def both(z):
        mon=np.exp(exponents@z)
        vals=out_matrix@mon
        deriv=(out_matrix*mon[None,:])@exponents
        a=vals[3];da=deriv[3]
        inds=[0,1,2,4,5,6,7]
        f=vals[inds]/a
        j=(deriv[inds]-f[:,None]*da[None,:])/a
        return f,j
    return both

def run(max_nfev=220):
    source=ROOT/'results/holdout_q3.json'
    raw=json.loads(source.read_text())
    inputs={i:{'P':c['P'],'Q':c['Q']} for i,c in enumerate(raw['cases']) if c['result']=='UNKNOWN'}
    specs=catalog();rng=np.random.default_rng(2026111223)
    permutation=rng.permutation(len(specs));ts=time.perf_counter()
    out={'base_archive_sha256':'a7062b55396452139b017d361e690fec70ce21da580150893ce1ea817a38d4f9','source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'seed':2026111223,'catalog_count':len(specs),'scope':'four nodes, three mixed reactive branches on distinct pairs, four resistor branches on distinct pairs, modulo port swap and internal-node swap','numerical_filter':'full degree3 numerator and denominator, numerical generic rank7 at deterministic positive point; failed ranks are search heuristics, not exclusion proofs','max_nfev':max_nfev,'candidate_threshold':1e-10,'visited_topologies':0,'numeric_rank7_topologies':0,'proposals':[],'best':{}}
    found=set();targets={}
    for i,t in inputs.items():
        P=np.array(list(map(float,t['P'])));Q=np.array(list(map(float,t['Q'])))
        y=np.r_[P[:3],Q]/P[3];targets[i]=(y,np.maximum(1,abs(y)))
    for count,k in enumerate(permutation):
        spec=specs[k];out['visited_topologies']+=1
        fun=model(spec)
        if fun is None:continue
        _,j=fun(np.array([-.5,.1,.4,-.2,.6,-.3,.2]))
        if np.linalg.matrix_rank(j)!=7:continue
        out['numeric_rank7_topologies']+=1
        for i,t in inputs.items():
            if i in found:continue
            target,scale=targets[i]
            def f(z):return (fun(z)[0]-target)/scale
            def jac(z):return fun(z)[1]/scale[:,None]
            fit=least_squares(f,np.zeros(7),jac=jac,bounds=(-16,16),max_nfev=max_nfev,ftol=1e-11,xtol=1e-11,gtol=1e-11)
            v=np.exp(fit.x);err=float(max(abs(f(fit.x))))
            if str(i) not in out['best'] or err<out['best'][str(i)]['scaled_residual']:
                out['best'][str(i)]={'catalog_index':int(k),'scaled_residual':err}
            if err<out['candidate_threshold']:
                row={'index':i,'catalog_index':int(k),'target':t,'spec':spec,'parameters':[format(x,'.17g') for x in v],'scaled_residual':err,'nfev':fit.nfev,'jacobian_condition':float(np.linalg.cond(fun(fit.x)[1]))}
                out['proposals'].append(row);found.add(i)
                print('CANDIDATE',i,int(k),err,flush=True)
        out['elapsed_seconds']=time.perf_counter()-ts
        (ROOT/'experiments/topology_enumeration_candidates.json').write_text(json.dumps(out,indent=2)+'\n')
        if count%25==0:print('PROGRESS',count,len(found),out['best'],flush=True)
        if len(found)==len(inputs):break
    (ROOT/'experiments/topology_enumeration_candidates.json').write_text(json.dumps(out,indent=2)+'\n')
    return out

if __name__=='__main__':
    d=run();print(json.dumps({k:v for k,v in d.items() if k not in ('proposals','best')},indent=2))
