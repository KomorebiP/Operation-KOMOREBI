"""Author: Komorebi P. Independent composition/lift audit controls.

Contract: inspect the rebuilt graph, and solve its grounded nodal equations with
new Fraction or Q(sqrt(2),sqrt(3)) arithmetic. Check q+n+1 positive rational
arguments for each declared finite fixture, together with independent recursive
impedance evaluation and malformed-input controls. The independent arithmetic
does not import the production polynomial, algebraic-field, graph, or nodal
implementations. The production checker is the object under test.

Interval nodes with a provably rational root use that root, never their center.
The inherited cubic interval leaf is replayed and audited by the all-real proof;
it is not replaced by a rational sample of its component box.

The all-real, all-degree claims rest on reports/COMPOSITION_INDEPENDENT_AUDIT.md,
not on this finite test set. No search coverage or historical novelty is tested.

Run from project root: python3 -S experiments/composition_independent_audit.py
Only this script's JSON result and its independent audit report are written.
"""
from __future__ import annotations

from copy import deepcopy
from datetime import datetime, timezone
from fractions import Fraction as F
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from composition_certificate import (
    FORMAT, element_node, certificate_node, series_node, parallel_node,
    frequency_invert_node, make_composition, verify_circuit,
)


def check(condition, message):
    if not condition:
        raise AssertionError(message)


def solve(matrix, rhs):
    """Independent exact Gauss-Jordan elimination for F or Quadratic entries."""
    m = [list(row) + [value] for row, value in zip(matrix, rhs)]
    n = len(m)
    check(all(len(row) == n + 1 for row in m), "bad audit matrix dimensions")
    for j in range(n):
        pivot = next((i for i in range(j, n) if m[i][j]), None)
        check(pivot is not None, "singular audit nodal matrix")
        m[j], m[pivot] = m[pivot], m[j]
        z = m[j][j]
        m[j] = [x / z for x in m[j]]
        for i in range(n):
            if i != j and m[i][j]:
                z = m[i][j]
                m[i] = [a - z * b for a, b in zip(m[i], m[j])]
    return [row[-1] for row in m]


class Quadratic:
    """Independent four-dimensional exact field with basis 1,sqrt2,sqrt3,sqrt6."""
    __slots__ = ("coefficients",)

    def __init__(self, value=0):
        if isinstance(value, Quadratic):
            self.coefficients = value.coefficients
        elif isinstance(value, (list, tuple)):
            check(len(value) == 4, "bad audit field vector")
            self.coefficients = tuple(map(F, value))
        else:
            self.coefficients = (F(value), F(0), F(0), F(0))

    def __add__(self, other):
        other = Quadratic(other)
        return Quadratic([a + b for a, b in zip(self.coefficients, other.coefficients)])
    __radd__ = __add__

    def __neg__(self):
        return Quadratic([-a for a in self.coefficients])

    def __sub__(self, other):
        return self + -Quadratic(other)

    def __rsub__(self, other):
        return Quadratic(other) + -self

    def __mul__(self, other):
        other = Quadratic(other)
        out = [F(0)] * 4
        for i, a in enumerate(self.coefficients):
            for j, b in enumerate(other.coefficients):
                shared = i & j
                out[i ^ j] += a * b * (2 if shared & 1 else 1) * (3 if shared & 2 else 1)
        return Quadratic(out)
    __rmul__ = __mul__

    def inverse(self):
        check(bool(self), "division by audit field zero")
        columns = []
        for j in range(4):
            unit = [F(0)] * 4
            unit[j] = F(1)
            columns.append((self * Quadratic(unit)).coefficients)
        return Quadratic(solve([[columns[j][i] for j in range(4)] for i in range(4)],
                               [F(1), F(0), F(0), F(0)]))

    def __truediv__(self, other):
        return self * Quadratic(other).inverse()

    def __rtruediv__(self, other):
        return Quadratic(other) * self.inverse()

    def __bool__(self):
        return any(self.coefficients)

    def __eq__(self, other):
        return self.coefficients == Quadratic(other).coefficients


def polynomial_value(poly, argument):
    result = F(0)
    for a in reversed(poly):
        result = result * argument + F(a)
    return result


def target_value(target, argument):
    return polynomial_value(target["P"], argument) / polynomial_value(target["Q"], argument)


def expression_value(expression, argument):
    op = expression["op"]
    if op == "element":
        a = F(expression["value"])
        return a if expression["type"] == "R" else a * argument if expression["type"] == "L" else 1 / (a * argument)
    if op == "certificate":
        return target_value(expression["certificate"]["target"], argument)
    if op == "frequency_invert":
        return expression_value(expression["child"], 1 / argument)
    terms = [expression_value(child, argument) for child in expression["children"]]
    return sum(terms, F(0)) if op == "series" else 1 / sum((1 / z for z in terms), F(0))


def expression_counts(expression):
    op = expression["op"]
    if op == "element":
        return 1, int(expression["type"] != "R"), 0
    if op == "certificate":
        branches = expression["certificate"]["branches"]
        return len(branches), sum(row["type"] != "g" for row in branches), 1
    if op == "frequency_invert":
        return expression_counts(expression["child"])
    rows = [expression_counts(child) for child in expression["children"]]
    return tuple(sum(row[j] for row in rows) for j in range(3))


def root_for_context(context):
    poly = list(map(F, context["field"]["polynomial"]))
    lo, hi = map(F, context["field"]["interval"])
    if poly == [F(0), F(1)]:
        return Quadratic(0)
    check(poly in ([F(-2), F(0), F(1)], [F(-3), F(0), F(1)]), "undeclared algebraic audit field")
    index = 1 if poly[0] == -2 else 2
    vector = [F(0)] * 4
    check(lo > 0 or hi < 0, "audit requires a signed isolating interval")
    vector[index] = F(1 if lo > 0 else -1)
    return Quadratic(vector)


def coefficient_value(row, contexts, extended):
    value = row["coefficient"]
    if value["kind"] == "rational":
        result = F(value["value"])
    elif value["kind"] == "algebraic":
        context = contexts[value["context"]]
        coefficients = list(map(F, value["polynomial"]))
        if len(coefficients) == 1:
            result = coefficients[0]
        else:
            result = polynomial_value(coefficients, root_for_context(context))
    else:
        context = contexts[value["context"]]
        definition = context["definition"]
        check(len(definition["branches"]) == 1 and definition["branches"][0]["type"] == "g",
              "only the proved rational resistor root is used in audit nodal arithmetic")
        check(value["index"] == 0, "wrong interval index")
        result = 1 / target_value(definition["target"], F(1))
        lo, hi = map(F, context["component_intervals"][0])
        check(lo < result < hi, "independent resistor root outside interval box")
        check(result != F(definition["center"][0]), "fixture must distinguish the exact root from its center")
    return Quadratic(result) if extended else F(result)


def nodal_value(verified, argument):
    graph = verified["rebuilt_graph"]
    contexts = {entry["id"]: entry for entry in verified["parameter_contexts"]}
    extended = any(row["coefficient"]["kind"] == "algebraic" and
                   len(row["coefficient"]["polynomial"]) > 1 for row in graph["branches"])
    convert = Quadratic if extended else F
    nodes = sorted(set(graph["nodes"]) - {0})
    ix = {node: i for i, node in enumerate(nodes)}
    matrix = [[convert(0) for _ in nodes] for _ in nodes]
    rhs = [convert(int(node == 1)) for node in nodes]
    for row in graph["branches"]:
        a, b = row["nodes"]
        admittance = coefficient_value(row, contexts, extended)
        if row["type"] == "h":
            admittance /= argument
        elif row["type"] == "c":
            admittance *= argument
        if a:
            matrix[ix[a]][ix[a]] += admittance
        if b:
            matrix[ix[b]][ix[b]] += admittance
        if a and b:
            matrix[ix[a]][ix[b]] -= admittance
            matrix[ix[b]][ix[a]] -= admittance
    return solve(matrix, rhs)[ix[1]], extended


def sqrt_resistor_leaf(d, negative=False):
    sign = -1 if negative else 1
    # At t=sign*sqrt(d), g1=sign*t, g2=(d+sign*t)/(d-1).
    # Their series resistance is exactly 1, with both conductances positive.
    return {"format": "komorebi-algebraic-circuit-v1", "target": {"P": ["1"], "Q": ["1"]},
            "storage_budget": 0,
            "field": {"polynomial": [str(-d), "0", "1"],
                      "interval": ["-2", "-1"] if negative else ["1", "2"]},
            "branches": [{"type": "g", "nodes": [0, 917], "coefficient": ["0", str(sign)]},
                         {"type": "g", "nodes": [1, 917],
                          "coefficient": [str(F(d, d - 1)), str(F(sign, d - 1))]}]}


def rational_interval_leaf():
    return {"format": "komorebi-rlc-interval-v1", "target": {"P": ["2"], "Q": ["1"]},
            "storage_budget": 0, "branches": [{"type": "g", "nodes": [1, 0]}],
            "center": ["51/100"], "radii": ["1/10"], "preconditioner": [["-1/2"]]}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run():
    started_at = datetime.now(timezone.utc).isoformat()
    start = time.monotonic()
    inputs = [
        "src/composition_certificate.py", "src/algebraic_witness.py", "src/interval_certificate.py",
        "src/real_algebraic.py", "src/exact_polynomials.py", "src/interval_family.py",
        "reports/COMPOSITION_THEOREM.md", "reports/COUPLED_CORE_LIFT_THEOREM.md",
        "reports/FAMILY_INDEPENDENT_AUDIT.md", "reports/INTERVAL_CHECKER_NOTES.md",
        "THEOREMS_AND_PROOFS.md", "certificates/image_baseline_cubic.json",
        "certificates/boundary_endpoint_cubic.json", "certificates/historical_case_1.json",
        "certificates/local_family_case_1.json", "experiments/coupled_core_lift_audit.py",
        "experiments/coupled_core_lift_audit.json", "experiments/composition_independent_audit.py",
    ]
    before = {path: sha(ROOT / path) for path in inputs}
    def load(name):
        return json.loads((ROOT / name).read_text())
    image_leaf = certificate_node(load("certificates/image_baseline_cubic.json"))
    boundary_leaf = certificate_node(load("certificates/boundary_endpoint_cubic.json"))
    interval = certificate_node(rational_interval_leaf())
    a2, a3, negative_a2 = [certificate_node(c) for c in
                          [sqrt_resistor_leaf(2), sqrt_resistor_leaf(3), sqrt_resistor_leaf(2, True)]]
    R = lambda v: element_node("R", v)
    L = lambda v: element_node("L", v)
    C = lambda v: element_node("C", v)
    fixtures = [
        ("pure_resistor", R("7/3")),
        ("unequal_degree_inverse_L", frequency_invert_node(L("5/7"))),
        ("unequal_degree_inverse_C", frequency_invert_node(C("11/13"))),
        ("series_RL_inverse", frequency_invert_node(series_node(R(2), L(3)))),
        ("nested_mixed", parallel_node(series_node(R(2), L(3)),
                                      frequency_invert_node(series_node(C("2/5"), R("7/3"))))),
        ("parallel_same_type_inductors", parallel_node(L(2), L(3))),
        ("series_same_type_capacitors", series_node(C(2), C(3))),
        ("reused_algebraic_leaf", series_node(image_leaf, image_leaf)),
        ("two_different_rational_leaves", parallel_node(image_leaf, boundary_leaf)),
        ("double_frequency_inverse", frequency_invert_node(frequency_invert_node(
            series_node(image_leaf, parallel_node(R(4), C("3/2")))))),
        ("rational_interval_root_not_center", parallel_node(interval, interval)),
        ("interval_algebraic_mix", series_node(interval, image_leaf, L("2/3"))),
        ("independent_sqrt2_sqrt3_fields", parallel_node(series_node(a2, L(2)),
                                                        series_node(a3, C(3)))),
        ("reused_field_and_opposite_root", parallel_node(series_node(a2, a3, R(3)),
                                                         series_node(a2, negative_a2, L(4)))),
    ]
    positive = []
    artifacts = {}
    for label, expression in fixtures:
        certificate = make_composition(expression)
        verified = verify_circuit(certificate, certificate["target"], certificate["storage_budget"])
        physical, storage, leaves = expression_counts(expression)
        graph = verified["rebuilt_graph"]
        check(verified["physical_branch_count"] == physical == len(graph["branches"]), label + " branch count")
        check(verified["actual_storage"] == storage, label + " storage count")
        check(verified["leaf_occurrence_count"] == leaves, label + " leaf occurrence count")
        check(len({x["id"] for x in verified["parameter_contexts"]}) == leaves, label + " unique contexts")
        check([x["instance"] for x in graph["branches"]] == list(range(physical)), label + " physical instances")
        check(len({tuple(x["nodes"]) for x in graph["branches"]}) <= physical, label + " graph shape")
        degree = max(len(certificate["target"]["P"]), len(certificate["target"]["Q"])) - 1
        check(verified["reduced_target_degree"] == degree, label + " reported degree")
        check(verified["global_minimum_proved_by_degree"] == (storage == degree), label + " minimum gate")
        check(verified["realization_only"] == (storage != degree), label + " realization-only flag")
        extended = False
        for k in range(1, storage + degree + 2):
            s = F(2 * k + 1, 7)
            got, extended = nodal_value(verified, s)
            wanted = expression_value(expression, s)
            check(got == wanted, label + " independent nodal mismatch")
            check(target_value(certificate["target"], s) == wanted, label + " target mismatch")
        if label == "parallel_same_type_inductors":
            check([row["nodes"] for row in graph["branches"]] == [[0, 1], [0, 1]], "duplicates were merged")
            check(storage == 2 and degree == 1 and verified["realization_only"], "duplicate minimum overclaim")
        if label == "reused_algebraic_leaf":
            context_nodes = []
            for context in verified["parameter_contexts"]:
                context_nodes.append({node for row in graph["branches"]
                                      if row["coefficient"].get("context") == context["id"] for node in row["nodes"]})
            check(len(context_nodes[0] & context_nodes[1]) == 1, "series leaves share material beyond chain junction")
        positive.append({"label": label, "physical_branches": physical, "actual_storage": storage,
                         "degree": degree, "leaf_occurrences": leaves,
                         "exact_nodal_arguments": storage + degree + 1,
                         "arithmetic": "Q(sqrt(2),sqrt(3))" if extended else "Q",
                         "minimum_proved": storage == degree, "status": "PASS"})
        artifacts[label] = (certificate, verified)

    # Algebraically equivalent target descriptions and inert forged metadata.
    certificate, verified = artifacts["series_RL_inverse"]
    scaled = deepcopy(certificate)
    for name in ("P", "Q"):
        old = list(map(F, scaled["target"][name]))
        out = [F(0)] * (len(old) + 1)
        for i, value in enumerate(old):
            out[i] -= 3 * value
            out[i + 1] -= 3 * value
        scaled["target"][name] = list(map(str, out))
    scaled["rebuilt_graph"] = {"branches": []}
    scaled["equations"] = ["untrusted"]
    scaled["global_minimum_proved_by_degree"] = False
    check(verify_circuit(scaled, certificate["target"], certificate["storage_budget"])["target"]
          == verified["target"], "unreduced target or forged metadata affected semantics")

    rejections = []
    def reject(label, action):
        try:
            action()
        except ValueError as exc:
            rejections.append({"label": label, "status": "REJECTED", "exception": "ValueError", "reason": str(exc)})
        except Exception as exc:
            raise AssertionError(label + " escaped with " + type(exc).__name__) from exc
        else:
            raise AssertionError(label + " was accepted")

    base = artifacts["nested_mixed"][0]
    def mutate(path, value):
        changed = deepcopy(base)
        obj = changed
        for key in path[:-1]:
            obj = obj[key]
        obj[path[-1]] = value
        return changed
    reject("external_target_binding", lambda: verify_circuit(base, {"P": [1], "Q": [1]}))
    reject("external_budget_binding", lambda: verify_circuit(base, expected_budget=0))
    reject("declared_target_binding", lambda: verify_circuit(mutate(["target"], {"P": [1], "Q": [1]})))
    reject("insufficient_budget", lambda: verify_circuit(mutate(["storage_budget"], 0)))
    for value, label in [(True, "boolean"), ("2", "string"), (-1, "negative"), (257, "excessive")]:
        reject(label + "_budget", lambda value=value: verify_circuit(mutate(["storage_budget"], value)))
    for value, label in [(0, "zero"), (-1, "negative"), (True, "boolean"), (1.0, "float"),
                         ("NaN", "nan"), ("1/0", "zero_denominator"), ("1e2", "scientific_text")]:
        expression = {"op": "element", "type": "R", "value": value}
        reject(label + "_element", lambda expression=expression: make_composition(expression))
    for expression, label in [
        ({"op": "element", "type": "X", "value": 1}, "unknown_element"),
        ({"op": "reciprocal", "child": R(1)}, "unproved_reciprocal"),
        ({"op": "parallel", "children": [R(1)]}, "unary_parallel"),
        ({"op": "series", "children": []}, "empty_series"),
        ({"op": "element", "type": "R", "value": 1, "target": {}}, "extra_node_field"),
        ({"op": "series", "children": [R(1)] * 65}, "child_limit"),
        ({"op": "certificate", "certificate": base}, "nested_composition_leaf"),
    ]:
        reject(label, lambda expression=expression: make_composition(expression))
    depth = R(1)
    for _ in range(34):
        depth = {"op": "frequency_invert", "child": depth}
    reject("expression_depth_limit", lambda: make_composition(depth))
    cyclic = deepcopy(base)
    cyclic["metadata"] = cyclic
    reject("cyclic_ignored_metadata", lambda: verify_circuit(cyclic))
    reject("oversize_ignored_text", lambda: verify_circuit(dict(base, metadata="x" * 16385)))
    reject("nonstring_metadata_key", lambda: verify_circuit(dict(base, metadata={1: "x"})))
    reject("floating_ignored_metadata", lambda: verify_circuit(dict(base, metadata=1.0)))
    for target, label in [({"P": [0], "Q": [1]}, "zero_target"),
                          ({"P": [1], "Q": [0]}, "infinite_target"),
                          ({"P": [1.0], "Q": [1]}, "floating_target"),
                          ({"P": [True], "Q": [1]}, "boolean_target"),
                          ({"P": [1] + [0] * 65, "Q": [1]}, "untrimmed_degree_limit")]:
        reject(label, lambda target=target: verify_circuit(mutate(["target"], target)))
    leaf = sqrt_resistor_leaf(2)
    for field, value, label in [("nodes", [0, 0], "self_loop"), ("nodes", [0, True], "boolean_node"),
                                ("nodes", [0, -1], "negative_node"), ("nodes", [0], "missing_node"),
                                ("coefficient", [-1], "negative_algebraic_branch")]:
        broken = deepcopy(leaf)
        broken["branches"][0][field] = value
        reject(label, lambda broken=broken: verify_circuit(broken))
    duplicate = deepcopy(leaf)
    duplicate["branches"].append(deepcopy(duplicate["branches"][0]))
    reject("duplicate_inside_legacy_leaf", lambda: verify_circuit(duplicate))
    nonisolated = deepcopy(leaf)
    nonisolated["field"]["interval"] = ["-2", "2"]
    reject("nonisolated_algebraic_root", lambda: verify_circuit(nonisolated))
    singular = rational_interval_leaf()
    singular["preconditioner"] = [["0"]]
    reject("singular_interval_preconditioner", lambda: verify_circuit(singular))
    invalidbox = rational_interval_leaf()
    invalidbox["radii"] = ["1"]
    reject("nonpositive_interval_box", lambda: verify_circuit(invalidbox))

    # This originally exposed a portable-builder defect, not false acceptance.
    large = 2 ** 2100 + 1
    expression = series_node(R(F(1, large)), R(F(1, large + 2)))
    try:
        result = make_composition(expression)
    except ValueError as exc:
        portability = {"status": "PASS", "behavior": "builder rejects an output outside its replay caps", "reason": str(exc)}
    else:
        try:
            verify_circuit(result)
        except ValueError as exc:
            portability = {"status": "FAIL", "behavior": "builder returned an unreplayable certificate", "reason": str(exc)}
        else:
            portability = {"status": "PASS", "behavior": "builder output replays"}
    portability.update({"input_denominator_bits": large.bit_length(),
                        "normalized_output_denominator_bits": (F(1, large) + F(1, large + 2)).denominator.bit_length(),
                        "first_affected_revision": "1aa31c10cead9b2da925b2637a84fe9dde4240aad313a72024c4333f25f39ba9"})

    # General interval leaf: replay exact proof and verify occurrence semantics.
    real_leaf = certificate_node(load("certificates/historical_case_1.json"))
    interval_composition = make_composition(series_node(real_leaf, frequency_invert_node(real_leaf)))
    real_verified = verify_circuit(interval_composition)
    check(real_verified["leaf_occurrence_count"] == 2, "real interval leaf occurrences merged")
    check(real_verified["actual_storage"] == 6, "real interval branch count changed")
    check(all(c["kind"] == "interval" for c in real_verified["parameter_contexts"]), "real root semantics lost")
    check(len({c["id"] for c in real_verified["parameter_contexts"]}) == 2, "real root contexts merged")

    # Reproduce the author's documented exact computation in memory; its file is
    # not overwritten, and this reproduction is separate from our nodal audit.
    spec = importlib.util.spec_from_file_location("lift_controls_under_audit", ROOT / "experiments/coupled_core_lift_audit.py")
    lift_module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(lift_module)
    lift_replay = lift_module.run()
    recorded_lift = load("experiments/coupled_core_lift_audit.json")
    check(lift_replay == recorded_lift, "recorded lift computation differs on reproduction")
    check(len(lift_replay["instances"]) == 72, "lift finite range count")
    check(lift_replay["finite_check_scope"]["single_step_roundtrips"] == 108, "lift roundtrip count")
    check(lift_replay["finite_check_scope"]["exact_scalar_identity_checks"] == 324, "lift scalar count")
    check(lift_replay["uniform_cubic_certificate_replay"]["coefficient_domain"]
          == "all real coefficients in the closed target box", "uniform real scope changed")
    after = {path: sha(ROOT / path) for path in inputs}
    unchanged = before == after
    status = "PASS" if unchanged and portability["status"] == "PASS" else "FAIL"
    try:
        commit = subprocess.run(["git", "rev-parse", "HEAD"], cwd=ROOT, capture_output=True, text=True, check=True).stdout.strip()
        dirty = bool(subprocess.run(["git", "status", "--porcelain"], cwd=ROOT, capture_output=True, text=True, check=True).stdout.strip())
    except subprocess.CalledProcessError:
        # Match the official bounded runner's conservative non-Git convention:
        # unavailable status is not the empty clean porcelain status.  This is
        # explicitly a schema convention, not an observed Git dirty state.
        commit, dirty = "unavailable", True
    return {
        "schema_version": 2, "claim_id": "COMPOSITION_AND_COUPLED_CORE_INDEPENDENT_AUDIT",
        "status": status, "author": "Komorebi P.", "review_provenance": "independent delegated audit of raw source and proof",
        "repository": {"commit": commit, "dirty": dirty,
                       "git_state": "unavailable: not a Git checkout" if commit == "unavailable" else "observed Git status",
                       "dirty_interpretation": "conservative official-runner convention; not an observed Git dirty status" if commit == "unavailable" else "observed nonempty porcelain status"},
        "command": ["python3", "-S", "experiments/composition_independent_audit.py"],
        "environment": {"software": [{"name": "Python", "version": platform.python_version()}],
                        "hardware": platform.machine(), "platform": platform.platform()},
        "mathematics": {
            "assertion_tested": "Declared finite composition fixtures agree with independently rebuilt nodal equations; malformed inputs reject; the recorded lift computation reproduces exactly.",
            "coefficient_domain": "exact Q and Q(sqrt(2),sqrt(3)); inherited interval real roots replayed without center substitution",
            "conventions": "ascending polynomial arrays; conductance g, inverse inductance h, capacitance c; unit current at port1, ground0",
            "inputs": inputs, "bounds": {"declared_nodal_fixtures": len(positive), "exact_positive_arguments_per_fixture": "q+n+1", "maximum_storage_tested": max(x["actual_storage"] for x in positive)},
            "non_claims": ["No global target coverage", "No universal theorem from finite sampling", "No minimum total component count", "No novelty or external literature claim", "No running-time or memory upper bound"]},
        "randomness": {"used": False, "generator": "none; explicit deterministic fixtures", "seed": None},
        "run": {"started_at": started_at, "runtime_seconds": time.monotonic() - start,
                "exit_status": 0 if status == "PASS" else 1,
                "status": "completed" if status == "PASS" else "inputs-changed" if not unchanged else "failed",
                "resource_limits": {"memory_bytes": None, "cpu_seconds": None, "max_cores": None, "max_threads": None}},
        "input_artifacts": [{"path": path, "sha256": before[path], "sha256_after": after[path]} for path in inputs],
        "source_unchanged": unchanged,
        "positive_nodal_checks": positive,
        "exact_nodal_argument_count": sum(x["exact_nodal_arguments"] for x in positive),
        "equivalent_unreduced_target_and_ignored_metadata": "PASS",
        "rejection_controls": rejections,
        "portable_builder_regression": portability,
        "general_interval_occurrences": {"status": "PASS", "occurrences": 2, "actual_storage": 6,
                                         "semantics": "unique exact real leaf roots; no rational component approximation"},
        "lift_record_reproduction": {"status": "PASS", "identical_to_recorded_result": True,
                                      "selected_instances": 72, "single_step_roundtrips": 108,
                                      "exact_scalar_identity_checks": 324, "domain_rejection_controls": 11,
                                      "uniform_cubic_family_replay": "PASS"},
        "outputs": [], "declared_results": [],
        "checks": ["before/after source hashes", "independent exact nodal equations", "q+n+1 distinct positive rational arguments", "separate parameter contexts", "strict malformed rejection", "documented lift computation reproduction"],
        "result": "implementation and finite assertion verified in the stated range" if status == "PASS" else "portable-builder defect or changed inputs require follow-up",
        "residual_risks": ["Finite controls supplement the raw universal proof audit", "Existing exact leaf kernels remain dependencies; their raw source and relevant semantics were inspected", "The JSON is the result record itself; its hash belongs to the enclosing release provenance, avoiding a self-hash"]}


def report_text(result):
    """Preserve the independent human proof audit alongside reproducible controls."""
    hashes = {item["path"]: item["sha256"] for item in result["input_artifacts"]}
    source_table = "\n".join("| `" + path + "` | `" + digest + "` |" for path, digest in hashes.items())
    fixture_table = "\n".join(
        "| " + row["label"] + " | " + str(row["actual_storage"]) + " | " + str(row["degree"])
        + " | " + str(row["leaf_occurrences"]) + " | " + str(row["exact_nodal_arguments"])
        + " | " + row["arithmetic"] + " |"
        for row in result["positive_nodal_checks"])
    template = r'''# Independent audit of composition certificates and the coupled-core lift

**Author: Komorebi P.**  
**Review date:** @DATE@, UTC.  
**Review provenance:** Independent delegated review of the raw source, raw proofs, exact certificates and preserved dependencies. The reviewer did not author the composition checker or the lift proof. The audit calculations below use a separate nodal implementation.  
**Primary verdict:** Proved as written for the composition-acceptance claim and the normalized coupled-core lift theorem.  
**Implementation outcome:** @STATUS@ for the final revision in the stated finite range. One constructor portability defect was found in the earlier revision and corrected; its original failed run is retained.

## 1. Normalized claims and scope

### Composition claim

For every certificate accepted by `verify_composition_certificate` within the stated format and resource limits, the returned graph is a finite connected two-terminal network of positive ordinary uncoupled RLC branches. Its impedance is the declared rational target. Its actual reactive count `q` is at most its declared budget. The optional external target and budget bindings are checked exactly.

If the target's reduced degree is `n`, the returned global-minimum flag is true exactly when `q=n`. This equality proves minimum reactive count among all finite positive ordinary uncoupled RLC graphs. A case with `q>n` proves an exact realization and does not receive that minimum conclusion. Minimum resistor count, minimum total component count, uniqueness across topologies and general synthesis completeness are outside this claim.

Algebraic coefficients and interval-isolated exact real component vectors are admissible at leaves. Different leaf occurrences are separate physical copies even if they use identical certificate text. Frequency inversion is the substitution `s -> 1/s`; it is not a claimed reciprocal-impedance construction.

### Coupled-core lift claim

For every integer \(n\ge0\), let

\[
\mathcal C_n=\{(P,Q):\deg P=\deg Q=n,\ Q_n=1,\ P_n>0,\ \gcd(P,Q)=1\},
\]

with real coefficients and gcd understood over \(\mathbb R[s]\), up to a nonzero scalar. The coordinates are the `n+1` numerator coefficients and the first `n` denominator coefficients. For \(g,L>0\),

\[
W_{g,L}(P/Q)=\left[g+\frac1{Ls+P/Q}\right]^{-1}
\]

defines a rational diffeomorphism from \(\mathcal C_n\times(0,\infty)^2\) onto the stated open endpoint chart in \(\mathcal C_{n+1}\). It increases reduced degree by exactly one. An `n`-reactive positive core consequently gives an `(n+1)`-reactive realization attaining the universal degree lower bound.

Starting with the interior of the specific uniform cubic coefficient box, repeated lifts give a nonempty open family in every full normalized coefficient dimension \(2n+1\), \(n\ge3\). These statements quantify over real coefficients and positive real wrapper values. The finite point-certificate API has rational input and explicit size limits; it does not serialize every point of those real open families or certify unbounded degrees by itself.

## 2. Dependency map

| Dependency | Evidence reviewed | Role and scope |
|---|---|---|
| Algebraic leaf realization | Raw `algebraic_witness.py` and `real_algebraic.py`, preserved prior audit, exact nontrivial-field fixtures | Isolated real root, positive branch values, connectivity and full rational identity |
| Interval leaf realization | Raw `interval_certificate.py`, `INTERVAL_CHECKER_NOTES.md`, unchanged prior proof and fresh replay | Exact unique real root in the declared positive box, including fixed constraints |
| Uniform cubic base family | Raw `interval_family.py`, exact family certificate, `FAMILY_INDEPENDENT_AUDIT.md`, fresh replay | Every real coefficient vector in the entire box, not a set of sampled vectors |
| Graph composition | Raw `composition_certificate.py` and `COMPOSITION_THEOREM.md`, independent nodal calculations | Disjoint gluing, preserved branch occurrences, exact target identity |
| Reactive degree bound | Incidence-determinant/tree-and-forest derivation in the raw proofs | Lower bound over arbitrary competing positive uncoupled RLC graphs |
| Lift and inverse | Direct symbolic reconstruction of Sections 2–3 of `COUPLED_CORE_LIFT_THEOREM.md` | Degree preservation, inverse, open full-dimensional image |
| Declared finite controls | This audit script and reproduced lift record | Implementation controls with explicit finite bounds |

No implication is justified solely by a solver's success flag or by agreement between agents. Existing leaf kernels are inherited proof dependencies: their unchanged hashes, relevant raw source and proof semantics were inspected here, without claiming a new exhaustive audit of every historical component. No internet or external publication source was used. No unresolved external theorem is needed for the claims reviewed here.

## 3. Independent reconstruction of composition soundness

An accepted algebraic leaf chooses its specified isolated real root; an accepted interval leaf has the exact positive root supplied by the full-system contraction argument. For finitely many occurrences, all these choices coexist in a finite Cartesian product. There are no cross-leaf parameter equations to create an incompatibility. Equal roots in two occurrences are permitted; their physical branches and internal vertices still remain distinct.

The assembler maps only the local terminal labels `0` and `1` to its assigned terminals. It allocates every other local vertex freshly, independently of the magnitude or gaps in its old label. Series nodes allocate a chain of new junctions and attach children to successive distinct terminal pairs. Parallel nodes identify only corresponding terminals. Reading the code confirms that no unrelated internal vertex is glued, including when the same Python leaf object is reused.

At each positive real Laplace argument, all edge admittances are positive. The grounded nodal matrix is positive definite by connectivity, so each child's driving-point relation is defined. Series junctions carry one common through-current and voltage drops add. Parallel children share a voltage and their currents add. Consequently, for child impedances \(P/Q\) and \(A/B\),

\[
Z_{\rm series}=\frac{PB+AQ}{QB},\qquad
Z_{\rm parallel}=\frac{PA}{PB+AQ}.
\]

These are precisely the implemented polynomial operations, followed by exact reduction. The positive real values prevent an identically zero driving-point target from arising. Induction on the finite expression tree yields the complete rational identity. The returned graph, leaf counts and target are rebuilt from checked data; root-level graphs, equations and alleged minimum flags are not trusted.

Frequency inversion preserves the incidence graph and every coefficient reference, while swapping branch types `h` and `c`. Thus `h/s` becomes `h*s` and `c*s` becomes `c/s`, exactly matching the old branch admittance evaluated at `1/s`. In physical values an inductor `L` becomes a capacitor `1/L`, and a capacitor `C` becomes an inductor `1/C`. No interval center is substituted and no common algebraic field is required.

For polynomials, take \(d=\max(\deg P,\deg Q)\). The correct pair is

\[
\bigl(s^dP(1/s),\,s^dQ(1/s)\bigr).
\]

The implementation pads both ascending arrays to length `d+1` before reversal and then reduces. Both unequal-degree orientations, a mixed network and double inversion were checked independently. Reversing the original arrays separately would be wrong; the reviewed implementation does not do that.

Every physical branch is retained. In particular, same-type parallel branches created by composition are not merged, and reused leaves are counted once per occurrence. This differs harmlessly from the legacy leaves' prohibition of duplicate same-type branches inside one leaf: the assembled output is an explicitly counted multigraph.

## 4. The global degree lower bound

For a finite connected positive graph, write its grounded nodal matrix as \(B\operatorname{diag}(y_e)B^{\mathsf T}\). Expanding its determinant gives the spanning-tree sum; the input cofactor similarly gives the terminal-separating two-forest sum. Incidence minors vanish on cycles or components without a deleted terminal row, while rooted trees have determinant of absolute value one by leaf removal. This remains valid for parallel physical edge instances, because each has its own incidence column.

Let \(\ell\) be the total number of inductors, and \(q\) the total number of reactive branches. Multiplying both sums by \(s^\ell\) gives monomials of degree

\[
\ell-\#(\text{selected inductors})+\#(\text{selected capacitors}),
\]

between zero and `q`. The two resulting polynomials \(N,D\) are nonzero and have degrees at most `q`. They yield the graph impedance \(N/D\). This argument permits arbitrary positive real component values and arbitrary numbers of resistors or internal vertices.

If the target \(P/Q\) is reduced over the reals, \(PD=QN\) and coprimality imply \(P\mid N\) and \(Q\mid D\). Hence \(\max(\deg P,\deg Q)\le q\). For a rational target reduced over \(\mathbb Q\), its rational Bezout identity also holds over \(\mathbb R\), so the same conclusion applies. The composition checker's minimum conclusion at actual `q=n` therefore compares against the full physical class; it is not confined to the solver's searched topologies.

## 5. Independent reconstruction of the lift and open-image proof

Put \(N=P+sLQ\) and \(D=Q+gN\). Since `Q` is monic of exact degree `n`, the leading coefficients of `N,D` are `L,gL`, respectively. Both degrees are exactly `n+1`. Also

\[
\gcd(N,D)=\gcd(N,Q)=\gcd(P+sLQ,Q)=\gcd(P,Q)=1.
\]

Thus no cancellation is hidden in the degree claim. After normalizing the denominator,

\[
U=\frac{P+sLQ}{gL},\qquad V=\frac{Q+g(P+sLQ)}{gL}.
\]

For a normalized output of degree `n+1`, define

\[
g=\frac1{U_{n+1}},\quad H=V-gU,\quad h=H_n,\quad
L=\frac{U_{n+1}}h,\quad K=U-sLH.
\]

The leading terms in `H` and `K` cancel by construction. On the exact image domain, the strict conditions are \(h>0\) and \(K_n>0\). They give exact degree `n` to both recovered polynomials and the required positive core leading coefficient. The normalized core is

\[
P=K/h,\qquad Q=H/h.
\]

The coprimality chain \(\gcd(K,H)=\gcd(U,H)=\gcd(U,V)=1\) proves membership in \(\mathcal C_n\). Because \(gL=1/h\), the unnormalized forward pair is \(U/h,V/h\) and its normalization is exactly \(U,V\). Conversely, a forward image has \(H=Q/(gL)\), \(h=1/(gL)\) and \(K=P/(gL)\); all four input objects are recovered. This is a two-sided inverse, including the normalization, rather than just a dimension count.

For `n=0`, `H,K` are nonzero constants of the required positive sign. The displayed formulas still apply. The degree-zero control in the recorded experiment is consistent with this direct argument.

The coprime locus with nonzero leading coefficients is open in the normalized coordinates: the appropriate Sylvester determinant is nonzero there. All divisors in the forward and inverse formulas are nonzero on their stated domains. Therefore the maps are rational and smooth. The conditions \(h>0\), \(K_n>0\) define an open image. This establishes the stated rational diffeomorphism without an unproved Jacobian assertion.

The physical wrapper adds a positive series inductor `L` and a positive parallel resistor `1/g`, with only the intended terminals identified. Its storage count increases by one and its degree does too. The preceding lower bound proves its minimum reactive count.

### The all-real base and induction

The raw uniform-family source constructs the complete coefficient system \(F(x,y)\) in seven component variables and seven target coordinates. For each arbitrary real `y` in the specified target box, the same positive component box and invertible rational matrix define \(T_y(x)=x-YF(x,y)\). Exact interval enclosures over the joint box prove strict self-mapping and a contraction bound below one for that fixed arbitrary `y`. Hence an exact positive root exists for every such real vector. Rational verification arithmetic does not narrow that quantifier to rational vectors.

The independent Sylvester norm bound is exactly \(211787599/223125000000000<10^{-6}\). It proves coprimality everywhere in the coefficient box, and the positive numerator leading-coefficient bound retains degree three. The source and certificate hashes match the inherited independent family audit; their exact inequalities reproduced in the fresh run.

The interior \(\mathcal U_3\) is nonempty and open. Define

\[
\mathcal U_{n+1}=\Phi_n\bigl(\mathcal U_n\times(0,\infty)^2\bigr).
\]

A diffeomorphism onto an open subset sends open domain subsets to ambient open subsets. Induction gives nonempty open \(\mathcal U_n\) for every \(n\ge3\), in dimension \(7+2(n-3)=2n+1\). Each constructed graph has `2+m` inductors, one capacitor and `4+m` resistors for `n=3+m`. This all-degree claim is proved by the inverse and induction; the 72 finite rows are not its proof.

## 6. Independent exact implementation controls

The command is:

```bash
python3 -S experiments/composition_independent_audit.py
```

The independent test arithmetic imports no production polynomial, graph-polynomial, algebraic-field or nodal implementation. It forms the grounded nodal matrix directly from every returned physical branch and solves it with a separate exact Gauss-Jordan routine. The expected scalar impedance is evaluated recursively from the original expression. It also compares the declared target at every argument.

For each fixture, the audit uses exactly `q+n+1` distinct positive arguments \(s_k=(2k+1)/7\). Under the independently reviewed graph degree bound, these checks establish the rational-function identity for those particular fixtures: the cross-product polynomial has degree at most `q+n`. This remains a finite fixture set, not evidence of universal input coverage.

| Fixture | Actual q | Reduced n | Leaf occurrences | Exact arguments | Arithmetic |
|---|---:|---:|---:|---:|---|
@FIXTURE_TABLE@

All **14 fixtures and 73 exact nodal arguments** passed. Twelve graphs use rational arithmetic and two use an independent four-coordinate basis \(1,\sqrt2,\sqrt3,\sqrt6\). For \(d=2,3\), the nonrational resistor leaves use conductances \(\sqrt d\) and \((d+\sqrt d)/(d-1)\) in series; their resistance is exactly one. A repeated field occurrence and an opposite isolating-root interval are also present. This checks that the emitted algebraic contexts describe the intended roots without a hidden shared primitive-element assumption.

The exact interval-resistor fixture has target resistance two, component root \(g=1/2\), rational center \(51/100\), radius \(1/10\), and preconditioner \(-1/2\). Its exact root differs from its center. The independent nodal calculation uses the root derived from the resistor identity and checks that it lies strictly in the declared box. Substituting the center would fail the target comparison.

The general historical cubic interval leaf is separately replayed twice in one expression, once under frequency inversion. Its two parameter contexts and all six reactive occurrences remain separate. No rational component vector is substituted for its exact real roots; its conclusion uses the all-real leaf proof.

The **41 malformed-input controls** all rejected with `ValueError`. They cover external and declared target binding, external budget binding, actual storage overflow, invalid budget types, positivity, Boolean and floating values, invalid rational text, unsupported reciprocal operations, missing/extra expression fields, node shape and labels, duplicate branches inside a legacy leaf, nonisolating algebraic intervals, singular interval preconditioners, nonpositive component boxes, depth/child limits, cyclic metadata and oversized ignored data. A separately checked target multiplied by a common negative scalar and polynomial factor was accepted as the same rational function. Forged root metadata did not change the rebuilt result.

### Reproduction of the lift record

The author's documented lift computation was rerun in memory without overwriting its saved JSON. The complete returned data matched the saved record. The declared range is four interior rational cubic vectors, three wrapper streams, and depths `0,1,2,3,5,9`, giving **72 selected rows** at degrees `3,4,5,6,8,12`. The depth-zero rows repeat across streams; this count is not a count of 72 distinct targets. The run also contains **108 single-step inverse checks, 324 exact scalar checks, one degree-zero control and 11 domain rejection controls**. This reproduces the finite assertion, while the raw source and proof review establish its interpretation.

## 7. Defect found, retained failure and correction

The first frozen revision was

```text
1aa31c10cead9b2da925b2637a84fe9dde4240aad313a72024c4333f25f39ba9
```

It had one reproducible constructor defect. Set `A=2**2100+1` and build two series resistors of values `1/A` and `1/(A+2)`. Both input denominators have 2101 bits and fit the accepted limits. Their normalized total resistance has a 4201-bit denominator. The original `make_composition` returned that certificate, but `verify_circuit` then rejected its target with `ValueError: Rational coefficient resource limit exceeded`.

The acceptance kernel did not accept a false circuit. The failure was the promise that a successful constructor return is portable through its own replay interface. The original independent JSON correctly recorded `FAIL`, with all other nodal, malformed-input and lift checks passing. It is preserved at `history/frozen_composition_validation/experiments/composition_independent_audit.json`, SHA256:

```text
e52916364cc719de5517f29bfde21521342177b6e20c389117253ed83980f260
```

The correction adds `_preflight(result)` and `_target(result['target'])` before the constructor returns. Inspection against the frozen source confirmed that only this return boundary changed. The oversized output now rejects before any certificate is emitted, while an ordinary `1/17 + 1/19` resistor output still replays. The final audit reran the fixture and records **@PORTABILITY_STATUS@**. All other acceptance semantics remain those already reviewed.

No acceptance hole was found in the reviewed mathematical kernel or the tested malformed-input cases. This is a source audit plus bounded controls, not an assertion that every possible implementation failure has been exhaustively enumerated.

## 8. Obligation matrix

| Obligation | Verdict | Decisive evidence |
|---|---|---|
| Exact target and budget binding | Passed | Normalization, separate expression comparison, rejection controls |
| Strict positive physical values | Passed | Element parsing, checked leaf signs/positive boxes |
| Independent parameter contexts | Passed | Occurrence allocation, finite-product argument, multiquadratic and interval fixtures |
| Terminal gluing and internal labels | Passed | Raw injective allocation and independent nodal reconstruction |
| Same-type parallel occurrence counting | Passed | Explicit two-inductor fixture keeps q=2 while n=1 |
| Unequal-degree frequency inversion | Passed | Common-degree padding proof and both exact fixtures |
| Real interval root versus center | Passed | Unique-root semantics and off-center resistor fixture |
| Global minimum only at actual q=n | Passed | Universal degree bound and cancellation fixtures |
| Malformed data, budgets, exceptions | Passed in stated finite controls | 41 controlled `ValueError` rejections plus raw schema/preflight inspection |
| Portable constructor return | Corrected and passed | Preserved first failure, narrow patch review, final regression |
| Lift identity and no cancellation | Passed | Leading coefficients and gcd chain |
| Normalized two-sided inverse | Passed | Explicit recovery and substitutions |
| Smallest n=0 case | Passed | Constant H,K argument and exact control |
| Open full-dimensional real image | Passed | Rational inverse and strict image inequalities |
| All-real cubic input | Passed through unchanged exact dependency | Joint interval proof, Sylvester bound and fresh replay |
| All-degree induction | Passed | Open product domains and exact degree increase |
| Universal passive-target synthesis coverage | Out of scope | No such theorem is asserted |
| Search recovery rates and benchmark independence | Out of scope | Separate parent validation artifacts |
| Minimum total components and historical novelty | Not addressed | No such conclusion or external research attempted |

## 9. Reproducibility, exact revision and remaining limits

The input archive SHA256 is `66cb2e38c0f59235184199f266a9638c5a8d0ab9f4a60a87483cb0613e5ae31d`. This workspace is not a Git checkout, so provenance is recorded by exact paths and byte hashes. The v2 record follows the official runner's conservative `commit=unavailable, dirty=true` convention for this case, and explicitly identifies that flag as a schema convention, not an observed Git dirty state. The final run used Python **@PYTHON@**, exact integers/Fractions, and no randomness. Runtime was **@RUNTIME@ seconds**. Before/after hashes were equal for every recorded input: **@UNCHANGED@**.

The machine result is `experiments/composition_independent_audit.json`. It records the explicit mathematical contract, input hashes, software/platform, execution status, fixture results, rejection reasons and this report's output hash. Its own file hash belongs to the enclosing release provenance to avoid a self-hash. The `run.status` is **@RUN_STATUS@**. The source and report revisions audited are:

| Artifact | SHA256 at run start and end |
|---|---|
@SOURCE_TABLE@

The coupled-core raw proof was first reviewed at hash `c03359556d34186cbbb3b8d0dd3c9b07d6da258139255d688b5387d7c8dfb6c4`; the preserved frozen copy retains that original. The later change only records independent-review provenance. The theorem index appended the new claims while preserving the inherited lower bound. The composition proof's later changes record the constructor correction and updated test/source hashes. No mathematical gap was closed by silently changing either theorem during this audit.

There is no remaining gap in the two stated mathematical claims. Acceptance remains conditional on the explicit physical model and format limits. Rejection or a resource cap is not an infeasibility proof. The real open-family theorem does not make the point API complete, and the finite controls do not show that the target-only search always finds a leaf. Exact arithmetic may be expensive inside the declared limits; no fixed runtime or memory bound was established.

**Final mathematical proofreading:** The audit report's definitions, `q/n` usage, normalized inverse, sign conditions, LaTeX delimiters, code fences, source paths and provenance were reviewed. No mathematical-token correction was made to the source theorems or kernels by this reviewer. No unresolved notation or local typographical issue remains in the reviewed report.
'''
    replacements = {
        "@DATE@": result["run"]["started_at"][:10], "@STATUS@": result["status"],
        "@FIXTURE_TABLE@": fixture_table, "@SOURCE_TABLE@": source_table,
        "@PORTABILITY_STATUS@": result["portable_builder_regression"]["status"],
        "@PYTHON@": platform.python_version(), "@RUNTIME@": f'{result["run"]["runtime_seconds"]:.3f}',
        "@UNCHANGED@": str(result["source_unchanged"]), "@RUN_STATUS@": result["run"]["status"],
    }
    for key, value in replacements.items():
        template = template.replace(key, value)
    return template


if __name__ == "__main__":
    result = run()
    report = ROOT / "reports/COMPOSITION_INDEPENDENT_AUDIT.md"
    report.write_text(report_text(result))
    result["outputs"] = [{"path": "reports/COMPOSITION_INDEPENDENT_AUDIT.md", "sha256": sha(report), "kind": "result"}]
    result["declared_results"] = ["reports/COMPOSITION_INDEPENDENT_AUDIT.md"]
    output = ROOT / "experiments/composition_independent_audit.json"
    output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"status": result["status"], "nodal_fixtures": len(result["positive_nodal_checks"]),
                      "exact_nodal_arguments": result["exact_nodal_argument_count"],
                      "rejection_controls": len(result["rejection_controls"]),
                      "portable_builder": result["portable_builder_regression"]["status"],
                      "source_unchanged": result["source_unchanged"], "output": str(output)}, indent=2))
    raise SystemExit(0 if result["status"] == "PASS" else 1)
