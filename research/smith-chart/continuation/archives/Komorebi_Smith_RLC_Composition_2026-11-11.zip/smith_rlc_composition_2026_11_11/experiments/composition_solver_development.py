"""Author: Komorebi P. Explicitly inspected development checks, not a holdout.

The target constructor is test-only. The dispatcher receives only P and Q and
cannot read the constructor, source certificates, or generating component data.
"""
from __future__ import annotations

import argparse
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))

from real_algebraic import add, mul, scale
from interval_certificate import reduce_target
from dispatch import dispatch
from composition_certificate import verify_circuit
from compositional_solver import synthesize_compositional


def cap(P, Q, g, l):
    N = add(P, mul([F(0), F(l)], Q))
    return reduce_target(N, add(Q, scale(N, F(g))))


def fixture_targets():
    P = list(map(F, [150, 630, 2388, 3360]))
    Q = list(map(F, [175, 810, 1826, 1736]))
    P4, Q4 = cap(P, Q, F(2, 5), F(3, 2))
    P5, Q5 = cap(P4, Q4, F(7, 11), F(5, 3))
    P6, Q6 = cap(P5, Q5, F(13, 17), F(19, 23))
    return [('endcap_degree4', P4, Q4), ('nested_endcaps_degree6', P6, Q6)]


def main(output):
    files = ['src/compositional_solver.py', 'src/dispatch.py',
             'src/composition_certificate.py', 'src/graph_search_synthesis.py',
             'src/recursive_modules.py', 'experiments/composition_solver_development.py']
    hashes_before = {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in files}
    rows = []
    for name, P, Q in fixture_targets():
        target = {'P': list(map(str, P)), 'Q': list(map(str, Q))}
        baseline = dispatch(P, Q, interval_search=False)
        started = time.perf_counter()
        result = dispatch(P, Q)
        assert result['status'] == 'CERTIFIED_MINIMUM', (name, result)
        checked = verify_circuit(result['certificate'], target, max(len(P), len(Q)) - 1)
        assert checked['global_minimum_proved_by_degree']
        direct = synthesize_compositional(P, Q)
        assert direct['status'] == 'CERTIFIED_MINIMUM', (name, direct)
        assert direct['certificate']['format'] == 'komorebi-rlc-composition-v1'
        direct_check = verify_circuit(direct['certificate'], target, max(len(P), len(Q)) - 1)
        assert direct_check['global_minimum_proved_by_degree']
        rows.append({'name': name, 'target': target, 'baseline_status': baseline['status'],
                     'elapsed_seconds': time.perf_counter() - started,
                     'result': result, 'independent_replay': checked,
                     'direct_compositional_result': direct, 'direct_independent_replay': direct_check})
        print(json.dumps({'name': name, 'baseline_status': baseline['status'],
                          'status': result['status'],
                          'reactive_count': checked['actual_storage'],
                          'direct_topology_calls': direct['topology_calls']}), flush=True)

    P4, Q4 = fixture_targets()[0][1:]
    controls = []
    for name, kwargs, expected in [
        ('degree_limit', {'max_degree': 3}, 'UNKNOWN'),
        ('reactive_budget_below_degree', {'max_budget': 3}, 'UNKNOWN'),
        ('state_limit_without_root_leaf', {'max_states': 1, 'max_topology_calls': 0}, 'UNKNOWN'),
        ('disabled_topology_calls', {'max_topology_calls': 0}, 'UNKNOWN'),
        ('invalid_bool_budget', {'max_budget': True}, 'INVALID_INPUT'),
        ('invalid_zero_starts', {'topology_starts': 0}, 'INVALID_INPUT'),
    ]:
        result = synthesize_compositional(P4, Q4, **kwargs)
        assert result['status'] == expected, (name, result)
        controls.append({'name': name, 'expected': expected, 'result': result})
    wrong_target = dispatch([1.25, 1], [1, 1])
    assert wrong_target['status'] == 'INVALID_INPUT'
    controls.append({'name': 'floating_point_input', 'result': wrong_target})

    hashes_after = {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in files}
    assert hashes_before == hashes_after
    report = {'author': 'Komorebi P.', 'status': 'PASS',
              'classification': 'Inspected development fixtures and resource/validation controls; not an untouched holdout',
              'successful_targets': len(rows), 'control_groups': len(controls),
              'results': rows, 'controls': controls,
              'input_sha256_before': hashes_before, 'input_sha256_after': hashes_after}
    Path(output).write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'status': 'PASS', 'successful_targets': len(rows),
                      'control_groups': len(controls), 'output': str(output)}), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', default=str(ROOT / 'experiments/composition_solver_development_results.json'))
    args = parser.parse_args()
    main(args.output)
