"""Komorebi P. Direct certificate composition, explicitly distinct from search."""
from pathlib import Path
from fractions import Fraction as F
import json
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from composition_certificate import (certificate_node,element_node,series_node,
                                     parallel_node,make_composition,verify_circuit)


def main():
    core=json.loads((ROOT/'certificates/historical_case_1.json').read_text())
    data=json.loads((ROOT/'experiments/composition_validation_inputs.json').read_text())
    expression=parallel_node(element_node('R','7/2'),
                             series_node(element_node('L','5/3'),certificate_node(core)))
    shown=make_composition(expression,target=data['cases'][0]['target'],budget=4)
    shown['provenance']={'author':'Komorebi P.','route':'Direct assembly of known cubic witness for illustrated circuit',
                         'is_target_only_discovery':False,'outer_resistor':'7/2','outer_inductor':'5/3'}
    certificate_path=ROOT/'certificates/composition_illustrated_degree4.json'
    certificate_path.write_text(json.dumps(shown,indent=2)+'\n')
    checked=verify_circuit(shown,data['cases'][0]['target'],4)
    assert checked['actual_storage']==4 and checked['resistors']==5
    expression=certificate_node(core)
    wrappers=[]
    for m in range(9):
        g=F(m+2,m+7); L=F(m+3,m+5)
        expression=parallel_node(element_node('R',1/g),series_node(element_node('L',L),expression))
        wrappers.append({'conductance':str(g),'resistance':str(1/g),'inductance':str(L)})
    twelve=make_composition(expression,budget=12)
    twelve['provenance']={'author':'Komorebi P.','route':'Direct forward lift of known interval core through nine endcaps',
                          'is_target_only_discovery':False,'wrappers_inner_to_outer':wrappers}
    path=ROOT/'certificates/composition_direct_degree12.json'
    path.write_text(json.dumps(twelve,indent=2)+'\n')
    twelve_check=verify_circuit(twelve,expected_budget=12)
    assert twelve_check['global_minimum_proved_by_degree']
    assert twelve_check['actual_storage']==12 and twelve_check['resistors']==13
    print(json.dumps({'status':'PASS','certificates':[str(certificate_path.relative_to(ROOT)),str(path.relative_to(ROOT))],
                      'degree4':{'reactive':4,'resistors':5},'degree12':{'reactive':12,'resistors':13},
                      'scope':'Forward certificate construction from known core, separate from target-only validation'},indent=2))


if __name__=='__main__':main()
