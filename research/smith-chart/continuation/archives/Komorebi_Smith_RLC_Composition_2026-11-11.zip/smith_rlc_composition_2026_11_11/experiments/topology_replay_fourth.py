"""Author: Komorebi P. Reproduce bounded discovery for historical case 3."""
import json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from topology_search import fit_target

if __name__=='__main__':
    c=json.loads((ROOT/'results/holdout_q3.json').read_text())['cases'][3]
    for resistors,starts,label in [(4,5,'multistart'),(5,2,'eight')]:
        result=fit_target(c['P'],c['Q'],resistors=resistors,starts=starts,max_nfev=600)
        (ROOT/f'experiments/topology_fourth_{label}.json').write_text(json.dumps(result,indent=2)+'\n')
        print(label,result['status'],result['attempts'],flush=True)
