"""Komorebi P. Freeze a target-only test of new composition routes.

This is structural validation around previously studied cubic targets, not
an untouched test of new cubic topology coverage. The solver receives only
the target coefficient file, never the separate generation record.
"""
from pathlib import Path
from fractions import Fraction as F
from math import gcd, lcm
import hashlib
import json
import random
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
from real_algebraic import add, mul, trim, gcd as pgcd, divmod_poly

SEED = 202611121137


def reduce_pair(P, Q):
    P, Q = trim(P), trim(Q)
    common = pgcd(P, Q)
    P, Q = divmod_poly(P, common)[0], divmod_poly(Q, common)[0]
    den = lcm(*(v.denominator for v in P + Q))
    values = [int(v * den) for v in P + Q]
    d = gcd(*values)
    sign = 1 if Q[-1] > 0 else -1
    values = [sign * v // d for v in values]
    return values[:len(P)], values[len(P):]


def plus(z, w):
    P, Q = z; A, B = w
    return reduce_pair(add(mul(P, B), mul(A, Q)), mul(Q, B))


def par(z, w):
    P, Q = z; A, B = w
    return reduce_pair(mul(P, A), add(mul(P, B), mul(A, Q)))


def invert_frequency(z):
    P, Q = z; n = max(len(P), len(Q))
    return reduce_pair(list(reversed(P + [F(0)] * (n - len(P)))),
                       list(reversed(Q + [F(0)] * (n - len(Q)))))


def main():
    rng = random.Random(SEED)
    samples = []
    records = []
    source_hashes = {}
    cores = {}
    for index in (1, 3, 21):
        path = ROOT / 'certificates' / f'historical_case_{index}.json'
        data = json.loads(path.read_text())
        cores[index] = ([F(x) for x in data['target']['P']],
                        [F(x) for x in data['target']['Q']])
        source_hashes[str(path.relative_to(ROOT))] = hashlib.sha256(path.read_bytes()).hexdigest()

    def value():
        return F(rng.randint(1, 9), rng.randint(2, 11))

    def record(name, core, ops):
        z = cores[core]
        q = 3
        encoded = []
        for op, args in ops:
            args = list(map(F, args))
            if op == 'endcap':
                g, L = args
                z = par(plus(z, ([0, L], [1])), ([1 / g], [1]))
                q += 1
            elif op == 'frequency_inverse':
                z = invert_frequency(z)
            elif op == 'series_L':
                z = plus(z, ([0, args[0]], [1])); q += 1
            elif op == 'series_C':
                z = plus(z, ([1], [0, args[0]])); q += 1
            elif op == 'shunt_C':
                z = par(z, ([1], [0, args[0]])); q += 1
            elif op == 'shunt_L':
                z = par(z, ([0, args[0]], [1])); q += 1
            elif op == 'series_RC_pole':
                rho, a = args
                z = plus(z, ([rho], [a, 1])); q += 1
            elif op == 'parallel_RL_pole':
                rho, a = args
                z = par(z, ([a, 1], [rho])); q += 1
            elif op == 'series_quadratic':
                # (s+1)/(s^2+2s+3) = C1 || R1 || (R1/2 + sL1/2).
                z = plus(z, ([1, 1], [3, 2, 1])); q += 2
            elif op == 'parallel_dual_quadratic':
                # Reciprocal of the explicitly series/parallel module above.
                z = par(z, ([3, 2, 1], [1, 1])); q += 2
            else:
                raise ValueError(op)
            encoded.append({'operation': op, 'arguments': list(map(str, args))})
        P, Q = reduce_pair(*z)
        degree = max(len(P), len(Q)) - 1
        assert degree == q, (name, degree, q)
        samples.append({'id': name, 'target': {'P': P, 'Q': Q}, 'expected_degree': degree})
        records.append({'id': name, 'source_core_case': core, 'generation_operations': encoded})

    record('endcap_degree4', 1, [('endcap', ['2/7', '5/3'])])
    record('endcaps_degree5', 3, [('endcap', [value(), value()]) for _ in range(2)])
    record('endcaps_degree6', 21, [('endcap', [value(), value()]) for _ in range(3)])
    record('endcaps_degree7', 1, [('endcap', [value(), value()]) for _ in range(4)])
    record('inverse_endcap_degree4', 3, [('endcap', [value(), value()]), ('frequency_inverse', [])])
    record('inverse_endcaps_degree5', 21, [('endcap', [value(), value()]) for _ in range(2)] + [('frequency_inverse', [])])
    record('series_L_degree4', 1, [('series_L', [value()])])
    record('series_C_degree4', 3, [('series_C', [value()])])
    record('shunt_C_degree4', 21, [('shunt_C', [value()])])
    record('shunt_L_degree4', 1, [('shunt_L', [value()])])
    record('series_RC_degree4', 3, [('series_RC_pole', [value(), value()])])
    record('parallel_RL_degree4', 21, [('parallel_RL_pole', [value(), value()])])
    record('series_quadratic_degree5', 1, [('series_quadratic', [])])
    record('parallel_quadratic_degree5', 3, [('parallel_dual_quadratic', [])])

    folder = ROOT / 'experiments'
    inputs = folder / 'composition_validation_inputs.json'
    generation = folder / 'composition_validation_generation.json'
    contract = folder / 'composition_validation_freeze.json'
    for path in (inputs, generation, contract):
        if path.exists():
            raise FileExistsError('Refusing to overwrite frozen evidence: ' + str(path))
    inputs.write_text(json.dumps({'schema': 'target-only-composition-validation-v1',
                                 'cases': samples}, indent=2) + '\n')
    generation.write_text(json.dumps({'author': 'Komorebi P.', 'seed': SEED,
                                     'source_target_hashes': source_hashes,
                                     'cases': records}, indent=2) + '\n')
    freeze = {
        'author': 'Komorebi P.',
        'claim': 'Bounded structural validation of composition discovery around known cubic cores',
        'scope': '14 unseen wrapper targets, degrees4-7; cubic source targets are previously studied',
        'non_claims': ['New cubic topology coverage', 'Complete synthesis', 'Total component minimum'],
        'seed': SEED,
        'frozen_before_first_solver_run': True,
        'files': {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
                  for p in (Path(__file__), inputs, generation)},
        'source_target_hashes': source_hashes,
        'solver_inputs': str(inputs.relative_to(ROOT)),
        'forbidden_solver_input': str(generation.relative_to(ROOT)),
        'planned_acceptance': 'Independent exact original-target binding, actual storage equals reduced degree',
        'planned_budget': {'max_degree': 12, 'max_states': 80, 'topology_starts': 2,
                           'topology_evaluations': 600, 'topology_seed': 2026111223,
                           'max_topology_calls': 16},
        'software': {'python': sys.version.split()[0]},
    }
    contract.write_text(json.dumps(freeze, indent=2) + '\n')
    print(json.dumps({'status': 'FROZEN', 'cases': len(samples),
                      'files': freeze['files'], 'example': samples[0]}, indent=2))


if __name__ == '__main__':
    main()
