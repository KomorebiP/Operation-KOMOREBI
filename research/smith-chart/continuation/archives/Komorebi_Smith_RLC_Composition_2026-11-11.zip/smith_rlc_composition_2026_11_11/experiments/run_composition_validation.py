"""Komorebi P. Frozen target-only structural validation, with exact acceptance."""
from pathlib import Path
import argparse
import hashlib
import json
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'src'))
from dispatch import dispatch
from composition_certificate import verify_circuit


def run(output):
    started = time.perf_counter()
    inputs = ROOT/'experiments/composition_validation_inputs.json'
    data = json.loads(inputs.read_text())
    freeze = json.loads((ROOT/'experiments/composition_validation_freeze.json').read_text())
    key = str(inputs.relative_to(ROOT))
    assert hashlib.sha256(inputs.read_bytes()).hexdigest() == freeze['files'][key]
    baseline = json.loads((ROOT/'computations/composition_baseline_001/results.json').read_text())
    old = {r['id']: r for r in baseline['cases']}
    kwargs = freeze['planned_budget']
    rows = []
    output.parent.mkdir(parents=True, exist_ok=True)
    for case in data['cases']:
        target = case['target']; t0 = time.perf_counter()
        answer = dispatch(target['P'], target['Q'], max_budget=case['expected_degree'], **kwargs)
        verification = None
        if answer['status'] == 'CERTIFIED_MINIMUM':
            verification = verify_circuit(answer['certificate'], expected_target=target,
                                           expected_budget=case['expected_degree'])
            assert verification['status'] == 'PASS'
            assert verification['actual_storage'] == case['expected_degree']
            assert verification['global_minimum_proved_by_degree']
        row = {'id': case['id'], 'target': target, 'expected_degree': case['expected_degree'],
               'baseline_status': old[case['id']]['status'], 'status': answer['status'],
               'certificate_format': answer.get('certificate', {}).get('format'),
               'verification': verification, 'seconds': time.perf_counter()-t0,
               'result': answer}
        rows.append(row)
        output.write_text(json.dumps({'status':'IN_PROGRESS','cases':rows}, indent=2)+'\n')
        print('VALIDATION', case['id'], 'baseline='+row['baseline_status'],
              'current='+answer['status'], 'q='+str(case['expected_degree']),
              'seconds='+str(round(row['seconds'], 3)), flush=True)
    record = {'status':'PASS' if all(r['status']=='CERTIFIED_MINIMUM' for r in rows) else 'PARTIAL',
              'author':'Komorebi P.',
              'claim':'Bounded structural validation of composition discovery around known cubic cores',
              'total':len(rows), 'baseline_certified':baseline['certified'],
              'certified':sum(r['status']=='CERTIFIED_MINIMUM' for r in rows),
              'unknown':sum(r['status']=='UNKNOWN' for r in rows),
              'newly_solved':sum(r['status']=='CERTIFIED_MINIMUM' and r['baseline_status']=='UNKNOWN' for r in rows),
              'composition_certificates':sum(r['certificate_format']=='komorebi-rlc-composition-v1' for r in rows),
              'legacy_algebraic_certificates':sum(r['certificate_format']=='komorebi-algebraic-circuit-v1' for r in rows),
              'bounds':kwargs,'input_sha256':hashlib.sha256(inputs.read_bytes()).hexdigest(),
              'seconds':time.perf_counter()-started,'cases':rows,
              'interpretation':'Inputs and seed were frozen before first run of this implementation. These are fresh wrapper targets around already studied cubic targets, not new cubic-core topology coverage. Each accepted exact certificate binds to the original target. Search failure is UNKNOWN, not impossibility.'}
    output.write_text(json.dumps(record, indent=2)+'\n')
    print(json.dumps({k:v for k,v in record.items() if k!='cases'}, indent=2), flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True)
    run(p.parse_args().output)
