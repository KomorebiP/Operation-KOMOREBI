"""Author: Komorebi P. Independent review fixtures for RLC interval kernels.

The finite fixtures cross-check compiler arithmetic.  The uniform theorem is
the audited determinant/contraction proof, not an inference from these fixtures.
"""
from pathlib import Path
from fractions import Fraction as F
from copy import deepcopy
import hashlib
import json
import platform
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
from interval_certificate import (graph_polynomials, build_coefficient_system,
    evaluate_polynomial, evaluate_system, verify_interval_circuit)
from interval_family import (joint_system, sylvester_matrix,
    verify_coefficient_family)


def determinant(matrix):
    """Independent fraction-free-in-spirit Gaussian determinant, exact Fractions."""
    A = [list(map(F, row)) for row in matrix]
    result = F(1)
    n = len(A)
    for k in range(n):
        j = next((i for i in range(k, n) if A[i][k]), None)
        if j is None:
            return F(0)
        if j != k:
            A[k], A[j] = A[j], A[k]
            result = -result
        pivot = A[k][k]
        result *= pivot
        for i in range(k + 1, n):
            factor = A[i][k] / pivot
            for j in range(k + 1, n):
                A[i][j] -= factor * A[k][j]
    return result


def nodal_pair(branches, values, s):
    nodes = sorted({n for row in branches for n in row['nodes']} - {0})
    index = {n: k for k, n in enumerate(nodes)}
    matrix = [[F(0)] * len(nodes) for _ in nodes]
    n_inductors = 0
    for row, value in zip(branches, values):
        kind = row['type']
        y = value if kind == 'g' else value * s if kind == 'c' else value / s
        n_inductors += kind == 'h'
        a, b = row['nodes']
        if a:
            matrix[index[a]][index[a]] += y
        if b:
            matrix[index[b]][index[b]] += y
        if a and b:
            matrix[index[a]][index[b]] -= y
            matrix[index[b]][index[a]] -= y
    p = index[1]
    minor = [[a for j, a in enumerate(row) if j != p]
             for i, row in enumerate(matrix) if i != p]
    return s ** n_inductors * determinant(minor), s ** n_inductors * determinant(matrix)


def univariate_value(polys, values, s):
    return sum((evaluate_polynomial(poly, values) * s ** k
                for k, poly in enumerate(polys)), F(0))


def require_rejected(fn, cert):
    try:
        fn(cert)
    except (ValueError, KeyError, TypeError):
        return True
    raise AssertionError('Corrupted certificate accepted')


def main():
    paths = ['src/interval_certificate.py', 'src/interval_family.py',
             'src/exact_polynomials.py', 'src/real_algebraic.py',
             'certificates/historical_case_1.json',
             'certificates/local_family_case_1.json']
    def hashes():
        return {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in paths}
    before = hashes()
    start = time.perf_counter()
    point = json.loads((ROOT / paths[-2]).read_text())
    family = json.loads((ROOT / paths[-1]).read_text())
    point_report = verify_interval_circuit(point, expected_target=point['target'], expected_budget=3)
    family_report = verify_coefficient_family(family)
    graph = graph_polynomials(point['branches'])
    fixtures = [[F(i + 2, i + 3) for i in range(7)],
                [F(2 * i + 3, 3 * i + 2) for i in range(7)],
                [F(3 * i + 5, i + 1) for i in range(7)]]
    arguments = [F(1, 7), F(1, 2), F(1), F(2), F(5), F(11), F(17)]
    nodal_count = 0
    for values in fixtures:
        for s in arguments:
            expected = nodal_pair(point['branches'], values, s)
            actual = (univariate_value(graph['numerator'], values, s),
                      univariate_value(graph['denominator'], values, s))
            assert expected == actual
            nodal_count += 1
    _, joint = joint_system(family['branches'])
    a = list(map(F, family['target_box']['center']))
    rho = list(map(F, family['target_box']['radii']))
    target_samples = [a,
                      [v + r for v, r in zip(a, rho)],
                      [v - r for v, r in zip(a, rho)],
                      [v + (-1) ** i * r for i, (v, r) in enumerate(zip(a, rho))]]
    joint_count = 0
    for values in fixtures:
        for target in target_samples:
            system = build_coefficient_system(family['branches'], target[:4], target[4:] + [F(1)])
            expected = evaluate_system(system, values)
            actual = [evaluate_polynomial(poly, values + target) for poly in joint]
            assert expected == actual
            joint_count += 1
    # Direct convolution checks the exact Sylvester orientation and coordinate order.
    sylvester_count = 0
    for target in target_samples:
        uv = [F(2), F(-3), F(7, 4), F(-1), F(5, 2), F(9)]
        P = target[:4]
        Q = target[4:] + [F(1)]
        independent = [F(0)] * 6
        for k in range(3):
            for j in range(4):
                independent[k + j] += uv[k] * P[j] + uv[k + 3] * Q[j]
        computed = [sum((x * y for x, y in zip(row, uv)), F(0))
                    for row in sylvester_matrix(target)]
        assert independent == computed
        assert determinant(sylvester_matrix(target)) != 0
        sylvester_count += 1
    controls = []
    c = deepcopy(point)
    c['target']['P'][0] = str(F(c['target']['P'][0]) + 1)
    controls.append(('point_wrong_target', require_rejected(verify_interval_circuit, c)))
    c = deepcopy(point)
    c['preconditioner'][0] = ['0'] * 7
    controls.append(('point_singular_preconditioner', require_rejected(verify_interval_circuit, c)))
    c = deepcopy(point)
    c['radii'][0] = str(F(c['center'][0]))
    controls.append(('point_nonpositive_box', require_rejected(verify_interval_circuit, c)))
    c = deepcopy(family)
    c['preconditioner'][0] = ['0'] * 7
    controls.append(('family_singular_preconditioner', require_rejected(verify_coefficient_family, c)))
    c = deepcopy(family)
    c['target_box']['radii'] = ['10'] * 7
    controls.append(('family_wide_target_box', require_rejected(verify_coefficient_family, c)))
    c = deepcopy(family)
    c['target_box']['coordinates'] = 'different order'
    controls.append(('family_coordinate_swap', require_rejected(verify_coefficient_family, c)))
    c = deepcopy(family)
    c['branches'][0]['type'] = 'g'
    controls.append(('family_wrong_storage', require_rejected(verify_coefficient_family, c)))
    c = deepcopy(family)
    c['target_box']['center'][3] = '0'
    controls.append(('family_degree_loss', require_rejected(verify_coefficient_family, c)))
    after = hashes()
    report = {'status': 'PASS' if before == after else 'INPUTS_CHANGED',
              'python': platform.python_version(),
              'argv': [sys.executable, '-S', 'experiments/prior_independent_audit.py'],
              'assertion_tested': 'Kernel replay and independent rational determinant, coefficient, and convolution fixtures; corruption rejection.',
              'inputs_before': before, 'inputs_after': after,
              'nodal_fixture_pairs': nodal_count,
              'joint_coefficient_fixture_pairs': joint_count,
              'sylvester_convolution_fixtures': sylvester_count,
              'rejection_controls': controls,
              'point_replay': point_report, 'family_replay': family_report,
              'elapsed_seconds': time.perf_counter() - start,
              'limitation': 'Finite fixtures validate implementation examples. The all-real family claim depends on the separately audited uniform interval proof.'}
    (ROOT / 'experiments/prior_independent_audit.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: v for k, v in report.items() if k not in ('point_replay', 'family_replay', 'inputs_before', 'inputs_after')}, indent=2))


if __name__ == '__main__':
    main()
