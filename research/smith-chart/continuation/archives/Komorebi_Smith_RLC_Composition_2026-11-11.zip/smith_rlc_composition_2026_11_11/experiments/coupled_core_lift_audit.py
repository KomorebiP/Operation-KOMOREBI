"""Author: Komorebi P. Exact checks accompanying the coupled-core lift proof.

The universal result is proved in reports/COUPLED_CORE_LIFT_THEOREM.md.
This script replays the inherited uniform cubic certificate, then checks a
finite, declared set of rational instances and domain controls.  Its polynomial
arithmetic is independent of the endpoint extraction and composition code.
Only the Python standard library is needed; run with python3 -S.
"""
from __future__ import annotations

import argparse
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path
import platform
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from interval_family import verify_coefficient_family


def trim(poly):
    result = [F(v) for v in poly]
    while len(result) > 1 and result[-1] == 0:
        result.pop()
    return result or [F(0)]


def plus(left, right):
    size = max(len(left), len(right))
    return trim([(left[i] if i < len(left) else F(0))
                 + (right[i] if i < len(right) else F(0))
                 for i in range(size)])


def times_scalar(poly, value):
    return trim([F(value) * v for v in poly])


def minus(left, right):
    return plus(left, times_scalar(right, -1))


def shift(poly):
    return trim([F(0)] + list(poly))


def divide(left, right):
    remainder, right = trim(left), trim(right)
    if not any(right):
        raise ZeroDivisionError("zero polynomial")
    quotient = [F(0)] * max(1, len(left) - len(right) + 1)
    while any(remainder) and len(remainder) >= len(right):
        power = len(remainder) - len(right)
        coefficient = remainder[-1] / right[-1]
        quotient[power] += coefficient
        remainder = minus(remainder, [F(0)] * power
                          + times_scalar(right, coefficient))
    return trim(quotient), remainder


def monic_gcd(left, right):
    left, right = trim(left), trim(right)
    while any(right):
        left, right = right, divide(left, right)[1]
    return times_scalar(left, 1 / left[-1]) if any(left) else [F(0)]


def value(poly, s):
    result = F(0)
    for coefficient in reversed(poly):
        result = result * s + coefficient
    return result


def normalize(P, Q):
    P, Q = trim(P), trim(Q)
    if not any(Q):
        raise ValueError("zero denominator")
    return times_scalar(P, 1 / Q[-1]), times_scalar(Q, 1 / Q[-1])


def core_domain(P, Q):
    P, Q = trim(P), trim(Q)
    if len(P) != len(Q) or Q[-1] != 1 or P[-1] <= 0:
        raise ValueError("equal exact degrees, monic Q, and positive P lead required")
    if monic_gcd(P, Q) != [F(1)]:
        raise ValueError("coprime core required")
    return len(P) - 1


def lift(P, Q, g, L):
    n = core_domain(P, Q)
    g, L = F(g), F(L)
    if g <= 0 or L <= 0:
        raise ValueError("strictly positive g and L required")
    N = plus(P, times_scalar(shift(Q), L))
    D = plus(Q, times_scalar(N, g))
    U, V = normalize(N, D)
    assert core_domain(U, V) == n + 1
    return U, V


def unlift(U, V):
    d = core_domain(U, V)
    if d < 1:
        raise ValueError("positive output degree required")
    g = 1 / U[-1]
    H = minus(V, times_scalar(U, g))
    if len(H) != d or H[-1] <= 0:
        raise ValueError("H must have degree d-1 and positive leading coefficient")
    L = U[-1] / H[-1]
    K = minus(U, times_scalar(shift(H), L))
    if len(K) != d or K[-1] <= 0:
        raise ValueError("K must have degree d-1 and positive leading coefficient")
    P, Q = normalize(K, H)
    assert core_domain(P, Q) == d - 1
    return P, Q, g, L


def exact_target(P, Q):
    return {"P": list(map(str, P)), "Q": list(map(str, Q))}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def rejected(label, function):
    try:
        function()
    except (ValueError, ZeroDivisionError) as exc:
        return {"label": label, "status": "REJECTED", "reason": str(exc)}
    raise AssertionError("Domain control unexpectedly accepted: " + label)


def run():
    sources = [
        "certificates/local_family_case_1.json",
        "src/interval_family.py", "src/interval_certificate.py",
        "src/exact_polynomials.py", "src/real_algebraic.py",
        "experiments/coupled_core_lift_audit.py",
    ]
    before = {name: sha(ROOT / name) for name in sources}
    cert = json.loads((ROOT / sources[0]).read_text())
    family_check = verify_coefficient_family(cert)
    assert family_check["status"] == "PASS"
    assert F(family_check["uniform_contraction_bound"]) < F(1, 4)
    assert F(family_check["sylvester_nonsingularity_bound"]) < F(1, 10**6)
    center = list(map(F, cert["target_box"]["center"]))
    radii = list(map(F, cert["target_box"]["radii"]))
    # These four points are strictly inside the certified real coefficient box.
    offsets = [
        [F(0)] * 7,
        [F(1, 2)] * 7,
        [F(-1, 2)] * 7,
        [F((-1) ** j, 3) for j in range(7)],
    ]
    streams = [
        [(F(j + 2, j + 5), F(2 * j + 3, j + 2)) for j in range(9)],
        [(F(j + 7, 2 * j + 3), F(j + 1, j + 4)) for j in range(9)],
        [(F(1, j + 2), F(j + 2, 1)) for j in range(9)],
    ]
    selected_depths = {0, 1, 2, 3, 5, 9}
    rows, nodal_identity_checks = [], 0
    for base_id, offset in enumerate(offsets):
        coordinates = [a + r * t for a, r, t in zip(center, radii, offset)]
        baseP, baseQ = coordinates[:4], coordinates[4:] + [F(1)]
        assert core_domain(baseP, baseQ) == 3
        for stream_id, stream in enumerate(streams):
            P, Q = baseP, baseQ
            wrappers = []
            for depth in range(10):
                if depth:
                    g, L = stream[depth - 1]
                    U, V = lift(P, Q, g, L)
                    # Direct scalar impedance identity at nonzero rational s,
                    # independent of the inverse implementation.
                    for s in [F(1, 7), F(1), F(11, 3)]:
                        z = value(P, s) / value(Q, s)
                        expected = 1 / (g + 1 / (L * s + z))
                        assert value(U, s) / value(V, s) == expected
                        nodal_identity_checks += 1
                    recovered = unlift(U, V)
                    assert recovered == (P, Q, g, L)
                    P, Q = U, V
                    wrappers.append((g, L))
                if depth in selected_depths:
                    coreP, coreQ = P, Q
                    recovered_wrappers = []
                    for _ in range(depth):
                        coreP, coreQ, g, L = unlift(coreP, coreQ)
                        recovered_wrappers.append((g, L))
                    assert (coreP, coreQ) == (baseP, baseQ)
                    assert recovered_wrappers == list(reversed(wrappers))
                    # Monic normalization is invariant under either sign of a
                    # nonzero common representation scale.
                    for scale in [F(11, 7), F(-13, 5)]:
                        assert normalize(times_scalar(P, scale),
                                         times_scalar(Q, scale)) == (P, Q)
                    rows.append({
                        "base_id": base_id, "wrapper_stream_id": stream_id,
                        "depth": depth, "reduced_degree": 3 + depth,
                        "reactive_count": 3 + depth,
                        "resistor_count": 4 + depth,
                        "inverse_roundtrip": "PASS",
                        "target_sha256": hashlib.sha256(json.dumps(
                            exact_target(P, Q), sort_keys=True).encode()).hexdigest(),
                    })
    # Nullary iteration and the smallest algebraic lift are checked explicitly.
    constantP, constantQ = [F(5, 7)], [F(1)]
    oneU, oneV = lift(constantP, constantQ, F(3, 5), F(7, 11))
    assert unlift(oneU, oneV) == (constantP, constantQ, F(3, 5), F(7, 11))
    controls = [
        rejected("zero g", lambda: lift(constantP, constantQ, 0, 1)),
        rejected("zero L", lambda: lift(constantP, constantQ, 1, 0)),
        rejected("negative g", lambda: lift(constantP, constantQ, -1, 1)),
        rejected("negative L", lambda: lift(constantP, constantQ, 1, -1)),
        rejected("noncoprime raw degree", lambda: lift([F(1), F(1)], [F(1), F(1)], 1, 1)),
        rejected("unequal core degrees", lambda: lift([F(1)], [F(1), F(1)], 1, 1)),
        rejected("negative core leading ratio", lambda: lift([F(-1)], [F(1)], 1, 1)),
        rejected("nonmonic core representation", lambda: lift([F(2)], [F(2)], 1, 1)),
        rejected("inverse H degree collapse", lambda: unlift([F(1), F(0), F(1)], [F(2), F(0), F(1)])),
        rejected("inverse nonpositive H lead", lambda: unlift([F(2), F(1)], [F(1), F(1)])),
        rejected("inverse negative K lead", lambda: unlift([F(-1), F(1)], [F(2), F(1)])),
    ]
    exampleP = list(map(F, [150, 630, 2388, 3360]))
    exampleQ = list(map(F, [175, 810, 1826, 1736]))
    exampleP, exampleQ = normalize(exampleP, exampleQ)
    exampleU, exampleV = lift(exampleP, exampleQ, F(2, 5), F(3, 2))
    integerP = list(map(F, [1500, 8925, 36030, 60990, 26040]))
    integerQ = list(map(F, [2350, 11670, 32672, 41756, 10416]))
    assert normalize(integerP, integerQ) == (exampleU, exampleV)
    assert unlift(exampleU, exampleV) == (exampleP, exampleQ, F(2, 5), F(3, 2))
    after = {name: sha(ROOT / name) for name in sources}
    assert before == after
    return {
        "status": "PASS",
        "author": "Komorebi P.",
        "arithmetic": "Python standard-library Fraction and integer arithmetic",
        "python": platform.python_version(),
        "source_hashes_before": before, "source_hashes_after": after,
        "source_unchanged": True,
        "uniform_cubic_certificate_replay": family_check,
        "finite_check_scope": {
            "coefficient_points": 4, "wrapper_streams": 3,
            "selected_depths": sorted(selected_depths),
            "selected_degree_range": [3, 12],
            "selected_instances": len(rows),
            "single_step_roundtrips": 4 * 3 * 9,
            "exact_scalar_identity_checks": nodal_identity_checks,
            "randomness": "none; all fixtures deterministic and declared in script",
            "interpretation": "supplementary finite controls; the all-degree/all-real claim rests on the report proof",
        },
        "instances": rows,
        "degree_zero_core_to_degree_one_roundtrip": "PASS",
        "domain_rejection_controls": controls,
        "degree_four_example": {
            "core_target": {"P": [150, 630, 2388, 3360], "Q": [175, 810, 1826, 1736]},
            "conductance_g": "2/5", "resistance_R": "5/2", "inductance_L": "3/2",
            "integer_target": exact_target(integerP, integerQ),
            "normalized_target": exact_target(exampleU, exampleV),
            "reactive_count": 4, "resistor_count": 5,
        },
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path,
                        default=ROOT / "experiments/coupled_core_lift_audit.json")
    args = parser.parse_args()
    result = run()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"status": result["status"],
                      "instances": result["finite_check_scope"]["selected_instances"],
                      "rejection_controls": len(result["domain_rejection_controls"]),
                      "output": str(args.output)}, indent=2))
