"""Author: Komorebi P. Python-only exact circuit figure for this checkpoint."""
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'figures';OUT.mkdir(exist_ok=True)
fig,ax=plt.subplots(figsize=(12,7.6),dpi=190)
fig.patch.set_facecolor('#f8fafc');ax.set_facecolor('#f8fafc')
ink='#183145';reactive='#087f8c';resistive='#9b5825'
lw=2.8

def wire(x,y):ax.plot(x,y,color=ink,lw=lw,solid_capstyle='round')

def resistor(a,b,label,label_position):
    a=np.array(a,dtype=float);b=np.array(b,dtype=float);d=b-a;n=np.array([-d[1],d[0]])/np.linalg.norm(d)
    t=np.linspace(0.12,0.88,9);zig=np.array([a+d*u+n*(0 if i in (0,8) else (0.12 if i%2 else -.12)) for i,u in enumerate(t)])
    wire([a[0],zig[0,0]],[a[1],zig[0,1]]);wire([zig[-1,0],b[0]],[zig[-1,1],b[1]])
    ax.plot(zig[:,0],zig[:,1],lw=lw,color=resistive)
    ax.text(*label_position,label,fontsize=18,color=ink,ha='center',va='center')

def capacitor(a,b,label,label_position):
    a=np.array(a,dtype=float);b=np.array(b,dtype=float);d=b-a;u=d/np.linalg.norm(d);n=np.array([-u[1],u[0]])
    c=(a+b)/2;p=c-.07*u;q=c+.07*u
    wire([a[0],p[0]],[a[1],p[1]]);wire([q[0],b[0]],[q[1],b[1]])
    for v in (p,q):ax.plot([v[0]-.24*n[0],v[0]+.24*n[0]],[v[1]-.24*n[1],v[1]+.24*n[1]],lw=3.5,color=reactive)
    ax.text(*label_position,label,fontsize=18,color=ink,ha='center',va='center')

def inductor(a,b,label,label_position):
    a=np.array(a,dtype=float);b=np.array(b,dtype=float);u=(b-a)/np.linalg.norm(b-a);n=np.array([-u[1],u[0]])
    start=a+.22*u;end=b-.22*u;length=np.linalg.norm(end-start)
    wire([a[0],start[0]],[a[1],start[1]]);wire([end[0],b[0]],[end[1],b[1]])
    for i in range(4):
        theta=np.linspace(-np.pi/2,np.pi/2,80)
        path=start[None,:]+u[None,:]*(length/4*(i+.5)+length/8*np.sin(theta))[:,None]+n[None,:]*(.18*np.cos(theta))[:,None]
        ax.plot(path[:,0],path[:,1],lw=lw,color=reactive)
    ax.text(*label_position,label,fontsize=18,color=ink,ha='center',va='center')

ax.text(0,4.1,'Exact five-element realization',fontsize=27,fontweight='bold',color=ink)
ax.text(0,3.58,'Three reactive elements attain the exact degree lower bound.',fontsize=15,color='#4c6373')
wire([0,.7],[2.3,2.3]);capacitor((.7,2.3),(2.2,2.3),r'$C_0=\frac{4}{5}$',(1.45,2.94));wire([2.2,3.1],[2.3,2.3])
inductor((3.1,2.3),(3.1,0),r'$L=7$',(2.35,1.18))
wire([3.1,3.8],[2.3,2.3]);resistor((3.8,2.3),(5.7,2.3),r'$R_1=\frac{10}{7}$',(4.75,2.94));wire([5.7,6.65],[2.3,2.3])
resistor((6.65,2.3),(6.65,0),r'$R_2=\frac{6}{35}$',(5.77,1.12))
wire([6.65,8.8],[2.3,2.3]);capacitor((8.8,2.3),(8.8,0),r'$C_1=\frac{147}{16}$',(9.7,1.12))
wire([0,8.8],[0,0])
for x,y in [(3.1,2.3),(3.1,0),(6.65,2.3),(6.65,0),(8.8,0)]:ax.plot(x,y,'o',color=ink,ms=6)
for y in (0,2.3):ax.plot(0,y,'o',mfc='#f8fafc',mec=ink,mew=2.6,ms=8)
ax.text(-.42,1.2,r'$Z(s)$',fontsize=21,color=ink,rotation=90,ha='center',va='center')
ax.text(0,-.58,'All component values are exact and strictly positive. Normalized units.',fontsize=13,color='#4c6373')
ax.text(0,-1.42,r'$Z(s)=\dfrac{2520s^3+3997s^2+1850s+320}{1764s^3+1480s^2+256s}$',fontsize=23,color=ink)
ax.text(0,-2.07,'Komorebi P.  |  Smith chart / RLC continuation  |  November 11, 2026',fontsize=11,color='#60717d')
ax.set_xlim(-.7,10.7);ax.set_ylim(-2.25,4.45);ax.axis('off')
fig.subplots_adjust(left=.045,right=.98,top=.97,bottom=.04)
fig.savefig(OUT/'Exact_Boundary_Circuit.png',facecolor=fig.get_facecolor(),bbox_inches='tight')
fig.savefig(OUT/'Exact_Boundary_Circuit.svg',facecolor=fig.get_facecolor(),bbox_inches='tight')
plt.close(fig)
