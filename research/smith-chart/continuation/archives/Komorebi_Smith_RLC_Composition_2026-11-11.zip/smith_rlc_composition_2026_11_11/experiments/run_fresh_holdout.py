"""Author: Komorebi P. Frozen independent q3 benchmark, target-only fitting."""
from pathlib import Path
import argparse
import hashlib
import json
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from recursive_modules import synthesize
from graph_search_synthesis import find_topology_interval
from algebraic_witness import verify_algebraic_circuit
from interval_certificate import verify_interval_circuit


def run(output):
    path=ROOT/'experiments/fresh_holdout_inputs.json'
    data=json.loads(path.read_text());started=time.perf_counter();rows=[]
    before={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted((ROOT/'src').glob('*.py'))}
    for row in data['cases']:
        target=row['target']
        # Baseline truth is checked independently, never passed into fitting.
        verify_algebraic_circuit(row['known_witness'],target,3)
        t=time.perf_counter();baseline=synthesize(target['P'],target['Q'],max_degree=3)
        baseline_seconds=time.perf_counter()-t
        if baseline['status']=='CERTIFIED_MINIMUM':
            verify_algebraic_circuit(baseline['certificate'],target,3)
            result=baseline;new_seconds=0.0
        else:
            t=time.perf_counter()
            result=find_topology_interval(target['P'],target['Q'],starts=1,max_nfev=220,max_candidates=2)
            new_seconds=time.perf_counter()-t
            if result['status']=='CERTIFIED_MINIMUM':
                verify_interval_circuit(result['certificate'],target,3)
        rows.append({'index':row['index'],'node_count':row['node_count'],
                     'target':target,'baseline_status':baseline['status'],
                     'baseline_seconds':baseline_seconds,'interval_search_seconds':new_seconds,
                     'final_status':result['status'],'result':result})
        print('FRESH',row['index'],'nodes',row['node_count'],baseline['status'],'->',result['status'],flush=True)
    after={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()
           for p in sorted((ROOT/'src').glob('*.py'))}
    if before!=after:raise RuntimeError('Solver sources changed during fresh validation')
    summary=[]
    for nodes in (4,5):
        part=[row for row in rows if row['node_count']==nodes]
        summary.append({'nodes':nodes,'cases':len(part),
                        'baseline_certified':sum(row['baseline_status']=='CERTIFIED_MINIMUM' for row in part),
                        'final_certified':sum(row['final_status']=='CERTIFIED_MINIMUM' for row in part),
                        'unknown':sum(row['final_status']=='UNKNOWN' for row in part)})
    record={'status':'COMPLETE','input_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
            'seed':data['seed'],'valid_cases':len(rows),'summary':summary,
            'baseline_certified':sum(row['baseline_status']=='CERTIFIED_MINIMUM' for row in rows),
            'final_certified':sum(row['final_status']=='CERTIFIED_MINIMUM' for row in rows),
            'unknown':sum(row['final_status']=='UNKNOWN' for row in rows),
            'solver_source_hashes':before,'sources_unchanged':before==after,
            'caps':{'starts':1,'max_nfev':220,'max_candidates_per_resistor_count':2,'resistor_counts':[4,5]},
            'elapsed_seconds':time.perf_counter()-started,'cases':rows,
            'scope':'Finite seeded 4/5-node rational-component corpus. No universal coverage claim.'}
    output.parent.mkdir(parents=True,exist_ok=True)
    output.write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps({k:v for k,v in record.items() if k not in ('cases','solver_source_hashes')},indent=2),flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',required=True,type=Path)
    run(p.parse_args().output)
