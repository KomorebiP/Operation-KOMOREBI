# Exact composition of independently certified RLC networks

**Author: Komorebi P.**  
**Continuation date:** November 12, 2026.  
**Implementation:** `src/composition_certificate.py`  
**Certificate format:** `komorebi-rlc-composition-v1`

## 1. Result and precise scope

An accepted composition certificate specifies a connected, finite, two-terminal
network of strictly positive, uncoupled resistors, inductors, and capacitors.
The network is rebuilt from verified circuit leaves and physical element leaves
using series connection, parallel connection, and frequency inversion. Its input
impedance is exactly the declared rational function, and its actual number of
reactive branch instances is at most the declared storage budget.

Algebraic circuit leaves and interval-certified circuit leaves may be mixed.
Different leaves may use different algebraic number fields or different exact
interval roots. No common primitive element is required. Each leaf occurrence
retains its own exact parameter context and receives fresh internal vertices.

Let `q` be the actual number of inductors and capacitors in the rebuilt graph,
and let `n` be the reduced rational degree of the complete target. When `q = n`,
the witness establishes a global minimum of `n` reactive elements within the
stated positive, finite, uncoupled RLC model. When `q > n`, the certificate
establishes a realization only. That inequality does not, by itself, prove the
witness nonminimal: the degree lower bound can be nonsharp. In the explicit
duplicate-capacitor test, a smaller circuit is independently evident.

This is a composition theorem and a bounded proof checker. It is not a complete
synthesis algorithm, an exhaustive topology classification, a general
lower-budget refutation method, or a novelty claim. Optimizer failures and
restricted search misses supply no impossibility conclusion.

## 2. Model and independent leaf obligations

Vertices `0` and `1` are the ground and input terminal of an individual leaf.
For a positive Laplace argument `s`, the three branch types have admittances

\[
y_g(s)=g,\qquad y_h(s)=\frac{h}{s},\qquad y_c(s)=cs,
\]

where

\[
g=\frac1R>0,\qquad h=\frac1L>0,\qquad c=C>0.
\]

The existing `komorebi-algebraic-circuit-v1` checker verifies an isolated real
root, exact positive branch coefficients in its polynomial quotient
representation, connectivity, and the exact driving-point rational identity by
nodal solves and a sufficient number of exact interpolation samples. Its
polynomial and sign machinery is in `real_algebraic.py`. The composition wrapper
adds explicit shape and resource checks before calling that unchanged kernel.

The existing `komorebi-rlc-interval-v1` checker reconstructs every coefficient
equation of the graph identity from the physical graph. Its rational
preconditioner must be invertible. Strict self-mapping and a weighted
contraction prove a unique exact real component vector in the supplied positive
box, including any declared fixed-parameter constraints. That exact root need
not equal the rational center, and the proof does not assert irrationality.

Every certificate occurrence is replayed independently. A valid component
value or graph is never inferred from a supplied success flag, alleged equation
list, optimizer return status, center approximation, or graph in root metadata.
The expression's `certificate` node accepts only those two existing leaf
formats. A previously built composition is reused by inserting its expression,
so all composition operations remain visible to the same bounded traversal.

For a finite set of accepted leaves, choose each field's isolated root and each
interval certificate's unique local root. These choices coexist: the leaf
definitions impose no cross-leaf equations. Their finite Cartesian product is
nonempty. Equal certificate text used twice describes two physical copies;
these may have equal numerical values, but their internal vertices and parameter
references are still separate occurrences.

## 3. Exact target representation and binding

The root supplies

```json
{
  "format": "komorebi-rlc-composition-v1",
  "target": {"P": ["..."], "Q": ["..."]},
  "storage_budget": 4,
  "expression": {"op": "..."}
}
```

`P` and `Q` are nonempty ascending arrays of exact rational coefficients. Neither
polynomial may be zero. Input rational values are integers, `Fraction` objects
in the Python API, or bounded integer / numerator-denominator strings. Binary
floating-point values and exponential text are rejected. Portable constructors
serialize rational values as strings.

The checker cancels the exact rational polynomial gcd and makes `Q` monic. Thus
target binding compares rational functions exactly, rather than insisting on a
particular common scaling of their coefficient arrays. This also removes common
factors before the final degree is measured:

\[
n=\max(\deg P_{\rm red},\deg Q_{\rm red}).
\]

An optional external `expected_target` must reduce to the same rational function
as the declared target. An optional external `expected_budget` must be a
nonnegative integer equal to the declared budget. The rebuilt actual count is
checked against that declared budget. A looser declared budget neither increases
the actual count nor prevents degree equality from proving minimality.

The computed expression target is separately compared with the declared target.
The checker never trusts an equation or graph supplied alongside the expression.
Extra root-level fields are inert metadata, subject to the same input-size and
cycle preflight as the rest of the object. Expression nodes themselves have exact
key schemas; additional keys are rejected.

## 4. Constructive gluing and impedance identity

### 4.1 Element leaves

For a physical value `v > 0`, an element leaf contributes exactly one branch:

| Element | Input impedance | Rebuilt branch type | Admittance coefficient |
|---|---|---|---|
| `R`, value `v` | `v` | `g` | `1/v` |
| `L`, value `v` | `v s` | `h` | `1/v` |
| `C`, value `v` | `1/(v s)` | `c` | `v` |

An element's coefficient is an exact positive rational reference. Its endpoints
are the two distinct terminals assigned by the parent construction.

### 4.2 Certificate leaves

The leaf checker supplies a connected positive graph with terminal vertices
`0` and `1`. The assembler maps these two vertices to the assigned ground and
port of that occurrence. Every other leaf vertex receives a newly allocated
global vertex. The allocation is injective within the leaf and disjoint from all
previous internal allocations. It preserves every branch and its exact
coefficient reference.

No input graph is accepted as the assembled graph. The assembler constructs
every edge from the checked leaf's actual `branches` list. The emitted graph has
global terminals `[0, 1]`, a list of vertices, and individual branch records.

### 4.3 Series composition

For children `H_1, ..., H_m`, with `m >= 2`, start with disjoint copies. Allocate
`m-1` fresh articulation vertices, and connect the children in a chain from the
parent input to its ground. Only the successive terminals are identified; all
other child vertices remain disjoint.

At every positive `s`, all branch admittances are positive and each child is a
connected resistive network at that argument. Its terminal current-voltage
relation is well defined. Kirchhoff's current law at each articulation vertex
gives the same through-current in all children. Their voltage drops add, so

\[
Z_{\rm series}(s)=\sum_{i=1}^{m}Z_i(s).
\]

For two exact rational child targets `P/Q` and `A/B`, the implementation computes

\[
Z_{\rm series}(s)=\frac{PB+AQ}{QB}
\]

and reduces the result exactly. Iterating this binary identity implements the
`m`-child node. Connectivity and positivity are preserved.

### 4.4 Parallel composition

Start again with disjoint copies. Identify all child ground terminals with the
parent ground, and all child input terminals with the parent input. These are
the only vertex identifications. Every child has the same terminal voltage,
and Kirchhoff's current law adds their currents:

\[
\frac1{Z_{\rm parallel}(s)}=\sum_{i=1}^{m}\frac1{Z_i(s)}.
\]

For two exact rational targets, the implementation therefore computes

\[
Z_{\rm parallel}(s)=\frac{PA}{PB+AQ}
\]

and reduces exactly. The terms are strictly positive at `s > 0`, so neither a
zero driving-point impedance nor an identically zero denominator arises.

Parallel same-type branch instances are permitted in the assembled multigraph.
They retain distinct instance numbers and each contributes to the physical
count. The assembler does not merge them. This is compatible with the existing
leaf checkers' requirement that duplicates inside an individual leaf be merged:
composition creates a new graph with explicit physical copies.

### 4.5 Structural induction

Each leaf has the asserted positive graph and exact rational input impedance.
Each internal operation above produces a connected positive graph and the
computed rational impedance from graphs already established for its children.
Induction on the finite expression tree proves the complete graph/target
identity. The implementation also checks final connectivity, rather than using
the inductive connectivity argument as a reason to omit an implementation
consistency check.

## 5. Frequency inversion

Let `G` be any accepted graph. Keep its incidence structure and conductance
branches. Change every `h` branch to a `c` branch with the same positive
admittance coefficient, and every `c` branch to an `h` branch with the same
coefficient. Then, branch by branch,

\[
y_{G^{\iota}}(s)=y_G(1/s).
\]

Consequently the grounded nodal matrix of the transformed graph at `s` equals
that of the original graph at `1/s`. For all positive arguments its input
impedance is

\[
Z_{G^{\iota}}(s)=Z_G(1/s).
\]

There is no field conversion, coefficient inversion, or interval-center
substitution. The coefficient references themselves are unchanged. In physical
value language, a normalized inductor `L` becomes a capacitor `1/L`, and a
capacitor `C` becomes an inductor `1/C`. The number of reactive branch instances
is unchanged. Applying the operation twice restores every branch type.

For the polynomial transformation, set

\[
d=\max(\deg P,\deg Q),\quad
P^{\iota}(s)=s^dP(1/s),\quad Q^{\iota}(s)=s^dQ(1/s).
\]

Both ascending arrays must first be padded to the same length `d+1`, then
reversed, and finally reduced together. Reversing unequal-length arrays
separately omits a power of `s` and is unsound. For example, `2s/1` becomes
`2/s`, while `2/(1+6s)` becomes `2s/(6+s)`. Both unequal-degree orientations are
independently checked against the rebuilt graph.

This operation is **frequency inversion**, not reciprocal impedance. A generic
`reciprocal` expression node is absent. Swapping branch types in an arbitrary
bridge does not, by itself, prove a realization of `1/Z(s)`.

## 6. Physical storage count and global lower bound

### Lemma: a positive RLC graph with `q` reactive branches has degree at most `q`

Consider a finite connected two-terminal graph with `n_L` inductors and `n_C`
capacitors, where `q = n_L + n_C`. Parallel edge instances are allowed.
Let `T(s)` be its weighted spanning-tree sum and `F(s)` its weighted spanning
two-forest sum separating the terminals, with each edge weight equal to its
branch admittance. The grounded matrix-tree identity and the corresponding
cofactor identity give

\[
Z(s)=\frac{F(s)}{T(s)}.
\]

For completeness, write the grounded nodal matrix as
`A = B diag(y_e) B^T`, where `B` is the oriented incidence matrix with the
ground row deleted. Expanding the determinant by Cauchy–Binet gives a sum over
edge subsets of size `|V|-1`, weighted by `det(B_S)^2`. Incidence-column
dependence eliminates cyclic subsets, and a missing connected component
eliminates disconnected subsets. Successive removal of a leaf vertex shows
that the incidence determinant of each spanning tree is `+1` or `-1`.
Consequently `det(A) = T`.

Delete the input row from `B` as well. The same determinant expansion for the
input cofactor uses edge subsets of size `|V|-2`. Its nonzero incidence minors
are exactly the spanning forests with two components, one containing each
terminal; deleting leaves in each rooted component again gives absolute
determinant one. A component without a terminal makes the corresponding minor
singular. Thus the cofactor is `F`. Unit current injected at the input gives
`Z = (A^{-1})_{11} = F/T` by the adjugate formula. This derivation works with
parallel edge instances too, because each instance has its own incidence column.

Each tree or forest uses each physical edge instance at most once. If its chosen
edges include `k_C` capacitors and `k_L` inductors, its power of `s` is
`k_C-k_L`. Multiplying both sums by `s^{n_L}` changes that exponent to

\[
0\le n_L+k_C-k_L\le n_L+n_C=q.
\]

Thus

\[
N(s)=s^{n_L}F(s),\qquad D(s)=s^{n_L}T(s)
\]

are nonzero real-coefficient polynomials of degree at most `q`. Positive edge
weights and connectivity make the relevant sums positive for every `s > 0`.

Suppose the impedance equals a reduced rational target `P/Q`. Coprimeness over
the rationals supplies rational polynomials `U,V` with `UP+VQ=1`; that same
identity holds over the reals. Therefore `P,Q` are also coprime in `R[s]`.
From `PD=QN`, divisibility gives `P | N` and `Q | D`, up to nonzero constant
scaling. Hence

\[
\max(\deg P,\deg Q)\le q.
\]

This argument permits arbitrary positive real component values. It does not
require them to lie in one algebraic field, to be rational, or to be specified
by a particular certificate format.

### Corollary: equality certifies global reactive minimality

Every positive finite uncoupled RLC realization of a reduced degree-`n` target
has at least `n` reactive branch instances. If the assembled accepted witness
has actual count `q = n`, it attains that lower bound. This comparison concerns
the complete model, not merely the topologies searched by a synthesis routine.

The actual assembled count is the sum of the child counts for series and
parallel connection, and is unchanged by frequency inversion. No branch is
deleted or merged. Counts refer to physical branch instances, not to distinct
parameter symbols, reused certificate objects, or the count implied by a
reduced rational expression.

The checker returns `global_minimum_proved_by_degree = (q == n)`. If cancellation
reduces `n` below `q`, it returns `realization_only = true` and explicitly states
that reactive minimality was not established. For example, capacitors `2` and
`3` in parallel retain two branch instances but have impedance `1/(5s)`, of
degree one. The certificate correctly records two physical reactive elements
and declines a minimum claim for that two-element witness.

## 7. Parameter references and replayable graph output

The rebuilt graph's branch coefficient is one of:

```json
{"kind": "rational", "value": "2/5"}
```

```json
{"kind": "algebraic", "context": "leaf_0", "polynomial": ["0", "1/2"]}
```

```json
{"kind": "interval", "context": "leaf_1", "index": 3}
```

`parameter_contexts` assigns an occurrence ID and an expression path to every
certificate leaf. An algebraic context records its defining polynomial and
isolating interval. An interval context records the checked target, original
branch order, box, optional fixed parameters, equation digest, component
intervals, and exact-root semantics. The original proof witness remains in the
certificate expression and its independent checker result is in `leaf_results`.
The interval coordinate index always refers to that leaf's original branch
order, even when gluing relabels nodes or frequency inversion swaps branch types.

The context's `certificate_sha256` is the SHA256 of the **normalized checked
leaf JSON**, with sorted keys, compact separators, and ASCII JSON encoding.
Normalization makes the rational target reduced and monic, normalizes numeric
strings, and sorts each branch's endpoints while retaining branch order. This
digest is not advertised as the byte hash of the original certificate file.
Identical normalized leaves may have the same digest and still have distinct
occurrence IDs, vertex allocations, and coefficient references.

## 8. Public interface

| Entry point | Purpose |
|---|---|
| `verify_circuit(cert, expected_target=None, expected_budget=None)` | Dispatch algebraic, interval, or composition certificates; independently verify the supported format and optional external binding. |
| `verify_composition_certificate(cert, expected_target=None, expected_budget=None)` | Verify a composition and return its exact derived target, counts, rebuilt graph, contexts, and leaf results. |
| `element_node(type, value)` | Create a positive physical `R`, `L`, or `C` node. |
| `certificate_node(cert)` | Copy one existing algebraic or interval certificate as a leaf. |
| `series_node(*children)` | Create a series node; one list/tuple of children is also accepted. |
| `parallel_node(*children)` | Create a parallel node with the same calling convention. |
| `frequency_invert_node(child)` | Create an `s -> 1/s` transformation node. |
| `make_composition(expression, target=None, budget=None)` | Verify the expression and construct a portable certificate, computing omitted target and budget exactly. |

`make_composition` checks an explicitly supplied target and budget too. Before
returning, it also checks that the generated normalized target and complete
serialized certificate fit the accepted input limits. Arithmetic can otherwise
produce an output larger than its individually valid input components. It is a
constructor convenience; an independent consumer should still replay the
returned certificate. The dispatcher's old-format results do not gain a newly
assembled graph: graph/context output belongs to composition verification.

For the independently interval-certified historical cubic

\[
Z_0(s)=\frac{150+630s+2388s^2+3360s^3}
                 {175+810s+1826s^2+1736s^3},
\]

adding an exposed series inductor `L = 2` gives

\[
Z(s)=2s+Z_0(s)
=\frac{150+980s+4008s^2+7012s^3+3472s^4}
       {175+810s+1826s^2+1736s^3}.
\]

The following invokes the complete checker:

```python
import json
from composition_certificate import (
    certificate_node, element_node, series_node, make_composition, verify_circuit,
)

core = json.load(open("certificates/historical_case_1.json"))
target = {
    "P": [150, 980, 4008, 7012, 3472],
    "Q": [175, 810, 1826, 1736],
}
expression = series_node(certificate_node(core), element_node("L", 2))
certificate = make_composition(expression, target=target, budget=4)
checked = verify_circuit(certificate, expected_target=target, expected_budget=4)
assert checked["actual_storage"] == checked["reduced_target_degree"] == 4
assert checked["global_minimum_proved_by_degree"]
```

This example proves a concrete four-reactive realization and minimum; it does
not establish that an unassisted search can discover every such core. Search
recovery and its finite validation belong to separate continuation artifacts.

## 9. Explicit acceptance limits and failure behavior

The checker applies the following conservative limits. Exceeding a limit is a
rejection of the submitted evidence under this implementation, not a proof that
the target cannot be realized.

| Resource | Bound |
|---|---:|
| Expression depth, with root at depth zero | 32 |
| Expression node occurrences | 256 |
| Children per series/parallel node | 64 |
| Certificate leaf occurrences | 64 |
| Total physical branch instances | 256 |
| Total assembled vertices, including terminals | 257 |
| Declared storage budget | 256 |
| Reduced target degree | 64 |
| Algebraic leaf branches | 64 |
| Interval leaf branches | 20, plus the unchanged interval kernel's forest cap |
| Algebraic defining polynomial degree | 32 |
| Algebraic branch coefficient polynomial degree | 64 |
| Input rational numerator/denominator bit length | 4096 |
| Computed rational coefficient bit length at checked boundaries | 65536 |
| Rational text length | 2500 characters |
| Whole input item occurrences | 100000 |
| Whole input nesting depth | 128 |
| Individual input string length | 16384 characters |
| Aggregate input string length | 4000000 characters |

The interval forest enumeration and algebraic sign refinement retain their
existing finite caps. These are operation/input limits, not a guaranteed fixed
wall-clock runtime. Exact arithmetic may be expensive within them.

Preflight detects cyclic Python objects and also scans ignored metadata. A reused
noncyclic object is counted once for every occurrence. Malformed structures,
unsupported operations, invalid numeric forms, nonpositive elements, false leaf
proofs, disconnected leaf graphs, incorrect targets, insufficient budgets, and
violated external bindings reject with `ValueError` through the new interface.

## 10. Implementation evidence and provenance

The new executable check is

```bash
python src/test_composition_core.py
```

At the frozen checker revision below, it passes **65 named groups**: 16 positive
groups and 49 rejection controls. Its independent rational nodal implementation
checks **42 circuits at 222 exact samples**. The scalar expression evaluator and
Fraction Gaussian elimination do not reuse the production checker's gluing,
rational target algebra, or legacy nodal solver. For each rational graph there
are at least `n+q+1` distinct positive integer samples, plus a fractional sample.
That count is sufficient for an independent rational-function identity check
under the proved graph degree bound.

The positive checks include the user's image-pinned cubic

\[
P=[28,52,100,144],\qquad Q=[11,113,169,36],
\]

an interval cubic plus an outer inductor, two nontrivial algebraic fields
(`sqrt(2)` and `sqrt(3)`), mixed interval/algebraic contexts, an off-center
interval resistor, duplicated leaves with disjoint internals, explicit
cancellation, loose declared budgets, both unequal-degree frequency-inversion
orientations, and frequency inversion of interval-root references.

The negative controls corrupt leaf parameters and proof data, target and budget
bindings, graph node syntax, element positivity, expression schemas, numerical
representations, and resource limits. A forged root graph, equation list, count,
or claimed minimum cannot change the rebuilt result. These finite checks do not
constitute topology coverage, completeness, or a substitute for the proof above.

Independent review found one constructor portability defect in the initial
revision, not a false-acceptance defect. Let `A = 2**2100 + 1` and compose two
resistors with values `1/A` and `1/(A+2)`. Each input fits the 4096-bit limit, but
their normalized summed impedance has a 4201-bit denominator. The first
constructor emitted that certificate, while the public replay interface
correctly rejected its oversized target. The corrected constructor preflights
its serialized result and strictly parses its generated target before returning.
It now rejects this unsupported output instead of presenting it as portable.
The 65th group records that exact regression. The initial source, first frozen
validation run, and first independent audit's failure record are retained under
`history/frozen_composition_validation/`; the hashes below identify the corrected
checker and tests. The composition theorem and ordinary small-coefficient
certificates are unaffected by this input/output-bound consistency repair.

The continuation starts from
`Komorebi_Smith_RLC_Interval_Continuation_2026-11-11.zip`, SHA256

```text
66cb2e38c0f59235184199f266a9638c5a8d0ab9f4a60a87483cb0613e5ae31d
```

Frozen source and directly used fixture byte hashes:

| File | SHA256 |
|---|---|
| `src/composition_certificate.py` | `324948708abc1d9ee49b40bc93f54428f552d65d50a1c2db20b47b729e53bc40` |
| `src/test_composition_core.py` | `1c52931adcd0722e28f37e85185b09a2f2a264eff213c1123a56bd3f5eceb3ed` |
| `src/algebraic_witness.py` | `8490cf4b993774cdaec091df9f63e30ec5efed79c7136a6c03a7c4a6949fd883` |
| `src/interval_certificate.py` | `538da6d3c897554c2468b3c8c10508d2505374c4e9a007dcf110aa408c711de1` |
| `src/real_algebraic.py` | `7a32375fc115c63bebc505c2b93eaa817b72dc9a093c49da9c664c40b0bb7c57` |
| `src/exact_polynomials.py` | `d94e61424ecc82cb2489c358de45de460c76b3529926c01036ba5ea66918e2a6` |
| `certificates/image_baseline_cubic.json` | `cd4dd6be83347df7d372b0004b7c61c19578082908d3d579f9465154d274576c` |
| `certificates/historical_case_1.json` | `a750210a7d1d4781c45eaaa7b9b539f6b443db38ff77956008a3f58a454bc4f3` |

The four inherited kernel files above were not edited for this composition
checker. Independent source review and the bounded synthesis validation, when
completed, are recorded separately so their provenance and scope remain clear.
