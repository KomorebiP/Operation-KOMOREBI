# Independent audit of composition certificates and the coupled-core lift

**Author: Komorebi P.**  
**Review date:** 2026-11-12, UTC.  
**Review provenance:** Independent delegated review of the raw source, raw proofs, exact certificates and preserved dependencies. The reviewer did not author the composition checker or the lift proof. The audit calculations below use a separate nodal implementation.  
**Primary verdict:** Proved as written for the composition-acceptance claim and the normalized coupled-core lift theorem.  
**Implementation outcome:** PASS for the final revision in the stated finite range. One constructor portability defect was found in the earlier revision and corrected; its original failed run is retained.

## 1. Normalized claims and scope

### Composition claim

For every certificate accepted by `verify_composition_certificate` within the stated format and resource limits, the returned graph is a finite connected two-terminal network of positive ordinary uncoupled RLC branches. Its impedance is the declared rational target. Its actual reactive count `q` is at most its declared budget. The optional external target and budget bindings are checked exactly.

If the target's reduced degree is `n`, the returned global-minimum flag is true exactly when `q=n`. This equality proves minimum reactive count among all finite positive ordinary uncoupled RLC graphs. A case with `q>n` proves an exact realization and does not receive that minimum conclusion. Minimum resistor count, minimum total component count, uniqueness across topologies and general synthesis completeness are outside this claim.

Algebraic coefficients and interval-isolated exact real component vectors are admissible at leaves. Different leaf occurrences are separate physical copies even if they use identical certificate text. Frequency inversion is the substitution `s -> 1/s`; it is not a claimed reciprocal-impedance construction.

### Coupled-core lift claim

For every integer \(n\ge0\), let

\[
\mathcal C_n=\{(P,Q):\deg P=\deg Q=n,\ Q_n=1,\ P_n>0,\ \gcd(P,Q)=1\},
\]

with real coefficients and gcd understood over \(\mathbb R[s]\), up to a nonzero scalar. The coordinates are the `n+1` numerator coefficients and the first `n` denominator coefficients. For \(g,L>0\),

\[
W_{g,L}(P/Q)=\left[g+\frac1{Ls+P/Q}\right]^{-1}
\]

defines a rational diffeomorphism from \(\mathcal C_n\times(0,\infty)^2\) onto the stated open endpoint chart in \(\mathcal C_{n+1}\). It increases reduced degree by exactly one. An `n`-reactive positive core consequently gives an `(n+1)`-reactive realization attaining the universal degree lower bound.

Starting with the interior of the specific uniform cubic coefficient box, repeated lifts give a nonempty open family in every full normalized coefficient dimension \(2n+1\), \(n\ge3\). These statements quantify over real coefficients and positive real wrapper values. The finite point-certificate API has rational input and explicit size limits; it does not serialize every point of those real open families or certify unbounded degrees by itself.

## 2. Dependency map

| Dependency | Evidence reviewed | Role and scope |
|---|---|---|
| Algebraic leaf realization | Raw `algebraic_witness.py` and `real_algebraic.py`, preserved prior audit, exact nontrivial-field fixtures | Isolated real root, positive branch values, connectivity and full rational identity |
| Interval leaf realization | Raw `interval_certificate.py`, `INTERVAL_CHECKER_NOTES.md`, unchanged prior proof and fresh replay | Exact unique real root in the declared positive box, including fixed constraints |
| Uniform cubic base family | Raw `interval_family.py`, exact family certificate, `FAMILY_INDEPENDENT_AUDIT.md`, fresh replay | Every real coefficient vector in the entire box, not a set of sampled vectors |
| Graph composition | Raw `composition_certificate.py` and `COMPOSITION_THEOREM.md`, independent nodal calculations | Disjoint gluing, preserved branch occurrences, exact target identity |
| Reactive degree bound | Incidence-determinant/tree-and-forest derivation in the raw proofs | Lower bound over arbitrary competing positive uncoupled RLC graphs |
| Lift and inverse | Direct symbolic reconstruction of Sections 2–3 of `COUPLED_CORE_LIFT_THEOREM.md` | Degree preservation, inverse, open full-dimensional image |
| Declared finite controls | This audit script and reproduced lift record | Implementation controls with explicit finite bounds |

No implication is justified solely by a solver's success flag or by agreement between agents. Existing leaf kernels are inherited proof dependencies: their unchanged hashes, relevant raw source and proof semantics were inspected here, without claiming a new exhaustive audit of every historical component. No internet or external publication source was used. No unresolved external theorem is needed for the claims reviewed here.

## 3. Independent reconstruction of composition soundness

An accepted algebraic leaf chooses its specified isolated real root; an accepted interval leaf has the exact positive root supplied by the full-system contraction argument. For finitely many occurrences, all these choices coexist in a finite Cartesian product. There are no cross-leaf parameter equations to create an incompatibility. Equal roots in two occurrences are permitted; their physical branches and internal vertices still remain distinct.

The assembler maps only the local terminal labels `0` and `1` to its assigned terminals. It allocates every other local vertex freshly, independently of the magnitude or gaps in its old label. Series nodes allocate a chain of new junctions and attach children to successive distinct terminal pairs. Parallel nodes identify only corresponding terminals. Reading the code confirms that no unrelated internal vertex is glued, including when the same Python leaf object is reused.

At each positive real Laplace argument, all edge admittances are positive. The grounded nodal matrix is positive definite by connectivity, so each child's driving-point relation is defined. Series junctions carry one common through-current and voltage drops add. Parallel children share a voltage and their currents add. Consequently, for child impedances \(P/Q\) and \(A/B\),

\[
Z_{\rm series}=\frac{PB+AQ}{QB},\qquad
Z_{\rm parallel}=\frac{PA}{PB+AQ}.
\]

These are precisely the implemented polynomial operations, followed by exact reduction. The positive real values prevent an identically zero driving-point target from arising. Induction on the finite expression tree yields the complete rational identity. The returned graph, leaf counts and target are rebuilt from checked data; root-level graphs, equations and alleged minimum flags are not trusted.

Frequency inversion preserves the incidence graph and every coefficient reference, while swapping branch types `h` and `c`. Thus `h/s` becomes `h*s` and `c*s` becomes `c/s`, exactly matching the old branch admittance evaluated at `1/s`. In physical values an inductor `L` becomes a capacitor `1/L`, and a capacitor `C` becomes an inductor `1/C`. No interval center is substituted and no common algebraic field is required.

For polynomials, take \(d=\max(\deg P,\deg Q)\). The correct pair is

\[
\bigl(s^dP(1/s),\,s^dQ(1/s)\bigr).
\]

The implementation pads both ascending arrays to length `d+1` before reversal and then reduces. Both unequal-degree orientations, a mixed network and double inversion were checked independently. Reversing the original arrays separately would be wrong; the reviewed implementation does not do that.

Every physical branch is retained. In particular, same-type parallel branches created by composition are not merged, and reused leaves are counted once per occurrence. This differs harmlessly from the legacy leaves' prohibition of duplicate same-type branches inside one leaf: the assembled output is an explicitly counted multigraph.

## 4. The global degree lower bound

For a finite connected positive graph, write its grounded nodal matrix as \(B\operatorname{diag}(y_e)B^{\mathsf T}\). Expanding its determinant gives the spanning-tree sum; the input cofactor similarly gives the terminal-separating two-forest sum. Incidence minors vanish on cycles or components without a deleted terminal row, while rooted trees have determinant of absolute value one by leaf removal. This remains valid for parallel physical edge instances, because each has its own incidence column.

Let \(\ell\) be the total number of inductors, and \(q\) the total number of reactive branches. Multiplying both sums by \(s^\ell\) gives monomials of degree

\[
\ell-\#(\text{selected inductors})+\#(\text{selected capacitors}),
\]

between zero and `q`. The two resulting polynomials \(N,D\) are nonzero and have degrees at most `q`. They yield the graph impedance \(N/D\). This argument permits arbitrary positive real component values and arbitrary numbers of resistors or internal vertices.

If the target \(P/Q\) is reduced over the reals, \(PD=QN\) and coprimality imply \(P\mid N\) and \(Q\mid D\). Hence \(\max(\deg P,\deg Q)\le q\). For a rational target reduced over \(\mathbb Q\), its rational Bezout identity also holds over \(\mathbb R\), so the same conclusion applies. The composition checker's minimum conclusion at actual `q=n` therefore compares against the full physical class; it is not confined to the solver's searched topologies.

## 5. Independent reconstruction of the lift and open-image proof

Put \(N=P+sLQ\) and \(D=Q+gN\). Since `Q` is monic of exact degree `n`, the leading coefficients of `N,D` are `L,gL`, respectively. Both degrees are exactly `n+1`. Also

\[
\gcd(N,D)=\gcd(N,Q)=\gcd(P+sLQ,Q)=\gcd(P,Q)=1.
\]

Thus no cancellation is hidden in the degree claim. After normalizing the denominator,

\[
U=\frac{P+sLQ}{gL},\qquad V=\frac{Q+g(P+sLQ)}{gL}.
\]

For a normalized output of degree `n+1`, define

\[
g=\frac1{U_{n+1}},\quad H=V-gU,\quad h=H_n,\quad
L=\frac{U_{n+1}}h,\quad K=U-sLH.
\]

The leading terms in `H` and `K` cancel by construction. On the exact image domain, the strict conditions are \(h>0\) and \(K_n>0\). They give exact degree `n` to both recovered polynomials and the required positive core leading coefficient. The normalized core is

\[
P=K/h,\qquad Q=H/h.
\]

The coprimality chain \(\gcd(K,H)=\gcd(U,H)=\gcd(U,V)=1\) proves membership in \(\mathcal C_n\). Because \(gL=1/h\), the unnormalized forward pair is \(U/h,V/h\) and its normalization is exactly \(U,V\). Conversely, a forward image has \(H=Q/(gL)\), \(h=1/(gL)\) and \(K=P/(gL)\); all four input objects are recovered. This is a two-sided inverse, including the normalization, rather than just a dimension count.

For `n=0`, `H,K` are nonzero constants of the required positive sign. The displayed formulas still apply. The degree-zero control in the recorded experiment is consistent with this direct argument.

The coprime locus with nonzero leading coefficients is open in the normalized coordinates: the appropriate Sylvester determinant is nonzero there. All divisors in the forward and inverse formulas are nonzero on their stated domains. Therefore the maps are rational and smooth. The conditions \(h>0\), \(K_n>0\) define an open image. This establishes the stated rational diffeomorphism without an unproved Jacobian assertion.

The physical wrapper adds a positive series inductor `L` and a positive parallel resistor `1/g`, with only the intended terminals identified. Its storage count increases by one and its degree does too. The preceding lower bound proves its minimum reactive count.

### The all-real base and induction

The raw uniform-family source constructs the complete coefficient system \(F(x,y)\) in seven component variables and seven target coordinates. For each arbitrary real `y` in the specified target box, the same positive component box and invertible rational matrix define \(T_y(x)=x-YF(x,y)\). Exact interval enclosures over the joint box prove strict self-mapping and a contraction bound below one for that fixed arbitrary `y`. Hence an exact positive root exists for every such real vector. Rational verification arithmetic does not narrow that quantifier to rational vectors.

The independent Sylvester norm bound is exactly \(211787599/223125000000000<10^{-6}\). It proves coprimality everywhere in the coefficient box, and the positive numerator leading-coefficient bound retains degree three. The source and certificate hashes match the inherited independent family audit; their exact inequalities reproduced in the fresh run.

The interior \(\mathcal U_3\) is nonempty and open. Define

\[
\mathcal U_{n+1}=\Phi_n\bigl(\mathcal U_n\times(0,\infty)^2\bigr).
\]

A diffeomorphism onto an open subset sends open domain subsets to ambient open subsets. Induction gives nonempty open \(\mathcal U_n\) for every \(n\ge3\), in dimension \(7+2(n-3)=2n+1\). Each constructed graph has `2+m` inductors, one capacitor and `4+m` resistors for `n=3+m`. This all-degree claim is proved by the inverse and induction; the 72 finite rows are not its proof.

## 6. Independent exact implementation controls

The command is:

```bash
python3 -S experiments/composition_independent_audit.py
```

The independent test arithmetic imports no production polynomial, graph-polynomial, algebraic-field or nodal implementation. It forms the grounded nodal matrix directly from every returned physical branch and solves it with a separate exact Gauss-Jordan routine. The expected scalar impedance is evaluated recursively from the original expression. It also compares the declared target at every argument.

For each fixture, the audit uses exactly `q+n+1` distinct positive arguments \(s_k=(2k+1)/7\). Under the independently reviewed graph degree bound, these checks establish the rational-function identity for those particular fixtures: the cross-product polynomial has degree at most `q+n`. This remains a finite fixture set, not evidence of universal input coverage.

| Fixture | Actual q | Reduced n | Leaf occurrences | Exact arguments | Arithmetic |
|---|---:|---:|---:|---:|---|
| pure_resistor | 0 | 0 | 0 | 1 | Q |
| unequal_degree_inverse_L | 1 | 1 | 0 | 3 | Q |
| unequal_degree_inverse_C | 1 | 1 | 0 | 3 | Q |
| series_RL_inverse | 1 | 1 | 0 | 3 | Q |
| nested_mixed | 2 | 2 | 0 | 5 | Q |
| parallel_same_type_inductors | 2 | 1 | 0 | 4 | Q |
| series_same_type_capacitors | 2 | 1 | 0 | 4 | Q |
| reused_algebraic_leaf | 6 | 3 | 2 | 10 | Q |
| two_different_rational_leaves | 6 | 6 | 2 | 13 | Q |
| double_frequency_inverse | 4 | 4 | 1 | 9 | Q |
| rational_interval_root_not_center | 0 | 0 | 2 | 1 | Q |
| interval_algebraic_mix | 4 | 4 | 2 | 9 | Q |
| independent_sqrt2_sqrt3_fields | 2 | 2 | 2 | 5 | Q(sqrt(2),sqrt(3)) |
| reused_field_and_opposite_root | 1 | 1 | 4 | 3 | Q(sqrt(2),sqrt(3)) |

All **14 fixtures and 73 exact nodal arguments** passed. Twelve graphs use rational arithmetic and two use an independent four-coordinate basis \(1,\sqrt2,\sqrt3,\sqrt6\). For \(d=2,3\), the nonrational resistor leaves use conductances \(\sqrt d\) and \((d+\sqrt d)/(d-1)\) in series; their resistance is exactly one. A repeated field occurrence and an opposite isolating-root interval are also present. This checks that the emitted algebraic contexts describe the intended roots without a hidden shared primitive-element assumption.

The exact interval-resistor fixture has target resistance two, component root \(g=1/2\), rational center \(51/100\), radius \(1/10\), and preconditioner \(-1/2\). Its exact root differs from its center. The independent nodal calculation uses the root derived from the resistor identity and checks that it lies strictly in the declared box. Substituting the center would fail the target comparison.

The general historical cubic interval leaf is separately replayed twice in one expression, once under frequency inversion. Its two parameter contexts and all six reactive occurrences remain separate. No rational component vector is substituted for its exact real roots; its conclusion uses the all-real leaf proof.

The **41 malformed-input controls** all rejected with `ValueError`. They cover external and declared target binding, external budget binding, actual storage overflow, invalid budget types, positivity, Boolean and floating values, invalid rational text, unsupported reciprocal operations, missing/extra expression fields, node shape and labels, duplicate branches inside a legacy leaf, nonisolating algebraic intervals, singular interval preconditioners, nonpositive component boxes, depth/child limits, cyclic metadata and oversized ignored data. A separately checked target multiplied by a common negative scalar and polynomial factor was accepted as the same rational function. Forged root metadata did not change the rebuilt result.

### Reproduction of the lift record

The author's documented lift computation was rerun in memory without overwriting its saved JSON. The complete returned data matched the saved record. The declared range is four interior rational cubic vectors, three wrapper streams, and depths `0,1,2,3,5,9`, giving **72 selected rows** at degrees `3,4,5,6,8,12`. The depth-zero rows repeat across streams; this count is not a count of 72 distinct targets. The run also contains **108 single-step inverse checks, 324 exact scalar checks, one degree-zero control and 11 domain rejection controls**. This reproduces the finite assertion, while the raw source and proof review establish its interpretation.

## 7. Defect found, retained failure and correction

The first frozen revision was

```text
1aa31c10cead9b2da925b2637a84fe9dde4240aad313a72024c4333f25f39ba9
```

It had one reproducible constructor defect. Set `A=2**2100+1` and build two series resistors of values `1/A` and `1/(A+2)`. Both input denominators have 2101 bits and fit the accepted limits. Their normalized total resistance has a 4201-bit denominator. The original `make_composition` returned that certificate, but `verify_circuit` then rejected its target with `ValueError: Rational coefficient resource limit exceeded`.

The acceptance kernel did not accept a false circuit. The failure was the promise that a successful constructor return is portable through its own replay interface. The original independent JSON correctly recorded `FAIL`, with all other nodal, malformed-input and lift checks passing. It is preserved at `history/frozen_composition_validation/experiments/composition_independent_audit.json`, SHA256:

```text
e52916364cc719de5517f29bfde21521342177b6e20c389117253ed83980f260
```

The correction adds `_preflight(result)` and `_target(result['target'])` before the constructor returns. Inspection against the frozen source confirmed that only this return boundary changed. The oversized output now rejects before any certificate is emitted, while an ordinary `1/17 + 1/19` resistor output still replays. The final audit reran the fixture and records **PASS**. All other acceptance semantics remain those already reviewed.

No acceptance hole was found in the reviewed mathematical kernel or the tested malformed-input cases. This is a source audit plus bounded controls, not an assertion that every possible implementation failure has been exhaustively enumerated.

## 8. Obligation matrix

| Obligation | Verdict | Decisive evidence |
|---|---|---|
| Exact target and budget binding | Passed | Normalization, separate expression comparison, rejection controls |
| Strict positive physical values | Passed | Element parsing, checked leaf signs/positive boxes |
| Independent parameter contexts | Passed | Occurrence allocation, finite-product argument, multiquadratic and interval fixtures |
| Terminal gluing and internal labels | Passed | Raw injective allocation and independent nodal reconstruction |
| Same-type parallel occurrence counting | Passed | Explicit two-inductor fixture keeps q=2 while n=1 |
| Unequal-degree frequency inversion | Passed | Common-degree padding proof and both exact fixtures |
| Real interval root versus center | Passed | Unique-root semantics and off-center resistor fixture |
| Global minimum only at actual q=n | Passed | Universal degree bound and cancellation fixtures |
| Malformed data, budgets, exceptions | Passed in stated finite controls | 41 controlled `ValueError` rejections plus raw schema/preflight inspection |
| Portable constructor return | Corrected and passed | Preserved first failure, narrow patch review, final regression |
| Lift identity and no cancellation | Passed | Leading coefficients and gcd chain |
| Normalized two-sided inverse | Passed | Explicit recovery and substitutions |
| Smallest n=0 case | Passed | Constant H,K argument and exact control |
| Open full-dimensional real image | Passed | Rational inverse and strict image inequalities |
| All-real cubic input | Passed through unchanged exact dependency | Joint interval proof, Sylvester bound and fresh replay |
| All-degree induction | Passed | Open product domains and exact degree increase |
| Universal passive-target synthesis coverage | Out of scope | No such theorem is asserted |
| Search recovery rates and benchmark independence | Out of scope | Separate parent validation artifacts |
| Minimum total components and historical novelty | Not addressed | No such conclusion or external research attempted |

## 9. Reproducibility, exact revision and remaining limits

The input archive SHA256 is `66cb2e38c0f59235184199f266a9638c5a8d0ab9f4a60a87483cb0613e5ae31d`. This workspace is not a Git checkout, so provenance is recorded by exact paths and byte hashes. The v2 record follows the official runner's conservative `commit=unavailable, dirty=true` convention for this case, and explicitly identifies that flag as a schema convention, not an observed Git dirty state. The final run used Python **3.12.14**, exact integers/Fractions, and no randomness. Runtime was **1.206 seconds**. Before/after hashes were equal for every recorded input: **True**.

The machine result is `experiments/composition_independent_audit.json`. It records the explicit mathematical contract, input hashes, software/platform, execution status, fixture results, rejection reasons and this report's output hash. Its own file hash belongs to the enclosing release provenance to avoid a self-hash. The `run.status` is **completed**. The source and report revisions audited are:

| Artifact | SHA256 at run start and end |
|---|---|
| `src/composition_certificate.py` | `324948708abc1d9ee49b40bc93f54428f552d65d50a1c2db20b47b729e53bc40` |
| `src/algebraic_witness.py` | `8490cf4b993774cdaec091df9f63e30ec5efed79c7136a6c03a7c4a6949fd883` |
| `src/interval_certificate.py` | `538da6d3c897554c2468b3c8c10508d2505374c4e9a007dcf110aa408c711de1` |
| `src/real_algebraic.py` | `7a32375fc115c63bebc505c2b93eaa817b72dc9a093c49da9c664c40b0bb7c57` |
| `src/exact_polynomials.py` | `d94e61424ecc82cb2489c358de45de460c76b3529926c01036ba5ea66918e2a6` |
| `src/interval_family.py` | `81772b2a1a25fc3651013ced311d984fbce1c0647833c9dcfb2beadbf9dca52e` |
| `reports/COMPOSITION_THEOREM.md` | `4b988a5cb24f4bba44ea226941d1dd7bae64fe5b8f945506f216a2333f64e68c` |
| `reports/COUPLED_CORE_LIFT_THEOREM.md` | `1352b4bda3c1d15afc9a1d39b9cbd489f1dfd93ca9fcf443902cb273f339ca6b` |
| `reports/FAMILY_INDEPENDENT_AUDIT.md` | `706d4a9dd07286c82955c475f05ffa8ce39287169941ded2dd504e75666c066a` |
| `reports/INTERVAL_CHECKER_NOTES.md` | `2a6893805bdfb9ea92e0df42b523ab632dd2f87bd43d3ecb612e42a94378534b` |
| `THEOREMS_AND_PROOFS.md` | `608bcfd17240dddee6ff3e3a58828730f7f5c74a8810559ff339e7d2bf511acc` |
| `certificates/image_baseline_cubic.json` | `cd4dd6be83347df7d372b0004b7c61c19578082908d3d579f9465154d274576c` |
| `certificates/boundary_endpoint_cubic.json` | `d779e391414a43b50e089449a5e2a5a0f476261a9e1ff4de5eb3c6cfe180fce3` |
| `certificates/historical_case_1.json` | `a750210a7d1d4781c45eaaa7b9b539f6b443db38ff77956008a3f58a454bc4f3` |
| `certificates/local_family_case_1.json` | `28d096fa089bb550208f7dc7e5eede622d4cdf9704210088447c99e5f2899ffe` |
| `experiments/coupled_core_lift_audit.py` | `44731ef7ea1270cd7b7fccd452ebf1a10689d5514f89cc44030912a5a75c4a20` |
| `experiments/coupled_core_lift_audit.json` | `bc238f07d1c736bc50e51c91da31c70a5709eb5515e0a907d0dc64b22cccc410` |
| `experiments/composition_independent_audit.py` | `708dd8225bb5c99251145a5084e5e580861d6aae8669517c8cecaca70d3ab27b` |

The coupled-core raw proof was first reviewed at hash `c03359556d34186cbbb3b8d0dd3c9b07d6da258139255d688b5387d7c8dfb6c4`; the preserved frozen copy retains that original. The later change only records independent-review provenance. The theorem index appended the new claims while preserving the inherited lower bound. The composition proof's later changes record the constructor correction and updated test/source hashes. No mathematical gap was closed by silently changing either theorem during this audit.

There is no remaining gap in the two stated mathematical claims. Acceptance remains conditional on the explicit physical model and format limits. Rejection or a resource cap is not an infeasibility proof. The real open-family theorem does not make the point API complete, and the finite controls do not show that the target-only search always finds a leaf. Exact arithmetic may be expensive inside the declared limits; no fixed runtime or memory bound was established.

**Final mathematical proofreading:** The audit report's definitions, `q/n` usage, normalized inverse, sign conditions, LaTeX delimiters, code fences, source paths and provenance were reviewed. No mathematical-token correction was made to the source theorems or kernels by this reviewer. No unresolved notation or local typographical issue remains in the reviewed report.
