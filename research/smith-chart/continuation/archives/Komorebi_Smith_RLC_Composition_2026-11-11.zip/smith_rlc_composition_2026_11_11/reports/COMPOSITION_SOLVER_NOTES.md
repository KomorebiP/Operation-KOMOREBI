# Target-only synthesis with interval-certified cores

**Author: Komorebi P.**  
**Checkpoint:** `smith-rlc-composition-2026-11-11`  
**Date:** November 11, 2026 (America/Chicago; execution logs use UTC).

## Implemented boundary crossing

The preceding release could discover and verify a coupled cubic core through
`komorebi-rlc-interval-v1`, but its recursive module routines assumed that every
component lived in one explicitly represented algebraic field. That mismatch
prevented the new cubic certificates from being grafted automatically into
higher-degree targets.

`src/compositional_solver.py` now performs the same kind of target-only exact
endpoint and passive factor decomposition while carrying an expression of
separately verified circuit leaves. The new composition checker establishes
the combined circuit independently. No primitive-element conversion, rounding
of certified component roots, or fixture lookup is needed.

The public function is:

```python
synthesize_compositional(
    P, Q, *, max_degree=12, max_states=250, max_budget=None,
    topology_starts=2, topology_evaluations=600,
    topology_seed=2026111223, max_topology_calls=16,
)
```

Polynomial coefficient arrays are ascending and exact. Integer and rational
string inputs are supported; floating-point coefficients are rejected.

The dispatcher preserves the preceding exact rational/algebraic search as its
first route. Only after that route returns UNKNOWN does its optional interval
phase invoke the new composition search. Existing easy successes retain their
old certificate format. `interval_search=False` continues to select the
inherited route alone, and the command line exposes the new seed and topology
call limit.

## Search operations and acceptance

At each normalized residual target the solver tries an inherited exact base
chart. An eligible full `(3,3)` residual can then use the bounded four-node,
three-reactive interval graph search. That search still proposes from the
declared four/five-resistor catalogs; it has not become a complete graph
enumerator.

The outer operations are exact:

* Exposed series L, series C, shunt C and shunt L endpoint removal.
* A shunt resistor followed by a series inductor and a residual core.
* A series resistor followed by a shunt capacitor and a residual core.
* Frequency inversion of either complete endpoint construction.
* The inherited passive simple-pole and irreducible-quadratic factor modules
  in series impedance or parallel admittance orientation.

Frequency inversion pads both numerator and denominator to their common
maximum degree before reversing coefficients. This preserves powers of `s`
when the two degrees differ. The reciprocal operation used for factor-module
orientation is restricted to the already defined series/parallel module tree.
There is no reciprocal-impedance operation applied to an arbitrary bridge
graph.

Every recursive step strictly decreases reduced rational degree. The residual
cache uses a coprime target with monic denominator as its key, so the same
target cannot consume topology-search effort repeatedly within a call. The
cache is local to that call: no validation target receives a certificate from
an earlier call.

A proposed leaf is accepted only after `verify_circuit` binds it to the actual
residual target and exact reactive budget. Every composed expression is then
checked against the entire target at that recursive level. The final return
performs another full independent check against the original input. A minimum
claim is returned only when the counted physical reactive components equal
the reduced rational degree.

The new search caps the number of visited residual states and numerical
topology calls, as well as using the pre-existing numerical start/evaluation
limits. Checker resource bounds apply independently. A missed proposal,
exhausted search cap or rejected certificate gives UNKNOWN; it does not give
an all-topology infeasibility result. A requested reactive budget below the
exact reduced degree is reported separately as excluded by the degree lower
bound, while retaining the conservative UNKNOWN search status.

## Development evidence

The development script is
`experiments/composition_solver_development.py`. Its exact targets and expected
operations were inspected during implementation, so they are not an untouched
holdout. The completed result and source hashes are in
`experiments/composition_solver_development_results.json`.

| Inspected target | Inherited dispatcher | Current dispatcher | Direct composition search |
|---|---|---|---|
| Degree-four positive endcap | UNKNOWN | Certified minimum, composition certificate | Four reactive elements; one topology call; two residual states |
| Degree-six nested endcaps | Certified minimum | Inherited algebraic certificate preserved | Six reactive elements; one topology call; four residual states |

The degree-four target is

\[
P=[1500,8925,36030,60990,26040],\qquad
Q=[2350,11670,32672,41756,10416].
\]

It has the exact decomposition

\[
Z(s)=\left[\frac25+
  \frac{1}{(3/2)s+Z_c(s)}\right]^{-1},
\qquad
Z_c(s)=\frac{150+630s+2388s^2+3360s^3}
{175+810s+1826s^2+1736s^3}.
\]

The solver receives only the full target's coefficients. It recovers the
outer resistor `5/2` and inductor `3/2`, discovers a positive interval-certified
core, and verifies the complete graph. The returned circuit has three
inductors, one capacitor and five resistors. Its four reactive elements attain
the degree-four lower bound. The interval certificate specifies an exact
root in a rational box; it does not assert that the root is irrational.

The direct degree-six composition test adds two further endcaps with
`(g,L)=(7/11,5/3)` and `(13/17,19/23)`. Its assembled graph has five inductors,
one capacitor and seven resistors. The inherited solver independently finds a
different six-reactive circuit, through a frequency-inverted endpoint and an
RC Cauer core. This is compatibility evidence, not new coverage.

The first development script incorrectly required that every dispatcher
success use the new composition format. That assertion failed on this
already-solvable degree-six example. The failure and correction are recorded
in `experiments/composition_solver_development_failures.json`; the exact
inherited witness is retained in
`experiments/composition_solver_development_degree6_baseline.json`. The
corrected script checks format preservation and invokes the new solver
directly to exercise the nested construction. No fixture was reclassified as
untouched validation.

Seven additional development controls pass: a degree limit, a reactive budget
below the degree lower bound, a one-state search cap, disabled topology calls,
a Boolean budget, zero numerical starts and floating-point input. The first
four return UNKNOWN and the last three return INVALID_INPUT, as expected.
All recorded input hashes remained unchanged during the completed run.

## Reproduction

From the checkpoint directory:

```bash
python3 experiments/composition_solver_development.py
python3 src/dispatch.py path/to/target.json --output result.json
python3 src/dispatch.py path/to/target.json --skip-interval-search
```

The first command is an inspected development replay. Separate frozen
structural-validation evidence is managed by the parent checkpoint workflow
and is not included in these development totals.

## Source freeze for the first structural validation

| File | SHA256 |
|---|---|
| `src/compositional_solver.py` | `6766f549fb5b5db18c53e450ce1be19ff2184bd5f58ddf462e6a8d80da733a36` |
| `src/dispatch.py` | `4dbe856aedce98be69d59fc9623d458964796f52a832553296da358170b5d309` |
| `experiments/composition_solver_development.py` | `ea8daa83752c5d01c983488d132900f392545db98c3412e3e778f07dc304dbb6` |

The checker revision exercised in the completed development run is
`1aa31c10cead9b2da925b2637a84fe9dde4240aad313a72024c4333f25f39ba9`.
No source files owned by the earlier exact or interval kernels were modified
by this solver task.

## Remaining scope

This change connects independently certified cores to exact outer modules.
It does not supply a universal positive-real RLC synthesis algorithm, a
complete topology classification, or a global lower-budget refutation engine.
Targets without a supported exact degree-reducing module path can still return
UNKNOWN. The minimum statements apply to the actual accepted certificates;
finite success counts do not establish completeness or novelty.
