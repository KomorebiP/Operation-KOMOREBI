# Package layout and provenance audit

**Project author:** Komorebi P.  
**Checkpoint:** `smith-rlc-composition-2026-11-11`  
**Audit date:** November 12, 2026, UTC.  
**Outcome:** Dependency closures and current evidence routing verified. One original failed audit retains explicitly documented provenance-schema limitations.

## Scope and method

This is a read-only package audit, apart from this report. It checks archived and current evidence roots, input/output hashes, retained source revisions, ZIP integrity, documentation paths and agreement of reported counters. It does not rerun numerical discovery, independently reprove the mathematical theorems, or replace the separate code/proof audit. The package assembler restored missing historical bytes during the audit; the auditor then checked the resulting files independently.

The installed computation-audit validator was run with each record's own project root:

```bash
python3 /home/agent/.codex/plugins/cache/openai-curated-remote/mathbox/4.0.0/skills/computation-audit/scripts/validate_manifest.py MANIFEST.json --root SNAPSHOT_ROOT
```

Additional checks used SHA256 of actual file bytes, Python ZIP CRC checks, an entry-by-entry comparison with the immutable parent ZIP, and inspection of documented file and script dependencies. No command recorded in an evidence file was executed automatically.

## 1. Valid evidence records and their roots

All six `manifest.json` files below pass the installed validator, including input and output hash verification. Every one records `run.status = completed`.

| Record, relative to its root | Root relative to this checkpoint | Verdict |
|---|---|---|
| `computations/composition_baseline_001/manifest.json` | `.` | Valid; inherited 3/14 baseline |
| `computations/composition_release_001/manifest.json` | `.` | Valid; current corrected release |
| `computations/composition_validation_001/manifest.json` | `history/frozen_composition_validation` | Valid; original 14/14 structural discovery |
| `computations/fresh_holdout_001/manifest.json` | `history/frozen_validation` | Valid; older frozen 23/24 cubic experiment |
| `computations/release_001/manifest.json` | `history/interval_checkpoint` | Valid; previous interval release |
| `computations/fresh_holdout_001/manifest.json` | `history/interval_checkpoint/history/frozen_validation` | Valid; identical retained copy of the older cubic experiment |

The current `experiments/composition_independent_audit.json` also passes the official validator against the checkpoint root. It records `status = PASS`, `run.status = completed`, 18 unchanged pinned inputs, and the hashed independent report output. Its SHA256 is:

```text
bd4292079b4fd65d37cefb7550d69a87ea5e38283785d1ea7a409757358230e5
```

Schema and hash validity establish provenance consistency. The mathematical interpretation remains supplied by the relevant proof and independent audit documents.

## 2. Historical layout defects found and repaired

The initial extracted `history/interval_checkpoint/` was a partial copy. Its release manifest lacked 23 pinned inputs, and its preserved whole-package inventory lacked 115 of its 152 listed files. This also broke historical README instructions for the original six-reactive proof, nested frozen cubic experiment, figures and reports. The package assembler restored the complete old checkpoint.

After restoration, all **152 original inventory entries match**, and all **154 file entries in the immediate-parent ZIP match the extracted historical tree byte for byte**. In particular, the old release and nested frozen experiment now validate at the roots their original commands expect. No historical result, source file or inventory was rewritten to obtain these checks.

The initial failed composition audit lacked nine pinned inputs in its frozen root. All nine are restored at their exact recorded hashes. The retained generator also required `certificates/historical_case_3.json` and `certificates/historical_case_21.json`, beyond those nine inputs. Both are restored. All three generator source-core hashes and all three files in `composition_validation_freeze.json` now match in the frozen root.

The exact repaired manifest inputs and hashes are listed in the appendices. The complete parent restoration also closes archived documentation references beyond those input lists.

## 3. Retained historical limitation

The original failed record is:

```text
history/frozen_composition_validation/experiments/composition_independent_audit.json
SHA256 e52916364cc719de5517f29bfde21521342177b6e20c389117253ed83980f260
```

Its complete 18-input hash closure now matches, but the record itself is **not a validator-valid v2 manifest**. It has the original `repository.dirty = null` and `outputs = []`. The installed validator reports:

```text
invalid manifest: repository.dirty must be boolean; outputs must include hashed artifacts
```

This limitation is retained rather than repaired in place. The record remains exact historical evidence of the constructor portability failure; it must not be described as the valid provenance manifest for the 14/14 discovery experiment. That experiment has its own valid manifest, listed above. The final corrected independent audit is another separate, valid record.

`history/FROZEN_SNAPSHOTS.md` now makes these distinctions explicit. The frozen audit script writes to its historical JSON path if invoked directly, so a future reproduction should work from a separate copy instead of overwriting the preserved failure.

## 4. Revision and archive identity

| Artifact | Verified SHA256 |
|---|---|
| Immediate parent ZIP, `history/Komorebi_Smith_RLC_Interval_Continuation_2026-11-11.zip` | `66cb2e38c0f59235184199f266a9638c5a8d0ab9f4a60a87483cb0613e5ae31d` |
| Earlier ZIP, `history/Komorebi_RLC_General_Solver_Continuation_2026-11-11.zip` | `a7062b55396452139b017d361e690fec70ce21da580150893ce1ea817a38d4f9` |
| Frozen composition checker | `1aa31c10cead9b2da925b2637a84fe9dde4240aad313a72024c4333f25f39ba9` |
| Current corrected composition checker | `324948708abc1d9ee49b40bc93f54428f552d65d50a1c2db20b47b729e53bc40` |
| Frozen structural-validation manifest | `a7d124f1cdbfddd22e5128b32df690a6789de315b1d0cec10067724e2c5ef032` |
| Current release manifest | `f95b4aa34e8f428e8586dc9ad068d4c6a275af9aa3f3774e51c6b49909c5843c` |
| Restored interval package inventory | `bd3b151af17329c373efb3abe4665f3a767feb8716816a57ac477e44e4783a2c` |

Both included ZIPs pass CRC validation. `BASE_COMPOSITION_CHECKPOINT.json` identifies the immediate parent; the inherited `BASE_CHECKPOINT.json` belongs to the preceding interval stage. The snapshot map now explains this ancestry distinction.

## 5. Current documentation and counters

The current README, report, handoff, engineering notes, results, continuity record and verification summary route readers to the composition release. Their substantive evidence counts agree with the actual records:

- Frozen wrapper discovery: 14/14, inherited baseline 3/14, eleven new interval-containing composition successes, three inherited algebraic successes, degrees 4–7.
- Current release: 67 inherited groups, 41 interval groups, 65 composition groups, 26 indexed portable entries, six critical previous dispatcher targets and the original exact-six replay.
- Composition controls: 16 positive groups and 49 rejection controls; 42 independent rational nodal circuits and 222 exact arguments.
- Separate independent audit: fourteen graphs, 73 exact nodal arguments and 41 malformed-input controls.
- Lift controls: 72 selected rows, 108 inverse round trips and 324 scalar checks; repeated zero-depth rows are not presented as distinct targets.
- Previous cubic evidence remains separated as 50/50 historical regression, 23/24 frozen validation against 21/24, and later 24/24 regression.

The degree-twelve certificate is labeled as forward construction. The theorem's all-real open families remain distinct from bounded point-certificate serialization and target-only discovery. The general synthesis problem, resistor/total-component minimality and historical novelty are not asserted as settled.

The report's next-route statement was aligned with the handoff: test direct specialization of the uniform family to ordinary point certificates first; require a dedicated member format only if that route is insufficient. Current machine-readable source hashes in `CONTINUITY.json` and `VERIFICATION_SUMMARY.json` match the actual current sources.

## 6. Release boundary

No unresolved missing input or changed pinned hash remains in the checked evidence roots. The retained initial-failure schema defect is explicit and does not alter the valid current release or frozen discovery manifests.

The final root `MANIFEST.sha256.json`, `SHA256SUMS.txt`, new distributable ZIP and its fresh-extraction verification are assembled after this report is frozen. Their final hashes and completeness checks belong to the enclosing release verification, not to this report. This avoids treating an in-progress inventory or a self-referential hash as final evidence.

## Appendix A. Restored interval-release pinned inputs

All paths below are relative to `history/interval_checkpoint/`. The source of recovery was the immutable previous interval checkpoint; all expected hashes were checked after copying.

| Path | Verified SHA256 |
|---|---|
| `certificates/INDEX.json` | `998bcb57ed8bfedccb04e11da88df2dc48b17524b36c24654d18587c524fa974` |
| `certificates/boundary_endpoint_cubic.json` | `d779e391414a43b50e089449a5e2a5a0f476261a9e1ff4de5eb3c6cfe180fce3` |
| `certificates/fresh_case_12.json` | `ce89994f3e3c1bc540213520c6d633e2f9421876c5286c8ff16b08d33bf53ed4` |
| `certificates/fresh_case_8.json` | `ffcf5c4485ce9b91b2f0976b00cd89c11f47e5d9b4b45c0c73bc0174a8cd118e` |
| `certificates/historical_case_1.json` | `a750210a7d1d4781c45eaaa7b9b539f6b443db38ff77956008a3f58a454bc4f3` |
| `certificates/historical_case_21.json` | `b92a6769f0027ae75772edab6243f212b86f45bfe91874be35d82d7b7134bb29` |
| `certificates/historical_case_3.json` | `430cc68ecdd87e214274e450cb50f4c10da1f1473401443e93071f0b197a2f28` |
| `certificates/historical_case_3_eight_branch.json` | `c1d6e33ca72a504ca92c93be1221e60dd495d896bb05d8a94861017ee892a10c` |
| `certificates/historical_case_4.json` | `178c0e236e02d5b9c85073601acf777357120932d72de44ab0f80e4489aaf659` |
| `certificates/image_baseline_cubic.json` | `cd4dd6be83347df7d372b0004b7c61c19578082908d3d579f9465154d274576c` |
| `certificates/local_family_case_1.json` | `28d096fa089bb550208f7dc7e5eede622d4cdf9704210088447c99e5f2899ffe` |
| `experiments/fresh_holdout_inputs.json` | `2992b64944ec3bd6b860e2b118c7fba2b62706abcab471b5c90ed3c6fc1f8947` |
| `results/holdout_q3.json` | `f80da085ae1c2e1398ac70f33791b63f5262fadb62be965365f4a760ce0b445b` |
| `examples/boundary_degree_two_recursion.json` | `835645b80295490d982eef183a9966cb2096d413b936525f64c2e0a912b73026` |
| `examples/bridge_three_node.json` | `f9b6ffe0275b7ea2c4840e3151f9012d2c5b3cff6433ad2fe07c795abf424a29` |
| `examples/degree5_nested_endcap.json` | `286961d931c00f6030694e67eee3e7202e903202e3206d69ec4544db952a30e9` |
| `examples/degree8_rc_ladder.json` | `4fd3f2bdfccec8c07e854d39b24774693a361c31f6fa21637352b01b2cf77fc0` |
| `examples/hard_coupled_q3.json` | `892e11d8a722cccf3bdfba302144f02ce599279b9d204a507b556a13dbc70101` |
| `examples/holdout_unknown_q3.json` | `335183898625dfb65bcd268817a6821c4b923c40cc2febf966d855f9649acfd4` |
| `examples/hughes_minimum_q2.json` | `3b2b9ca7319629d767e28e6d461d8ac706426cd97c0426433c480f9b8a7aafb4` |
| `examples/sparse_bridge_A.json` | `450bb60ce0bdb148c448489849a604091aaad9e05712d7a6a4d84d18f28b2ac7` |
| `examples/sparse_bridge_B.json` | `a37a1a89e73ea246dedb2d0d57d262a9af4ade7f6386be3ead3ba9a4b9157d7e` |
| `examples/unresolved_mixed_q3.json` | `b34baf51dbc9528a1e1fdaabe7828ce8f44406c318e14644b4087694e462b4c7` |

## Appendix B. Restored frozen failed-audit inputs

All paths below are relative to `history/frozen_composition_validation/`. The historical theorem file comes from the old interval checkpoint; the lift script and result retain their original unchanged current-project bytes.

| Path | Verified SHA256 |
|---|---|
| `reports/FAMILY_INDEPENDENT_AUDIT.md` | `706d4a9dd07286c82955c475f05ffa8ce39287169941ded2dd504e75666c066a` |
| `reports/INTERVAL_CHECKER_NOTES.md` | `2a6893805bdfb9ea92e0df42b523ab632dd2f87bd43d3ecb612e42a94378534b` |
| `THEOREMS_AND_PROOFS.md` | `642943acb7faa669eddc9c95a751978f1f8b49be2f75f5d648b8b33021ad12e1` |
| `certificates/image_baseline_cubic.json` | `cd4dd6be83347df7d372b0004b7c61c19578082908d3d579f9465154d274576c` |
| `certificates/boundary_endpoint_cubic.json` | `d779e391414a43b50e089449a5e2a5a0f476261a9e1ff4de5eb3c6cfe180fce3` |
| `certificates/historical_case_1.json` | `a750210a7d1d4781c45eaaa7b9b539f6b443db38ff77956008a3f58a454bc4f3` |
| `certificates/local_family_case_1.json` | `28d096fa089bb550208f7dc7e5eede622d4cdf9704210088447c99e5f2899ffe` |
| `experiments/coupled_core_lift_audit.py` | `44731ef7ea1270cd7b7fccd452ebf1a10689d5514f89cc44030912a5a75c4a20` |
| `experiments/coupled_core_lift_audit.json` | `bc238f07d1c736bc50e51c91da31c70a5709eb5515e0a907d0dc64b22cccc410` |

The generator's additional restored dependencies are:

| Path | Verified SHA256 |
|---|---|
| `certificates/historical_case_3.json` | `430cc68ecdd87e214274e450cb50f4c10da1f1473401443e93071f0b197a2f28` |
| `certificates/historical_case_21.json` | `b92a6769f0027ae75772edab6243f212b86f45bfe91874be35d82d7b7134bb29` |
