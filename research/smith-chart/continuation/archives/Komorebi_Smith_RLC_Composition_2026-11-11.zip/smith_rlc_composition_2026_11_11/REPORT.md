# Exact composition of coupled RLC cores

**Author: Komorebi P.**  
**Checkpoint:** `smith-rlc-composition-2026-11-11`  
**Research date:** November 11, 2026, America/Chicago; execution timestamps are UTC.  
**Status:** Unpublished continuation of the latest interval-synthesis checkpoint.

## 1. Result

The higher-degree solver can now use interval-certified coupled cubic cores inside exact passive series/parallel modules. It returns a certificate for the complete circuit, with separate exact parameter contexts for its leaves and an independently reconstructed graph. The new verifier handles algebraic leaves, interval leaves and positive rational physical elements without converting all component values into one common algebraic field.

The first frozen structural validation certified **14 of 14 targets**, compared with **3 of 14** for the inherited solver. All eleven newly solved targets use the new composition format with an interval-certified cubic leaf. Every accepted full circuit was checked against the original target and attained its exact rational-degree lower bound.

A separate theorem lifts the previously certified seven-dimensional real cubic coefficient box to full-dimensional open minimum-reactive families at every degree `n>=3`. The proof supplies an explicit two-sided inverse and establishes noncancellation. The finite validation concerns fresh wrapper targets around previously studied cubic cores; the all-degree statement concerns an explicitly described sufficient family. Neither is a universal passive-network synthesis algorithm.

## 2. Latest state and supplied images

The immediate parent is `Komorebi_Smith_RLC_Interval_Continuation_2026-11-11.zip`, SHA256:

```text
66cb2e38c0f59235184199f266a9638c5a8d0ab9f4a60a87483cb0613e5ae31d
```

The supplied images pin the exact identity

\[
\frac{144s^3+100s^2+52s+28}{36s^3+169s^2+113s+11}
=\left[\frac14+\frac1{s+(12s+7)/(36s^2+25s+1)}\right]^{-1}.
\]

Its certificate and identity record remain in `certificates/image_baseline_cubic.json` and `reports/IMAGE_BASELINE_CHECK.json`. This cubic is distinct from the coupled core in the new illustrated example below.

The original degree-six target already has a positive six-reactive witness. This continuation retains and replays it; the superseded six-versus-seven uncertainty is not reopened. Its graph has three inductors, three capacitors and seven resistors.

Previous evidence is preserved without relabeling: the historical cubic set reached 50/50 regression; the frozen independent cubic experiment reached 23/24 against a 21/24 baseline; solving its subsequently inspected final case gave 24/24 regression. Those numbers belong to the previous checkpoint and its frozen source snapshots.

## 3. Certificate and solver changes

The previous cubic interval certificate isolates exact real component values in a rational box. The older recursive composer expected an explicit common algebraic-field representation. A valid cubic interval root therefore could not be carried automatically through a higher-degree decomposition.

The new format, `komorebi-rlc-composition-v1`, records five supported operations: an independently verified circuit leaf, a positive R/L/C element, series composition, parallel composition and frequency inversion. Each leaf occurrence receives fresh internal node labels and its own exact parameter context. Its terminal impedance is already certified as a rational function; those functions can then be combined exactly.

The checker verifies every leaf, reconstructs the graph, reduces scalar impedance expressions, compares the complete result with the requested target, checks the budget and counts every physical reactive branch instance. It does not silently merge repeated parallel components. If cancellation lowers the final rational degree, it reports a realization without claiming minimum reactive count. Minimality follows only when actual reactive count equals final reduced degree.

Frequency inversion preserves the graph while exchanging inductive and capacitive admittance types. Both target polynomials are padded to one common degree before reversal. There is no generic reciprocal operation for arbitrary coupled graphs. Duality is used only for explicitly series/parallel outer modules where the construction is justified.

The dispatcher retains inherited exact search first. Its new bounded fallback recursively applies exact exposed-element, positive endpoint and passive simple-pole/quadratic reductions. At an eligible cubic residual it invokes target-only topology discovery, then submits the leaf and every complete graft to exact checking. Failed residuals are cached. Recursion strictly lowers degree, and state/topology-call limits are explicit. The discovery module does not read saved fixture certificates or generating circuits.

## 4. A concrete new quartic target

Use the previously certified coupled core

\[
Z_c(s)=\frac{3360s^3+2388s^2+630s+150}
{1736s^3+1826s^2+810s+175}.
\]

Add `L=5/3` in series with this core, then place `R=7/2` across the entire arm. The full impedance is

\[
Z_4(s)=\left[\frac27+\frac1{(5/3)s+Z_c(s)}\right]^{-1}
\]

\[
\boxed{
Z_4(s)=\frac{60760s^4+134470s^3+78498s^2+19355s+3150}
{17360s^4+74876s^3+60774s^2+22540s+4575}.
}
\]

This is the first frozen validation target. The inherited solver returned `UNKNOWN`; the new dispatcher found an exact minimum certificate from its coefficients alone. Separately, `certificates/composition_illustrated_degree4.json` directly composes the retained core witness with the two stated rational elements. That illustrated construction has three inductors, one capacitor and five resistors. Its reduced degree is four, so four reactive elements are globally minimum in the stated physical class. No minimum-resistor conclusion follows.

The Python-generated `figures/Composed_Core_Smith_Chart.png` and `.svg` show the circuit and impedance traces for reference impedance `Z0=1`. Frequency sampling illustrates the functions; certificate acceptance uses exact identities and rational inequalities. The exact DC/high-frequency reflection coefficients are `−1/13,29/91` for the core and `−19/103,5/9` for the composed circuit.

A separately labeled forward certificate applies nine positive endcaps to a known core and verifies a degree-twelve target with twelve reactive elements and thirteen resistors. This is portable forward composition at degree twelve, not target-only discovery at that degree.

## 5. Extension to every degree

Let P,Q be coprime real polynomials of equal degree n, with Q monic and positive leading numerator coefficient. For g,L>0, define

\[
N=P+sLQ,\qquad D=Q+gN.
\]

Both have degree n+1, with leading coefficients L and gL. Moreover,

\[
\gcd(N,D)=\gcd(N,Q)=\gcd(P,Q)=1.
\]

The physical operation adds exactly one reactive element and raises reduced degree by exactly one. The universal graph-degree lower bound then proves minimum reactive count whenever the original core attains its degree.

The stronger open-family statement follows from an explicit inverse. Normalize the output U/V so V is monic, and set

\[
g=\frac1{U_{n+1}},\quad H=V-gU,\quad h=H_n,
\quad L=\frac{U_{n+1}}h,
\]

\[
K=U-sLH,\qquad P=K/h,\qquad Q=H/h.
\]

On the precise image chart, h>0 and K_n>0. These are open conditions, and the forward and inverse maps are rational and two-sided. This proves a diffeomorphism onto an open coefficient chart; parameter counting alone would not establish the claim.

Start with the interior of the exact cubic box in `certificates/local_family_case_1.json` and iterate. For every n>=3, the result is a nonempty open family of dimension

\[
7+2(n-3)=2n+1,
\]

the full normalized coefficient dimension. Its positive realization has

\[
\#L=n-1,\qquad \#C=1,\qquad \#R=n+1,
\]

and global minimum reactive count n. This is an all-real theorem. The machine point format has finite size/depth limits and accepts rational outer values and existing exact point leaves; it does not serialize every arbitrary real member of the theorem's family.

The proof is in `reports/COUPLED_CORE_LIFT_THEOREM.md`. Independent review checks its domains, inverse, openness, n=0 edge case, noncancellation and lower-bound dependency. The 72 selected rational rows (including repeated zero-depth entries), 108 inverse round trips and 324 scalar identity checks are supplementary finite implementation controls, not the basis for the universal quantifiers.

## 6. Frozen structural validation

Before the new implementation saw the validation targets, an independent generator fixed fourteen coefficient pairs, their generation record, source-core hashes and seeds. The solver received P/Q only. Its budget was `max_states=80`, `max_degree=12`, at most sixteen cubic topology searches, two starts and 600 evaluations per topology proposal. The provenance runner additionally bounded the run to one core and one numerical-library thread.

| Attachment family | Cases | Degrees | Inherited certified | Current certified |
|---|---:|---|---:|---:|
| One to four series-L / shunt-R endcaps | 4 | 4–7 | 1 | 4 |
| Frequency-inverted endcaps | 2 | 4–5 | 0 | 2 |
| Exposed series-L, series-C, shunt-C, shunt-L | 4 | 4 | 0 | 4 |
| Passive simple-pole modules | 2 | 4 | 2 | 2 |
| Passive quadratic modules | 2 | 5 | 0 | 2 |
| **Total** | **14** | **4–7** | **3** | **14** |

All eleven new successes contain an interval-certified cubic leaf. Three inherited successes keep their algebraic format. The frozen run completed in about 142 seconds in its recorded environment; this is descriptive timing, not a general performance claim.

Input SHA256:

```text
3c2aa0c8ae86411684f962448a4095404c87f4a71d8ef8e5429c1ff7d1a31dd8
```

The original source, data, generation record, output and valid v2 manifest are preserved together at `history/frozen_composition_validation/`. The later constructor correction does not retroactively change that revision. All fourteen frozen certificates replay under the corrected release checker.

## 7. Independent checks and corrected failures

The composition core suite has **65 groups**: sixteen positive groups and 49 rejection controls. Its separate exact rational nodal calculation covers 42 circuits and 222 evaluation arguments. Tests cover cancellation, separate algebraic fields, mixed interval/algebraic leaves, repeated leaf copies, frequency inversion of unequal-degree targets, malformed data, target/budget corruption and resource caps.

A different reviewer directly audited the code and proofs and reconstructed fourteen graphs at 73 exact nodal arguments, including independently implemented `Q(sqrt(2),sqrt(3))` arithmetic. Forty-one malformed controls were rejected. The reviewer also checked the inherited uniform cubic input and the all-degree lifting proof.

The first independent audit failed on a constructor portability defect. Two valid-size rational resistors could sum to a normalized target beyond the reader's 4096-bit rational-input limit. `make_composition` returned that certificate, and replay then correctly rejected it. No false circuit realization was accepted. The fix preflights the emitted object and strictly parses its generated target before returning. The exact counterexample is now a regression control, and the failed audit is preserved in the frozen history.

A development test also initially demanded that every successful dispatcher result use the new format. It failed because the inherited solver already found a different exact degree-six witness. The corrected test checks validity and preserves inherited formats, then separately exercises the composition routine. The failed expectation and valid inherited witness remain in the development records.

The current release gate runs 67 inherited groups, 41 interval-core groups, 65 composition groups, all 26 indexed certificate entries, six critical prior dispatcher targets and the original six-reactive exact proof. It pins the independent audit to the current source files. Its manifest and results are in `computations/composition_release_001/`.

## 8. Limits and next step

An accepted certificate proves the stated circuit and, when degree equality holds, its global minimum reactive count. The bounded numerical and structural search remains incomplete. Exhausting a chart, optimizer or resource limit returns `UNKNOWN` and cannot establish nonexistence.

Discovery currently reaches one coupled core through supported outer modules. The certificate format can carry multiple independently parameterized leaves, but the search does not generally split a target into several unknown coupled cores. Lower-dimensional/singular charts and wider topology coverage also remain open.

The next concrete step is a direct point-certificate route for the exact uniform cubic family. First test whether its component center, radii and preconditioner specialize to an ordinary interval certificate at each rational coefficient vector inside the box. If that route is insufficient, a dedicated family-member leaf would need its own binding and parameter-context proof. This would remove numerical rediscovery for the known local family. The explicit inverse could then strip higher-degree endcaps, test exact base-box membership and return a certificate throughout the rational subfamily. The present theorem alone does not implement that route.

All work retains attribution as Komorebi P. No external publication or historical-priority claim has been made. This checkpoint includes complete code, proofs, failed controls, exact certificates, figures, hashes and continuation state.
