# Komorebi Smith-chart / RLC composition checkpoint

**Author: Komorebi P.**  
**Checkpoint:** `smith-rlc-composition-2026-11-11`  
**Research date:** November 11, 2026, America/Chicago; execution logs use UTC.  
**Publication status:** Unpublished continuation.

The solver now composes exact interval-certified cubic cores with passive outer modules and independently certifies the complete higher-degree circuit. The frozen structural comparison is **14/14 certified, versus 3/14 for the inherited solver**. All eleven new successes contain an interval-certified cubic core. These are fresh wrapper targets around already studied cores, not a new cubic-topology holdout.

A separate proof lifts the explicit real cubic coefficient neighborhood to nonempty open families of full dimension `2n+1` at every degree `n>=3`, with global minimum reactive count `n`.

## Start here

- `REPORT.md`: results, concrete quartic example, proof interpretation and limits.
- `THEOREMS_AND_PROOFS.md`: current claim map T1–T6.
- `reports/COMPOSITION_THEOREM.md`: certificate semantics and graph proof.
- `reports/COUPLED_CORE_LIFT_THEOREM.md`: all-degree lift, inverse and open-family proof.
- `reports/COMPOSITION_INDEPENDENT_AUDIT.md`: separate proof/code review and corrected defect.
- `HANDOFF.md`: exact current state and next research route.

## Replay without numerical packages

From this directory:

```bash
python3 -S src/replay_composition_certificates.py
python3 -S src/composition_certificate.py certificates/composition_illustrated_degree4.json
python3 -S src/composition_certificate.py certificates/composition_direct_degree12.json
```

The combined index contains ten inherited certificates, including the uniform family, and sixteen from this continuation. The degree-twelve certificate is an exact forward construction from a known core, separately labeled from target-only discovery.

## Discover from target coefficients

Discovery uses the package versions in `requirements.lock.txt`; exact acceptance and replay use Python's standard library.

```bash
python3 src/dispatch.py examples/composition_degree4.json --max-budget 4
python3 src/dispatch.py examples/composition_degree5_quadratic.json --max-budget 5
```

Coefficient arrays are in ascending powers. Elements are positive ordinary uncoupled R/L/C components. `CERTIFIED_MINIMUM` includes an independently checkable circuit with actual reactive count equal to reduced rational degree. `UNKNOWN` means that the declared constructive search did not certify a solution; it does not mean impossible.

The inherited exact dispatcher remains first. The new fallback uses exact endpoint/factor reductions, normalized residual caching and bounded cubic topology discovery. Inherited successes preserve their algebraic certificate format.

## Reproduce the release gate

```bash
python3 experiments/run_composition_release.py --output computations/manual_release/results.json
python3 -S experiments/coupled_core_lift_audit.py --output computations/manual_lift.json
```

Use a new output directory for a fresh recorded run. Archived contracts and v2 manifests record source hashes, exact inputs, versions, seeds, limits and outputs. The current gate is `computations/composition_release_001/`. The frozen wrapper-discovery revision is under `history/frozen_composition_validation/`; its checker predates the narrow constructor portability correction. All frozen certificates also replay under the corrected current checker.

## Continuity

The immediate parent archive is included under `history/`, SHA256 `66cb2e38c0f59235184199f266a9638c5a8d0ab9f4a60a87483cb0613e5ae31d`. The image-pinned cubic remains exact, and the original degree-six target remains solved with six reactive elements. The previous cubic fresh-validation result remains **23/24** at its frozen revision; its later **24/24** is regression evidence.

The general all-topology minimum-RLC synthesis problem remains open. No minimum-resistor, minimum-total-component, universal-coverage or historical-novelty claim is made.
