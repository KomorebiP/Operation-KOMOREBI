# Start here

**Komorebi P. — Smith/RLC composition continuation**

Open `REPORT.md` for the result and `figures/Composed_Core_Smith_Chart.png` for the concrete quartic circuit and Smith chart. The full code, exact point/family certificates, independent reviews, initial failures and frozen experiments are included.

The new milestone is complete: higher-degree target-only synthesis can carry interval-certified coupled cubic cores. The frozen structural result is 14/14 versus 3/14. The associated exact lifting theorem produces full-dimensional open minimum-reactive families at every degree.

Portable verification:

```bash
python3 -S src/replay_composition_certificates.py
```

Target-only discovery example:

```bash
python3 src/dispatch.py examples/composition_degree4.json --max-budget 4
```

See `THEOREMS_AND_PROOFS.md` for precise claims, `VERIFICATION_SUMMARY.json` for the current gate, and `HANDOFF.md` for the next route. The original degree-six minimum remains 6, and the image identity remains exact. The general synthesis goal remains open; this checkpoint is unpublished.
