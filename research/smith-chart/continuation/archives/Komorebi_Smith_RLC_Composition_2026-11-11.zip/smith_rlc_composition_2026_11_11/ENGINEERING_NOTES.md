# Engineering notes

**Author: Komorebi P.**  
**Checkpoint:** `smith-rlc-composition-2026-11-11`.

## Acceptance architecture

`composition_certificate.py` is standard-library-only. `verify_circuit(cert, expected_target=None, expected_budget=None)` dispatches the two inherited point formats and the new composition format. `verify_composition_certificate` parses the expression, checks each leaf through its inherited kernel, reconstructs the graph, computes a canonical coprime rational target and checks the external bindings. Expected budget binds the declared budget exactly; actual reactive count must be at most that budget. Minimum status depends on actual count equaling reduced degree.

The expression operations are `certificate`, `element`, `series`, `parallel`, `frequency_invert`. An element value is its physical R/L/C value. Rebuilt graph coefficients use admittance conventions g=1/R, h=1/L, c=C. Certificate leaves support algebraic and interval point formats; a reused composition contributes its expression, not a composition nested as a certificate leaf.

Each leaf occurrence receives an independent context identifier. Branch coefficients reference exact rational values, a polynomial in an isolated algebraic-field root, or a coordinate of an interval-certified root. Copies keep disjoint internal vertices even when their serialized certificates are identical. No unproved cross-leaf numerical substitution or field conversion occurs.

Duplicate same-type parallel branches remain distinct physical instances and are counted. This is intentionally different from some inherited graft helpers that merge coefficients. A certificate with q greater than reduced degree proves realization only. Frequency inversion pads P and Q to a common degree, reverses them, reduces the result and exchanges h/c types while retaining coefficient references.

## Resource bounds and corrected constructor contract

The current checker limits expression depth 32, expression nodes 256, leaf occurrences 64, physical branches 256, target degree 64, input rational size 4096 bits and computed coefficient size 65536 bits. These are explicit implementation limits, not mathematical completeness bounds. Input preflight also limits text, array sizes, cycles and metadata payloads.

The original constructor checked its expression and computed result but did not recheck the generated wire target against the tighter input limit. With `A=2**2100+1`, two series resistors `1/A` and `1/(A+2)` produced a 4201-bit denominator and an unreplayable output. The final constructor runs `_preflight(result)` and `_target(result['target'])` before returning. It now rejects oversized output at construction. Existing normal certificates are unchanged.

## Search interface

```python
synthesize_compositional(
    P, Q, max_degree=12, max_states=250, max_budget=None,
    topology_starts=2, topology_evaluations=600,
    topology_seed=2026111223, max_topology_calls=16,
)
```

The public dispatcher preserves its previous arguments and adds `topology_seed` and `max_topology_calls`. `interval_search=False` retains the inherited-only comparison route. Every successful new leaf, every graft and the final complete certificate is replayed by the exact checker.

Supported reductions are exposed series-L/C and shunt-C/L elements, positive two-element endpoint caps, and exact passive simple-pole/quadratic sections. Frequency-inverted caps use common-degree padding. Reciprocal module duality applies only to explicit series/parallel module trees. The graph-search leaf route is restricted to eligible degree-(3,3) residuals and the existing bounded catalogs. Target normalization and a residual cache avoid repeated searches.

Discovery receives P/Q only and imports no saved certificate or generating-circuit fixture. `UNKNOWN` includes unsupported routes and exhausted limits. A budget below reduced degree is excluded by the degree lower bound, but the current API still returns an explicitly explained `UNKNOWN`, not a general all-topology decision result.

## Proof and test files

| File | Purpose |
|---|---|
| `src/composition_certificate.py` | Exact independent composition acceptance |
| `src/compositional_solver.py` | Bounded target-only search and exact grafts |
| `src/test_composition_core.py` | 65 groups; 42 independent rational nodal circuits / 222 arguments |
| `experiments/composition_independent_audit.py` | Separate exact rational/multiquadratic graph and proof controls |
| `experiments/coupled_core_lift_audit.py` | Exact forward/inverse family controls |
| `src/replay_composition_certificates.py` | All 26 current indexed entries, standard library only |
| `experiments/run_composition_release.py` | Current combined release gate |

The independent audit JSON has valid v2 provenance. Its non-Git dirty flag follows the official runner's conservative unavailable-repository convention, explicitly documented as such; file hashes and the immutable parent archive supply provenance. Its first mathematical/implementation run failed on the now-corrected constructor contract. The retained initial failed audit also has original provenance-schema limitations; see `history/FROZEN_SNAPSHOTS.md`.

## Evidence locations

- `computations/composition_baseline_001/`: inherited 3/14 structural baseline, using its frozen old source closure.
- `history/frozen_composition_validation/`: original 14/14 discovery source/data/results and initial failed independent audit.
- `computations/composition_release_001/`: current corrected-checker regression and replay.
- `history/frozen_validation/`: older 23/24 cubic frozen validation.
- `history/interval_checkpoint/`: prior interval release documents and dependency snapshot.
- `history/Komorebi_Smith_RLC_Interval_Continuation_2026-11-11.zip`: complete immutable immediate parent.

Do not validate a historical manifest against the current changed source tree. Use its co-located frozen root. The new discovery contracts record a two-start/600-evaluation search, one-core/one-thread execution and bounded logs/time. Finite benchmark successes establish the recorded cases only.

## Reproduction and next engineering boundary

Exact replay needs Python only; search uses NumPy, SciPy and SymPy at recorded versions. Fresh outputs should go to a new directory so historical evidence is not overwritten. Source hashes are authoritative for the recorded run; publication status remains unpublished.

The next implementation should test direct specialization of the uniform family certificate to rational points before inventing a new leaf format. Target-only decomposition into multiple unknown coupled cores is still absent even though the composition checker already supports multiple independent leaves.
