# Results and evidence interpretation

**Author: Komorebi P.**

## New checkpoint

| Result | Accepted scope |
|---|---|
| Frozen structural discovery 14/14 versus inherited 3/14 | Fresh outer targets around known cubic cores; degrees 4–7 |
| Eleven newly solved targets | Complete composition certificates, each containing an interval cubic leaf |
| Three preserved inherited successes | Algebraic witness format retained |
| Exact quartic example | Four reactive elements; illustrated graph has five resistors |
| Direct degree-twelve certificate | Forward construction; 12 reactive elements / 13 resistors; not target-only discovery |
| All-degree lift theorem | Nonempty open real coefficient family of dimension 2n+1 for every n>=3 |
| Global minimum reactive count n | Proven only for accepted q=n circuits and stated lifted family |
| Independent composition audit |14 graphs/73 exact nodal arguments,41 malformed controls, all scoped obligations pass |

## Current release gate

The release combines 67 inherited assertion groups, 41 interval-core groups, 65 composition groups and 26 indexed portable certificate entries. Six critical inherited cubic targets and the original exact-six proof are replayed. The authoritative result and v2 manifest are in `computations/composition_release_001/`.

The composition suite contains 16 positive groups and 49 rejection controls; its independent rational nodal calculations cover 42 circuits at 222 arguments. The separate reviewer uses additional rational/multiquadratic arithmetic. Counts from different suites are not presented as one statistical coverage percentage.

The lift script records 72 selected rows, 108 single-step inverse checks and 324 scalar identities. Some zero-depth rows repeat across wrapper streams; 72 does not mean 72 distinct targets. The universal theorem rests on the exact proof and uniform cubic certificate.

## Preserved earlier evidence

- Original degree-six target: q_min=6, already established and freshly replayed here.
- Image-pinned cubic: exact identity and three-reactive certificate retained.
- Historical cubic corpus: 50/50 regression in the prior release.
- Previous independent cubic validation: 23/24 at its frozen revision, against 21/24 baseline.
- Subsequent inspected cubic corpus: 24/24 regression, not untouched validation.

## Failures retained

The first composition constructor could emit an output beyond the reader's rational-size limit. The exact reproducible failure and original source are preserved; the final constructor rejects it before output. No invalid realization was accepted. A development assertion also wrongly required the new certificate format for a valid inherited success; that expectation was corrected and the valid witness retained.

## Not established

Universal all-topology synthesis, complete numerical discovery, general lower-budget refutation, minimum resistor/total count and historical novelty remain unproved or uninvestigated. The all-real theorem does not imply unbounded machine serialization.
