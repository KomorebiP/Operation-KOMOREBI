# Six versus seven reactive elements: coupled synthesis and the dirty-circuit analogy

**Author: Komorebi P.**  
**Date: 11 November 2026**  
**Status: Research continuation. No closure of the six-versus-seven reactive-element question.**

## Problem and established results

For the reduced positive-real rational impedance

\[
Z_6(s)=\frac{450s^6+1385s^5+2477s^4+2200s^3+1142s^2+335s+75}{150s^6+795s^5+1375s^4+1720s^3+1250s^2+445s+25},
\]

the established construction gives a transformer-free one-port containing 4 inductors, 3 capacitors, and 14 positive resistors, with an exact algebraic existence certificate. Its rational McMillan degree is six, and the remaining question is

\[
\boxed{q_{\min}\in\{6,7\}.}
\]

A separate six-reactive construction uses an ideal transformer-based static three-port, so it does not resolve the transformer-free restriction.

Earlier certified necessary conditions for an exactly six-reactive RLC network include: exactly 3 inductors and 3 capacitors (Sylvester/extended Cauchy index), at least five nodes including the port and ground, both same-type reactive edge sets being forests without a port-to-ground path, and nontrivial capacitive/inductive endpoint sensitivities. There are 1,934 admissible labelled five-node reactive placements under these graph restrictions, or 168 symmetry classes. Pole-by-pole independently passive series synthesis has an exact seven-reactive lower bound, **only** in that restricted decomposition class.

## How the August dirty-circuit results do and do not relate

The earlier XOR example has lower-only gate distance 7 and unrestricted gate distance 6. Borrowing a normally forbidden intermediate row and restoring it at the endpoint saves one gate. This is a *structural analogy*, not a theorem about electrical RLC synthesis.

In the RLC problem, the seven-reactive circuit includes one pole-dark internal mode: seven physical energy-storage elements generate a degree-six observable driving-point impedance. Its unobservable degree is *not* a disposable free component: eliminating the state from a state-space description does not generally preserve an ordinary transformer-free positive-element circuit realization.

In another exact construction, a six-reactive circuit uses an ideal static transformer-based combiner. Its two-subnetwork impedance mixing function is

\[
M(a,b)=\frac{2ab+a+b}{a+b+2}.
\]

Previous work proved that no fixed **resistor-only** combiner containing one instance of each independent variable one-port can realize this function for all positive independent \(a,b\): at \((a,b)=(1,10)\), \(\partial M/\partial a=242/169>1\), violating the unit-current Rayleigh/Thomson sensitivity bound. This does *not* exclude a six-reactive circuit with differently coupled, redistributed storage elements. Thus, a viable dirty-workspace analogue needs a genuinely coupled topology rather than a clean replacement of the ideal combiner.

## New exact necessary component-budget bounds

The following simple argument supplies additional necessary inequalities for **any** transformer-free positive-element RLC realization (regardless of its node count). It is an exact mathematical deduction, not a novelty or minimum-count proof.

For a fixed positive real Laplace parameter \(s>0\), set the port voltage to 1 and ground to 0. Regard a resistor as conductance \(1/R\), an inductor as conductance \(1/(sL)\), and a capacitor as conductance \(sC\). Then the driving-point **admittance** \(Y(s)=1/Z(s)\) is the Dirichlet minimum

\[
Y(s)=\min_{v_0=0,\,v_1=1}\left[\sum_R \frac{(\Delta v)^2}{R}
+\sum_L\frac{(\Delta v)^2}{sL}
+\sum_C sC(\Delta v)^2\right].
\]

The discrete maximum principle implies \(0\le v_j\le1\) for the minimizer, hence \(|\Delta v_e|\le1\) for every edge. Differentiating the minimized energy (envelope principle) gives

\[
Y'(s)=\sum_C C_e(\Delta v_e)^2
-\frac1{s^2}\sum_L\frac{(\Delta v_e)^2}{L_e}.
\]

Therefore at every \(s>0\),

\[
\boxed{-\frac{1}{s^2}\sum_L\frac1{L_e}\ \le\ Y'(s)\ \le\ \sum_C C_e.}
\]

Direct polynomial expansion of the exact target yields

\[
Y_6(s)=\frac{1}{3}+\frac{40}{9}s+O(s^2),\qquad s\downarrow0,
\]

and

\[
Y_6(s)=\frac{1}{3}+\frac{20}{27s}+O(s^{-2}),\qquad s\to\infty.
\]

Consequently **every** admissible transformer-free realization satisfies

\[
\boxed{\sum_C C_e\ge\frac{40}{9},\qquad \sum_L \frac1{L_e}\ge\frac{20}{27}.}
\]

For a hypothetical six-element realization, each sum runs over **exactly three** components. These are dimensionless normalized component values in the original \(Z_0=1\) and dimensionless Laplace-frequency convention. They do **not** exclude all possible triples, so they do not close the gap. This argument is also valid for transformer-free circuits having more than six reactive elements.

### Five-node cut constraints

If an exactly-six-reactive five-node circuit exists, both its 3-edge inductor and 3-edge capacitor forests each partition the five nodes into exactly two components, with port and ground on opposite sides. Let \(\delta_L\) and \(\delta_C\) be the resistor cuts between the corresponding two components. At \(s=0\), inductors are shorts and capacitors opens; at \(s=\infty\), the reverse holds. Since \(Z_6(0)=Z_6(\infty)=3\), every such circuit must also satisfy the **linear resistor-conductance equalities**

\[
\boxed{\sum_{e\in\delta_L}g_e=\frac13,
\quad\sum_{e\in\delta_C}g_e=\frac13.}
\]

These are useful exact constraints for the next algebraic solver. They apply to five-node realizations under the three-edge forest hypotheses, not automatically as simple two-cut formulas to all larger-node networks. Missing resistor edges have \(g_e=0\).

## Reproducible numerical experiment (no existence or impossibility claim)

The accompanying `smith_six_coupled_probe.py` independently regenerates all 14,400 labelled 3-inductor/3-capacitor edge placements among five nodes and checks the standard forest, port-short and endpoint-visibility conditions. It obtains **1,934** survivors and **168** classes, matching the older project report.

For each of the 168 five-node classes, it places positive resistor conductances on all ten available undirected node pairs and fits 16 strictly positive parameters (10 resistor conductances, 3 reciprocal inductances and 3 capacitances) by a bounded-log-coordinate nonlinear least-squares fit. The objective uses 18 imaginary-frequency samples plus seven positive real frequency samples. It uses an analytically implemented Jacobian of the nodal-response residual. The Jacobian was checked against centered numerical derivatives (maximum discrepancy approximately \(1.3\times10^{-9}\) at the check point).

A first complete pass with at most 160 solver evaluations per class and one initialization per class produced a best maximum normalized complex relative residual of approximately **0.00245625**. A subsequent refinement of the top eight classes with additional starts and at most 500 solver evaluations each produced **0.00245455** for its best fit. On an independent logarithmic imaginary-axis grid of 2,001 frequencies from \(10^{-4}\) to \(10^4\), this fitted circuit had maximum normalized relative residual approximately **0.00249920**.

The best exploratory five-node reactive topology has inductor edges `(0,2),(0,3),(2,4)` and capacitor edges `(0,4),(1,2),(1,3)`; `smith_six_multistart_results.json` contains the best 16 positive numerical component parameters and residual scores. This is **not** an exact algebraic circuit. A separate extended all-topology 3-start run exceeded the execution time limit before producing a final result file, so its partial progress is not presented as a completed audit. The present numerical search does not disprove six-reactive realizability, even within five nodes, and certainly says nothing decisive about six-to-fourteen-node topologies.

A finite approximate frequency-grid fit can never certify the exact rational identity. Certification of a discovered candidate would require its exact nodal polynomial identity and a rational or algebraic existence certificate with strictly positive parameters. Exclusion requires exhaustive certified infeasibility across the required reactive placements and all allowed node counts.

## Next decisive work

1. Solve the coupled 3L+3C five-node cofactor equations **with the two resistor-cut equalities imposed exactly**, using elimination, continuation and interval certification. Allow zero conductances to include sparse resistor graphs.
2. If these fail, expand to six or more reactive endpoints; resistor-only auxiliary nodes can be Kron-reduced and do not add energy storage, but can change effective coupling among the reactive endpoints.
3. Treat a numerical near-match only as a proposal; certify any candidate by exact polynomial equations and rational interval enclosures.
4. In the obstruction direction, combine sign/degree invariants with exhaustive real-algebraic positivity tests. Excluding all 168 five-node classes would still not exclude the larger-node cases.

**Bottom line:** The exact lower and upper bounds remain \(6\le q_{\min}\le7\). The dirty-circuit analogy highlights why we should search globally coupled topologies rather than insist on intermediate clean decompositions; no direct six-versus-seven transfer theorem is proved. The new endpoint constraints make that search more sharply specified, but they are not a closure.
