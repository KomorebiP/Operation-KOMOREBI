#!/usr/bin/env python3
"""Author: Komorebi P. Independent derivative checks and rejection controls."""
from fractions import Fraction as F
from pathlib import Path
import json,copy,sys
from verify_exact_six import regenerate,evaluate,verify,BASE
if not __debug__:raise RuntimeError('Do not disable assertions.')
terms,_,_=regenerate()
x=[F(j+2,j+3) for j in range(13)];f,J=evaluate(x,terms);delta=F(1,100)
# Every variable enters each monomial at most once, so a centered finite
# difference is exactly the derivative (not an approximation) in that variable.
for j in range(13):
    xp=x.copy();xm=x.copy();xp[j]+=delta;xm[j]-=delta
    fp,_=evaluate(xp,terms);fm,_=evaluate(xm,terms)
    for i in range(13):assert (fp[i]-fm[i])/(2*delta)==J[i][j]
cert=json.loads((BASE/'results/six_reactive_certificate.json').read_text())
rejections={}
for name in ('perturbed_center','negative_parameter','wrong_target'):
    bad=copy.deepcopy(cert)
    if name=='perturbed_center':bad['center'][0]=str(F(bad['center'][0])+F(1,1000))
    elif name=='negative_parameter':bad['center'][0]=str(-F(bad['center'][0]))
    else:bad['target_P_ascending'][0]+=1
    try:
        verify(bad)
    except AssertionError:
        rejections[name]='REJECTED AS REQUIRED'
    else:
        raise RuntimeError('Rejection control unexpectedly accepted: '+name)
report={'status':'PASS','author':'Komorebi P.','exact_Jacobian_entry_checks':169,'rejection_controls':rejections}
(BASE/'results/audit_report.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
