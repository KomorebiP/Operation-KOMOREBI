"""Author: Komorebi P. Disjoint endpoint 3L+3C search, numerical discovery only.
Complete resistor graph on 14 retained terminals. Does not certify exclusion.
"""
from coupled_search import model
from pathlib import Path
BASE=Path(__file__).resolve().parents[1]
import numpy as np,json,itertools,time,os
from scipy.optimize import least_squares

def make_start(seed,rng,glue):
    n=14;pairs=list(itertools.combinations(range(n),2));es=seed['L']+seed['C']
    groups={j:[] for j in range(seed['n'])};groups[0]=[0];groups[1]=[1]
    for k,(a,b) in enumerate(es):groups[a].append(2+2*k);groups[b].append(3+2*k)
    gs={e:1e-8 for e in pairs}
    for grp in groups.values():
        for e in itertools.combinations(grp,2):gs[tuple(sorted(e))]=glue
    p=np.array(seed['params']);nr=len(seed['resistor_edges'])
    for e,g in zip(seed['resistor_edges'],p[:nr]):
        a,b=e;ga,gb=groups[a],groups[b]
        for u in ga:
            for v in gb:gs[tuple(sorted((u,v)))]+=g/(len(ga)*len(gb))
    return np.log(np.r_[[gs[e] for e in pairs],p[nr:]])

def run():
    L=[(2,3),(4,5),(6,7)];C=[(8,9),(10,11),(12,13)];rng=np.random.default_rng(991)
    f=model(14,L,C);pairs=list(itertools.combinations(range(14),2))
    seeds=json.load(open(BASE/'results/search7.json'))[:4]
    best=1.;records=[];tt=time.time()
    for k in range(8):
        seed=seeds[k%len(seeds)]
        x=make_start(seed,rng,10. if k<4 else 2.)
        opt=least_squares(lambda x:f(x)[0],x,jac=lambda x:f(x)[1],bounds=(-25,15),max_nfev=3500,xtol=1e-14,ftol=1e-14,gtol=1e-14)
        err=float(np.max(np.abs(f(opt.x)[0])))
        rec={'n':14,'L':L,'C':C,'resistor_edges':pairs,'params':np.exp(opt.x).tolist(),'error':err,'nfev':opt.nfev,'seed_index':k}
        print('run',k,'error',err,'eval',opt.nfev,'secs',time.time()-tt,flush=True)
        records.append(rec)
        json.dump(sorted(records,key=lambda z:z['error']),open(BASE/'results/search14.json','w'),indent=2)
        if err<best:
            best=err;json.dump(rec,open(BASE/'results/best14.json','w'),indent=2)
        if err<1e-11:break
if __name__=='__main__':run()
