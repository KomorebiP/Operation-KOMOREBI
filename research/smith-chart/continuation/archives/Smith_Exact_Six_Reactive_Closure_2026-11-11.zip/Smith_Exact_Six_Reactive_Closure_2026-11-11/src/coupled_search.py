"""Author: Komorebi P. Noncertifying candidate discovery for exact rational identity.
Candidate acceptance in this program is numerical only. Certification is separate.
"""
from pathlib import Path
BASE=Path(__file__).resolve().parents[1]
import numpy as np, json, itertools, os, sys, time
from scipy.optimize import least_squares
P=np.array([450,1385,2477,2200,1142,335,75.])
Q=np.array([150,795,1375,1720,1250,445,25.])
# 13 distinct complex interpolation arguments determine the degree<=12 cross-product.
S=np.r_[1j*np.geomspace(.04,20,10), [.0+0.07,.4,4.]]
T=np.polyval(P,S)/np.polyval(Q,S); SCALE=np.abs(T)

def model(n,L,C,rf=None):
    pairs=list(itertools.combinations(range(n),2))
    if rf is None:rf=pairs
    edges=rf+list(L)+list(C)
    B=np.zeros((len(edges),n-1))
    for j,(a,b) in enumerate(edges):
        if a:B[j,a-1]+=1
        if b:B[j,b-1]-=1
    mats=np.einsum('ia,ib->iab',B,B)
    nr=len(rf);nl=len(L);nc=len(C)
    fac=np.c_[np.ones((len(S),nr)),np.tile(1/S[:,None],(1,nl)),np.tile(S[:,None],(1,nc))]
    rhs=np.zeros((len(S),n-1,1),complex);rhs[:,0,0]=1
    cache=[None,None,None]
    def calc(x):
        if cache[0] is not None and np.array_equal(x,cache[0]):return cache[1],cache[2]
        ad=fac*np.exp(x)[None,:]
        Y=np.einsum('ni,iab->nab',ad,mats,optimize=False)
        V=np.linalg.solve(Y,rhs)[:,:,0]
        er=(V[:,0]-T)/SCALE
        drops=V@B.T
        jac=-ad*drops**2/SCALE[:,None]
        cache[:]=[x.copy(),np.r_[er.real,er.imag],np.r_[jac.real,jac.imag]]
        return cache[1],cache[2]
    return calc

def split_topologies(seed):
    L=[tuple(e) for e in seed['L']];C=[tuple(e) for e in seed['C']]
    # split any vertex's nonempty proper set of incident reactive edges
    es=L+C
    out=[]
    for v in range(5):
        inc=[k for k,e in enumerate(es) if v in e]
        for sz in range(1,len(inc)+1):
            for move in itertools.combinations(inc,sz):
                if sz==len(inc):continue
                ee=[tuple(sorted(5 if k in move and a==v else a for a in e)) for k,e in enumerate(es)]
                out.append((v,ee[:3],ee[3:]))
    return out

def run():
    prior=json.load(open(BASE/'history/smith_six_multistart_results.json'))
    pairs5=list(itertools.combinations(range(5),2)); pairs6=list(itertools.combinations(range(6),2))
    rng=np.random.default_rng(421)
    best=1.;records=[];t=time.time()
    todo=[]
    for seed in prior[:5]:
        for v,L,C in split_topologies(seed):todo.append((seed,v,L,C))
    rng.shuffle(todo)
    for k,(seed,v,L,C) in enumerate(todo):
        f=model(6,L,C)
        old=np.array(seed['params'])
        rs=[]
        for e in pairs6:
            if 5 not in e:rs.append(old[pairs5.index(e)])
            elif v in e:rs.append(3.)
            else:rs.append(.003)
        x=np.log(np.r_[rs,old[10:]])
        opt=least_squares(lambda x:f(x)[0],x,jac=lambda x:f(x)[1],bounds=(-20,15),max_nfev=350,xtol=3e-13,ftol=3e-13,gtol=1e-13)
        err=float(np.max(np.abs(f(opt.x)[0])))
        rec={'n':6,'L':L,'C':C,'resistor_edges':pairs6,'params':np.exp(opt.x).tolist(),'error':err,'nfev':opt.nfev,'seed_index':k}
        if err<best:
            best=err;print('BEST',k,'error',best,'L',L,'C',C,'time',time.time()-t,flush=True)
            json.dump(rec,open(BASE/'results/best6.json','w'),indent=2)
        records.append(rec)
        if k%10==0:
            print('progress',k,'/',len(todo),flush=True)
            json.dump(sorted(records,key=lambda z:z['error'])[:30],open(BASE/'results/search6.json','w'),indent=2)
        if best<1e-10:break
    json.dump(sorted(records,key=lambda z:z['error']),open(BASE/'results/search6.json','w'),indent=2)
    print('FINISHED',len(records),'best',best,flush=True)
if __name__=='__main__':run()
