"""Author: Komorebi P. High precision root proposal, not the acceptance certificate.
The separate Fraction-only verifier proves exact existence.
"""
import mpmath as mp,json,time
from pathlib import Path
BASE=Path(__file__).resolve().parents[1]
mp.mp.dps=130
system=json.loads((BASE/'results/exact_polynomial_system.json').read_text())
seed=json.loads((BASE/'results/sparse_candidate.json').read_text())
terms=[(t['vars'],[(i,c) for i,c in enumerate(t['coefficients']) if c]) for t in system['terms']]

def fj(x):
 f=mp.matrix(13,1);J=mp.matrix(13,13)
 for ids,co in terms:
  val=mp.fprod(x[j] for j in ids)
  deriv=[(j,val/x[j]) for j in ids]
  for i,c in co:
   f[i]+=c*val
   for j,dv in deriv:J[i,j]+=c*dv
 return f,J
x=mp.matrix([mp.mpf(str(a)) for a in seed['params']]);start=time.time()
for k in range(8):
 f,J=fj(x);dx=mp.lu_solve(J,-f);x+=dx
 print(k,'residual',mp.nstr(max(abs(a) for a in f),8),'step',mp.nstr(max(abs(a) for a in dx),8),'seconds',time.time()-start,flush=True)
 if max(abs(a) for a in dx)<mp.mpf('1e-118'):break
f,J=fj(x);M=J**-1
out={'author':'Komorebi P.','precision_digits':130,'root':[mp.nstr(a,122) for a in x],'inverse_jacobian':[[mp.nstr(M[i,j],122) for j in range(13)] for i in range(13)],'residual_max':mp.nstr(max(abs(a) for a in f),10),'inverse_norm':mp.nstr(max(sum(abs(M[i,j]) for j in range(13)) for i in range(13)),30)}
(BASE/'results/high_precision_root.json').write_text(json.dumps(out,indent=2))
print('ROOT');print('\n'.join(out['root']));print('inverse norm',out['inverse_norm'])
