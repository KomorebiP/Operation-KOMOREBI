"""Author: Komorebi P. Search for two minimal cubic series sections.
Numerical proposals only, not exact existence certificates.
"""
from pathlib import Path
BASE=Path(__file__).resolve().parents[1]
import numpy as np,itertools,json,time
from scipy.signal import residue
from scipy.optimize import least_squares
P=np.array([450,1385,2477,2200,1142,335,75.]);Q=np.array([150,795,1375,1720,1250,445,25.])
r,p,k=residue(P,Q)
print('poles',p,'residues',r,flush=True)
ss=np.r_[1j*np.geomspace(.02,30,12), .01,.1,.4,1.,10.]
idxreal=np.where(np.abs(p.imag)<1e-9)[0]
idxpairs=[i for i in range(len(p)) if p[i].imag>1e-9]


def classes(n,nl,nc):
 pairs=list(itertools.combinations(range(n),2));memo=set();out=[]
 def comp(ed):
  par=list(range(n))
  def find(i):
   while par[i]!=i:i=par[i]
   return i
  for a,b in ed:
   i,j=find(a),find(b)
   if i==j:return None
   par[i]=j
  if find(0)==find(1):return None
  return tuple(find(i) for i in range(n))
 for L in itertools.combinations(pairs,nl):
  if comp(L) is None:continue
  for C in itertools.combinations(pairs,nc):
   if comp(C) is None:continue
   reps=[]
   for pp in itertools.permutations(range(2,n)):
    for swap in (False,True):
     mp=[1,0,*pp] if swap else [0,1,*pp]
     conv=lambda ed:tuple(sorted(tuple(sorted((mp[a],mp[b]))) for a,b in ed))
     reps.append((conv(L),conv(C)))
   canon=min(reps)
   if canon not in memo:memo.add(canon);out.append(canon)
 return out

def make(n,L,C,F,lower,upper):
 pairs=list(itertools.combinations(range(n),2));edges=pairs+list(L)+list(C)
 B=np.zeros((len(edges),n-1))
 for j,(a,b) in enumerate(edges):
  if a:B[j,a-1]+=1
  if b:B[j,b-1]-=1
 mats=np.einsum('ia,ib->iab',B,B)
 nr=len(pairs);nl=len(L);nc=len(C)
 fac=np.c_[np.ones((len(ss),nr)),np.tile(1/ss[:,None],(1,nl)),np.tile(ss[:,None],(1,nc))]
 rhs=np.zeros((len(ss),n-1,1),complex);rhs[:,0,0]=1
 cache=[None,None,None]
 scale=np.maximum(.1,np.abs(F+(lower+upper)/2))
 def fun(x):
  if cache[0] is not None and np.array_equal(x,cache[0]):return cache[1],cache[2]
  z=x[-1];rc=lower+(upper-lower)*z
  ad=fac*np.exp(x[:-1])[None,:]
  Y=np.einsum('ni,iab->nab',ad,mats,optimize=False)
  V=np.linalg.solve(Y,rhs)[:,:,0]
  er=(V[:,0]-F-rc)/scale
  drops=V@B.T;jac=-ad*drops**2/scale[:,None]
  jac=np.c_[jac,-(upper-lower)/scale]
  cache[:]=[x.copy(),np.r_[er.real,er.imag],np.r_[jac.real,jac.imag]]
  return cache[1],cache[2]
 return fun

def run(n=4):
 rng=np.random.default_rng(415);cs=classes(n,1,2);print('classes',n,len(cs),flush=True);results=[];best=1.;t=time.time()
 w=1j*np.r_[0,np.geomspace(1e-5,1e5,10000)]
 for ii in idxpairs:
  pair=[ii,np.argmin(abs(p-p[ii].conjugate()))]
  for ir in idxreal:
   ids=pair+[ir];other=[j for j in range(6) if j not in ids]
   f=lambda x,ls:sum(r[i]/(x-p[i]) for i in ls)
   lo=-np.min(f(w,ids).real)+1e-6;hi=3+np.min(f(w,other).real)-1e-6
   print('group',ids,'constant range',lo,hi,flush=True)
   if lo>=hi:continue
   for k,(L,C) in enumerate(cs):
    ff=make(n,L,C,f(ss,ids),lo,hi)
    for st in range(2):
     x=np.r_[rng.normal(-.5,1.,n*(n-1)//2+3),.5]
     sol=least_squares(lambda x:ff(x)[0],x,jac=lambda x:ff(x)[1],bounds=(np.r_[np.full(len(x)-1,-18),0.],np.r_[np.full(len(x)-1,15),1.]),max_nfev=400,ftol=1e-12,xtol=1e-12,gtol=1e-12)
     err=max(abs(ff(sol.x)[0]));rec={'n':n,'L':L,'C':C,'params':np.exp(sol.x[:-1]).tolist(),'r_const':float(lo+(hi-lo)*sol.x[-1]),'pole_ids':[int(v) for v in ids],'error':float(err),'poles':[[z.real,z.imag] for z in p],'residues':[[z.real,z.imag] for z in r]}
     if err<best:
      best=err;print('BEST',best,'r',rec['r_const'],'L',L,'C',C,'secs',time.time()-t,flush=True)
      json.dump(rec,open(BASE/'results/bestcubic.json','w'),indent=2)
     results.append(rec)
     if err<1e-10:
      json.dump(rec,open(BASE/'results/cubic_candidate.json','w'),indent=2);return
 json.dump(sorted(results,key=lambda z:z['error']),open(BASE/'results/cubic_results.json','w'),indent=2)
 print('FINISH',len(results),'best',best,flush=True)
if __name__=='__main__':
 import sys
 run(int(sys.argv[1]) if len(sys.argv)>1 else 4)
