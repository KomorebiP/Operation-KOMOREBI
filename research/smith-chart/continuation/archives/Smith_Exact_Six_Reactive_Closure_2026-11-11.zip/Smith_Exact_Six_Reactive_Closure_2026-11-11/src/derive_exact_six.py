"""Author: Komorebi P. Exact matrix-tree derivation for the six-reactive circuit.
Enumerates spanning trees and port-separating two-component spanning forests.
All polynomial coefficient data are integers. No numerical acceptance here.
"""
import json,itertools,os
from pathlib import Path
BASE=str(Path(__file__).resolve().parents[1])
seed=json.load(open(BASE+'/results/sparse_candidate.json'))
R=seed['resistor_edges'];L=seed['L'];C=seed['C'];edges=R+L+C;n=seed['n']
exps=[0]*len(R)+[-1]*len(L)+[1]*len(C)
P=[75,335,1142,2200,2477,1385,450]
Q=[25,445,1250,1720,1375,795,150]

def comps(ids):
    par=list(range(n))
    def find(i):
        while par[i]!=i:i=par[i]
        return i
    for j in ids:
        a,b=edges[j];a,b=find(a),find(b)
        if a==b:return None
        par[a]=b
    return [find(i) for i in range(n)]

trees=[];forests=[]
for ids in itertools.combinations(range(len(edges)),n-1):
    cc=comps(ids)
    if cc is not None:
        assert len(set(cc))==1
        trees.append((ids,3+sum(exps[i] for i in ids)))
for ids in itertools.combinations(range(len(edges)),n-2):
    cc=comps(ids)
    if cc is not None and cc[0]!=cc[1]:
        assert len(set(cc))==2
        forests.append((ids,3+sum(exps[i] for i in ids)))
assert all(0<=k<=6 for ids,k in trees+forests)
# F(s)=N(s)Q(s)-D(s)P(s), coefficient vector 0..12.
terms=[]
for ids,k in forests:
    co=[0]*13
    for j,q in enumerate(Q):co[j+k]+=q
    terms.append({'vars':ids,'coefficients':co,'origin':'N','s_power':k})
for ids,k in trees:
    co=[0]*13
    for j,p in enumerate(P):co[j+k]-=p
    terms.append({'vars':ids,'coefficients':co,'origin':'D','s_power':k})
obj={'author':'Komorebi P.','n_nodes':n,'port':[1,0], 'R_edges':R,'L_edges':L,'C_edges':C,'variable_convention':'R conductances, then reciprocal inductances, then capacitances', 'target_P_ascending':P,'target_Q_ascending':Q,'terms':terms,'n_trees':len(trees),'n_forests':len(forests)}
json.dump(obj,open(BASE+'/results/exact_polynomial_system.json','w'),indent=2)
print('trees',len(trees),'forests',len(forests),'terms',len(terms))
print('N coefficient monomial counts',[sum(k==a for ids,k in forests) for a in range(7)])
print('D coefficient monomial counts',[sum(k==a for ids,k in trees) for a in range(7)])
