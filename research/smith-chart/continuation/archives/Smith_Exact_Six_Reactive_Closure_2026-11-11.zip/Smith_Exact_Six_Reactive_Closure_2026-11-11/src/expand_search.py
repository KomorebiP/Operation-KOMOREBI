"""Author: Komorebi P. Expand endpoint graphs without adding storage.
Every search record is numerical only and requires exact certification.
"""
from pathlib import Path
BASE=Path(__file__).resolve().parents[1]
import numpy as np,json,itertools,time,sys,os
from scipy.optimize import least_squares
from coupled_search import model

def splits(seed):
    n=seed['n'];es=seed['L']+seed['C'];out=[]
    for v in range(n):
        inc=[k for k,e in enumerate(es) if v in e]
        for sz in range(1,len(inc)+1):
            for move in itertools.combinations(inc,sz):
                if sz==len(inc) and v>=2:continue
                ee=[tuple(sorted(n if k in move and a==v else a for a in e)) for k,e in enumerate(es)]
                out.append((v,ee[:3],ee[3:]))
    return out

def run(n,ns=20,maxeval=800):
    prior=json.load(open(BASE/f'results/search{n-1}.json'))
    rng=np.random.default_rng(781+n);todo=[];unique=set()
    for seed in prior[:ns]:
        for v,L,C in splits(seed):
            ky=(tuple(L),tuple(C))
            if ky in unique:continue
            unique.add(ky);todo.append((seed,v,L,C))
    rng.shuffle(todo); best=1.;records=[];t=time.time()
    prs=list(itertools.combinations(range(n),2));oldprs=list(itertools.combinations(range(n-1),2));nro=len(oldprs)
    for k,(seed,v,L,C) in enumerate(todo):
        old=np.array(seed['params']);rs=[]
        for e in prs:
            if n-1 not in e:rs.append(old[oldprs.index(e)])
            elif v in e:rs.append(3.)
            else:rs.append(.001)
        f=model(n,L,C)
        x=np.log(np.r_[rs,old[nro:]])
        opt=least_squares(lambda x:f(x)[0],x,jac=lambda x:f(x)[1],bounds=(-24,18),max_nfev=maxeval,xtol=2e-14,ftol=2e-14,gtol=1e-14)
        err=float(np.max(np.abs(f(opt.x)[0])))
        rec={'n':n,'L':L,'C':C,'resistor_edges':prs,'params':np.exp(opt.x).tolist(),'error':err,'nfev':opt.nfev,'seed_index':k}
        records.append(rec)
        if err<best:
            best=err;print('BEST',k,'err',best,'L',L,'C',C,'eval',opt.nfev,'time',time.time()-t,flush=True)
            json.dump(rec,open(BASE/f'results/best{n}.json','w'),indent=2)
        if k%25==0:
            print('progress',k,len(todo),flush=True)
            json.dump(sorted(records,key=lambda z:z['error'])[:50],open(BASE/f'results/search{n}.json','w'),indent=2)
        if best<1e-11:break
    json.dump(sorted(records,key=lambda z:z['error']),open(BASE/f'results/search{n}.json','w'),indent=2)
    print('FINISHED',len(records),'best',best,flush=True)
if __name__=='__main__':run(int(sys.argv[1]),int(sys.argv[2]) if len(sys.argv)>2 else 20)
