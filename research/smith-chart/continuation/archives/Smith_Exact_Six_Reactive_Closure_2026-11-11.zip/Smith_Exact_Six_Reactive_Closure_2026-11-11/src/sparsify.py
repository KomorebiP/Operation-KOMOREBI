"""Author: Komorebi P. Sparse candidate search. Numerical output only."""
from pathlib import Path
BASE=Path(__file__).resolve().parents[1]
import sys,json,numpy as np,itertools
from scipy.optimize import least_squares
from coupled_search import model
seed=json.load(open(BASE/'results/best8.json'))
prs=[tuple(e) for e in seed['resistor_edges']];pp=np.array(seed['params']);L=seed['L'];C=seed['C']
order=np.argsort(-pp[:28]); records=[]
for nr in range(7,15):
 ix=sorted(order[:nr]);rf=[prs[i] for i in ix];x=np.log(np.r_[pp[ix],pp[-6:]])
 f=model(8,L,C,rf)
 sol=least_squares(lambda x:f(x)[0],x,jac=lambda x:f(x)[1],bounds=(-25,20),max_nfev=3000,ftol=1e-14,xtol=1e-14,gtol=1e-14)
 err=float(np.max(abs(f(sol.x)[0])));rec={'n':8,'L':L,'C':C,'resistor_edges':rf,'params':np.exp(sol.x).tolist(),'error':err,'nfev':sol.nfev}
 print('nr',nr,'err',err,'eval',sol.nfev,'params',np.exp(sol.x),flush=True)
 records.append(rec)
 if err<1e-11:
  json.dump(rec,open(BASE/'results/sparse_candidate.json','w'),indent=2);break
json.dump(records,open(BASE/'results/sparsify.json','w'),indent=2)
