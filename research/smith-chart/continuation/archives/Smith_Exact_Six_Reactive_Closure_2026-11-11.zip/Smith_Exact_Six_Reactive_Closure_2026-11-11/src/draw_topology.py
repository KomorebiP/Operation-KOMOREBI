"""Author: Komorebi P. Python-generated schematic, no generative imagery.
Only the labeled topology is illustrated; exact values are in the certificate.
"""
from pathlib import Path
import math
BASE=Path(__file__).resolve().parents[1]
# A straight-line planar embedding of the certified graph, scaled to a page.
pos={0:(520,365),3:(100,575),4:(520,155),1:(800,505),5:(660,295),6:(520,435),2:(940,575),7:(380,295)}
R=[(0,3),(0,4),(1,5),(1,6),(2,5),(3,6),(4,7)]
L=[(0,5),(2,3),(3,7)]
C=[(0,6),(1,2),(4,5)]
a=['<svg xmlns="http://www.w3.org/2000/svg" width="1100" height="760" viewBox="0 0 1100 760">',
'<style>text{font-family:Arial,sans-serif;fill:#111} .w{stroke:#222;stroke-width:2;fill:none} .node{fill:#fff;stroke:#222;stroke-width:2} .label{font-size:15px;text-anchor:middle;stroke:none} </style>',
'<rect width="1100" height="760" fill="white"/>',
'<text x="65" y="60" font-size="28" font-weight="bold">Exact minimum-six-reactive realization</text>',
'<text x="65" y="91" font-size="17">3 inductors + 3 capacitors + 7 resistors. Port: node 1 to ground node 0.</text>']
def point(p,q,t,n=0):
 dx=q[0]-p[0];dy=q[1]-p[1];d=math.hypot(dx,dy)
 return p[0]+t*dx-n*dy/d,p[1]+t*dy+n*dx/d

def path(pts):a.append('<path class="w" d="'+' '.join(('M' if i==0 else 'L')+f'{x:.3f},{y:.3f}' for i,(x,y) in enumerate(pts))+'"/>')
for typ,edges in [('R',R),('L',L),('C',C)]:
 for u,v in edges:
  p,q=pos[u],pos[v];dist=math.dist(p,q);half=min(20,dist*.19);t0=.5-half/dist;t1=.5+half/dist
  path([point(p,q,0),point(p,q,t0)])
  path([point(p,q,t1),point(p,q,1)])
  if typ=='R':
   ts=[t0+(t1-t0)*i/8 for i in range(9)]
   pts=[point(p,q,t,0 if i in(0,8) else (-1 if i%2 else 1)*6) for i,t in enumerate(ts)]
   path(pts)
  elif typ=='L':
   pts=[]
   for k in range(81):
    f=k/80;pts.append(point(p,q,t0+(t1-t0)*f,7*math.sin(6*math.pi*f)))
   path(pts)
  else:
   tminus=.5-4/dist;tplus=.5+4/dist
   path([point(p,q,t0),point(p,q,tminus)])
   path([point(p,q,tminus,-10),point(p,q,tminus,10)])
   path([point(p,q,tplus,-10),point(p,q,tplus,10)])
   path([point(p,q,tplus),point(p,q,t1)])
  xx,yy=point(p,q,.5,28)
  # Dedicated placement for short central capacitor.
  if (u,v)==(0,6):xx,yy=562,405
  a.append(f'<rect x="{xx-22:.3f}" y="{yy-13:.3f}" width="44" height="18" fill="white"/><text class="label" x="{xx:.3f}" y="{yy:.3f}">{typ}{u}{v}</text>')
for k,(x,y) in pos.items():
 a.append(f'<circle class="node" cx="{x}" cy="{y}" r="12"/>')
 a.append(f'<text x="{x}" y="{y+5}" font-size="14" font-weight="bold" text-anchor="middle">{k}</text>')
a += ['<text x="65" y="670" font-size="16">Rij, Lij, Cij connect the indicated node pair. Lines crossing a label are not extra connections.</text>',
'<text x="65" y="698" font-size="15">Exact algebraic values and proof: Smith_Six_Reactive_Closure.md and six_reactive_certificate.json.</text>',
'<text x="65" y="725" font-size="14">Author: Komorebi P. | 11 November 2026 | Python-generated schematic</text>','</svg>']
(BASE/'figures/topology.svg').write_text('\n'.join(a))
try:
 import cairosvg
 cairosvg.svg2png(url=str(BASE/'figures/topology.svg'),write_to=str(BASE/'figures/topology.png'),output_width=1650,output_height=1140)
except ImportError:pass
print(BASE/'figures/topology.svg')
