# Exact six-reactive Smith chart synthesis

**Author: Komorebi P.**  
**Date: 11 November 2026**

The six-versus-seven question for the recorded degree-six target is closed:

**q_min = 6.**

The exact transformer-free witness uses **3 inductors, 3 capacitors, and 7 positive resistors**, on 8 nodes including port and ground. The proof certifies an isolated algebraic solution, not a frequency fit. This is an instance-specific ideal-circuit theorem, not a claim of historical priority or hardware validation.

## Read first

`Smith_Six_Reactive_Closure.md` gives the target, complete circuit, lower bound, integer polynomial equations, rational contraction proof, and scope.

## Verify without installing dependencies

```bash
python src/verify_exact_six.py
python src/audit_certificate.py
```

Python 3.9 or later is sufficient for the acceptance verifier. Do not use `python -O`. All acceptance comparisons use integers and `fractions.Fraction`. Verification regenerates the polynomial system from hard-coded circuit edges rather than trusting a cached symbolic expression.

`results/six_reactive_certificate.json` is the exact certificate. The small decimal component table and SPICE files are approximations and are not the proof.

## Contents

- `Smith_Six_Reactive_Closure.md`: mathematical theorem and proof.
- `results/six_reactive_certificate.json`: exact rational center, inverse-Jacobian approximation, and radius.
- `src/verify_exact_six.py`: independent standard-library acceptance verifier.
- `src/audit_certificate.py`: exact derivative audit and rejection controls.
- `results/verification_report.json`, `results/audit_report.json`: passing results from this release.
- `results/exact_polynomial_system.json`: expanded integer equations for inspection.
- `src/derive_exact_six.py`, `src/refine_exact_six.py`: optional derivation and high-precision root proposal.
- `component_values.json`: normalized and illustrative physical values, labeled approximate.
- `six_reactive_normalized.cir`, `six_reactive_50ohm_1ns.cir`: decimal ideal-circuit netlists. External SPICE was not run.
- `ENGINEERING_NOTES.md` and `HANDOFF.md`: discovery provenance, limitations, and continuity.
- `history/`: prior five-node numerical seed and superseded status note.
- Other `src/` and `results/` files: numerical search provenance, not additional proofs.

The optional discovery scripts use NumPy and SciPy. High-precision refinement uses mpmath. These dependencies are unnecessary for the exact acceptance and audit commands.

Keep the certified files unchanged when experimenting. Numerical search scripts overwrite their corresponding exploratory result files. Do not overwrite the accepted certificate with a newly fitted circuit unless a fresh exact verification passes.
