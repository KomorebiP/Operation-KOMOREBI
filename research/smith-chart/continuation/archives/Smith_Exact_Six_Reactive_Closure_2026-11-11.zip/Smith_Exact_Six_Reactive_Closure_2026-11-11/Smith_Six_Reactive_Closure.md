# Closing the six-versus-seven reactive-element gap

**Author: Komorebi P.**  
**Date: 11 November 2026**  
**Status: Exact constructive result, with a reproduced rational-arithmetic existence certificate.**

## Result

For the specific impedance studied in the Smith chart continuation,

\[
Z_6(s)=\frac{450s^6+1385s^5+2477s^4+2200s^3+1142s^2+335s+75}
{150s^6+795s^5+1375s^4+1720s^3+1250s^2+445s+25},
\]

the minimum number of physical inductors and capacitors in a finite, ordinary, passive, transformer-free RLC one-port is exactly

\[
\boxed{q_{\min}=6.}
\]

A witness has **three inductors, three capacitors, and seven positive resistors**, connected on eight nodes including the input and ground. It has thirteen ideal components in total. It contains no ideal transformers, mutual inductances, controlled sources, negative elements, or extra storage elements.

The result closes the previously recorded bound \(6\le q_{\min}\le7\) for this particular target. It does not claim that every degree-six positive-real impedance has a six-reactive transformer-free realization. It does not prove that seven resistors, thirteen total components, or eight nodes are minimal. Historical priority has not been established.

The proof is not the very small residual produced by a numerical optimizer. It is a finite rational certificate proving that a system of thirteen integer polynomial equations has an exact positive solution in a specified rational cube. The resulting circuit impedance is identically \(Z_6(s)\).

## 1. Exact statement and conventions

All values are normalized. The port is between node 1 and ground node 0. Nodes 2 through 7 are internal circuit nodes. Conductances, reciprocal inductances, and capacitances are ordered as

\[
x=(g_{03},g_{04},g_{15},g_{16},g_{25},g_{36},g_{47},
h_{05},h_{23},h_{37},c_{06},c_{12},c_{45}),
\]

where a resistor has resistance \(1/g_{ij}\), an inductor has inductance \(1/h_{ij}\), and a capacitor has capacitance \(c_{ij}\). Their branch admittances are respectively \(g_{ij}\), \(h_{ij}/s\), and \(c_{ij}s\).

**Theorem.** There is a unique zero of the polynomial system defined in Section 4 in the rational cube specified in `results/six_reactive_certificate.json`. Every coordinate of that zero is positive. The circuit using these exact values and the topology below has input impedance \(Z_6\). Its six-reactive count is globally minimal among the stated class of RLC one-ports.

The uniqueness is only uniqueness in this certificate cube. No uniqueness of all possible circuits, or of all solutions for this topology, is asserted.

## 2. Explicit circuit

![Python-generated schematic of the certified circuit](figures/topology.png)

The complete topology and approximate physical element values are:

| Component | Nodes | Approximate normalized value |
|---|---|---:|
| Resistor | 0–3 | 5.34170416147148211 |
| Resistor | 0–4 | 36.9923701840224470 |
| Resistor | 1–5 | 7.08085498198704371 |
| Resistor | 1–6 | 3.26293029206220981 |
| Resistor | 2–5 | 0.245458423788188289 |
| Resistor | 3–6 | 1.70929328451621297 |
| Resistor | 4–7 | 0.0296835849176941186 |
| Inductor | 0–5 | 1.65459624861652794 |
| Inductor | 2–3 | 5.39126706749734056 |
| Inductor | 3–7 | 2.63805520738157842 |
| Capacitor | 0–6 | 0.227524398708765654 |
| Capacitor | 1–2 | 5.22269311623683997 |
| Capacitor | 4–5 | 0.262341654667861857 |

These decimal values are a readable approximation, **not** the exact definition of the circuit. The exact values are the isolated real algebraic solution described below. Substituting rounded values into a simulator produces an approximate, not symbolically identical, response.

The seven resistor edges form a connected spanning tree. Consequently, for any positive values in the certificate cube, the resistive part of the grounded nodal matrix is positive definite. This also provides a direct well-posedness and strict-dissipation check for the ideal circuit.

A node is a connection point, not an energy-storage element. Expanding from the earlier five-node search to eight nodes does not relax the six-reactive budget. Node 7, for example, is the intermediate connection of the resistor on 4–7 and the inductor on 3–7.

## 3. The universal lower bound is six

Write \(Z_6=P/Q\) with the numerator and denominator displayed above. Exact rational Euclidean arithmetic gives

\[
\gcd(P,Q)=1.
\]

As an additional integer check,

\[
\operatorname{Res}_s(P,Q)=48289705700056104960000000000\ne0.
\]

Both polynomials have degree six. Thus the reduced driving-point transfer function has McMillan degree six.

An ordinary ideal RLC network with \(q\) physical inductors and capacitors has at most \(q\) independent energy-storage state variables: one current per inductor and one voltage per capacitor. Kirchhoff constraints can reduce the independent dynamic order, but cannot increase it. After eliminating algebraic constraints, the rational input-output transfer function therefore has degree at most \(q\). It follows that every realization in the stipulated class requires

\[
q\ge6.
\]

The witness below uses exactly six. The lower and upper bounds therefore coincide. No exclusion of all five-node, six-node, or seven-node topologies is needed to prove this minimum once the witness is certified.

## 4. Integer polynomial equations derived from the circuit

For each edge \(e\), let \(b_e\in\mathbb R^7\) be its grounded incidence vector, with the coordinate of node 0 removed. Its orientation is arbitrary because only \(b_eb_e^\mathsf T\) appears. Define

\[
Y(s,x)=\sum_{e\in R}g_e b_eb_e^\mathsf T
+\frac1s\sum_{e\in L}h_e b_eb_e^\mathsf T
+s\sum_{e\in C}c_e b_eb_e^\mathsf T.
\]

A unit current at node 1 gives \(Z(s,x)=(Y^{-1})_{11}\). Cramer's rule yields

\[
N(s,x)=s^3\det Y_{\widehat1\widehat1}(s,x),
\qquad D(s,x)=s^3\det Y(s,x),
\qquad Z(s,x)=\frac{N(s,x)}{D(s,x)}.
\]

The factor \(s^3\) clears the denominators contributed by the three inductors.

The matrix-tree theorem gives an especially transparent exact expansion. A spanning tree contributes the product of its seven branch admittances to the grounded determinant. A spanning forest with two components, one containing node 0 and the other containing node 1, contributes the product of its six branch admittances to the port cofactor. Enumerating the specified thirteen-edge graph gives:

- 581 spanning-tree monomials in \(D\).
- 389 port-separating spanning-forest monomials in \(N\).

Each monomial uses each component parameter at most once. Multiplication by \(s^3\) gives powers of \(s\) between zero and six. Thus both \(N\) and \(D\) have degree at most six. The counts of monomials in successive coefficients \(s^0,\ldots,s^6\) are

\[
N:(12,51,95,111,81,33,6),
\]
\[
D:(17,68,139,164,126,57,10).
\]

All coefficients in these two expansions are sums of positive products when \(x>0\), so both leading coefficients are nonzero and both degrees are exactly six.

Define the thirteen coefficient equations by

\[
N(s,x)Q(s)-D(s,x)P(s)=\sum_{k=0}^{12}F_k(x)s^k.
\]

Each \(F_k\) is an explicitly defined integer polynomial, consisting of degree-six and degree-seven square-free monomials. The finite system is

\[
F(x)=(F_0(x),\ldots,F_{12}(x))^\mathsf T=0.
\]

`src/verify_exact_six.py` regenerates these equations directly from the edge lists. It does not trust the saved expanded polynomial file. `results/exact_polynomial_system.json` is a human-inspectable expanded record of the same system.

## 5. Exact rational existence certificate

The certificate contains an exact rational center \(x_0\), an exact rational \(13\times13\) preconditioning matrix \(M\), and the radius

\[
r=10^{-50}.
\]

The center and matrix entries are terminating-decimal rational approximations obtained during discovery. The acceptance proof treats them as exact fractions, not floating-point values. Set

\[
K=\{x\in\mathbb R^{13}:\|x-x_0\|_\infty\le r\}.
\]

The rational verifier proves all of the following strict inequalities:

\[
\|F(x_0)\|_\infty<10^{-80},
\qquad
\eta:=\|MF(x_0)\|_\infty<10^{-80},
\]

\[
\delta:=\|I-MDF(x_0)\|_\infty<10^{-80},
\qquad \|M\|_\infty<61,
\]

\[
\min_j(x_{0,j}-r)>\frac{27}{1000},
\qquad \max_j(|x_{0,j}|+r)<34.
\]

The displayed lower bound concerns the parameter coordinates \(g,h,c\). Positivity of the actual resistances and inductances follows by taking reciprocals of their positive conductances and reciprocal inductances.

For completeness, the derivative-variation bound uses only polynomial coefficients. A square-free monomial of degree \(d\) has total absolute second-derivative sum at most

\[
d(d-1)34^{d-2}
\]

on \(K\). Multiplying by the absolute integer coefficients and summing gives the exact integer bound

\[
H=1877355152181696
\]

for the maximum, over equation rows, of the sum of all absolute Hessian entries. Hence

\[
\|DF(x)-DF(x_0)\|_\infty\le Hr
\quad(x\in K).
\]

The verifier then establishes

\[
q:=\delta+\|M\|_\infty Hr<10^{-30}<1,
\]

and, as a separate exact comparison,

\[
\eta+qr<r.
\]

Consider

\[
T(x)=x-MF(x).
\]

The derivative estimate proves that \(T\) is a contraction on \(K\), with Lipschitz constant at most \(q\). The displacement inequality proves that \(T(K)\subseteq K\). The Banach fixed-point theorem therefore supplies a unique fixed point \(x_*\in K\).

Since \(\|I-MDF(x_0)\|_\infty<1\), the square matrix \(MDF(x_0)\) is invertible. Consequently \(M\) is invertible. Thus \(T(x_*)=x_*\) implies \(F(x_*)=0\), not merely \(MF(x_*)=0\) for a singular preconditioner. Every coordinate of \(x_*\) is strictly positive. The Jacobian remains nonsingular on the cube, so this is an isolated algebraic solution of the integer polynomial system.

This is the existence proof. The small high-precision residual used to locate the cube is not, by itself, the proof.

## 6. From the root to an exact physical realization

At the certified root,

\[
N(s,x_*)Q(s)\equiv D(s,x_*)P(s).
\]

The denominator \(D\) is not identically zero. For positive real \(s\), the connected positive resistor graph alone makes the grounded matrix positive definite, and adding the positive reactive admittances preserves that property. Hence the driving-point function is well defined there and equals \(P/Q\). Equality of rational functions extends the identity everywhere both expressions are defined, with the usual limiting interpretation at removable singularities.

Because \(P\) and \(Q\) are coprime, \(Q\) divides \(D\). Both have degree six. Therefore

\[
D(s,x_*)=\kappa Q(s),\qquad N(s,x_*)=\kappa P(s)
\]

for a nonzero constant \(\kappa\), in fact positive by the coefficient signs. There is **no hidden-mode cancellation** in this six-reactive realization.

The circuit is an ordinary connected network of positive R, L, and C elements. Its passivity is a property of the circuit itself, not an inference from sampled measurements. On the open right half-plane the real part of every branch admittance is nonnegative, and the resistor subgraph gives strict dissipation. Thus the network has the required passive driving-point impedance.

Combining this witness with Section 3 proves \(q_{\min}=6\).

## 7. What changed relative to the earlier work

The earlier exact seven-reactive construction used two circuit sections in series. One section carried an internal mode absent from the observed impedance. Algebraically deleting that mode did not supply a six-element positive transformer-free circuit.

The new witness is a different, globally coupled topology. The discovery sequence allowed additional connection nodes while preserving exactly three inductors and three capacitors. An eight-node candidate matched the target numerically. Removing small resistor conductances and resolving the equations then produced the seven-resistor topology above. Its integer cofactor equations were subsequently certified independently of the numerical search.

The older seven-reactive construction remains a valid upper-bound witness. Its status changes from the best certified construction in the project to a nonminimal reactive realization of this target.

The dirty-XOR circuit work supplied a useful warning against restrictive intermediate decompositions. It was not used as an electrical theorem, and no formal conversion from a six-gate XOR shortcut to this RLC circuit is claimed. The successful RLC argument is the explicit coupled circuit plus the exact certificate.

## 8. Reproduction and audit

From the extracted package directory, run:

```bash
python src/verify_exact_six.py
python src/audit_certificate.py
```

These two commands use only Python's standard library. Do not use Python's `-O` option, which disables assertions. The scripts explicitly reject optimized mode.

The verifier regenerates the 970 monomials from the circuit graph, checks the coprime degree-six target, evaluates the polynomial residual and Jacobian with exact fractions, and checks the fixed-point inequalities. It also compares the tree formulas with independently assembled nodal determinants at seven positive rational frequency fixtures.

The separate audit checks all 169 Jacobian entries using exact centered differences. Those differences are exact because every equation is affine in each individual parameter. It also confirms that three deliberately incorrect certificates are rejected: a perturbed center, a negative component parameter, and an altered target numerator.

To repeat the optional high-precision discovery stage after installing `mpmath`, run:

```bash
python src/derive_exact_six.py
python src/refine_exact_six.py
```

The saved certificate is sufficient for verification. Recreating a numerical search is not required to establish the theorem. Search scripts and historical results are retained for provenance and further synthesis work. Their output is explicitly numerical until accompanied by a new certificate.

This is a computer-assisted mathematical proof using an explicit analytic fixed-point argument and exact rational computations. It is not a Lean formalization, a hardware experiment, or an external SPICE validation.

## 9. Physical scaling and scope

For reference impedance \(Z_0>0\) and time scale \(\tau>0\), set

\[
Z_{\rm phys}(s_{\rm phys})=Z_0Z_6(\tau s_{\rm phys}).
\]

The corresponding physical values are

\[
R_{\rm phys}=Z_0R,\qquad L_{\rm phys}=Z_0\tau L,
\qquad C_{\rm phys}=\frac{\tau}{Z_0}C.
\]

The package includes an illustrative decimal netlist with \(Z_0=50\,\Omega\) and \(\tau=1\,\mathrm{ns}\), along with the normalized netlist. Both use rounded values and are labeled accordingly. No external SPICE simulator was run. Real component tolerances, parasitics, self-resonance, and layout have not been assessed.

The result is an exact minimum-reactive synthesis theorem for one specified rational impedance. The complete topology and a short independently replayable certificate are now available. Claims about historical novelty, resistor minimization, minimal node count, total-component optimality, or measured RF performance remain separate questions.
