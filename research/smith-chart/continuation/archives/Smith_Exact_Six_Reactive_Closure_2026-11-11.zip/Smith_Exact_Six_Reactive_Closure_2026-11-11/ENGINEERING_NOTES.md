# Engineering and proof notes

Author: Komorebi P.  
Date: 11 November 2026

## Goal and source recovery

The prior attached ZIP and research note were recovered in the active runtime. They contained the five-node 3L+3C fitting code and results, not an exact six-reactive solution. The prior note explicitly left the minimum in {6,7}. The present proof independently defines and verifies the same target.

## Discovery sequence

1. Extended the best recorded five-node candidates by splitting reactive endpoints, adding resistor interconnections, and keeping exactly 3L+3C. Completed 106 six-node numerical fits. These did not close the problem.
2. A first seven-node run was interrupted by an execution limit after partial progress. That incomplete log is retained as `search7.log` and is not counted as a completed search. A fresh run completed 341 seven-node fits (`search7_full.log`). None was exact.
3. Tried a 14-node disjoint-endpoint parameterization with eight initializations. It did not find an exact solution. This is not an impossibility proof for that model.
4. Tried four-node one-inductor/two-capacitor cubic sections over admissible numerical feedthrough intervals. A JSON serialization error for NumPy integer indices interrupted the initial run. It was fixed, and the restarted run completed 88 numerical fits without an exact section. That route did not close the problem.
5. An eight-node expansion found a candidate at the 39th evaluated topology, with a sampled residual around 7e-14. This was only a proposal, not a theorem.
6. Pruned the candidate's resistor graph to the seven largest conductances, retained all six reactive elements, and refitted. The thirteen-parameter sparse circuit matched to about 3e-14 in floating-point sampling.
7. Independently enumerated 581 spanning trees and 389 port-separating forests of the sparse graph. Derived all thirteen coefficients of NQ-DP as integer polynomials.
8. Refined their common root at 130-digit precision using the polynomial equations, rather than the frequency-sampling objective. The root and inverse Jacobian were converted to exact rational data.
9. Ran the exact Fraction-only contraction verifier, then replayed it from the saved certificate. Both passed.
10. Independently checked every Jacobian entry by exact affine centered differences and required rejection of a shifted center, a negative parameter, and a changed target. All passed.

## Acceptance proof, not discovery evidence

The proof does not use the completeness of any topology search, a numerical fit threshold, a floating-point passivity test, or the 14-node experiment. Only the explicit sparse graph, regenerated integer equations, exact rational inequalities, standard fixed-point theorem, and coprime degree-six lower bound are needed.

The helper numerical model uses 13 complex interpolation arguments. The polynomial cross-product has degree at most 12, but its numerical residuals still do not establish exact zeros. The final proof bypasses this issue by certifying all thirteen real coefficient equations directly.

## Why this closes the full minimum question

There is a global degree lower bound of six. One exact six-element witness is enough for equality, regardless of the number of failed earlier searches or whether all smaller-node topologies have been classified. The proof does not need a universal seven-element obstruction.

## Computation integrity

The acceptance checker regenerates the graph polynomials and checks the target coefficients and edge metadata. It uses Python integers and fractions for every acceptance comparison. Float values occur only in elapsed-time reporting. Python optimized mode is explicitly disallowed because assertions must execute.

The Hessian bound is deliberately coarse. It uses a common absolute coordinate bound of 34 and square-free monomial degrees six or seven. This produces a safe integer bound of 1877355152181696. The radius 1e-50 makes this ample for the contraction check. Sharper interval arithmetic is unnecessary for this witness.

## Limits

No historical novelty claim. No claim of minimum resistance count, minimum node count, or minimum total components. No measured device, parasitics model, tolerance certification, external SPICE execution, or Lean verification. No repository publication or Library mutation was performed.
