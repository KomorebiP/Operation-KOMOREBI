# Sources and exact proof dependencies

Author: Komorebi P.

## External mathematics

1. Timothy H. Hughes, *Why RLC realizations of certain impedances need many more energy storage elements than expected*, IEEE Transactions on Automatic Control 62(9), 4333--4346 (2017). Accepted manuscript arXiv:1611.06258v2.
   - https://arxiv.org/pdf/1611.06258v2
   - Required statements: Lemma 3 and Theorems 4--6, manuscript printed pages 4--5.
   - Scope checked: ordinary RLC networks; Theorems 4--5 do not restrict the resistor count. We use K=omega_0=F=1, W=2/3. The exceptions fail by exact rational arithmetic.
   - The upper witness is separately checked using the inherited seven-edge circuit, rather than inferred from an uninspected diagram.

2. Gabriela Jeronimo, Daniel Perrucci and Elias Tsigaridas, *On the Minimum of a Polynomial Function on a Basic Closed Semialgebraic Set and Applications*, SIAM Journal on Optimization 23(1), 241--255 (2013), DOI 10.1137/110857751.
   - Publisher: https://doi.org/10.1137/110857751
   - Author-hosted manuscript: https://mate.dm.uba.ar/~perrucci/On_the_minimum_pol_funct.pdf
   - Author bibliography: https://who.paris.inria.fr/Elias.Tsigaridas/b2hd-jpt-siopt-13.html
   - arXiv manuscript: https://arxiv.org/pdf/1112.0544
   - Required statement: Theorem 1, printed page 2 of the manuscripts. The minimum on a compact connected component, when nonzero, is at least (2^(4-n/2)*Htilde*d^n)^(-n*2^n*d^n), where Htilde=max(H,2n+2m), d is even, and all defining and objective polynomials have integer coefficients and the stated degree/height bounds.
   - The formula was inspected in rendered PDF images, not trusted from garbled parsed exponents.

These published theorems are mathematical dependencies. The Python code does not re-prove them. The new material is the exact bounded network encoding, its uniform arithmetic specialization, and the quantitative propagation using the retained project proof.

## Retained project sources

- `history/Komorebi_Smith_RLC_Obstruction_Propagation_2026-11-12.zip`: compact physical boundary semantics, bounded vertex count, degree bound and qualitative propagation.
- `history/Komorebi_Smith_Quantitative_Transfer_2026-11-12.zip`: sharp compact-admittance response bound, finite-scale allocation, three-packet localization and multiband constants.

The original archives are unchanged. Their tests were rerun from separate extracted directories. The new paper restates all physical reduction steps required to apply the external bound.

## Retrieval limitations

The Hughes PDF page containing Theorems 4--5 rendered successfully. A request to render the next page failed twice with fetch/cache errors. The parsed theorem text and the separately replayed positive circuit supply the remaining necessary source information. No unread circuit figure is used as acceptance evidence.

An additional simplex-minimum paper was inspected as a possible alternative approach but is not a dependency of the final proof or code.
