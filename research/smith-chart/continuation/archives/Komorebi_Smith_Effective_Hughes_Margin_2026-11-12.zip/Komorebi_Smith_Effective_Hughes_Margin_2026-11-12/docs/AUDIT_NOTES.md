# Audit, limitations and claim boundaries

Author: Komorebi P.  
Research date: 12 November 2026.

## What changed

The previous note had an uncomputed numerical premise Delta_H. The present note replaces it by an explicit theorem-derived rational lower bound, 2^(-2^803). This is smaller than any useful numerical tolerance. It is nevertheless not a guessed or hypothetical margin.

The route is not an exhaustive simulation. For every master skeleton the real sample-error minimum is a nonzero polynomial minimum on compact semialgebraic components. A published effective lower bound is uniform in the graph shape. Exact current elimination cuts the variable count from 456 to 393 and improves the simple power-of-two exponent from 2^929 to 2^803.

The model allows approximate competitors of reduced degree three or four, arbitrary real positive component values, unlimited original resistor count, and all compact open/short boundaries. It does not restrict approximate competitors to the Hughes minimum-function exceptional families.

## Application obligations checked in the written derivation

- The resistor-only elimination retains all reactive endpoints and does not increase reactive count.
- Open/short boundary solutions reduce to physical networks rather than introducing ideal transformers.
- The sample port normalization bounds all relevant finite-network voltages and currents.
- Spanning-star current elimination is exact even when the corresponding resistor parameter is zero.
- Seven positive samples force identity between the degree-two target and any at-most-four-reactive response when the error is zero.
- Hughes's exact all-topology exclusion rules out that zero-error case.
- The feasibility set is compact, each connected component is compact, and the objective is an integer polynomial with nonzero minimum on each nonempty component.
- The JPT minimum bound has the correct factor Htilde*d^n. A misordered plain-text rendering was not used.
- Polynomial counts, degree bounds, coefficient height and exponent estimates are uniform across all labeled skeletons.
- The proof does not assert that the number of compact components is one, nor does it require regularity or an isolated root.

These items were self-reviewed. They have not been independently audited by another mathematician or a proof assistant.

## Executed evidence

The current suite has 978 recorded check groups. These are groups, not 978 universal theorems.

- All 90 placement/type choices for one of four reactive slots were built. The other slots were fixed. Each model has 393 variables, 343 equations, 926 inequalities, total degree at most two, and height 304.
- Thirty selected compact assignments at budgets zero through four were checked against a separate exact grounded-nodal implementation at seven samples each. These include open and short components.
- The five-reactive Hughes circuit admits error zero in the q=5 formulation. This is an explicit control against extending the positivity premise to an invalid budget.
- The known five-reactive circuit was checked at ten exact positive arguments, exceeding the eight required by the degree identity bound.
- Binary-rational arithmetic was compared to ordinary Fraction arithmetic on 500 small cases. Actual exponents of size 2^803 were handled exactly without expansion.
- Explicit transfer and strict-resistor inequalities were checked at seven band counts, including 1000.
- Small surrogate margins test forward rational identities and transfer routines only. They are explicitly NOT certified alternative Hughes margins.
- Twelve altered application records, thirty negative-slack controls and five invalid API inputs were rejected. Seven deliberately oversized expansion requests were refused by the resource cap.

The inherited quantitative suite and the earlier compactness/obstruction suite were also rerun. Logs and original parent archives are retained. The original degree-six Komorebi circuit certificate is not in these compact parent archives and was not rerun here.

## What the verifier does not do

`verify_application` checks a fixed arithmetic and schema instantiation. It does not establish the external theorems' truth, automatically verify the entire mathematical reduction, or solve the 65,610,000 skeleton models. Its result is not labeled a formal UNSAT certificate.

The finite model tests are useful controls on the implementation. The all-topology conclusion follows from the written uniform proof and cited theorems, not from extrapolating the tests.

## Practical limitations

The exponent E=2^803 has 242 decimal digits. Expanding even the margin denominator requires more than 10^241 binary digits. The software intentionally stores exact compressed rationals c*2^(-e). It does not supply ordinary floating-point/SPICE-ready component values or expanded target coefficient arrays for these particular parameters.

The stored family netlists prove no minimum resistor count. A forward construction has 4k inductors, 3k capacitors and 2k+1 resistors after strictification. The reactive minimum is a theorem dependency, not a result of a new inverse solver run.

## Failures or unfinished attempts

No assertion in the new numerical/model suite failed in the recorded run. The page-five Hughes screenshot retrieval failed as described in SOURCES.md. The more practical global margin optimization, an independent low-level refutation certificate, and formal proof checking were not executed, rather than attempted and incorrectly relabeled successful.

## Priority and publication

No novelty audit was performed for effective RLC separation or these concrete parameter choices. Effective semialgebraic lower bounds and the Hughes base classification are prior art. All material remains unpublished, with no public site or GitHub edits.
