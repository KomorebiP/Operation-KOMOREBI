# Effective Hughes separation and explicit multiscale RLC families

**Author: Komorebi P.**  
**Date:** 12 November 2026  
**Status:** Unpublished, self-reviewed mathematical derivation. Uses two explicit published theorem dependencies. Exact finite implementation checks supplement the proof. No independent mathematical review, Lean verification, or historical-priority claim.

## 0. What is established and what is not

The previous quantitative-transfer checkpoint required an unspecified positive rational separation margin for

\[
H(s)=\frac{6s^2+3s+4}{6s^2+2s+9}
\]

against all ordinary positive, uncoupled, transformer-free RLC networks with at most four reactive elements and arbitrarily many resistors. This note derives the explicit bound

\[
\boxed{\Delta_H=2^{-2^{803}}.}
\]

It is a valid lower bound, not the optimum distance and not a practical tolerance. The proof combines the previously derived compact network representation with the effective polynomial-minimum theorem of Jeronimo, Perrucci and Tsigaridas (JPT), and Hughes's exact four-reactive exclusion. It does not perform a new enumeration of all circuit topologies.

Set E=2^803 and, for each integer k>=1, define

\[
\Delta=2^{-E},\quad
\delta=\frac{1}{9\,2^{2E+11}},\quad
\epsilon_k=\frac{1}{81(7k-1)^2\,2^{6E+33}},\quad
\rho=2^{-(E+4)}.
\]

Define B_delta and T_k as in Section 9. The retained quantitative-transfer proof then gives explicit rational-function expression families with

\[
\deg T_k=4k,\quad q_{\min}(T_k)=7k,
\]

and the same degree and minimum for rho+T_k. These are finitely specified exact rational functions. Their fully expanded coefficients and component denominators have not been materialized. The software retains their exact short arithmetic descriptions.

The remaining certificate gap is important: the application record checks finite arithmetic, model construction and constants. It does not reprove either published theorem or replay the new universal reduction in a formal proof kernel. No compact all-topology interval-cover or sum-of-squares certificate has been generated. There is no numerical optimization of the true margin, no useful engineering bound, and no arbitrary-target minimum synthesis algorithm.

## 1. Scope, target and exact source obstruction

An allowed circuit is a finite one-port containing positive finite ordinary resistors, inductors and capacitors, with no transformers, mutual inductances, controlled sources or negative components. Arbitrarily many resistors are allowed. Opens and shorts are allowed only as intermediate compact descriptions and are physically deleted or contracted before counting surviving reactive branches.

For a reduced real rational impedance Z=P/Q, degree means max(deg P,deg Q). Write

\[
\gamma_Z(s)=\frac{Z(s)-1}{Z(s)+1}.
\]

Every sample in this note is a positive REAL Laplace argument, not an imaginary-axis frequency.

Use the seven distinct rational arguments

\[
S=\{1/2,3/4,1,5/4,3/2,7/4,2\}.
\]

The reduced gamma values of H are, in this order,

\[
-9/37,\ -17/94,\ -2/15,\ -15/152,\ -7/95,\ -1/18,\ -3/71.
\]

In particular the largest reduced denominator is 152. The s=7/4 value reduces further than the raw ratio -13/234.

### Published exact obstruction

Hughes, *Why RLC realizations of certain impedances need many more energy storage elements than expected*, IEEE TAC 62(9), 4333--4346 (2017), arXiv:1611.06258v2, Theorems 4--6, classifies the relevant biquadratic minimum functions without a restriction on resistor count.

Our target has K=omega_0=F=1 and W=2/3 in that paper's Lemma 3. Its real dissipation numerator is 36(omega^2-1)^2, its denominator is Hurwitz, and H(i)=i. The degree-two polynomials are coprime.

The two three-reactive exceptions require W=1/2 or W=2, so neither applies. Of the four-reactive exceptions, two require 1<W<2 and therefore cannot apply. The other two require F^2=4/3 or F^2=4/27. Neither equals 1. The published classification therefore excludes EVERY realization with at most four reactive elements. This is a dependency, not a new proof of Hughes's classification.

A retained five-reactive positive circuit is replayed separately at ten positive rational samples. Its branch count and the rational identity degree bound show that it realizes H exactly. Thus q_min(H)=5. The lower-bound proof below needs only the published exclusion, not a numerical fitter.

## 2. Compress an unrestricted resistor network to bounded size

Fix a reactive budget q. Retain the port terminals and all endpoints of the reactive edges. There are at most

\[
N=2q+2
\]

retained vertices. Eliminate all other vertices using only the resistor conductance Laplacian. Each eliminated connected resistor component that touches retained vertices has a nonsingular grounded Dirichlet block. Its inverse is nonnegative, and its Schur complement is again a conductance Laplacian. A component touching no retained vertex is irrelevant and is discarded.

This reduction is frequency independent. No reactive branch is eliminated, created or made free. The resulting resistor network is represented by at most one nonnegative conductance on every retained pair. Zero conductance means absence. Pad unused vertices and absent branches as necessary.

Write

\[
R=\binom N2,\qquad A=R+q.
\]

A master skeleton has R resistor slots plus q reactive slots. Each reactive slot selects one pair of vertices and one of the two types L,C. Repeated positions are allowed and cover parallel reactive branches. There are (2R)^q labeled choices, not a claim of distinct unlabeled topologies.

For q=4:

\[
N=10,\quad R=45,\quad A=49,\quad (2R)^q=90^4=65,610,000.
\]

All ensuing bounds are uniform in the choice of skeleton. The proof does not require executing this many searches.

## 3. Compact sample equations, including all boundaries

For each branch let kappa denote g, C or 1/L, according to its type. Introduce

\[
t=\frac{\kappa}{1+\kappa}\in[0,1].
\]

At a positive rational sample s, put phi_R=1, phi_C=s, phi_L=1/s. Write phi=a/b in lowest terms. The integer-coefficient branch equation is

\[
b(1-t)i-a\,t(v_u-v_v)=0. \tag{1}
\]

When t=0 this imposes i=0. When t=1 it imposes v_u=v_v. Hence the compact boundaries are physical opens and wires.

Normalize the driving source by V+I=1, with ground voltage zero. Then

\[
V=Z/(1+Z),\quad I=1/(1+Z),\quad \gamma=2V-1.
\]

At real s>0 all finite admittances are positive. The maximum principle gives 0<=v_j<=1. To bound an edge current, cut the network at any voltage level strictly between its endpoint voltages. Every current across that cut has the same sign. KCL shows their total is at most the supplied current I<=1. Thus every oriented branch current lies in [-1,1]. Missing padded vertices can have zero potential and current.

Every compact solution of (1) and KCL has physical boundary semantics. Contract all t=1 edges and delete all t=0 edges. Summing KCL over a contracted component cancels internal wire currents. The remaining equations are ordinary positive finite RLC equations. The port is either short, open, or a genuine finite positive one-port, with no more than q surviving reactive edges. Therefore the compact system does not introduce a transformer or any additional boundary realization technology.

These arguments are the retained compactness lemmas, restated here because the effective-bound application depends on the boundary cases.

## 4. Remove current variables by exact KCL, not by approximation

Use ground 0 and port 1. Among the complete resistor slots choose the star (j,0), j=1,...,N-1, with orientation toward ground. This is a spanning tree of the POTENTIAL graph even if some of its compact parameters later become zero.

At one sample, retain N-1 voltage variables and only the A-(N-1) chord-current variables. For each non-ground vertex j, KCL uniquely recovers its star current:

\[
i_{j0}=\mathbf1_{j=1}(1-v_1)-\sum_{e\text{ chord}} b_{je}i_e. \tag{2}
\]

Here b is the oriented incidence matrix. Substitute (2) into the star branch equations and impose both bounds -1<=i_{j0}<=1 as linear inequalities. This transformation is exactly equivalent to the original KCL formulation. It is valid at t=0 and t=1. It removes variables, not physical reactive elements.

There are now exactly A sample variables: N-1 voltages plus A-N+1 independent chord currents.

Introduce one further variable z in [0,2], bounding the maximum target error. If the target gamma at a sample is c/d, d>0, append

\[
dz-\bigl(d(2v_1-1)-c\bigr)\ge0,\qquad
dz+\bigl(d(2v_1-1)-c\bigr)\ge0. \tag{3}
\]

No denominator in these equations depends on a circuit parameter.

## 5. Exact counts and coefficient-height bound

Let r=|S|. The reduced formulation has

\[
\nu=(r+1)A+1
\]

variables, rA branch equalities, 2nu direct box inequalities, 2r(N-1) eliminated-current inequalities, and 2r target-error inequalities. Thus the total number of defining polynomials is

\[
m=rA+2\nu+2rN. \tag{4}
\]

All are integer polynomials of degree at most two. The star-current formula has coefficients in {-1,0,1}. Its substitution into a resistor branch equation preserves the degree bound. Chord branch equations have coefficients bounded by max(a,b). Repeated reactive slots have separate current variables, so their incidence coefficients do not add in one monomial.

For any sample target c/d in [-1,1], the coefficients in (3) have absolute value at most 2d. For the present samples, a,b<=7 and max d=152. Consequently a uniform height bound for every defining polynomial and the objective z is

\[
H_* = 304.
\]

For the Hughes application:

\[
\boxed{\nu=393,\quad m=1269,\quad d=2,\quad H_*=304.}
\]

The individual totals are 343 equalities and 926 inequalities. The latter comprise 786 direct bounds, 126 recovered-current bounds and 14 error inequalities. Every skeleton has exactly these declared counts, possibly with some redundant constraints.

For comparison, keeping all branch currents and KCL equations gives nu=456 and m=1332. That unreduced route supplies an independent, weaker bound in Section 8. Redundant equations may be omitted without weakening the conservative totals used in the estimate.

## 6. Why the objective minimum is strictly positive

For a fixed master skeleton, let T be the set satisfying its equalities and inequalities. It is a closed subset of a bounded box, so it is compact. Empty sets require no analysis. Every connected component C of a nonempty T is also compact.

The variable z is nonnegative. If some point of T had z=0, (3) would enforce exact agreement with H at all seven samples. The boundary reduction in Section 3 would give a genuine ordinary circuit with at most four reactive elements, or a port open/short. The latter two cannot match these finite interior gamma values.

An ordinary circuit with at most q reactive branches has rational degree at most q. One proof uses its weighted spanning-tree and terminal-separating two-forest polynomials: after multiplying numerator and denominator by s to the number of inductors, every monomial has degree between zero and q. Cancellation only reduces degree.

The difference between a degree-at-most-four rational function and H has cross-multiplied numerator degree at most six. Seven distinct positive sample agreements force rational identity. Such a circuit would realize H with at most four reactive elements, contradicting Hughes's theorem.

Therefore z is strictly positive on T. Its minimum on every nonempty compact component C is nonzero. The effective theorem below applies component by component. There is no regular-root, isolated-solution, interior-parameter or genericity assumption.

## 7. Published effective-minimum theorem and its application

The external quantitative input is Theorem 1 of Gabriela Jeronimo, Daniel Perrucci and Elias Tsigaridas, *On the Minimum of a Polynomial Function on a Basic Closed Semialgebraic Set and Applications*, SIAM Journal on Optimization 23(1), 241--255 (2013), DOI 10.1137/110857751.

In the notation needed here, a basic closed semialgebraic set in nu>=2 variables is defined by m integer polynomials of degree bounded by an even d and coefficients bounded by H_*. On a compact connected component, the nonzero minimum of an integer polynomial objective with the same degree/height bounds has absolute value at least

\[
\left(2^{4-\nu/2}\,\widetilde H\,d^{\nu}\right)^{-\nu 2^{\nu}d^{\nu}},
\qquad \widetilde H=\max\{H_*,2\nu+2m\}. \tag{5}
\]

The factor is **Htilde times d^nu**, NOT Htilde^d times nu. The PDF typography was checked visually against both an author-hosted copy and the arXiv version. No sum-of-squares degree increase is needed: z is linear and the feasibility constraints are quadratic.

In our reduced model,

\[
\widetilde H=\max(304,786+2538)=3324<2^{12}.
\]

For d=2, the base in (5) equals

\[
2^{4-393/2}\,3324\,2^{393}
=3324\,2^{200.5}<2^{213}.
\]

Its exponent magnitude is

\[
393\,2^{393}2^{393}=393\,2^{786}.
\]

It follows that every feasible error bound z satisfies

\[
z\ge 2^{-K},\qquad K=213\cdot393\cdot2^{786}=83709\,2^{786}.
\]

Since 83709<2^17, K<2^803. In particular,

\[
\boxed{
\max_{s\in S}|\gamma_N(s)-\gamma_H(s)|\ge2^{-2^{803}}
}
\tag{6}
\]

for every ordinary transformer-free network N with at most four reactive elements. To see that the objective z may be chosen equal to the actual maximum error, take its physical bounded sample witnesses and set z to that maximum. It lies in [0,2], so it is feasible.

Every skeleton uses the same degree, height and count bounds. Applying (5) to all of them introduces NO multiplicative penalty for the number of skeletons. The result is uniform, rather than a union-bound estimate or a claimed enumeration.

The denominator of (6) has more than 10^241 binary digits. Only the exact exponent recipe is stored. This limitation affects practicality, not mathematical positivity or rationality.

## 8. A redundant uneliminated derivation and a general compiler theorem

Without eliminating the nine star currents at each sample, there are nu=456 variables, 406 branch/KCL equalities, 912 box inequalities and 14 error inequalities, totaling m=1332. Then Htilde=3576<2^12 and the base in (5) is less than 2^244. Thus

\[
z\ge2^{-244\cdot456\cdot2^{912}}>2^{-2^{929}}.
\]

This weaker estimate is retained to cross-check the counting route independently of star elimination. The stronger estimate uses the exact equivalence of the two systems.

### General effective conversion

Let a rational target Z of degree n be known, by a separate exact proof, not to have an allowed realization with at most q reactive elements. Choose r>=n+q+1 distinct positive rational samples where Z is finite and positive. Let their compact responses be c_i/d_i in lowest terms. Set

\[
N=2q+2,\quad A=\binom N2+q,\quad
\nu=(r+1)A+1,\quad m=rA+2\nu+2rN.
\]

Take H_* to be at least 2, all sample numerators and denominators, and all 2d_i. Put

\[
\widetilde H=\max(H_*,2\nu+2m),\quad
b=4+\lceil\nu/2\rceil+\lceil\log_2\widetilde H\rceil.
\]

The same argument yields the explicit sample margin

\[
\boxed{\Delta(Z,q,S)=2^{-b\nu 4^{\nu}}.} \tag{7}
\]

This converts an exact nonrealizability theorem into a conservative robust one. It is NOT an algorithm that establishes the required nonrealizability premise for arbitrary input. The software's general count function reports the arithmetic but makes no unsupported physical-exclusion conclusion.

## 9. Close the numerical premise in the retained transfer theorem

The preceding quantitative-transfer note proves a topology-independent Lipschitz inequality at positive real s:

\[
|\gamma_{\mathcal N}(s)-\gamma_{\widetilde{\mathcal N}}(s)|
\le2\sum_e|u_e(s)-\widetilde u_e(s)|,
\quad u_e=y_e/(1+y_e).
\]

It also proves that, after threshold-rounding at scale-separated arguments, one physical reactive edge can remain active in at most one packet. These results are retained with their proofs, not inferred from the new finite tests.

The localized target is

\[
B_\delta(s)=\left[H(s)^{-1}+\delta(s+s^{-1})\right]^{-1}
=\frac{6s^3+3s^2+4s}
{6\delta s^4+(6+3\delta)s^3+(2+10\delta)s^2+(9+3\delta)s+4\delta}.
\]

Its three scale profiles are 4s/(9s+4), H(s) and 1/(1+s). Their reactive minima are 1,5,1. The first and last have exact sample margins 8/105 and 3/20 against zero-reactive circuits.

Our explicit Delta=2^(-E), E=2^803, is smaller than both outer margins. Set

\[
\eta_0=\Delta/96,\qquad
\delta=\Delta^2/18432=\eta_0^2/2.
\]

The three-packet rounding bound is Delta/4, and the target approximation error is at most 18delta=Delta^2/1024<Delta/4. The separation condition is strict because delta=eta_0^2/2<(eta_0/(1-eta_0))^2. Therefore

\[
q_{\min}(B_\delta)=7,
\]

and the sampled gamma vector of B_delta has margin at least Delta/2 against every at-most-six-reactive circuit on

\[
S_B=\delta S\cup S\cup\delta^{-1}S.
\]

The matching upper bound is the five-reactive Hughes circuit with the two specified positive shunt elements.

For each k>=1 set Q=7k-1, M_B=2/delta and

\[
\eta_1=\frac{\Delta\delta}{32Q},\qquad
\epsilon_k=\frac{\Delta^2\delta^2}{2048Q^2}=\eta_1^2/2.
\]

Define

\[
T_k(s)=\sum_{j=0}^{k-1}B_\delta(s/\epsilon_k^j).
\]

The outer rounding error is Delta/8. The leakage error is at most

\[
\frac{4M_B\epsilon_k}{\delta(1-\epsilon_k)}
<\frac{\Delta^2}{128Q^2}<\Delta/8.
\]

Thus the retained allocation theorem gives q_min(T_k)=7k and a robust sample margin at least Delta/4 from all at-most-(7k-1)-reactive competitors. Its samples are the union of epsilon_k^j S_B. These conclusions no longer require supplying an unspecified numerical margin.

### Degree check

B_delta has reduced degree four, for every delta>0. A common root of its numerator and denominator would have to be a common root of the original H numerator and denominator, or zero. Neither is possible. Its poles lie in the explicit annulus

\[
a=\frac{4\delta}{9+7\delta},\qquad
b=\frac{3(1+\delta)}{2\delta}.
\]

For delta<1/2, a/b>= (32/225)delta^2, while epsilon_k/delta^2<1/2048. The scaled pole sets are disjoint. At a pole of one summand, all others are analytic, so the pole cannot cancel. Consequently

\[
\boxed{\deg T_k=4k,\qquad q_{\min}(T_k)=7k.}
\]

The permitted epsilon depends explicitly on k. No claim of one common epsilon for every k is made.

## 10. An explicit strictly dissipative family

Let rho=Delta/16 and define

\[
\widehat T_k(s)=\rho+T_k(s).
\]

At positive real sample arguments,

\[
|\gamma_{\widehat T_k}(s)-\gamma_{T_k}(s)|\le2\rho=\Delta/8.
\]

The previous Delta/4 exclusion therefore leaves a margin at least Delta/8 against every at-most-(7k-1)-reactive circuit. Adding a positive resistor introduces no new reactive element, so

\[
\boxed{\deg\widehat T_k=4k,\quad q_{\min}(\widehat T_k)=7k.}
\]

The degree is unchanged because adding rho Q to a reduced numerator does not change its gcd with Q, and Q retains its degree 4k.

The constructed targets obey Re \widehat T_k(i omega)>=rho>0. There are no imaginary-axis poles in B_delta: H has none and its admittance has positive real part away from omega=+/-1; at those two frequencies the added lossless shunt cancels and H remains finite and nonzero. At zero B_delta is zero, not a pole. Thus the statement holds at all real frequencies. Both endpoint impedances of \widehat T_k equal rho.

One construction has 4k inductors, 3k capacitors and 2k+1 resistors. This count is not a proof of minimum resistor or total element count.

## 11. Machine records, tests and remaining boundary

`results/THEOREM_APPLICATION.json` binds the exact target, seven samples, source dependencies, model counts, coefficient bound and integer exponent arithmetic. `src/effective_margin.py` rejects alterations to that instantiated record. Its scope is deliberately named ARITHMETIC_AND_SCHEMA_PASS, not a formal all-topology UNSAT proof.

`src/master_model.py` generates the actual integer quadratic equations and inequalities for a selected skeleton. The tests compare reconstructed star currents and branch equations to a separate exact nodal evaluator. All 90 choices for one reactive slot are inspected while the other three are fixed. That local inventory is NOT the full 90^4 topology family. The proof of the uniform bounds is analytical.

The five-reactive positive witness is a critical negative control on the argument's scope: the q=5 master system admits zero error. No claim of a positive margin at that budget is made.

`src/binary_rational.py` handles c*2^(-e) exactly and checks exponent identities at the actual gigantic exponent. It refuses infeasible expanded output under an explicit bit cap. The generated netlists are exact compressed rational descriptions, not floating-point component estimates.

Outstanding work is a larger and practically meaningful base margin, a compact independently replayable refutation certificate or formalization of the proof dependencies, independent mathematical review, and arbitrary-target minimum synthesis. The separate original degree-six target's established q_min=6 is preserved and is not contradicted by these different targets. That original certificate was not newly rerun in this supplement.
