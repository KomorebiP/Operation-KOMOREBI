"""Authenticate package files and optionally replay finite tests.
Author: Komorebi P. This does not constitute formal mathematical verification.
"""
import argparse,hashlib,json,os,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--tests',action='store_true');a=p.parse_args()
    manifest=json.loads((ROOT/'MANIFEST.json').read_text())
    listed={item['path']:item['sha256'] for item in manifest['files']}
    actual={f.relative_to(ROOT).as_posix() for f in ROOT.rglob('*') if f.is_file()
            and '__pycache__' not in f.parts and f.name!='MANIFEST.json'}
    if actual!=set(listed):raise ValueError('manifest file set mismatch')
    for name,expected in listed.items():
        digest=hashlib.sha256((ROOT/name).read_bytes()).hexdigest()
        if digest!=expected:raise ValueError('hash mismatch: '+name)
    sys.path.insert(0,str(ROOT/'src'))
    from effective_margin import verify_application
    result=verify_application(json.loads((ROOT/'results/THEOREM_APPLICATION.json').read_text()))
    print(json.dumps({'package_hashes':'PASS','files':len(listed),'application_check':result},indent=2))
    if a.tests:
        env=os.environ.copy();env['KOMOREBI_CHECK_ONLY']='1';env['PYTHONDONTWRITEBYTECODE']='1'
        subprocess.run([sys.executable,'-B','-S',str(ROOT/'tests/run_checks.py')],env=env,check=True,cwd=ROOT)
        for name,expected in listed.items():
            if hashlib.sha256((ROOT/name).read_bytes()).hexdigest()!=expected:
                raise ValueError('test modified a manifested file: '+name)
        print('POST_TEST_FILE_HASHES_PASS')

if __name__=='__main__':main()
