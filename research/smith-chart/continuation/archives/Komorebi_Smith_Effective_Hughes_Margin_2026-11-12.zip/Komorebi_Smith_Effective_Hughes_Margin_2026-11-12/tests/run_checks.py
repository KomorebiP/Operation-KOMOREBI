"""Reproducible finite regression checks. Author: Komorebi P.

These checks do not replace the published theorems or the written universal
proof. No all-topology enumeration or formal theorem-prover run is claimed.
"""
import sys,json,random,copy,time,os
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from effective_margin import (hughes_application,verify_application,model_bounds,
                              SAMPLES,hughes_gamma,evaluate,H_P,H_Q)
from binary_rational import BinaryRational as B,recipe
from master_model import MasterModel,orient_pair
from family_recipe import build_family,HUGHES_EDGES
from compact_rlc import Edge,sample
from rational_functions import (reduce_rational,degree,dissipation,localize,
                                rational_value,series,argument_scale)
from quantitative_transfer import packet_conditions,localized_tail_bound

counts={}
def ok(label):counts[label]=counts.get(label,0)+1
rng=random.Random(202611120803)
t0=time.monotonic()
a=hughes_application();verify_application(a)
assert a['model_reduced']['variables']==393
assert a['model_reduced']['constraints']==1269
assert a['model_reduced']['equalities']==343
assert a['model_reduced']['inequalities']==926
assert a['model_reduced']['coefficient_height_bound']==304
assert a['model_reduced']['htilde']==3324
assert a['model_reduced']['base_log2_ceiling']==213
assert a['model_unreduced']['variables']==456
assert a['model_unreduced']['constraints']==1332
assert a['model_unreduced']['htilde']==3576
assert a['model_unreduced']['base_log2_ceiling']==244
assert int(a['model_reduced']['dyadic_exponent_bound'])==83709*2**786
assert int(a['model_reduced']['dyadic_exponent_bound'])<2**803
assert int(a['model_unreduced']['dyadic_exponent_bound'])<2**929
ok('fixed_bound_arithmetic')
assert a['gamma_samples']==['-9/37','-17/94','-2/15','-15/152','-7/95','-1/18','-3/71']
assert a['exception_squared_values']=={'case_c':'4/3','case_f':'4/27','F_squared':'1'}
assert degree(reduce_rational(H_P,H_Q))==2
assert dissipation(H_P,H_Q)==[36,-72,36]
ok('Hughes_parameter_arithmetic')

# Exhaust all 90 locations/types for ONE variable reactive slot. This does not
# enumerate the 90^4 full skeleton family. The other three slots stay fixed.
choices=[(kind,u,v) for kind in ('L','C') for u,v in combinations(range(10),2)]
model_summaries=[]
for choice in choices:
    m=MasterModel(4,[choice,('L',1,2),('C',2,3),('L',8,9)])
    summary=m.summary()
    assert summary['variables']==393 and summary['constraints']==1269
    assert summary['degree']==2 and summary['height']==304
    assert summary['equalities']==343 and summary['inequalities']==926
    model_summaries.append(summary)
    ok('single_slot_90_position_type_model_inventory')

# Exact current elimination and branch-law comparison against a distinct
# grounded nodal evaluator, including ideal open/short assignments.
for q in range(5):
    N=2*q+2;pairs=list(combinations(range(N),2))
    for trial in range(6):
        reactive=[(rng.choice(('L','C')),*rng.choice(pairs)) for _ in range(q)]
        m=MasterModel(q,reactive)
        bounds=model_bounds(q,SAMPLES,[hughes_gamma(s) for s in SAMPLES])
        assert m.summary()['variables']==bounds['variables']
        assert m.summary()['constraints']==bounds['constraints']
        ok('general_budget_model_dimensions')
        params=[F(rng.randrange(1,8),8) for _ in range(m.E)]
        if trial%2:
            params=[rng.choice((F(0),F(1),t)) for t in params]
        x,w=m.witness(params)
        assert m.validate(x) and m.check_elimination(x,w)
        for k,ww in enumerate(w):
            assert all(abs(i)<=1 for i in ww['currents'])
            assert all(0<=v<=1 for v in ww['voltages'])
            assert abs(ww['gamma']-hughes_gamma(SAMPLES[k]))<=x[m.zindex]
            ok('exact_compact_KCL_sample_reconstruction')
        assert B(x[m.zindex],0).compare(B(1,2**803))>0
        ok('tested_network_errors_above_margin_not_global_evidence')
        bad=x.copy();bad[m.zindex]=F(-1)
        try:m.validate(bad)
        except ValueError:ok('negative_slack_rejected')
        else:raise AssertionError('negative slack accepted')

# Actual five-reactive Hughes circuit is feasible with ZERO sample error at
# q=5. This is a control against wrongly extending the q=4 positivity premise.
rslots=[(kind,u,v) for kind,u,v,value in HUGHES_EDGES if kind!='R']
m5=MasterModel(5,rslots)
rmap={frozenset((u,v)):1/value for kind,u,v,value in HUGHES_EDGES if kind=='R'}
rparams=[value if kind=='C' else 1/value for kind,u,v,value in HUGHES_EDGES if kind!='R']
params=[]
react_i=0
for kind,u,v in m5.edges:
    if kind=='R':kap=rmap.get(frozenset((u,v)),F(0))
    else:kap=rparams[react_i];react_i+=1
    params.append(kap/(1+kap))
x,w=m5.witness(params,z=0)
assert m5.validate(x) and m5.check_elimination(x,w)
assert all(ww['gamma']==hughes_gamma(s) for s,ww in zip(SAMPLES,w))
ok('q5_zero_error_positive_control')
physical=[]
for kind,u,v,value in HUGHES_EDGES:
    kap=value if kind=='C' else 1/value
    physical.append(Edge(kind,u,v,kap/(1+kap)))
for s in map(F,('1/10','1/3','1/2','3/4','1','5/4','3/2','2','3','10')):
    assert sample(5,physical,s)['gamma']==hughes_gamma(s)
    ok('five_reactive_upper_witness_exact_samples')

# Ordinary small binary-rational arithmetic checked against Fraction.
for _ in range(500):
    u=B(F(rng.randrange(1,70),rng.randrange(1,70)),rng.randrange(-30,31))
    v=B(F(rng.randrange(1,70),rng.randrange(1,70)),rng.randrange(-30,31))
    uf,vf=u.to_fraction(),v.to_fraction()
    assert u.compare(v)==((uf>vf)-(uf<vf))
    assert (u*v).to_fraction()==uf*vf
    assert (u/v).to_fraction()==uf/vf
    assert (u**-2).to_fraction()==1/(uf*uf)
    ok('binary_rational_independent_fraction_roundtrip')

# The ACTUAL gigantic exponents are manipulated exactly, without expansion.
for k in (1,2,3,4,10,100,1000):
    r=recipe(k);gap,delta,eps=(r[t] for t in ('gap','delta','epsilon'))
    eta0=gap/96
    assert delta==eta0**2/2 and eta0.compare(F(1,2))<0
    assert (24*eta0)==gap/4
    assert (18*delta).compare(gap/4)<0
    Q=7*k-1;M=B(2,0)/delta;eta1=gap*delta/(32*Q)
    assert eps==eta1**2/2 and eps.compare(F(1,2))<0
    assert 2*Q*M*eta1==gap/8
    conservative_leak=8*M*eps/delta
    assert conservative_leak==gap**2/(128*Q*Q)
    assert conservative_leak.compare(gap/8)<0
    assert (eps/delta**2).compare(F(32,225))<0
    assert 2*r['rho']==gap/8
    ok('actual_exponent_transfer_and_strictification')
    try:gap.to_fraction(max_bits=100000)
    except OverflowError:ok('gigantic_expansion_explicitly_refused')
    else:raise AssertionError('astronomical denominator unexpectedly expanded')

# Small surrogate gaps test the closed-form transport and forward identities.
# These surrogate values are NOT asserted to be valid Hughes margins.
for exp in (4,8,12):
    gap=F(1,2**exp);delta=gap*gap/18432
    base=reduce_rational(H_P,H_Q);b=localize(base,delta)
    assert degree(b)==4
    for k in (1,2,3):
        Q=7*k-1;M=2/delta;eta=gap*delta/(32*Q)
        eps=gap*gap*delta*delta/(2048*Q*Q)
        verdict=packet_conditions(Q=Q,M=M,eta=eta,epsilon=eps,margin=gap/2,
                                 target_error=localized_tail_bound(eps,delta,M))
        assert verdict['status']=='CONDITIONAL_INEQUALITIES_PASS'
        assert not verdict['base_margin_verified_here']
        z=([F(0)],[F(1)])
        for j in range(k):z=series(z,argument_scale(b,1/eps**j))
        assert degree(z)==4*k
        for s in (F(1,2),F(1),F(2)):
            assert rational_value(z,s)==sum(rational_value(b,s/eps**j) for j in range(k))
            ok('surrogate_forward_identity_not_lower_bound')
        ok('surrogate_transfer_parameters_not_Hughes_margin')

for k in (1,2,4,10):
    for strict in (False,True):
        nl=build_family(k,strictly_dissipative=strict)
        assert nl['counts']=={'R':2*k+int(strict),'L':4*k,'C':3*k}
        assert nl['vertices']==4*k+1+int(strict)
        assert len(nl['edges'])==9*k+int(strict)
        assert all(e['u']!=e['v'] and 0<=e['u']<nl['vertices'] and 0<=e['v']<nl['vertices'] for e in nl['edges'])
        ok('actual_compressed_netlist_counts_and_connectivity')

# Tampered theorem-application records are rejected. These controls do not
# pretend that external mathematical theorems are replayed by this validator.
mutations=[('model_reduced','variables',392),('model_reduced','constraints',1268),
           ('model_reduced','coefficient_height_bound',300),('model_reduced','base_log2_ceiling',212),
           ('model_reduced','reactive_budget',5),('model_reduced','htilde',3000),
           ('margin','negative_exponent',str(2**800)),
           ('target','reduced_degree',1),('target','P_ascending',[5,3,6])]
for section,key,value in mutations:
    bad=copy.deepcopy(a);bad[section][key]=value
    try:verify_application(bad)
    except ValueError:ok('tampered_application_rejected')
    else:raise AssertionError('tampered record accepted')
for change in ('sources','sample','formal'):
    bad=copy.deepcopy(a)
    if change=='sources':bad['dependencies']=[]
    elif change=='sample':bad['samples'][0]='0'
    else:bad['lean_formalized']=True
    try:verify_application(bad)
    except ValueError:ok('tampered_application_rejected')
    else:raise AssertionError('tampered record accepted')
for fn in (lambda:recipe(0),lambda:recipe(True),lambda:B(F(-1),0),
           lambda:MasterModel(1,[('C',1,1)]),
           lambda:model_bounds(4,[F(1),F(1)],[F(0),F(0)])):
    try:fn()
    except ValueError:ok('invalid_inputs_rejected')
    else:raise AssertionError('invalid input accepted')

report={'schema':'komorebi-effective-margin-checks-v1','status':'PASS',
        'author':'Komorebi P.','seed':202611120803,'counts':counts,
        'total_recorded_check_groups':sum(counts.values()),
        'elapsed_seconds':round(time.monotonic()-t0,3),
        'inventory_scope':'90 placements/types for one slot; 30 test assignments across q=0..4; one exact q=5 zero-error control',
        'all_90_power_4_skeletons_enumerated':False,
        'base_margin_type':'explicit theorem-derived bound using external Hughes and JPT results',
        'independent_mathematical_review':False,'formal_proof_checked':False,
        'expanded_astronomical_rationals':False}
if os.environ.get('KOMOREBI_CHECK_ONLY') != '1':
    (ROOT/'results').mkdir(exist_ok=True)
    (ROOT/'results'/'THEOREM_APPLICATION.json').write_text(json.dumps(a,indent=2)+'\n')
    (ROOT/'results'/'CHECKS.json').write_text(json.dumps(report,indent=2)+'\n')
    (ROOT/'results'/'MODEL_INVENTORY.json').write_text(json.dumps({'count':len(model_summaries),
        'representative':model_summaries[0],'max_height':max(m['height'] for m in model_summaries),
        'all_topologies_enumerated':False},indent=2)+'\n')
    for k in (1,2,4):
        (ROOT/'results'/f'EXPLICIT_STRICT_FAMILY_k{k}.json').write_text(json.dumps(build_family(k),indent=2)+'\n')
print(json.dumps(report,indent=2))
