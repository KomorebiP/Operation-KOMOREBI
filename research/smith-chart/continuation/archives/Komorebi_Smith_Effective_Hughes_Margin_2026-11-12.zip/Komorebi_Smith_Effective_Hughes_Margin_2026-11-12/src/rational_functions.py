"""Small independent exact polynomial/rational-function arithmetic.
Author: Komorebi P. Coefficients are in ascending powers.
"""
from fractions import Fraction as F

def trim(p):
    p=list(map(F,p))
    while len(p)>1 and p[-1]==0: p.pop()
    return p or [F(0)]
def add(p,q): return trim([(p[i] if i<len(p) else 0)+(q[i] if i<len(q) else 0) for i in range(max(len(p),len(q)))])
def scale(p,c): return trim([F(c)*x for x in p])
def mul(p,q):
    out=[F(0)]*(len(p)+len(q)-1)
    for i,a in enumerate(p):
        for j,b in enumerate(q): out[i+j]+=a*b
    return trim(out)
def shift(p): return trim([F(0)]+list(p))
def evaluate(p,s):
    y=F(0)
    for a in reversed(p): y=y*s+a
    return y

def divide(p,q):
    p,q=trim(p),trim(q)
    if q==[0]: raise ZeroDivisionError()
    out=[F(0)]*max(1,len(p)-len(q)+1)
    while p!=[0] and len(p)>=len(q):
        d=len(p)-len(q); c=p[-1]/q[-1]; out[d]=c
        p=add(p,scale([F(0)]*d+q,-c))
    return trim(out),p

def gcd(p,q):
    p,q=trim(p),trim(q)
    while q!=[0]: p,q=q,divide(p,q)[1]
    return scale(p,1/p[-1])

def reduce_rational(P,Q):
    P,Q=trim(P),trim(Q)
    if Q==[0]: raise ZeroDivisionError()
    g=gcd(P,Q); p,r=divide(P,g); q,t=divide(Q,g)
    assert r==t==[0]
    return scale(p,1/q[-1]),scale(q,1/q[-1])

def degree(z): return max(len(z[0]),len(z[1]))-1

def rational_value(z,s): return evaluate(z[0],s)/evaluate(z[1],s)

def series(z,w): return reduce_rational(add(mul(z[0],w[1]),mul(w[0],z[1])),mul(z[1],w[1]))

def argument_scale(z,a):
    return reduce_rational([c*F(a)**i for i,c in enumerate(z[0])],[c*F(a)**i for i,c in enumerate(z[1])])

def endpoint_lift(z,kind,eps):
    P,Q=z; eps=F(eps)
    if eps<=0: raise ValueError('Positive parameter required')
    if kind=='series_L': return reduce_rational(add(P,scale(shift(Q),eps)),Q)
    if kind=='shunt_C': return reduce_rational(P,add(Q,scale(shift(P),eps)))
    if kind=='series_C': return reduce_rational(add(shift(P),scale(Q,eps)),shift(Q))
    if kind=='shunt_L': return reduce_rational(shift(P),add(shift(Q),scale(P,eps)))
    raise ValueError('Unknown operation')

def localize(z,delta):
    P,Q=z; delta=F(delta)
    if delta<=0: raise ValueError('Positive parameter required')
    return reduce_rational(shift(P),add(shift(Q),scale(mul([F(1),F(0),F(1)],P),delta)))

def dissipation(P,Q):
    """Re[P(i*w) Q(-i*w)] as a polynomial in x=w*w."""
    out=[F(0)]*((len(P)+len(Q))//2)
    for i,a in enumerate(P):
        for j,b in enumerate(Q):
            if (i+j)%2==0: out[(i+j)//2]+=a*b*((-1)**((i+j)//2+j))
    return trim(out)
