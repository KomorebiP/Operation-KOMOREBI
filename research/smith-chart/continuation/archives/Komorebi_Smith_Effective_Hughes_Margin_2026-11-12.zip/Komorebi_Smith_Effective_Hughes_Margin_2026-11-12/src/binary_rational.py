"""Exact positive rationals stored as c * 2^(-e), without huge denominators.
Author: Komorebi P. This is exact representation, not floating point.
"""
from dataclasses import dataclass
from fractions import Fraction as F

@dataclass(frozen=True)
class BinaryRational:
    coefficient: F
    exponent: int

    def __post_init__(self):
        c=F(self.coefficient)
        if c <= 0 or type(self.exponent) is not int:
            raise ValueError('positive coefficient and integer exponent required')
        n,d=c.numerator,c.denominator
        vn=(n & -n).bit_length()-1
        vd=(d & -d).bit_length()-1
        object.__setattr__(self,'coefficient',F(n >> vn,d >> vd))
        object.__setattr__(self,'exponent',self.exponent-vn+vd)

    def __mul__(self, other):
        if not isinstance(other,BinaryRational): other=BinaryRational(F(other),0)
        return BinaryRational(self.coefficient*other.coefficient,self.exponent+other.exponent)

    __rmul__=__mul__

    def __truediv__(self, other):
        if not isinstance(other,BinaryRational): other=BinaryRational(F(other),0)
        return BinaryRational(self.coefficient/other.coefficient,self.exponent-other.exponent)

    def __pow__(self, power):
        if type(power) is not int: raise ValueError('integer power required')
        return BinaryRational(self.coefficient**power,self.exponent*power)

    def compare(self, other):
        if not isinstance(other,BinaryRational): other=BinaryRational(F(other),0)
        a=self.coefficient.numerator*other.coefficient.denominator
        b=other.coefficient.numerator*self.coefficient.denominator
        shift=other.exponent-self.exponent
        abits=a.bit_length()+shift
        bbits=b.bit_length()
        if abits != bbits: return 1 if abits>bbits else -1
        # Equal bit lengths imply a shift no larger than already stored inputs.
        if shift >= 0: a <<= shift
        else: b <<= -shift
        return (a>b)-(a<b)

    def to_fraction(self, max_bits=16384):
        if type(max_bits) is not int or max_bits < 1:
            raise ValueError('positive expansion cap required')
        needed=max(self.coefficient.numerator.bit_length()+max(0,-self.exponent),
                   self.coefficient.denominator.bit_length()+max(0,self.exponent))
        if needed>max_bits:
            raise OverflowError('exact expansion exceeds declared bit cap; use the compact representation')
        if self.exponent>=0:
            return F(self.coefficient.numerator,self.coefficient.denominator << self.exponent)
        return F(self.coefficient.numerator << -self.exponent,self.coefficient.denominator)

    def to_dict(self):
        return {'coefficient':str(self.coefficient),'negative_binary_exponent':str(self.exponent),
                'semantics':'coefficient * 2^(-negative_binary_exponent)'}


def recipe(k):
    if type(k) is not int or k<1: raise ValueError('positive integer band count required')
    E=1 << 803
    gap=BinaryRational(F(1),E)
    delta=BinaryRational(F(1,9),2*E+11)
    epsilon=BinaryRational(F(1,81*(7*k-1)**2),6*E+33)
    rho=BinaryRational(F(1),E+4)
    assert delta == gap**2 / 18432
    assert epsilon == gap**2 * delta**2 / (2048*(7*k-1)**2)
    assert rho == gap/16
    assert gap.compare(F(8,105))<0 and gap.compare(F(3,20))<0
    return {'k':k,'degree':4*k,'minimum_reactive_count':7*k,
            'delta':delta,'epsilon':epsilon,'rho':rho,'gap':gap,
            'target_margin':gap/4,'strict_target_margin':gap/8}
