"""Exact sparse quadratic master model with star-current elimination.
Author: Komorebi P.

The graph has 2q+2 vertices, a resistor slot on every pair, and q specified
reactive slots. Zero/one compact parameters encode opens/shorts. This builder
does not search all skeletons or decide their feasibility.
"""
from dataclasses import dataclass
from fractions import Fraction as F
from itertools import combinations
from effective_margin import SAMPLES, hughes_gamma
from compact_rlc import Edge, phi, sample

@dataclass
class Poly:
    terms: dict

    def __post_init__(self):
        clean={}
        for m,c in self.terms.items():
            if type(c) is not int: raise ValueError('integer polynomial coefficients required')
            key=tuple(sorted(m))
            clean[key]=clean.get(key,0)+c
        self.terms={m:c for m,c in clean.items() if c}

    @staticmethod
    def constant(c): return Poly({():c})
    @staticmethod
    def variable(i): return Poly({(i,):1})
    def __add__(self,other):
        if not isinstance(other,Poly): other=Poly.constant(other)
        out=self.terms.copy()
        for m,c in other.terms.items(): out[m]=out.get(m,0)+c
        return Poly(out)
    __radd__=__add__
    def __neg__(self): return Poly({m:-c for m,c in self.terms.items()})
    def __sub__(self,other): return self+-as_poly(other)
    def __rsub__(self,other): return as_poly(other)+-self
    def __mul__(self,other):
        other=as_poly(other);out={}
        for m,c in self.terms.items():
            for n,d in other.terms.items():
                key=tuple(sorted(m+n));out[key]=out.get(key,0)+c*d
        return Poly(out)
    __rmul__=__mul__
    def evaluate(self,x):
        result=F(0)
        for m,c in self.terms.items():
            term=F(c)
            for i in m: term*=x[i]
            result+=term
        return result
    @property
    def degree(self): return max(map(len,self.terms),default=0)
    @property
    def height(self): return max(map(abs,self.terms.values()),default=0)


def as_poly(a): return a if isinstance(a,Poly) else Poly.constant(a)


def orient_pair(u,v):
    if u==v: raise ValueError('no self-loop slot')
    if u==0: return v,0
    if v==0: return u,0
    return min(u,v),max(u,v)


class MasterModel:
    def __init__(self,q,reactive,samples=SAMPLES,target_gammas=None):
        if type(q) is not int or q<0 or len(reactive)!=q:
            raise ValueError('reactive slot count must equal nonnegative budget')
        self.q=q;self.N=2*q+2
        self.samples=tuple(map(F,samples))
        if not self.samples or len(set(self.samples))!=len(self.samples) or any(s<=0 for s in self.samples):
            raise ValueError('distinct positive samples required')
        self.targets=tuple(map(F,target_gammas)) if target_gammas is not None else tuple(hughes_gamma(s) for s in self.samples)
        if len(self.targets)!=len(self.samples) or any(abs(g)>1 for g in self.targets):
            raise ValueError('one compact target response per sample required')
        star=[('R',j,0) for j in range(1,self.N)]
        rest=[('R',u,v) for u,v in combinations(range(1,self.N),2)]
        rr=[]
        for kind,u,v in reactive:
            if kind not in ('L','C') or not (0<=u<self.N and 0<=v<self.N):
                raise ValueError('invalid reactive slot')
            rr.append((kind,*orient_pair(u,v)))
        self.edges=star+rest+rr
        self.E=len(self.edges);self.tree_count=self.N-1
        self.chord_count=self.E-self.tree_count
        self.nvars=self.E*(len(self.samples)+1)+1
        self.zindex=self.nvars-1
        self.equalities=[];self.inequalities=[];self.current_polys=[]
        self.bounds=[(F(0),F(1))]*self.E
        for _ in self.samples:
            self.bounds += [(F(0),F(1))]*(self.N-1)+[(F(-1),F(1))]*self.chord_count
        self.bounds += [(F(0),F(2))]
        for i,(lo,hi) in enumerate(self.bounds):
            x=Poly.variable(i)
            self.inequalities += [x-int(lo),int(hi)-x]
        for k,s in enumerate(self.samples):
            v=[Poly.constant(0)]+[Poly.variable(self.vidx(k,j)) for j in range(1,self.N)]
            chords=[Poly.variable(self.cidx(k,c)) for c in range(self.chord_count)]
            tree=[]
            for j in range(1,self.N):
                inc=Poly.constant(0)
                for c,(_,u,w) in enumerate(self.edges[self.tree_count:]):
                    if u==j: inc+=chords[c]
                    if w==j: inc-=chords[c]
                cur=(1-v[1] if j==1 else Poly.constant(0))-inc
                tree.append(cur)
                self.inequalities += [cur+1,1-cur]
            currents=tree+chords;self.current_polys.append(currents)
            for e,(kind,u,w) in enumerate(self.edges):
                t=Poly.variable(e);p=phi(kind,s)
                self.equalities.append(p.denominator*(1-t)*currents[e]-p.numerator*t*(v[u]-v[w]))
            target=self.targets[k];c,d=target.numerator,target.denominator
            err=d*(2*v[1]-1)-c;z=Poly.variable(self.zindex)
            self.inequalities += [d*z-err,d*z+err]
        assert len(self.bounds)==self.nvars

    def vidx(self,k,j): return self.E+k*self.E+j-1
    def cidx(self,k,c): return self.E+k*self.E+self.N-1+c

    def summary(self):
        polys=self.equalities+self.inequalities
        return {'variables':self.nvars,'equalities':len(self.equalities),
                'inequalities':len(self.inequalities),'constraints':len(polys),
                'degree':max(p.degree for p in polys),
                'height':max(p.height for p in polys),
                'edge_slots':self.E,'vertices':self.N,
                'terms':sum(len(p.terms) for p in polys)}

    def witness(self,parameters,z=None):
        if len(parameters)!=self.E: raise ValueError('one parameter per edge required')
        parameters=tuple(map(F,parameters))
        edges=[Edge(k,u,v,t) for (k,u,v),t in zip(self.edges,parameters)]
        witnesses=[sample(self.N,edges,s) for s in self.samples]
        actual=max(abs(w['gamma']-g) for w,g in zip(witnesses,self.targets))
        if z is None:z=actual
        x=list(parameters)
        for w in witnesses:
            x+=w['voltages'][1:]+w['currents'][self.tree_count:]
        x+=[F(z)]
        return x,witnesses

    def validate(self,x):
        if len(x)!=self.nvars:raise ValueError('assignment dimension mismatch')
        if any(p.evaluate(x)!=0 for p in self.equalities):
            raise ValueError('branch equation failed')
        if any(p.evaluate(x)<0 for p in self.inequalities):
            raise ValueError('bound or error inequality failed')
        return True

    def check_elimination(self,x,witnesses):
        for k,w in enumerate(witnesses):
            for e,p in enumerate(self.current_polys[k]):
                if p.evaluate(x)!=w['currents'][e]:
                    raise ValueError('eliminated tree current does not reconstruct KCL witness')
        return True
