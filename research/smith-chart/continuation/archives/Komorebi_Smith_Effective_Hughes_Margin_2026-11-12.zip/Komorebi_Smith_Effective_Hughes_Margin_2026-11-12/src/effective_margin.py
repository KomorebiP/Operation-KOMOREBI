"""Theorem-application arithmetic, not an SMT/UNSAT or Lean proof checker.
Author: Komorebi P.

The application uses Hughes (2017), Theorems 4--6, and Jeronimo--Perrucci--
Tsigaridas (2013), Theorem 1. Their mathematical truth is an explicit external
dependency. This module checks the instantiated arithmetic and model dimensions.
"""
from fractions import Fraction as F
from math import comb
import json

SAMPLES = tuple(map(F, ('1/2','3/4','1','5/4','3/2','7/4','2')))
H_P = (4, 3, 6)
H_Q = (9, 2, 6)
DEPENDENCIES = [
    {'id': 'HUGHES_2017_T4_T5_T6', 'url': 'https://arxiv.org/pdf/1611.06258v2',
     'role': 'exact all-topology exclusion at reactive budget four; upper bound five'},
    {'id': 'JPT_2013_T1', 'url': 'https://doi.org/10.1137/110857751',
     'author_copy': 'https://mate.dm.uba.ar/~perrucci/On_the_minimum_pol_funct.pdf',
     'role': 'effective nonzero polynomial-minimum bound on compact semialgebraic components'}
]


def evaluate(coefficients, x):
    out = F(0)
    for a in reversed(coefficients):
        out = out*x + a
    return out


def hughes_gamma(s):
    s = F(s)
    if s <= 0:
        raise ValueError('positive real Laplace sample required')
    p, q = evaluate(H_P, s), evaluate(H_Q, s)
    return (p-q)/(p+q)


def ceil_log2_positive(n):
    if type(n) is not int or n < 1:
        raise ValueError('positive integer required')
    return (n-1).bit_length()


def model_bounds(q, samples, target_gammas, *, eliminate_tree=True):
    """Uniform bounds for every labeled master skeleton, not its enumeration.

    Gamma values must be rational and in [-1,1]. An exact nonrealizability
    theorem and enough distinct samples are additional proof obligations.
    """
    if type(q) is not int or q < 0:
        raise ValueError('nonnegative integer budget required')
    samples, target_gammas = tuple(map(F, samples)), tuple(map(F, target_gammas))
    if not samples or len(samples) != len(target_gammas):
        raise ValueError('nonempty equally sized samples and targets required')
    if len(set(samples)) != len(samples) or any(s <= 0 for s in samples):
        raise ValueError('distinct positive samples required')
    if any(abs(g) > 1 for g in target_gammas):
        raise ValueError('target compact responses outside [-1,1]')
    vertices = 2*q+2
    resistors = comb(vertices, 2)
    edges = resistors+q
    sample_count = len(samples)
    if eliminate_tree:
        variables = edges+sample_count*edges+1
        equalities = sample_count*edges
        extra_current_bounds = 2*sample_count*(vertices-1)
    else:
        variables = edges+sample_count*(edges+vertices-1)+1
        equalities = sample_count*(edges+vertices-1)
        extra_current_bounds = 0
    inequalities = 2*variables+extra_current_bounds+2*sample_count
    constraints = equalities+inequalities
    height = max([2] + [max(s.numerator,s.denominator) for s in samples]
                 + [2*g.denominator for g in target_gammas])
    htilde = max(height,2*variables+2*constraints)
    # For even degree d=2, JPT's base is 2^(4+n/2)*Htilde.
    base_log2_ceiling = 4+(variables+1)//2+ceil_log2_positive(htilde)
    exponent_bound = base_log2_ceiling*variables*(1 << (2*variables))
    return {'reactive_budget':q, 'vertices':vertices, 'resistor_slots':resistors,
            'reactive_slots':q, 'edge_slots':edges, 'sample_count':sample_count,
            'tree_current_elimination':eliminate_tree,
            'variables':variables, 'equalities':equalities,
            'inequalities':inequalities, 'constraints':constraints,
            'polynomial_degree_bound':2, 'coefficient_height_bound':height,
            'htilde':htilde, 'base_log2_ceiling':base_log2_ceiling,
            'dyadic_exponent_bound':str(exponent_bound),
            'labeled_skeleton_count':str((2*resistors)**q)}


def hughes_application():
    gammas = tuple(hughes_gamma(s) for s in SAMPLES)
    reduced = model_bounds(4,SAMPLES,gammas)
    full = model_bounds(4,SAMPLES,gammas,eliminate_tree=False)
    W, F0 = F(2,3), F(1)
    c = W*W*(2*W-1)/(1-W)**2
    f = W*W*(1-W)**2/(2*W-1)
    # (a),(b) fail by W != 1/2,2. (d),(e) have wrong W interval.
    assert W not in (F(1,2),F(2)) and F0*F0 not in (c,f)
    exponent = 1 << 803
    assert int(reduced['dyadic_exponent_bound']) < exponent
    assert int(full['dyadic_exponent_bound']) < (1 << 929)
    return {
        'schema':'komorebi-effective-hughes-margin-v1',
        'author':'Komorebi P.',
        'status':'PAPER_DEPENDENT_THEOREM_APPLICATION',
        'target':{'P_ascending':list(H_P),'Q_ascending':list(H_Q),'reduced_degree':2},
        'samples':[str(x) for x in SAMPLES],
        'gamma_samples':[str(x) for x in gammas],
        'identity_samples_required':7,
        'hughes_parameters':{'K':'1','omega0':'1','W':'2/3','F':'1'},
        'exception_squared_values':{'case_c':str(c),'case_f':str(f),'F_squared':'1'},
        'model_reduced':reduced, 'model_unreduced':full,
        'margin':{'value':'2^(-2^803)', 'base':2, 'negative_exponent':str(exponent),
                  'exponent_bit_length':exponent.bit_length()},
        'dependencies':DEPENDENCIES,
        'independent_mathematical_review':False,
        'lean_formalized':False,
        'exhaustive_topology_search_executed':False,
        'expanded_margin_denominator_materialized':False,
        'verification_scope':'schema, arithmetic and local/model regression checks; external theorems and written all-topology reduction remain proof dependencies'
    }


def verify_application(record):
    """Reject any alteration of the fixed theorem instantiation.

    This is deliberately NOT advertised as independently proving either cited
    theorem, the physical reduction, or the universal conclusion in a kernel.
    """
    if record != hughes_application():
        raise ValueError('theorem-application record mismatch')
    return {'status':'ARITHMETIC_AND_SCHEMA_PASS',
            'external_mathematical_dependencies':[x['id'] for x in DEPENDENCIES],
            'all_topology_enumeration_performed':False,
            'formal_proof_checked':False}


if __name__ == '__main__':
    print(json.dumps(hughes_application(),indent=2))
