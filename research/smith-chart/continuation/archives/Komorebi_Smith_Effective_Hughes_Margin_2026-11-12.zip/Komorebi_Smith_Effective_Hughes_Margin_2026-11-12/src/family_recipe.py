"""Exact compressed forward netlists at arbitrary band count.
Author: Komorebi P.

These are symbolic rational values, not hardware-ready parameters. No gigantic
rational numerator/denominator expansion is attempted. Their minima rely on the
written effective-margin and inherited transfer proofs, not this generator alone.
"""
from fractions import Fraction as F
from binary_rational import BinaryRational as B,recipe
from effective_margin import hughes_application
import json

HUGHES_EDGES=(('L',1,2,F(1)),('R',2,0,F(4,9)),('R',1,3,F(1)),
              ('L',2,4,F(8,31)),('L',3,4,F(169,186)),
              ('C',3,4,F(186,169)),('C',4,0,F(31,8)))


def build_family(k,*,strictly_dissipative=True):
    r=recipe(k)
    if k>10000:raise ValueError('netlist cap: at most 10000 profiles')
    edges=[]
    for j in range(k):
        scale=r['epsilon']**(-j)
        mapping={0:j,1:j+1,2:k+1+3*j,3:k+2+3*j,4:k+3+3*j}
        local=[(kind,u,v,B(value,0)) for kind,u,v,value in HUGHES_EDGES]
        local += [('C',1,0,r['delta']),('L',1,0,r['delta']**-1)]
        for kind,u,v,value in local:
            if kind in ('L','C'):value=value*scale
            edges.append({'kind':kind,'u':mapping[u],'v':mapping[v],
                          'value':value.to_dict(),'profile':j})
    vertices=4*k+1;port=k
    if strictly_dissipative:
        edges.append({'kind':'R','u':vertices,'v':port,'value':r['rho'].to_dict(),
                      'role':'strictly_positive_series_resistance'})
        port=vertices;vertices+=1
    return {'schema':'komorebi-compressed-multiband-netlist-v1','author':'Komorebi P.',
            'status':'EXPLICIT_PAPER_DEPENDENT_FAMILY',
            'ground':0,'port':port,'vertices':vertices,'edges':edges,
            'degree':4*k,'minimum_reactive_count':7*k,
            'counts':{kind:sum(e['kind']==kind for e in edges) for kind in 'RLC'},
            'profile':'[H(s)^(-1)+delta*(s+1/s)]^(-1)',
            'target':'rho + sum(j=0..k-1, B_delta(s/epsilon^j))' if strictly_dissipative
                     else 'sum(j=0..k-1, B_delta(s/epsilon^j))',
            'parameters':{key:r[key].to_dict() for key in ('gap','delta','epsilon','rho')},
            'error_margin':r['strict_target_margin' if strictly_dissipative else 'target_margin'].to_dict(),
            'paper_dependencies':[d['id'] for d in hughes_application()['dependencies']],
            'expanded_coefficient_or_decimal_netlist':False,
            'formal_proof_checked':False}


if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('bands',type=int)
    p.add_argument('--without-series-resistor',action='store_true')
    a=p.parse_args()
    print(json.dumps(build_family(a.bands,strictly_dissipative=not a.without_series_resistor),indent=2))
