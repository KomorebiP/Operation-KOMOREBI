# Smith RLC: an explicit Hughes separation margin

Author: Komorebi P.  
Date: 12 November 2026  
Status: Unpublished, self-reviewed theorem application and exact research software.

## Result

For H(s)=(6s²+3s+4)/(6s²+2s+9), at the seven positive real samples
S={1/2,3/4,1,5/4,3/2,7/4,2}, every allowed circuit with at most four reactive elements differs from H in gamma=(Z-1)/(Z+1) by at least

    Delta_H = 2^(-2^803).

This explicit bound follows from Hughes's exact exclusion, the compact RLC graph reduction, and the published Jeronimo--Perrucci--Tsigaridas polynomial-minimum theorem. It is not a measured optimum, a practical engineering tolerance, or an independently kernel-checked refutation.

Writing E=2^803, the previously conditional multiscale construction now has explicit parameters:

    delta     = 1 / (9 * 2^(2E+11))
    epsilon_k = 1 / (81*(7k-1)^2 * 2^(6E+33))
    rho       = 2^(-E-4).

With B_delta(s)=[H(s)^(-1)+delta(s+1/s)]^(-1), both

    T_k(s) = sum(j=0..k-1, B_delta(s/epsilon_k^j))
    rho + T_k(s)

have degree 4k and minimum reactive count 7k. The second family is strictly dissipative, with real part at least rho on the imaginary axis. All numbers are exact rational expressions, but their gigantic expanded denominators are not materialized.

## Read first

- `docs/THEOREMS.md`: the full proof, uniform counts, published theorem application, explicit transfer, and scope.
- `docs/AUDIT_NOTES.md`: what was inspected, tested, not tested, and what remains.
- `docs/SOURCES.md`: exact external dependencies and source locations.
- `CONTINUITY_HANDOFF.md`: restart instructions and traps to avoid.

## Run

Python 3 with only the standard library:

```bash
python -B -S verify_package.py --tests
python -B -S src/effective_margin.py
python -B -S src/family_recipe.py 2 > two_band_compressed_netlist.json
```

The first command checks all manifested file hashes and runs the finite tests without overwriting release evidence. The second prints the fixed theorem-application record. The third generates a strictly dissipative degree-eight / fourteen-reactive netlist with exact compressed rational values.

`tests/run_checks.py` normally writes a fresh report. Set `KOMOREBI_CHECK_ONLY=1` to leave release evidence untouched. The verifier does this automatically.

## Evidence

The new suite records 978 finite check groups. It inventories all 90 location/type choices for one reactive slot with three other slots fixed, checks exact current elimination and compact nodal equations, includes a q=5 zero-error Hughes control, verifies exact compressed parameter arithmetic, and rejects deliberate corruptions. It does NOT enumerate all 90^4 full skeletons.

The inherited quantitative suite was freshly rerun (7,792 recorded checks). The inherited compactness/obstruction suite was also rerun. The unchanged parent ZIPs are retained in `history/`.

## Boundary

The explicit numerical-premise gap is closed at the level of the written theorem application. Independent mathematical review, formal replay of the published dependencies and new reduction, a compact low-level all-topology negative certificate, useful tolerances, and arbitrary-target minimum synthesis remain outstanding.

No GitHub or website changes were made. The earlier, separate degree-six target's q_min=6 result is unchanged and was not newly replayed in this supplement. No historical novelty claim is made.
