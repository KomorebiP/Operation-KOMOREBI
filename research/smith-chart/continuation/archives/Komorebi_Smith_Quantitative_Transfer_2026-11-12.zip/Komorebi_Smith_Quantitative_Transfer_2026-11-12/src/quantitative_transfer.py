"""Positive-real-Laplace residual bounds. Author: Komorebi P.

Rational inputs only. These routines verify arithmetic consequences of a
SUPPLIED base separation margin. They do not certify that margin against
all circuit topologies. See docs/THEOREMS.md for hypotheses and proofs.
"""
from fractions import Fraction as F
from compact_rlc import Edge, phi


def compact_at_sample(edge: Edge, s: F) -> F:
    """y/(1+y) at a positive real sample, including open/short endpoints."""
    s = F(s)
    if s <= 0:
        raise ValueError('sample must be positive')
    t, p = edge.t, phi(edge.kind, s)
    return p*t / (1-t+p*t)


def scale_edges(edges, scale: F):
    """Network N(scale*s), keeping graph and types, scaling coefficients."""
    scale = F(scale)
    if scale <= 0:
        raise ValueError('scale must be positive')
    return [Edge(e.kind, e.u, e.v, compact_at_sample(e, scale)) for e in edges]


def rounding(edges, eta: F):
    """Delete/contract only reactive edges outside the active compact window.

    Active edges have eta < t < 1-eta. Resistors remain unchanged.
    This operation is a physical graph reduction, not a spectral projection.
    """
    eta = F(eta)
    if not 0 < eta < F(1, 2):
        raise ValueError('eta must lie strictly between 0 and 1/2')
    result, active = [], 0
    for e in edges:
        t = e.t
        if e.kind != 'R':
            if t <= eta:
                t = F(0)
            elif t >= 1-eta:
                t = F(1)
            else:
                active += 1
        result.append(Edge(e.kind, e.u, e.v, t))
    return result, active


def pointwise_lipschitz_bound(edges, changed, s: F) -> F:
    if len(edges) != len(changed):
        raise ValueError('same skeleton required')
    if any((a.kind,a.u,a.v)!=(b.kind,b.u,b.v) for a,b in zip(edges,changed)):
        raise ValueError('same labeled skeleton required')
    return 2*sum((abs(compact_at_sample(a,s)-compact_at_sample(b,s))
                  for a,b in zip(edges,changed)), F(0))


def packet_conditions(*, Q: int, M: F, eta: F, epsilon: F,
                      margin: F, target_error: F):
    """Conditional finite-scale exclusion inequalities, not a base proof.

    margin must already lower-bound the sup-norm distance of each profile
    from all circuits below its assigned reactive budget, at the same samples.
    """
    M,eta,epsilon,margin,target_error=map(F,(M,eta,epsilon,margin,target_error))
    if not isinstance(Q,int) or Q < 1 or M < 1 or not 0<eta<F(1,2):
        raise ValueError('invalid budget, sample envelope or rounding window')
    if not 0<epsilon<1 or not 0<margin<=2 or target_error<0:
        raise ValueError('invalid separation, supplied margin or target error')
    sharp_rounding = 2*Q*M*eta/(1+(M-1)*eta)
    simple_rounding = 2*Q*M*eta
    allocation = epsilon < (eta/(1-eta))**2
    residual = target_error + sharp_rounding < margin
    return {
        'status': 'CONDITIONAL_INEQUALITIES_PASS' if allocation and residual else 'NOT_ESTABLISHED',
        'base_margin_verified_here': False,
        'distinct_band_allocation': allocation,
        'residual_below_margin': residual,
        'rounding_bound': str(sharp_rounding),
        'simple_rounding_bound': str(simple_rounding),
        'target_error_bound': str(target_error),
        'supplied_base_margin': str(margin),
    }


def localization_threshold_from_hughes_margin(margin: F, M: F):
    """Conditional threshold for the localized Hughes profile.

    Requires a proven distance margin for H from ALL <=4 reactive networks
    at seven distinct positive samples in [1/M,M]. Not supplied by this code.
    """
    margin,M=F(margin),F(M)
    if not 0<margin<=2 or M<1:
        raise ValueError('invalid margin or sample envelope')
    alpha=margin/(146*M)
    return {'alpha':str(alpha),'delta_max':str(alpha/4),
            'base_margin_verified_here':False,
            'dependency':'seven-sample all-topology <=4-reactive separation for Hughes H'}


def localized_tail_bound(epsilon:F, delta:F, M:F) -> F:
    epsilon,delta,M=map(F,(epsilon,delta,M))
    if not 0<epsilon<1 or delta<=0 or M<1:
        raise ValueError('invalid tail parameters')
    return 4*M*epsilon/(delta*(1-epsilon))


def three_scale_parameters(hughes_margin: F):
    """Derive explicit localization and a <=6-reactive exclusion margin.

    CONTRACT: hughes_margin is already independently certified against ALL
    <=4-reactive networks at S=(1/2,3/4,1,5/4,3/2,7/4,2). This function
    DOES NOT establish that premise. The low/high profile margins are
    elementary exact constant-response gaps, proved in the note.
    """
    dh = F(hughes_margin)
    if not 0 < dh <= 2:
        raise ValueError('supplied margin must lie in (0,2]')
    M, Q = F(2), 6
    gap = min(dh,F(8,105),F(3,20))
    eta=gap/(8*Q*M)
    delta=min(eta**2/2,gap/(36*M),1/M)
    error=9*M*delta
    inequalities=packet_conditions(Q=Q,M=M,eta=eta,epsilon=delta,
                                   margin=gap,target_error=error)
    assert inequalities['status']=='CONDITIONAL_INEQUALITIES_PASS'
    assert error+2*Q*M*eta <= gap/2
    return {'status':'CONDITIONAL_ON_SUPPLIED_HUGHES_MARGIN',
            'hughes_margin_verified_here':False,'common_margin':str(gap),
            'eta':str(eta),'delta':str(delta),
            'localized_margin_lower_bound':str(gap/2),
            'localized_sample_envelope':str(M/delta),
            'inequalities':inequalities}


def multiband_parameters(hughes_margin: F, k: int):
    """A rational parameter recipe conditional on the SAME base margin.

    Generates both a quantitative reactive-count separation and a conservative
    pole-separation bound. This is not an all-topology certificate generator.
    """
    if not isinstance(k,int) or k<1:
        raise ValueError('positive integer number of bands required')
    base=three_scale_parameters(hughes_margin)
    d=F(base['delta']);gap=F(base['localized_margin_lower_bound'])
    M=F(base['localized_sample_envelope']);Q=7*k-1
    eta=gap/(8*Q*M)
    # Denominator of B_delta in increasing powers of s.
    coeff=[4*d,9+3*d,2+10*d,6+3*d,6*d]
    pole_upper=1+max(abs(c/coeff[-1]) for c in coeff[:-1])
    pole_lower=1/(1+max(abs(c/coeff[0]) for c in coeff[1:]))
    eps=min(eta**2/2,d*gap/(16*M+d*gap),pole_lower/(2*pole_upper))
    error=localized_tail_bound(eps,d,M)
    verdict=packet_conditions(Q=Q,M=M,eta=eta,epsilon=eps,
                             margin=gap,target_error=error)
    assert verdict['status']=='CONDITIONAL_INEQUALITIES_PASS'
    assert error+2*Q*M*eta<=gap/2
    return {'status':'CONDITIONAL_ON_SUPPLIED_HUGHES_MARGIN',
            'hughes_margin_verified_here':False,'k':k,'delta':str(d),'epsilon':str(eps),
            'degree_conditional':4*k,'reactive_minimum_conditional':7*k,
            'pole_annulus':{'lower':str(pole_lower),'upper':str(pole_upper)},
            'localized_margin_lower_bound':str(gap),
            'final_margin_lower_bound':str(gap/2),
            'inequalities':verdict}
