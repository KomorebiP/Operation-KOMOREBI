"""Exact compact RLC sample semantics. Author: Komorebi P.

A branch parameter t in [0,1] stands for kappa=t/(1-t).
R: admittance kappa; C: kappa*s; L: kappa/s (kappa=1/L).
t=0 deletes a branch. t=1 shorts it. All calculations use Fraction.
This is a sample evaluator, not a general minimum-synthesis implementation.
"""
from dataclasses import dataclass
from fractions import Fraction as F
from itertools import combinations, product

@dataclass(frozen=True)
class Edge:
    kind: str
    u: int
    v: int
    t: F
    def __post_init__(self):
        if self.kind not in ('R', 'L', 'C') or self.u == self.v:
            raise ValueError('Invalid edge')
        if not isinstance(self.t, F) or not 0 <= self.t <= 1:
            raise ValueError('t must be a Fraction in [0,1]')

class DSU:
    def __init__(self, n): self.p = list(range(n))
    def find(self, a):
        while self.p[a] != a:
            self.p[a] = self.p[self.p[a]]; a = self.p[a]
        return a
    def union(self, a, b):
        a, b = self.find(a), self.find(b)
        if a != b: self.p[b] = a

def phi(kind, s):
    s = F(s)
    if s <= 0: raise ValueError('Positive real Laplace argument required')
    return {'R': F(1), 'C': s, 'L': 1/s}[kind]

def solve_linear(A, b):
    n = len(b)
    M = [[F(x) for x in A[i]] + [F(b[i])] for i in range(n)]
    for j in range(n):
        pivot = next((i for i in range(j, n) if M[i][j]), None)
        if pivot is None: raise ValueError('Singular linear system')
        M[j], M[pivot] = M[pivot], M[j]
        d = M[j][j]; M[j] = [x/d for x in M[j]]
        for i in range(n):
            if i != j and M[i][j]:
                c = M[i][j]; M[i] = [x-c*y for x,y in zip(M[i],M[j])]
    return [M[i][-1] for i in range(n)]

def sample(n, edges, s):
    """Unit source through unit resistance: V_port+I_port=1.

    Ground is node 0, port is node 1. Returns bounded node potentials and
    oriented currents, including a bounded choice of ideal-short currents.
    """
    if n < 2 or any(not 0 <= e.u < n or not 0 <= e.v < n for e in edges):
        raise ValueError('Invalid nodes')
    s = F(s); phi('R',s)
    ds = DSU(n)
    for e in edges:
        if e.t == 1: ds.union(e.u, e.v)
    roots = [ds.find(v) for v in range(n)]
    ground, port = roots[0], roots[1]
    finite = []
    adj = {r:set() for r in roots}
    for j,e in enumerate(edges):
        if 0 < e.t < 1 and roots[e.u] != roots[e.v]:
            a,b = roots[e.u],roots[e.v]
            y = e.t/(1-e.t)*phi(e.kind,s)
            finite.append((j,a,b,y)); adj[a].add(b); adj[b].add(a)
    if port == ground:
        potentials = {r:F(0) for r in roots}; Ip=F(1)
    else:
        active=set([ground,port]); todo=list(active)
        while todo:
            for w in adj[todo.pop()]:
                if w not in active: active.add(w); todo.append(w)
        unknown=sorted(active-{ground}); ix={v:i for i,v in enumerate(unknown)}
        A=[[F(0) for _ in unknown] for _ in unknown]; bvec=[F(0) for _ in unknown]
        for _,a,b,y in finite:
            if a not in active: continue
            for u,v in ((a,b),(b,a)):
                if u != ground:
                    A[ix[u]][ix[u]] += y
                    if v != ground: A[ix[u]][ix[v]] -= y
        A[ix[port]][ix[port]]+=1; bvec[ix[port]]=1
        vals=solve_linear(A,bvec)
        potentials={r:F(0) for r in roots}
        potentials.update({u:vals[ix[u]] for u in unknown})
        Ip=1-potentials[port]
    V=[potentials[r] for r in roots]
    currents=[F(0) for _ in edges]
    for j,a,b,y in finite: currents[j]=y*(potentials[a]-potentials[b])
    # Remaining KCL imbalances are carried on a spanning forest of short edges.
    residual=[F(0) for _ in range(n)]; residual[1]+=Ip; residual[0]-=Ip
    shortadj=[[] for _ in range(n)]
    for j,e in enumerate(edges):
        residual[e.u]-=currents[j]; residual[e.v]+=currents[j]
        if e.t == 1:
            shortadj[e.u].append((e.v,j)); shortadj[e.v].append((e.u,j))
    seen=set()
    for root in range(n):
        if root in seen: continue
        seen.add(root); order=[root]; parent={root:None}
        for u in order:
            for v,j in shortadj[u]:
                if v not in seen:
                    seen.add(v); parent[v]=(u,j); order.append(v)
        for v in reversed(order[1:]):
            u,j=parent[v]
            # Current from child to parent equals the child's residual demand.
            e=edges[j]; currents[j]=residual[v] if e.u==v else -residual[v]
            residual[u]+=residual[v]; residual[v]=0
        if residual[root]: raise ArithmeticError('Unbalanced contracted component')
    result={'voltages':V,'currents':currents,'V':V[1],'I':Ip,'gamma':2*V[1]-1}
    verify_sample(n,edges,s,result)
    return result

def verify_sample(n,edges,s,witness):
    V=witness['voltages']; currents=witness['currents']; Ip=witness['I']
    if len(V)!=n or len(currents)!=len(edges): raise ValueError('Dimension mismatch')
    if V[0]!=0 or V[1]+Ip!=1 or not 0<=Ip<=1: raise ValueError('Bad port normalization')
    if any(not 0<=v<=1 for v in V) or any(abs(i)>1 for i in currents):
        raise ValueError('Unbounded witness')
    balance=[F(0) for _ in range(n)]
    for e,i in zip(edges,currents):
        if (1-e.t)*i != e.t*phi(e.kind,s)*(V[e.u]-V[e.v]):
            raise ValueError('Branch equation failed')
        balance[e.u]+=i; balance[e.v]-=i
    expected=[F(0) for _ in range(n)]; expected[1]=Ip; expected[0]=-Ip
    if balance!=expected: raise ValueError('KCL failed')
    if witness['V']!=V[1] or witness['gamma']!=2*V[1]-1:
        raise ValueError('Port output failed')
    return True

def skeletons(q):
    """Lazy exhaustive labeled skeleton cover; extremely large for large q.

    Each skeleton has all possible resistor branches and q reactive slots.
    Zero parameters omit branches, so this also covers smaller budgets.
    Repeated reactive locations are intentional. No novelty/canonicality claim.
    """
    if not isinstance(q,int) or q<0: raise ValueError('Nonnegative integer q required')
    n=2*q+2; pairs=list(combinations(range(n),2))
    resistors=[('R',a,b) for a,b in pairs]
    choices=[(k,a,b) for k in ('L','C') for a,b in pairs]
    for reactive in product(choices, repeat=q):
        yield n, resistors+list(reactive)
