# Komorebi Smith: quantitative residual and scale transfer

Author: Komorebi P.  
Date: 12 November 2026  
Publication status: unpublished research supplement. No GitHub or site changes.

Start with `docs/THEOREMS.md`. It contains a sharp uniform circuit-response perturbation bound, a finite-scale reactive allocation theorem, a three-scale decomposition of the localized Hughes profile, and explicit rational parameter recipes conditional on one low-order separation certificate.

The main remaining unknown is a certified numerical seven-sample distance of the Hughes core from ALL circuits with at most four reactive elements. This archive does not claim to compute it. No hypothetical value passed into the arithmetic routines is a proof of that premise.

Run all finite tests using only the standard library:

    python -S tests/run_checks.py

The tests check graph response inequalities with exact Fractions, derivative bounds, zero/infinite component limits, active-scale uniqueness, finite profile errors, and input rejection. An elementary parallel RLC example has an analytically proved margin and supplies a complete finite-scale demonstration. Its reactive minimum already equals its degree. Hypothetical Hughes margins test conditional arithmetic only.

Files:

- `docs/THEOREMS.md`: full arguments, domains, constants and limitations.
- `docs/KOMOREBI_SOURCE_MAP.md`: which retrieved Komorebi results apply and which do not.
- `src/quantitative_transfer.py`: residual bounds and conditional parameter recipes.
- `src/compact_rlc.py`: unchanged evaluator from the preceding checkpoint.
- `tests/run_checks.py`: deterministic exact regression tests.
- `results/CHECKS.json`: executed finite-check record.
- `CONTINUITY_HANDOFF.md`: exact next proof obligation.

Universal mathematical results in this supplement are self-reviewed, not independently reviewed or Lean verified. Passing finite tests is supplementary evidence, not proof by sampling. No historical novelty claim.
