"""Exact finite regression evidence, not universal proofs. Author: Komorebi P."""
import sys, json, random, hashlib
from pathlib import Path
from fractions import Fraction as F
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from compact_rlc import Edge,sample
from quantitative_transfer import (compact_at_sample,scale_edges,rounding,
    pointwise_lipschitz_bound,packet_conditions,localization_threshold_from_hughes_margin,
    localized_tail_bound)

counts={}
def passed(name): counts[name]=counts.get(name,0)+1
rng=random.Random(2026111201)
samples=[F(1,3),F(1,2),F(1),F(3,2),F(2),F(3)]

# Connected positive interiors. Independent direct nodal solves for each pair.
for trial in range(160):
    n=rng.randrange(2,7)
    positions=[(j-1,j) for j in range(1,n)]
    positions += [tuple(rng.sample(range(n),2)) for _ in range(rng.randrange(1,6))]
    edges=[Edge(rng.choice('RLC'),a,b,F(rng.randrange(1,15),16)) for a,b in positions]
    changed=[Edge(e.kind,e.u,e.v,F(rng.randrange(17),16)) for e in edges]
    for s in samples:
        a=sample(n,edges,s); b=sample(n,changed,s)
        bound=pointwise_lipschitz_bound(edges,changed,s)
        assert abs(a['gamma']-b['gamma'])<=bound
        passed('exact_network_pair_lipschitz')
        for e,i in zip(edges,a['currents']):
            drop=abs(a['voltages'][e.u]-a['voltages'][e.v])
            u=compact_at_sample(e,s)
            assert drop+abs(i)<=1
            derivative=2*drop**2/(1-u)**2
            assert derivative<=2
            passed('exact_edge_derivative_and_cut_bound')
    # Rounding near physical deletion/short boundaries.
    eta=F(1,8)
    rounded,active=rounding(edges,eta)
    q=sum(e.kind!='R' for e in edges)
    for s in samples:
        got=abs(sample(n,edges,s)['gamma']-sample(n,rounded,s)['gamma'])
        M=max(s,1/s)
        assert got<=2*q*M*eta/(1+(M-1)*eta)
        passed('reactive_rounding_bound')

# The constant 2 is sharp, including both compact boundary endpoints.
for a in [F(0),F(1,7),F(1,2),F(6,7),F(1)]:
    for b in [F(0),F(1,5),F(4,5),F(1)]:
        ea=[Edge('R',1,0,a)]; eb=[Edge('R',1,0,b)]
        assert abs(sample(2,ea,F(1))['gamma']-sample(2,eb,F(1))['gamma'])==2*abs(a-b)
        passed('sharp_single_edge_constant')

# One-element allocation across arbitrarily many separated scale packets.
eta=F(1,20); eps=F(1,500)
assert eps<(eta/(1-eta))**2
for kind in 'LC':
    for exponent in range(-20,21):
        kappa=F(2)**exponent
        e=[Edge(kind,1,0,kappa/(1+kappa))]
        hits=0
        for j in range(7):
            scaled=scale_edges(e,eps**j)
            _,active=rounding(scaled,eta);hits+=active
        assert hits<=1
        passed('disjoint_scale_activity')

# Finite-scale demo with an ANALYTIC proven margin, not a fabricated Hughes gap.
# F(s)=s/(s^2+s+1), parallel R=L=C=1, q_min=2 by degree.
# gamma(1/2)=gamma(2)=-5/9, gamma(1)=-1/2.
# Every <=1 reactive network has a monotone positive-real response. Its
# distance from this three-sample bump is at least 1/36, attained by the
# constant resistor 17/55. Proof is in docs/THEOREMS.md.
def profile(s):return s/(s*s+s+1)
def gamma(z):return (z-1)/(z+1)
S=[F(1,2),F(1),F(2)]
assert [gamma(profile(s)) for s in S]==[F(-5,9),F(-1,2),F(-5,9)]
assert max(abs(gamma(profile(s))-gamma(F(17,55))) for s in S)==F(1,36)
passed('analytic_one_reactive_margin_arithmetic')
demos=[]
for k in (2,3,4):
    Q=2*k-1;M=F(2);margin=F(1,36)
    eta=margin/(8*Q*M)
    eps=min((eta/(1-eta))**2/2, margin/(32*M+margin))
    targeterr=localized_tail_bound(eps,F(1),M)
    verdict=packet_conditions(Q=Q,M=M,eta=eta,epsilon=eps,margin=margin,target_error=targeterr)
    assert verdict['status']=='CONDITIONAL_INEQUALITIES_PASS'
    max_actual=F(0)
    for j in range(k):
        for s in S:
            actual=abs(gamma(sum((profile(eps**(j-i)*s) for i in range(k)),F(0)))-gamma(profile(s)))
            assert actual<=targeterr
            max_actual=max(max_actual,actual)
            passed('finite_profile_leakage')
    demos.append({'profiles':k,'reactive_minimum_by_transfer':2*k,
                  'eta':str(eta),'epsilon':str(eps),'actual_max_sample_error':str(max_actual),
                  'base_margin':str(margin),'base_margin_proof':'analytic three-sample monotonicity',
                  'arithmetic':verdict,
                  'not_an_excess_storage_example':True})

# Input rejection and deliberate failure controls.
for change in [{'epsilon':F(1,2)}, {'target_error':F(1)}, {'eta':F(1,3)}]:
    p=dict(Q=3,M=F(2),eta=F(1,2000),epsilon=F(1,10**8),margin=F(1,36),target_error=F(1,10000))
    p.update(change)
    assert packet_conditions(**p)['status']=='NOT_ESTABLISHED'
    passed('failed_inequality_controls')
for bad in [0,-1,3]:
    try:localization_threshold_from_hughes_margin(F(bad),F(2))
    except ValueError:passed('invalid_margin_controls')
    else:raise AssertionError('invalid margin accepted')
# Threshold transfer is explicitly conditional. No numerical Hughes gap supplied.
for gap in [F(1,100),F(1,10000),F(1,10**8)]:
    M=F(2);r=localization_threshold_from_hughes_margin(gap,M)
    a=F(r['alpha']);d=F(r['delta_max'])
    assert 72*M*a+4*M*d==gap/2 and not r['base_margin_verified_here']
    passed('conditional_localization_threshold_arithmetic')

# Hypothetical margins test ONLY transfer arithmetic, never establish Hughes gaps.
from quantitative_transfer import three_scale_parameters,multiband_parameters
S7=[F(1,2),F(3,4),F(1),F(5,4),F(3,2),F(7,4),F(2)]
def H(s):return (6*s*s+3*s+4)/(6*s*s+2*s+9)
def B(d,s):return 1/(1/H(s)+d*(s+1/s))
def low(s):return 4*s/(9*s+4)
def high(s):return 1/(1+s)
assert (max(gamma(low(s)) for s in S7)-min(gamma(low(s)) for s in S7))/2==F(8,105)
assert (max(gamma(high(s)) for s in S7)-min(gamma(high(s)) for s in S7))/2==F(3,20)
passed('elementary_boundary_profile_margins')
for assumed_gap in [F(1,100),F(1,10000),F(1,10**8)]:
    data=three_scale_parameters(assumed_gap);d=F(data['delta'])
    for s in S7:
        for scale,limit in [(d,low),(F(1),H),(1/d,high)]:
            assert abs(gamma(B(d,scale*s))-gamma(limit(s)))<=18*d
            passed('three_scale_exact_error_bounds')
    for k in [1,2,3,10,100]:
        recipe=multiband_parameters(assumed_gap,k)
        assert not recipe['hughes_margin_verified_here']
        assert recipe['inequalities']['status']=='CONDITIONAL_INEQUALITIES_PASS'
        passed('conditional_arbitrary_band_parameter_recipes')

# Explicit closed-form recipes in the written theorem (not just min-based code).
for assumed_gap in [F(1,100),F(1,10000),F(1,10**8),F(1)]:
    D=min(assumed_gap,F(8,105),F(3,20));d=D*D/18432
    assert d==F(three_scale_parameters(assumed_gap)['delta'])
    for k in [1,2,3,10,100]:
        Q=7*k-1;M=2/d;gap=D/2;eta=D*d/(32*Q)
        eps=D*D*d*d/(2048*Q*Q)
        v=packet_conditions(Q=Q,M=M,eta=eta,epsilon=eps,margin=gap,
                            target_error=localized_tail_bound(eps,d,M))
        assert v['status']=='CONDITIONAL_INEQUALITIES_PASS'
        assert localized_tail_bound(eps,d,M)+2*Q*M*eta<gap/2
        a=4*d/(9+7*d);b=3*(1+d)/(2*d)
        assert eps<a/b
        passed('closed_form_conditional_parameters')

report={'status':'PASS','author':'Komorebi P.','seed':2026111201,
        'counts':counts,'total_exact_assertion_groups':sum(counts.values()),
        'finite_scale_demos':demos,
        'hughes_base_margin_computed':False,
        'hughes_localized_margin_computed':False,
        'independent_review':False,
        'scope':'Finite implementation checks supplement self-contained written proofs. No all-topology Hughes numerical margin claimed.'}
(ROOT/'results').mkdir(exist_ok=True)
(ROOT/'results'/'CHECKS.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':'PASS','counts':counts,'total':sum(counts.values())},indent=2))
