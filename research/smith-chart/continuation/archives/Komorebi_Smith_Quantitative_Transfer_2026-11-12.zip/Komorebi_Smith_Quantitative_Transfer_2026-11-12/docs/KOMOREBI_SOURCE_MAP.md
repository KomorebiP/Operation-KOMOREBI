# Actual source-to-application map

Author: Komorebi P.  
Date: 12 November 2026

## Retrieved Komorebi source

`Resolution_Theory_Expanded_Journal_Manuscript.tex`, Library backing file `file_00000000f2e081fbbe827a0bd00052b1`, version 1.

Relevant named statements read in the source:

- Weighted block Schur algebra (`thm:weighted_schur_algebra`).
- Local resolved Wiener theorem (`thm:resolved_neumann_inverse`).
- Block diagonal inverse path expansion (`thm:block_inverse_paths`).
- Resolved Newton Kantorovich certificate (`thm:resolved_newton`).
- Complete quantitative fiber adjoints (`thm:quantitative_fiber_adjoints`).
- Countable packet error transport (`thm:countable_error_transport`).

These establish the reusable packet, transfer, retained-residual and local-inverse framework. They do not already assert the RLC graph sensitivity lemma or the finite-scale reactive allocation theorem. Those are derived explicitly in this supplement.

## Immediate mathematical dependency

`Smith_RLC_Obstruction_Propagation_2026-11-12/docs/THEOREMS.md`, from the preceding supplied archive. Its compactness and finite-sample identity arguments give existence of a positive base gap. Its endpoint and scale-limit arguments are the qualitative predecessor. Its lower-bound numerical thresholds were explicitly uncomputed.

The unchanged `compact_rlc.py` evaluator is copied from that archive. The new Fraction tests use it to evaluate actual graph responses, including deletions and contractions. The test generator never assumes that a finite experiment certifies arbitrary topologies.

## Which machinery is actually helpful

Residual retention: replacing a branch by a short/open carries a response error, instead of equating an approximation with the target. This becomes the sharp constant-two compact-admittance lemma.

Scale packets and compatible reconstruction: all bands share the SAME physical component variables. Activity windows enforce the one-element/one-active-band budget. This is not ordinary independent frequency fitting and not a claim that Fourier projectors act on circuit components.

Weighted inverse paths: after a legitimate block decomposition A=D+E with ||D^-1 E||<1, the retained source theorem bounds the inverse and its path truncation. This can certify or sharpen local residuals, but requires actual matrix bounds. It is not an automatic universal lower bound.

Refinement logic: a global exclusion must cover every admissible graph and every parameter cell. Only complete children cover a parent. Unresolved leaves remain unresolved. Dyadic subdivision here is real-interval geometry, not p-adic distance.

Valuations: formal scale exponents can organize which coefficient survives each packet. They do not establish real positivity. No arithmetic local-to-global theorem is used without its hypotheses.

Newton certificates: useful for positive realization witnesses and parameter neighborhoods. A failed Newton search is never a negative certificate.

## External attribution checked

Timothy H. Hughes, *Why RLC realizations of certain impedances need many more energy storage elements than expected*, arXiv:1611.06258. The exact five-reactive Hughes-core classification is inherited from the preceding verified project record, not newly proved here.

Florian Dörfler and Francesco Bullo, *Kron Reduction of Graphs with Applications to Electrical Networks*, arXiv:1102.2950. Resistor Schur reduction and sensitivity theory have established prior art. No novelty claim is made for them.

Only attribution/background was checked externally. The new proofs are written out in `THEOREMS.md`.
