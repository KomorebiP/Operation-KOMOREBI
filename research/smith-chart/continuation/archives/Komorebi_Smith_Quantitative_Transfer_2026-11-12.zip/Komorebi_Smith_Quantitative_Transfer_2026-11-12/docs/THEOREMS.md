# Quantitative scale packets for transformer-free RLC lower bounds

Author: Komorebi P.  
Date: 12 November 2026  
Status: New self-reviewed derivations, with exact finite regression tests. Not independently reviewed, not Lean formalized, and no historical novelty claim.

## 1. Scope and what has changed

The preceding obstruction-propagation note proved qualitative small-parameter statements by compactness. This note supplies a topology-independent perturbation bound and finite-scale allocation rule. It also resolves the localized Hughes profile into three scales. Together these reduce numerical thresholds at arbitrary order to ONE independently certified finite-sample separation margin for the original degree-two Hughes target against all circuits with at most four reactive elements.

That base margin has NOT been computed here. Any routine accepting a numerical value for it treats that value as an external premise. Test values are hypothetical arithmetic inputs, not certified Hughes margins.

All networks are finite positive ordinary uncoupled RLC one-ports, with arbitrary resistor counts and no transformers. The normalized reference resistance is one. All sample arguments are positive REAL Laplace arguments, not imaginary-axis frequencies. Voltages and admittances are dimensionless under this normalization. The response coordinate is gamma(s)=(Z(s)-1)/(Z(s)+1). Opens and shorts have gamma=1 and -1.

## 2. A sharp compact-admittance Lipschitz lemma

At a fixed s>0 write every branch admittance as y_e>0 and u_e=y_e/(1+y_e). For two assignments u,u' on the same labeled graph,

    |gamma(u)-gamma(u')| <= 2 sum_e |u_e-u'_e|.        (2.1)

The inequality includes open/short boundary assignments by deletion/contraction and continuity. The constant two is sharp for a single branch, where gamma=1-2u.

### Proof

Use a unit source through a unit series resistor, so terminal voltage V and current I satisfy V+I=1. At positive real s the entire circuit is a positive conductance network. The maximum principle gives |v_a-v_b|<=V for every edge. Summing KCL across an intermediate voltage-level cut gives |i_e|<=I, since all currents across that cut have the same sign. Thus

    |v_a-v_b|+|i_e| <= 1.

For positive finite conductances, the grounded nodal equations, with the source resistor included, are Mv=b. An edge conductance variation has derivative dM/dy_e=b_e b_e^T. Symmetry gives

    dV/dy_e = -(b_e^T v)^2,
    dgamma/dy_e = -2(v_a-v_b)^2.

Since dy/du=(1-u)^(-2) and i=y(v_a-v_b),

    |dgamma/du_e|
      = 2(|v_a-v_b|/(1-u_e))^2
      = 2(|v_a-v_b|+|i_e|)^2 <= 2.

Integrate one coordinate at a time and use the triangle inequality. Floating irrelevant components may be discarded. Boundary values follow by the physical open/short limit, or the preceding note's compact boundary semantics. No inverse-matrix condition number enters the bound. QED.

The proof is a circuit-specific error-transfer result. It is not asserted to be a previously named Komorebi theorem or a historically new sensitivity identity.

## 3. Reactive rounding with an explicit residual

Parameterize each element at local argument s=1 by t=kappa/(1+kappa), where kappa=g,C,1/L for R,C,L. Fix 0<eta<1/2. Keep resistors unchanged. Delete reactive edges with t<=eta and contract reactive edges with t>=1-eta. The remaining reactive edges are called active.

At samples s in [1/M,M], M>=1, either deletion or contraction changes that edge's compact sample admittance by at most

    d_eta(M) = M eta / (1+(M-1)eta) <= M eta.

For deletion, y(s)<=M eta/(1-eta), and compactifying yields the stated bound. The short case is its reciprocal. Therefore any circuit with at most Q reactive elements differs from its rounded circuit by at most

    2Q d_eta(M) <= 2QM eta                              (3.1)

in gamma at every declared sample. Rounding may disconnect or short the port. Those cases remain legitimate compact response points and do not evade the estimate.

## 4. One physical element cannot be active in two separated scale packets

Observe a fixed physical circuit at scales s_phys=epsilon^j s. A capacitor's local coefficient is C epsilon^j. An inductor's is h epsilon^(-j), h=1/L.

Activity means its local coefficient belongs to the interval

    eta/(1-eta) < kappa_j < (1-eta)/eta.

If

    0<epsilon < [eta/(1-eta)]^2,                       (4.1)

a capacitor or inductor cannot be active at two distinct integer scale indices. Indeed, the ratio of its local coefficients is a nonzero integer power of epsilon, while the ratio of two numbers in the active interval cannot cross the stated endpoint ratio. This argument uses the SAME physical component value in all packets. Independent per-frequency circuit fitting would invalidate it.

The sum of active reactive counts over all rounded packet circuits is consequently at most the original reactive count. Resistors can occur in all packets because they are not counted.

## 5. Finite-scale robust allocation theorem

Let F_j be profile impedances with desired lower budgets r_j. For each profile choose a finite positive sample set S_j contained in [1/M,M]. Suppose a certified number Delta_j>0 satisfies

    max_{s in S_j}|gamma_N(s)-gamma_Fj(s)| >= Delta_j

for EVERY network N with at most r_j-1 reactive elements, including open/short limits. This is a robust all-topology margin, not a minimum over selected templates.

Put Q=sum_j r_j-1. Suppose the target T has packet errors

    E_j=max_{s in S_j}|gamma_T(epsilon^j s)-gamma_Fj(s)|.

If (4.1) holds and

    E_j + 2QM eta < Delta_j  for every j,               (5.1)

then T cannot be realized with at most Q reactive elements.

### Proof

Assume such a circuit exists. Rescale it separately in each packet and perform the rounding of Section 3. The rounded j-th circuit differs from F_j by less than Delta_j. It therefore has at least r_j active reactive elements. But Section 4 says each physical reactive element contributes to at most one active packet. Summing gives Q>=sum_j r_j, a contradiction. QED.

The sharper rounding bound 2Q d_eta(M) may replace 2QM eta. The same proof gives a ROBUST conclusion: if E_j+2QM eta<=Delta_j-beta for all j, every <=Q reactive circuit is at least beta away from T on the union of all scaled sample sets. This supplies reusable lower-budget separation margins, not just pointwise exclusions.

The theorem does not require the competing circuit to resemble the constructed series connection, have a prescribed topology, or have a bounded resistor count.

## 6. Three scale packets inside the localized Hughes profile

Let

    H(s)=(6s^2+3s+4)/(6s^2+2s+9),
    B_delta(s)=[H(s)^(-1)+delta(s+s^(-1))]^(-1).

The previously retained Hughes classification supplies r(H)=5. It is prior art. An independently checked five-reactive positive realization is retained in the predecessor package.

Direct algebra gives three distinct limits:

    B_delta(delta s)  -> F_-(s)=4s/(9s+4),
    B_delta(s)        -> F_0(s)=H(s),
    B_delta(s/delta)  -> F_+(s)=1/(1+s).

The low profile is a parallel inductor L=1 and resistor R=4/9. The high profile is a parallel capacitor C=1 and resistor R=1. Thus their reactive minima are one, and the middle minimum is five. The scale-resolved storage budget is 1+5+1=7. These are asymptotic profiles, not an exact sum decomposition of B_delta.

Use

    S={1/2,3/4,1,5/4,3/2,7/4,2},  M=2.

Every zero-reactive one-port has a constant gamma. For a monotone sampled function, the exact distance from constants is half its range. For the two boundary profiles this gives

    Delta_-=8/105,  Delta_+=3/20.

For H, let Delta_H>0 be any independently certified seven-sample distance lower bound against ALL <=4-reactive networks. Such a positive margin follows from the predecessor compactness theorem and finite-identity argument (degree 2 plus budget 4 plus one = 7 samples). Its numerical value remains uncomputed.

### Uniform rational error bounds

For all s in [1/M,M], M>=1, and 0<delta<=1/M,

    |gamma_Bdelta(delta s)-gamma_F-(s)| <= 9M delta,
    |gamma_Bdelta(s)-gamma_H(s)|        <= 4M delta,
    |gamma_Bdelta(s/delta)-gamma_F+(s)| <= 4M delta.

To check them, use gamma=(1-Y)/(1+Y), whose derivative magnitude in positive admittance Y is at most two. With P(z)=6z^2+3z+4 and Q(z)=6z^2+2z+9,

    Q(z)/P(z)-9/4 = -(30z^2+19z)/(4P(z)),
    Q(z)/P(z)-1   = (5-z)/P(z).

For z=delta s, P>=4, and the low packet also contains delta^2 s. Its gamma error is at most

    (30M^2 delta^2+19M delta)/8 + 2M delta^2
      <= (65/8)M delta < 9M delta.

For z=s/delta, P>=6z^2, and the high packet also contains delta^2/s. Its error is at most

    M delta/3 + (5M^2/3+2M)delta^2 <= 4M delta.

The middle estimate follows from the added admittance delta(s+1/s). QED.

### A fully explicit CONDITIONAL parameter transfer

Define

    Delta=min(Delta_H,8/105,3/20),
    eta_0=Delta/96,
    delta=Delta^2/18432 = eta_0^2/2.                    (6.1)

Here Q=6 and M=2. Since Delta<1, delta<1/2, and the scale-disjointness inequality is strict. The rounding error is at most Delta/4. The profile error is at most 18delta=Delta^2/1024<Delta/4.

Section 5 therefore proves both

    r(B_delta)=7,

and a robust separation margin

    Delta_B >= Delta/2                                 (6.2)

against ALL <=6-reactive networks on

    S_B = delta S union S union delta^(-1) S.

The upper bound seven is the five-reactive Hughes witness plus the stated parallel L,C. All rational values in (6.1) are explicit ONCE a valid rational Delta_H is supplied. No numerical Delta_H is certified in this supplement.

This avoids a separate six-reactive global margin search: the margin for the localized profile is transported from the original four-reactive base obstruction, together with two elementary zero-reactive margins.

## 7. Explicit conditional parameters at every number of bands

Fix delta from (6.1). Then B_delta has the degree-four positive rational expression recorded in the predecessor note and vanishes at both endpoints. Moreover, for every t>0,

    0<B_delta(t)<=min(t,1/t)/delta.

For k>=1 put

    T_k(s)=sum_{j=0}^{k-1}B_delta(s/epsilon^j),
    Q=7k-1,
    M_B=2/delta,
    eta_1=Delta delta/(32Q),
    epsilon=Delta^2 delta^2/(2048Q^2)=eta_1^2/2.        (7.1)

At each outer band, other profiles contribute at most

    2M_B epsilon/[delta(1-epsilon)]

in impedance, by summing two geometric tails. Since |d gamma/dZ|<=2 for positive real Z, the packet gamma error is at most

    E <=4M_B epsilon/[delta(1-epsilon)]
      = Delta^2/[256Q^2(1-epsilon)].

The outer rounding error is at most Delta/8. Since epsilon<1/2 and Delta<1, E<=Delta^2/(128Q^2)<Delta/8. Both errors together are less than Delta/4, while (6.2) supplies a base margin Delta/2. The active-window allocation condition is also strict. Thus

    r(T_k)=7k,

with a robust margin of at least Delta/4 against <=7k-1 reactive networks on the union of the scaled S_B sets. The construction gives the matching upper bound.

### Degree and pole separation

The degree-four denominator of B_delta has increasing coefficients

    [4delta,9+3delta,2+10delta,6+3delta,6delta].

For delta<1/2, all pole moduli lie in the coarse annulus

    a=4delta/(9+7delta),
    b=3(1+delta)/(2delta).

These are elementary coefficient root bounds applied to the polynomial and its reversal. The chosen epsilon in (7.1) obeys epsilon<a/b: after dividing by delta^2, its left side is at most 1/2048 while the right side is at least 32/225. Scaled pole sets are disjoint. At a pole of one summand all other summands are analytic, so no pole can cancel in the series sum. Therefore

    degree(T_k)=4k.

All quantitative conclusions are conditional on the ONE base separation certificate for Delta_H. The transfer proof itself is explicit and self-contained. It is not evidence that a numerical value for Delta_H has been computed.

## 8. Independently elementary demonstration without a Hughes premise

For a small complete demonstration use F(s)=s/(s^2+s+1), realized by R=L=C=1 in parallel. At s=1/2,1,2 its gamma values are -5/9,-1/2,-5/9. Every circuit with at most one reactive element is monotone on the positive real axis: a lone capacitor's admittance increases, a lone inductor's decreases, and port gamma is nonincreasing in each edge admittance. Arbitrary resistor networks do not change this direction.

The distance of that three-sample bump from any monotone sequence is at least 1/36. A constant resistor R=17/55 attains exactly 1/36. Thus this is an exact all-topology one-reactive separation margin.

The test script uses this proven margin to verify finite-scale criteria for 2,3,4 profiles, giving minima 4,6,8. These examples already attain their degree lower bounds. They validate the quantitative mechanism, not a new excess-storage result.

## 9. A secondary endpoint formula

A separate direct endpoint argument gives the conditional sufficient bound delta<=Delta_H/(584M) for r(B_delta)=7 when the original H margin uses seven samples in [1/M,M]. It uses two extra samples at alpha and 1/alpha, alpha=Delta_H/(146M), and the target's exact endpoint zeros.

At those extra samples, delta<=alpha/4 gives B_delta>=1/3 because H>=4/9. A hypothetical <=6-reactive realization must contain an inductive terminal path and a capacitive terminal path. At least one inverse inductance h and one capacitance c are <=18alpha, or those path impedances would force B_delta<1/3. Deleting those two distinct branches changes the core-sample gamma vector by at most 72M alpha. The original H differs from B_delta there by at most 4Mdelta. Their sum is <=Delta_H/2, contradicting the <=4-reactive separation margin.

This endpoint formula can be less conservative for establishing the exact point minimum. Unlike the three-scale argument, it does not by itself supply a robust unrestricted <=6-reactive sample margin. The three-scale route is therefore used for subsequent band composition.

## 10. What remains

The new hard computational obligation is a positive rational Delta_H together with an independently replayable all-topology seven-sample separation proof against <=4 reactive elements. A proof of r(H)=5 alone is not a numerical margin certificate. Fixed-template failure, solver UNKNOWN, or testing a set of graphs cannot supply it.

The earlier compact parameterization and dyadic exclusion format give a finite exhaustive route in principle. Komorebi's weighted block inverse and error-transport methods can accelerate the bounded subproblems, but their norm hypotheses must be checked. General Schur elimination of reactive vertices may produce rational multiports, not ordinary elements; it cannot silently lower the physical storage count.

The written arguments here are self-reviewed. Finite regression checks are not proofs of the universal quantifiers. No historical novelty, independent review, hardware execution, or complete arbitrary-target synthesis claim is made.
